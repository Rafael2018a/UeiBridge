using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using UeiDaq;

namespace SingleAILVDT
{
   /// <summary>
   /// Summary description for Form1.
   /// </summary>
   public class Form1 : System.Windows.Forms.Form
   {
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Label label2;
      private Session mySs = null;
      private AnalogScaledReader reader;
      private double[] scan;
      private Timer AITimer;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.ListView Data;
      private System.Windows.Forms.ColumnHeader Channel;
      private System.Windows.Forms.ColumnHeader Value;
      private System.Windows.Forms.Label DataLabel;
      private System.Windows.Forms.TextBox Minimum;
      private System.Windows.Forms.TextBox Maximum;
      private System.Windows.Forms.Label label7;
      private System.Windows.Forms.Label label8;
      private ComboBox WiringScheme;
      private Label label9;
      private Label label10;
      private TextBox Excitation;
      private CheckBox ExExcit;
      private TextBox ExFreq;
      private Label label11;
      private TextBox Sensitivity;
      private Label label12;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public Form1()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         Go.Enabled = true;
         Stop.Enabled = false;
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose(bool disposing)
      {
         if (disposing)
         {
            if (components != null)
            {
               components.Dispose();
            }
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
         this.Go = new System.Windows.Forms.Button();
         this.Quit = new System.Windows.Forms.Button();
         this.Resource = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.Stop = new System.Windows.Forms.Button();
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.Data = new System.Windows.Forms.ListView();
         this.Channel = new System.Windows.Forms.ColumnHeader();
         this.Value = new System.Windows.Forms.ColumnHeader();
         this.DataLabel = new System.Windows.Forms.Label();
         this.Minimum = new System.Windows.Forms.TextBox();
         this.Maximum = new System.Windows.Forms.TextBox();
         this.label7 = new System.Windows.Forms.Label();
         this.label8 = new System.Windows.Forms.Label();
         this.WiringScheme = new System.Windows.Forms.ComboBox();
         this.label9 = new System.Windows.Forms.Label();
         this.label10 = new System.Windows.Forms.Label();
         this.Excitation = new System.Windows.Forms.TextBox();
         this.ExExcit = new System.Windows.Forms.CheckBox();
         this.ExFreq = new System.Windows.Forms.TextBox();
         this.label11 = new System.Windows.Forms.Label();
         this.Sensitivity = new System.Windows.Forms.TextBox();
         this.label12 = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(440, 16);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(144, 40);
         this.Go.TabIndex = 1;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(440, 112);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(144, 40);
         this.Quit.TabIndex = 2;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(8, 24);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(226, 20);
         this.Resource.TabIndex = 3;
         this.Resource.Text = "simu://Dev0/Ai0:3";
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(4, 8);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(120, 16);
         this.label2.TabIndex = 9;
         this.label2.Text = "Resource name";
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(440, 64);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(144, 40);
         this.Stop.TabIndex = 11;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // ErrorText
         // 
         this.ErrorText.Location = new System.Drawing.Point(8, 299);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(576, 48);
         this.ErrorText.TabIndex = 12;
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(8, 280);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(104, 16);
         this.label1.TabIndex = 13;
         this.label1.Text = "Error Message";
         // 
         // Data
         // 
         this.Data.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Channel,
            this.Value});
         this.Data.GridLines = true;
         this.Data.Location = new System.Drawing.Point(265, 24);
         this.Data.Name = "Data";
         this.Data.Size = new System.Drawing.Size(146, 219);
         this.Data.TabIndex = 22;
         this.Data.UseCompatibleStateImageBehavior = false;
         this.Data.View = System.Windows.Forms.View.Details;
         // 
         // Channel
         // 
         this.Channel.Text = "Channel";
         // 
         // Value
         // 
         this.Value.Text = "Value";
         this.Value.Width = 82;
         // 
         // DataLabel
         // 
         this.DataLabel.AutoSize = true;
         this.DataLabel.Location = new System.Drawing.Point(262, 11);
         this.DataLabel.Name = "DataLabel";
         this.DataLabel.Size = new System.Drawing.Size(77, 13);
         this.DataLabel.TabIndex = 23;
         this.DataLabel.Text = "Gathered Data";
         // 
         // Minimum
         // 
         this.Minimum.Location = new System.Drawing.Point(134, 83);
         this.Minimum.Name = "Minimum";
         this.Minimum.Size = new System.Drawing.Size(100, 20);
         this.Minimum.TabIndex = 24;
         this.Minimum.Text = "-10.0";
         // 
         // Maximum
         // 
         this.Maximum.Location = new System.Drawing.Point(134, 123);
         this.Maximum.Name = "Maximum";
         this.Maximum.Size = new System.Drawing.Size(100, 20);
         this.Maximum.TabIndex = 25;
         this.Maximum.Text = "10.0";
         // 
         // label7
         // 
         this.label7.AutoSize = true;
         this.label7.Location = new System.Drawing.Point(131, 67);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(51, 13);
         this.label7.TabIndex = 26;
         this.label7.Text = "Low Limit";
         // 
         // label8
         // 
         this.label8.AutoSize = true;
         this.label8.Location = new System.Drawing.Point(131, 107);
         this.label8.Name = "label8";
         this.label8.Size = new System.Drawing.Size(53, 13);
         this.label8.TabIndex = 27;
         this.label8.Text = "High Limit";
         // 
         // WiringScheme
         // 
         this.WiringScheme.DisplayMember = "FiveWires";
         this.WiringScheme.Items.AddRange(new object[] {
            UeiDaq.LVDTWiringScheme.FiveWires,
            UeiDaq.LVDTWiringScheme.FourWires});
         this.WiringScheme.Location = new System.Drawing.Point(8, 78);
         this.WiringScheme.Name = "WiringScheme";
         this.WiringScheme.Size = new System.Drawing.Size(113, 21);
         this.WiringScheme.TabIndex = 30;
         this.WiringScheme.Text = "FiveWires";
         this.WiringScheme.ValueMember = "FiveWires";
         // 
         // label9
         // 
         this.label9.AutoSize = true;
         this.label9.Location = new System.Drawing.Point(5, 62);
         this.label9.Name = "label9";
         this.label9.Size = new System.Drawing.Size(79, 13);
         this.label9.TabIndex = 34;
         this.label9.Text = "Wiring Scheme";
         // 
         // label10
         // 
         this.label10.AutoSize = true;
         this.label10.Location = new System.Drawing.Point(4, 106);
         this.label10.Name = "label10";
         this.label10.Size = new System.Drawing.Size(92, 13);
         this.label10.TabIndex = 35;
         this.label10.Text = "Excitation Voltage";
         // 
         // Excitation
         // 
         this.Excitation.Location = new System.Drawing.Point(8, 123);
         this.Excitation.Name = "Excitation";
         this.Excitation.Size = new System.Drawing.Size(100, 20);
         this.Excitation.TabIndex = 37;
         this.Excitation.Text = "10";
         // 
         // ExExcit
         // 
         this.ExExcit.Location = new System.Drawing.Point(7, 209);
         this.ExExcit.Name = "ExExcit";
         this.ExExcit.Size = new System.Drawing.Size(135, 17);
         this.ExExcit.TabIndex = 38;
         this.ExExcit.Text = "Use External Excitation";
         // 
         // ExFreq
         // 
         this.ExFreq.Location = new System.Drawing.Point(6, 173);
         this.ExFreq.Name = "ExFreq";
         this.ExFreq.Size = new System.Drawing.Size(100, 20);
         this.ExFreq.TabIndex = 39;
         this.ExFreq.Text = "600";
         // 
         // label11
         // 
         this.label11.AutoSize = true;
         this.label11.Location = new System.Drawing.Point(3, 157);
         this.label11.Name = "label11";
         this.label11.Size = new System.Drawing.Size(106, 13);
         this.label11.TabIndex = 40;
         this.label11.Text = "Excitation Frequency";
         // 
         // Sensitivity
         // 
         this.Sensitivity.Location = new System.Drawing.Point(9, 257);
         this.Sensitivity.Name = "Sensitivity";
         this.Sensitivity.Size = new System.Drawing.Size(100, 20);
         this.Sensitivity.TabIndex = 41;
         this.Sensitivity.Text = "1";
         // 
         // label12
         // 
         this.label12.AutoSize = true;
         this.label12.Location = new System.Drawing.Point(6, 241);
         this.label12.Name = "label12";
         this.label12.Size = new System.Drawing.Size(93, 13);
         this.label12.TabIndex = 42;
         this.label12.Text = "Sensor Sensitivity ";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(592, 359);
         this.Controls.Add(this.label12);
         this.Controls.Add(this.Sensitivity);
         this.Controls.Add(this.ExFreq);
         this.Controls.Add(this.ExExcit);
         this.Controls.Add(this.Excitation);
         this.Controls.Add(this.WiringScheme);
         this.Controls.Add(this.Maximum);
         this.Controls.Add(this.Minimum);
         this.Controls.Add(this.Data);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.Resource);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Controls.Add(this.label9);
         this.Controls.Add(this.DataLabel);
         this.Controls.Add(this.label7);
         this.Controls.Add(this.label8);
         this.Controls.Add(this.label10);
         this.Controls.Add(this.label11);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.Name = "Form1";
         this.Text = "SingleAI LVDT/RVDT";
         this.ResumeLayout(false);
         this.PerformLayout();

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main()
      {
         Application.Run(new Form1());
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();

         Application.Exit();
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         UeiDaqStart();
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();
      }

      public void Timer_Tick(object sender, EventArgs eArgs)
      {
         if (sender == AITimer)
         {
            double[] scan = reader.ReadSingleScan();

            for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
            {
               Data.Items[i].SubItems[1].Text = scan[i].ToString();
            }
         }
      }

      private void UeiDaqStart()
      {
         ErrorText.Clear();
         Data.Items.Clear();

         try
         {
            mySs = new Session();

            mySs.CreateLVDTChannel(Resource.Text, Double.Parse(Minimum.Text), Double.Parse(Maximum.Text), Double.Parse(Sensitivity.Text), (LVDTWiringScheme)WiringScheme.SelectedItem, Double.Parse(Excitation.Text), Double.Parse(ExFreq.Text), ExExcit.Checked);

            for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
            {
               ListViewItem item = Data.Items.Add(mySs.GetChannel(i).GetIndex().ToString());
               item.SubItems.Add("0.0");
            }

            mySs.ConfigureTimingForSimpleIO();

            // Create a reader object to read data synchronously.
            reader = new AnalogScaledReader(mySs.GetDataStream());

            mySs.Start();

            AITimer = new Timer();
            AITimer.Interval = 100;
            AITimer.Start();
            AITimer.Tick += new EventHandler(Timer_Tick);

            Resource.Enabled = false;
            Go.Enabled = false;
            Stop.Enabled = true;
         }
         catch (UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            mySs.Dispose();
            mySs = null;
         }
      }

      private void UeiDaqStop()
      {
         if (mySs != null)
         {
            AITimer.Stop();

            try
            {
               mySs.Stop();
            }
            catch (UeiDaqException exception)
            {
               ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }

            mySs.Dispose();
            mySs = null;
         }

         Resource.Enabled = true;
         Go.Enabled = true;
         Stop.Enabled = false;
      }
   }
}
