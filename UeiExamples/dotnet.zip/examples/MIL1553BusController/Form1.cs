using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text.RegularExpressions;
using UeiDaq;

namespace MIL1553BCtoRT
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.Button Start;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Label label6;
      private System.Windows.Forms.TextBox RTPort;
      private System.Windows.Forms.GroupBox groupBox3;
      private System.Windows.Forms.Label label10;
      private System.Windows.Forms.Label label11;
      private System.Windows.Forms.TextBox BCPort;
      private TextBox Sa;
      private TextBox Rt;
      private Timer CycleTimer;
      private Timer BMTimer;
      private ComboBox BCCoupling;
      private TextBox BM;
      private ComboBox BCBus;
      private Label label14;
      private ComboBox RTCoupling;
      private Label label16;
      private ComboBox RTBus;
      private Label label15;
      private GroupBox groupBox2;
      private TextBox BCTxData;
      private Label label8;
      private TextBox WC;
      private TextBox RTRxData;
      private GroupBox groupBox4;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.BM = new System.Windows.Forms.TextBox();
         this.label4 = new System.Windows.Forms.Label();
         this.Start = new System.Windows.Forms.Button();
         this.Stop = new System.Windows.Forms.Button();
         this.Resource = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.BCCoupling = new System.Windows.Forms.ComboBox();
         this.Quit = new System.Windows.Forms.Button();
         this.label3 = new System.Windows.Forms.Label();
         this.label6 = new System.Windows.Forms.Label();
         this.Sa = new System.Windows.Forms.TextBox();
         this.label5 = new System.Windows.Forms.Label();
         this.Rt = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.BCPort = new System.Windows.Forms.TextBox();
         this.RTPort = new System.Windows.Forms.TextBox();
         this.groupBox3 = new System.Windows.Forms.GroupBox();
         this.label8 = new System.Windows.Forms.Label();
         this.RTCoupling = new System.Windows.Forms.ComboBox();
         this.label16 = new System.Windows.Forms.Label();
         this.RTBus = new System.Windows.Forms.ComboBox();
         this.label15 = new System.Windows.Forms.Label();
         this.BCBus = new System.Windows.Forms.ComboBox();
         this.label14 = new System.Windows.Forms.Label();
         this.label11 = new System.Windows.Forms.Label();
         this.label10 = new System.Windows.Forms.Label();
         this.WC = new System.Windows.Forms.TextBox();
         this.groupBox2 = new System.Windows.Forms.GroupBox();
         this.BCTxData = new System.Windows.Forms.TextBox();
         this.RTRxData = new System.Windows.Forms.TextBox();
         this.groupBox4 = new System.Windows.Forms.GroupBox();
         this.groupBox1.SuspendLayout();
         this.groupBox3.SuspendLayout();
         this.groupBox2.SuspendLayout();
         this.groupBox4.SuspendLayout();
         this.SuspendLayout();
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.BM);
         this.groupBox1.Location = new System.Drawing.Point(8, 425);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(504, 154);
         this.groupBox1.TabIndex = 22;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Bus monitor";
         // 
         // BM
         // 
         this.BM.Location = new System.Drawing.Point(6, 18);
         this.BM.Multiline = true;
         this.BM.Name = "BM";
         this.BM.ReadOnly = true;
         this.BM.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.BM.Size = new System.Drawing.Size(484, 130);
         this.BM.TabIndex = 0;
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(8, 8);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(488, 44);
         this.label4.TabIndex = 12;
         this.label4.Text = "This example shows how to send frames to a remote terminal from a bus controller." +
             "\r\nPort 0 is configured as a bus controller and port 1 is configured as a remote " +
             "terminal and BM.";
         // 
         // Start
         // 
         this.Start.Location = new System.Drawing.Point(16, 587);
         this.Start.Name = "Start";
         this.Start.Size = new System.Drawing.Size(88, 32);
         this.Start.TabIndex = 20;
         this.Start.Text = "Start";
         this.Start.Click += new System.EventHandler(this.Start_Click);
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(224, 587);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(88, 32);
         this.Stop.TabIndex = 19;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(10, 48);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(176, 20);
         this.Resource.TabIndex = 16;
         this.Resource.Text = "pdna://192.168.100.7/Dev3/";
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(10, 32);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(100, 16);
         this.label1.TabIndex = 13;
         this.label1.Text = "Resource";
         // 
         // BCCoupling
         // 
         this.BCCoupling.Items.AddRange(new object[] {
            "Disconnected",
            "Transformer",
            "LocalStub",
            "Direct"});
         this.BCCoupling.Location = new System.Drawing.Point(344, 32);
         this.BCCoupling.Name = "BCCoupling";
         this.BCCoupling.Size = new System.Drawing.Size(62, 21);
         this.BCCoupling.TabIndex = 15;
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(416, 585);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(88, 32);
         this.Quit.TabIndex = 18;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(8, 54);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(488, 29);
         this.label3.TabIndex = 14;
         this.label3.Text = "Press the \"Start\" button to start the session. MIL-1553 frames received by RT\r\n w" +
             "ill appear in the text box. Press the \"Send\" button to send frames out of BC.";
         // 
         // label6
         // 
         this.label6.Location = new System.Drawing.Point(449, 56);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(27, 16);
         this.label6.TabIndex = 4;
         this.label6.Text = "Sa";
         // 
         // Sa
         // 
         this.Sa.Location = new System.Drawing.Point(452, 73);
         this.Sa.Name = "Sa";
         this.Sa.Size = new System.Drawing.Size(27, 20);
         this.Sa.TabIndex = 3;
         this.Sa.Text = "0x2";
         // 
         // label5
         // 
         this.label5.Location = new System.Drawing.Point(416, 56);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(31, 13);
         this.label5.TabIndex = 2;
         this.label5.Text = "Rt";
         // 
         // Rt
         // 
         this.Rt.Location = new System.Drawing.Point(418, 73);
         this.Rt.Name = "Rt";
         this.Rt.Size = new System.Drawing.Size(31, 20);
         this.Rt.TabIndex = 1;
         this.Rt.Text = "0x1";
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(342, 15);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(100, 16);
         this.label2.TabIndex = 17;
         this.label2.Text = "BC coupling";
         // 
         // BCPort
         // 
         this.BCPort.Location = new System.Drawing.Point(190, 32);
         this.BCPort.Name = "BCPort";
         this.BCPort.Size = new System.Drawing.Size(48, 20);
         this.BCPort.TabIndex = 23;
         this.BCPort.Text = "MILB0";
         // 
         // RTPort
         // 
         this.RTPort.Location = new System.Drawing.Point(190, 72);
         this.RTPort.Name = "RTPort";
         this.RTPort.Size = new System.Drawing.Size(48, 20);
         this.RTPort.TabIndex = 23;
         this.RTPort.Text = "MILB1";
         // 
         // groupBox3
         // 
         this.groupBox3.Controls.Add(this.label8);
         this.groupBox3.Controls.Add(this.RTCoupling);
         this.groupBox3.Controls.Add(this.label16);
         this.groupBox3.Controls.Add(this.RTBus);
         this.groupBox3.Controls.Add(this.label15);
         this.groupBox3.Controls.Add(this.BCBus);
         this.groupBox3.Controls.Add(this.label14);
         this.groupBox3.Controls.Add(this.label11);
         this.groupBox3.Controls.Add(this.label10);
         this.groupBox3.Controls.Add(this.Resource);
         this.groupBox3.Controls.Add(this.label1);
         this.groupBox3.Controls.Add(this.BCPort);
         this.groupBox3.Controls.Add(this.label6);
         this.groupBox3.Controls.Add(this.label5);
         this.groupBox3.Controls.Add(this.RTPort);
         this.groupBox3.Controls.Add(this.Sa);
         this.groupBox3.Controls.Add(this.BCCoupling);
         this.groupBox3.Controls.Add(this.WC);
         this.groupBox3.Controls.Add(this.Rt);
         this.groupBox3.Controls.Add(this.label2);
         this.groupBox3.Location = new System.Drawing.Point(8, 92);
         this.groupBox3.Name = "groupBox3";
         this.groupBox3.Size = new System.Drawing.Size(504, 96);
         this.groupBox3.TabIndex = 24;
         this.groupBox3.TabStop = false;
         this.groupBox3.Text = "Ports Configuration";
         // 
         // label8
         // 
         this.label8.Location = new System.Drawing.Point(416, 15);
         this.label8.Name = "label8";
         this.label8.Size = new System.Drawing.Size(76, 16);
         this.label8.TabIndex = 30;
         this.label8.Text = "Word count";
         // 
         // RTCoupling
         // 
         this.RTCoupling.Items.AddRange(new object[] {
            "Disconnected",
            "Transformer",
            "LocalStub",
            "Direct"});
         this.RTCoupling.Location = new System.Drawing.Point(345, 72);
         this.RTCoupling.Name = "RTCoupling";
         this.RTCoupling.Size = new System.Drawing.Size(61, 21);
         this.RTCoupling.TabIndex = 28;
         // 
         // label16
         // 
         this.label16.Location = new System.Drawing.Point(343, 55);
         this.label16.Name = "label16";
         this.label16.Size = new System.Drawing.Size(66, 17);
         this.label16.TabIndex = 29;
         this.label16.Text = "RT coupling";
         // 
         // RTBus
         // 
         this.RTBus.Items.AddRange(new object[] {
            "Bus A",
            "Bus B",
            "Both"});
         this.RTBus.Location = new System.Drawing.Point(265, 72);
         this.RTBus.Name = "RTBus";
         this.RTBus.Size = new System.Drawing.Size(62, 21);
         this.RTBus.TabIndex = 26;
         // 
         // label15
         // 
         this.label15.Location = new System.Drawing.Point(263, 56);
         this.label15.Name = "label15";
         this.label15.Size = new System.Drawing.Size(92, 15);
         this.label15.TabIndex = 27;
         this.label15.Text = "RT bus";
         // 
         // BCBus
         // 
         this.BCBus.Items.AddRange(new object[] {
            "Bus A",
            "Bus B",
            "Both"});
         this.BCBus.Location = new System.Drawing.Point(265, 32);
         this.BCBus.Name = "BCBus";
         this.BCBus.Size = new System.Drawing.Size(62, 21);
         this.BCBus.TabIndex = 24;
         // 
         // label14
         // 
         this.label14.Location = new System.Drawing.Point(263, 16);
         this.label14.Name = "label14";
         this.label14.Size = new System.Drawing.Size(68, 15);
         this.label14.TabIndex = 25;
         this.label14.Text = "BC bus";
         // 
         // label11
         // 
         this.label11.Location = new System.Drawing.Point(189, 56);
         this.label11.Name = "label11";
         this.label11.Size = new System.Drawing.Size(49, 12);
         this.label11.TabIndex = 1;
         this.label11.Text = "RT port";
         // 
         // label10
         // 
         this.label10.Location = new System.Drawing.Point(189, 16);
         this.label10.Name = "label10";
         this.label10.Size = new System.Drawing.Size(49, 15);
         this.label10.TabIndex = 0;
         this.label10.Text = "BC port";
         // 
         // WC
         // 
         this.WC.Location = new System.Drawing.Point(418, 32);
         this.WC.Name = "WC";
         this.WC.Size = new System.Drawing.Size(31, 20);
         this.WC.TabIndex = 1;
         this.WC.Text = "4";
         // 
         // groupBox2
         // 
         this.groupBox2.Controls.Add(this.BCTxData);
         this.groupBox2.Location = new System.Drawing.Point(8, 194);
         this.groupBox2.Name = "groupBox2";
         this.groupBox2.Size = new System.Drawing.Size(504, 107);
         this.groupBox2.TabIndex = 23;
         this.groupBox2.TabStop = false;
         this.groupBox2.Text = "Bus Controller Transmit area";
         // 
         // BCTxData
         // 
         this.BCTxData.Location = new System.Drawing.Point(6, 18);
         this.BCTxData.Multiline = true;
         this.BCTxData.Name = "BCTxData";
         this.BCTxData.ReadOnly = true;
         this.BCTxData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.BCTxData.Size = new System.Drawing.Size(484, 83);
         this.BCTxData.TabIndex = 0;
         // 
         // RTRxData
         // 
         this.RTRxData.Location = new System.Drawing.Point(6, 18);
         this.RTRxData.Multiline = true;
         this.RTRxData.Name = "RTRxData";
         this.RTRxData.ReadOnly = true;
         this.RTRxData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.RTRxData.Size = new System.Drawing.Size(484, 88);
         this.RTRxData.TabIndex = 0;
         // 
         // groupBox4
         // 
         this.groupBox4.Controls.Add(this.RTRxData);
         this.groupBox4.Location = new System.Drawing.Point(8, 307);
         this.groupBox4.Name = "groupBox4";
         this.groupBox4.Size = new System.Drawing.Size(504, 112);
         this.groupBox4.TabIndex = 24;
         this.groupBox4.TabStop = false;
         this.groupBox4.Text = "Remote Terminal Receive area";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(520, 623);
         this.Controls.Add(this.groupBox4);
         this.Controls.Add(this.groupBox2);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.label4);
         this.Controls.Add(this.Start);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.groupBox3);
         this.Name = "Form1";
         this.Text = "MIL-1553 BC to RT";
         this.Load += new System.EventHandler(this.OnLoad);
         this.groupBox1.ResumeLayout(false);
         this.groupBox1.PerformLayout();
         this.groupBox3.ResumeLayout(false);
         this.groupBox3.PerformLayout();
         this.groupBox2.ResumeLayout(false);
         this.groupBox2.PerformLayout();
         this.groupBox4.ResumeLayout(false);
         this.groupBox4.PerformLayout();
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private Session MIL1553Session;
      private MIL1553Reader bcReader, rtReader;
      private MIL1553Writer bcWriter, rtWriter;
      private int count;
      private ushort startRt, startSa, wordCount;
      MIL1553RTFrame[] inRtFrm;
      MIL1553RTStatusFrame[] rtStatusFrm;
      MIL1553RTFrame[] outRtFrm; 
      MIL1553BCControlFrame[] bcControl;
      MIL1553BCCBDataFrame[][] fdata;
      MIL1553BCCBStatusFrame[][] fstatus;
            
      private void InitUI(bool isRunning)
      {
         if(isRunning)
         {
            Start.Enabled = false;
            Stop.Enabled = true;
            Quit.Enabled = false;
         }
         else
         {
            Start.Enabled = true;
            Stop.Enabled = false;
            Quit.Enabled = true;
         }
      }

      private void OnLoad(object sender, System.EventArgs e)
      {
         BCCoupling.SelectedIndex = 1;
         RTCoupling.SelectedIndex = 1;
         BCBus.SelectedIndex = 0;
         RTBus.SelectedIndex = 0;
         InitUI(false);
      }

      private void Start_Click(object sender, System.EventArgs e)
      {
         try
         {
            startRt = Convert.ToUInt16(Rt.Text, 16);
            startSa = Convert.ToUInt16(Sa.Text, 16);
            wordCount = Convert.ToUInt16(WC.Text);
            UInt16[] data16 = new UInt16[wordCount];

            MIL1553Session = new Session();

            // Create Bus writer port
            MIL1553Port bcPort = MIL1553Session.CreateMIL1553Port(Resource.Text + BCPort.Text, 
                                             (MIL1553PortCoupling)BCCoupling.SelectedIndex, 
                                             MIL1553PortOpMode.BusController);
            bcPort.SetTxBus((MIL1553PortActiveBus)BCBus.SelectedIndex);
            bcPort.SetRxBus((MIL1553PortActiveBus)BCBus.SelectedIndex);
            
            // Create Bus monitor port
            MIL1553Port rtPort = MIL1553Session.CreateMIL1553Port(Resource.Text + RTPort.Text,
                                             (MIL1553PortCoupling)RTCoupling.SelectedIndex,
                                             MIL1553PortOpMode.RemoteTerminal);
            rtPort.SetTxBus((MIL1553PortActiveBus)RTBus.SelectedIndex);
            rtPort.SetRxBus((MIL1553PortActiveBus)RTBus.SelectedIndex);

            MIL1553Session.ConfigureTimingForMessagingIO(1, 0.1);
            MIL1553Session.GetTiming().SetTimeout(10);

            // Start the session
            MIL1553Session.Start();

            // Create a reader for BC and RT ports
            bcReader = new MIL1553Reader(MIL1553Session.GetDataStream(), Int32.Parse(BCPort.Text.Substring(4,1)));
            rtReader = new MIL1553Reader(MIL1553Session.GetDataStream(), Int32.Parse(RTPort.Text.Substring(4,1)));

            // Create a writer for BC and RT ports
            bcWriter = new MIL1553Writer(MIL1553Session.GetDataStream(), Int32.Parse(BCPort.Text.Substring(4,1)));
            rtWriter = new MIL1553Writer(MIL1553Session.GetDataStream(), Int32.Parse(RTPort.Text.Substring(4,1)));

            // Create MIL-1553 frames used to send commands from BC to RT
            // and receive replies from RT to BC
            inRtFrm = new MIL1553RTFrame[] { new MIL1553RTFrame(startRt, startSa, 0, wordCount) };
            outRtFrm = new MIL1553RTFrame[] { new MIL1553RTFrame(startRt, startSa, 0, wordCount) };

            // Set UP RT/SAs we want to operate on RT port
            rtPort.ClearFilterEntries();
            MIL1553FilterEntry rtFilter = new MIL1553FilterEntry();
            rtFilter.Set(MIL1553FilterType.ByRt, startRt, startSa);
            rtFilter.EnableCommands(1, 1, 1);
            rtPort.AddFilterEntry(rtFilter);
            rtPort.EnableFilter(true);

            // Configure bus controller port
            // we will need three types of frames for BC: 
            //  *BCCB Data 
            //  *BCCB Status 
            //  *BCCB Scheduler (one minor and one major)
            MIL1553BCSchedFrame[] major = { new MIL1553BCSchedFrame(MIL1553BCFrameType.Major) };

            MIL1553BCSchedFrame[] minor = { new MIL1553BCSchedFrame(MIL1553BCFrameType.Minor) };

            fdata = new MIL1553BCCBDataFrame[2][];
            fdata[0] = new MIL1553BCCBDataFrame[] { new MIL1553BCCBDataFrame(0, 0, 0) }; // first minor frame entry
            fdata[1] = new MIL1553BCCBDataFrame[] { new MIL1553BCCBDataFrame(0, 1, 0) };

            fstatus = new MIL1553BCCBStatusFrame[2][];
            fstatus[0] = new MIL1553BCCBStatusFrame[] { new MIL1553BCCBStatusFrame(0, 0, 0) }; // first minor frame entry
            fstatus[1] = new MIL1553BCCBStatusFrame[] { new MIL1553BCCBStatusFrame(0, 1, 0) };

            // fill major frame
            major[0].AddMajorEntry(0, MIL1553BCMajorFlags.Enable);
            bcWriter.WriteBCSched(major);

            // fill minor frame - one for send and one for receive
            minor[0].AddMinorEntry(MIL1553BCMinorFlags.Enable);
            minor[0].AddMinorEntry(MIL1553BCMinorFlags.Enable);
            bcWriter.WriteBCSched(minor);

            // fill BCCB for this minor frame
            fdata[0][0].SetCommand(MIL1553CommandType.BCRT, startRt, startSa, wordCount);
            fdata[0][0].SetCommandBus(MIL1553PortActiveBus.A);    // Test: Both buses is a default setting
            fdata[0][0].SetCommandDelay(100);   // Test: default is 0
            fdata[0][0].SetRetryOptions(3, (MIL1553BCRetryType)(MIL1553BCRetryType.NoResponse |
                                                             MIL1553BCRetryType.PeriodicStatusRequest|
                                                             MIL1553BCRetryType.Reenable));
            for (ushort i = 0; i < wordCount; i++)
            {
               data16[i] = (ushort)(0x1010 + startRt + i);
            }
            fdata[0][0].CopyRxData(data16);
            bcWriter.WriteBCCBData(fdata[0]);

            fdata[1][0].SetCommand(MIL1553CommandType.RTBC, startRt, startSa, wordCount);
            fdata[1][0].SetCommandBus(MIL1553PortActiveBus.A);    // Test: Both buses is a default setting
            fdata[1][0].SetCommandDelay(100);   // Test: default is 0
            fdata[1][0].SetRetryOptions(3, (MIL1553BCRetryType)(MIL1553BCRetryType.NoResponse |
                                                             MIL1553BCRetryType.PeriodicStatusRequest |
                                                             MIL1553BCRetryType.Reenable));
            bcWriter.WriteBCCBData(fdata[1]);

            // Start operations
            // Start RT
            for (ushort i = 0; i < wordCount; i++)
            {
               data16[i] = (ushort)(1 + i);
            }
            outRtFrm[0].CopyData(data16);
            rtWriter.WriteRT(outRtFrm);

            // Start Bus Controller
            bcControl = new MIL1553BCControlFrame[] { new MIL1553BCControlFrame() };
            bcControl[0].Operation = MIL1553BCOps.Enable;
            bcControl[0].MajorClock = 1.0;
            bcControl[0].MinorClock = 10.0;
            bcWriter.WriteBCControl(bcControl);
            
            // Clear received frames from previous run
            BM.Clear();
            RTRxData.Clear();
            BCTxData.Clear();

            // Switch UI components to start state
            InitUI(true);

            // Start timer to periodically transmit new data from BC to RT
            CycleTimer = new Timer();
            CycleTimer.Interval = 1000;
            CycleTimer.Start();
            CycleTimer.Tick += new EventHandler(Timer_Tick);
            count = 0;

            // Start timer to monitor bus traffic
            BMTimer = new Timer();
            BMTimer.Interval = 10;
            BMTimer.Start();
            BMTimer.Tick += new EventHandler(BMTimer_Tick);
         }
         catch(UeiDaqException ex)
         {
            MIL1553Session.Dispose();
            MIL1553Session = null;
            MessageBox.Show(this, ex.Message, "Error");
            InitUI(false);
         }
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         try
         {
            // Stop bus controller
            bcControl[0].Operation = MIL1553BCOps.Disable;
            bcWriter.WriteBCControl(bcControl);
            CycleTimer.Stop();
            BMTimer.Stop();
            MIL1553Session.Stop();
         }
         catch(UeiDaqException ex)
         {
            MessageBox.Show(this, ex.Message, "Error");
         }

         MIL1553Session.Dispose();
         MIL1553Session = null;
         
         // Switch UI components to stop state
         InitUI(false);
      }

      public void Timer_Tick(object sender, EventArgs eArgs)
      {
         if (sender == CycleTimer)
         {
            try
            {
               // Update Data in RT transmit area. This is the data the RT sends in response
               // to a RT-BC command
               UInt16[] data16 = new UInt16[wordCount];
               for (ushort i = 0; i < wordCount; i++)
               {
                  data16[i] = (ushort)(count + i);
               }
               outRtFrm[0].CopyData(data16);
               rtWriter.WriteRT(outRtFrm);  
 
               // Read data received by RT during last BC-RT command("receive" area)
               inRtFrm = rtReader.ReadRT(1, startRt, startSa, 0, wordCount);    
               String inRtStr = count.ToString() + ": " + inRtFrm[0].GetFrameStr() + " Data:" + inRtFrm[0].GetDataStr();
               inRtStr = inRtStr.Replace("\t", " ");
               inRtStr = inRtStr.Replace("\n", Environment.NewLine);
               inRtStr += Environment.NewLine;
               RTRxData.AppendText(inRtStr);

               /*rtStatusFrm = rtReader.ReadRTStatus(1, startRt);
               String rtStsStr = "sts0:0x" + rtStatusFrm[0].Status0.ToString("X") +
                               ", sts1:0x" + rtStatusFrm[0].Status1.ToString("X");
               rtStsStr += Environment.NewLine;
               RTRxData.AppendText(rtStsStr);*/

               RTRxData.SelectionStart = RTRxData.Text.Length;
               RTRxData.ScrollToCaret();

               // Update Data in BC receive area. This is the data the BC sends along
               // with the BC-RT command
               for (ushort i = 0; i < wordCount; i++)
               {
                  data16[i] = (ushort)(0x1020 + count + i);
               }
               fdata[0][0].CopyRxData(data16);
               bcWriter.WriteBCCBData(fdata[0]);

               // Read data stored in BC "Transmit" command
               fstatus[1] = bcReader.ReadBCCBStatus(1, 0, 0, 1);
               String bccbStatusStr = count.ToString() + ": " + fstatus[1][0].GetBcDataStr(wordCount);
               bccbStatusStr = bccbStatusStr.Replace("\t", " ");
               bccbStatusStr = bccbStatusStr.Replace("\n", Environment.NewLine);
               bccbStatusStr += Environment.NewLine;
               BCTxData.AppendText(bccbStatusStr);

               String stsStr = "errsts0:0x" + fstatus[1][0].errsts0.ToString("X") +
                               ", errsts1:0x" + fstatus[1][0].errsts1.ToString("X");
               stsStr += Environment.NewLine;
               BCTxData.AppendText(stsStr);
                  
               stsStr = "STS: " + fstatus[1][0].GetStatusString();
               stsStr += Environment.NewLine;
               BCTxData.AppendText(stsStr);

               stsStr = "Err STS: " + fstatus[1][0].GetErrorStatusString();
               stsStr += Environment.NewLine;
               BCTxData.AppendText(stsStr);

               BCTxData.SelectionStart = BCTxData.Text.Length;
               BCTxData.ScrollToCaret();


            }
            catch (UeiDaqException ex)
            {
               if (Error.Timeout == ex.Error)
               {
                  // Ignore timeout error
               }
               else
               {
                  MIL1553Session.Dispose();
                  MIL1553Session = null;
                  MessageBox.Show(this, ex.Message, "Error");
                  InitUI(false);
               }
            }
            count++;
         }
      }

      public void BMTimer_Tick(object sender, EventArgs eArgs)
      {
         if (sender == BMTimer)
         {
            try
            {
               // Read Bus monitor messages received on RT port
               MIL1553BMFrame[] frames = rtReader.ReadBM(10);
               foreach (MIL1553BMFrame f in frames)
               {
                  // Get string representation of BM frame and relpalce tabs with spaces
                  String frameStr = f.GetBmMessageStr() + Environment.NewLine + f.GetBmDataStrDataOnly();
                  frameStr = frameStr.Replace("\t", " ");
                  frameStr = frameStr.Replace("\n", Environment.NewLine);

                  BM.AppendText(frameStr);

                  // Make sure latest received frame is visible
                  BM.SelectionStart = BM.Text.Length;
                  BM.ScrollToCaret();
               }
            }
            catch (UeiDaqException ex)
            {
               if (Error.Timeout == ex.Error)
               {
                  // Ignore timeout error
               }
               else
               {
                  MIL1553Session.Dispose();
                  MIL1553Session = null;
                  MessageBox.Show(this, ex.Message, "Error");
                  InitUI(false);
               }
            }
         }
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         Application.Exit();
      }
	}
}
