using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using UeiDaq;

namespace ARINC429
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.ListView ReceiveList;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.Button Start;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.ComboBox Speed;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.GroupBox groupBox2;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.Button Send;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.ColumnHeader labalHeader;
      private System.Windows.Forms.ColumnHeader dataHeader;
      private System.Windows.Forms.ColumnHeader sdiHeader;
      private System.Windows.Forms.ColumnHeader ssmHeader;
      private System.Windows.Forms.ColumnHeader parityHeader;
      private System.Windows.Forms.TextBox Label;
      private System.Windows.Forms.Label label6;
      private System.Windows.Forms.TextBox Data;
      private System.Windows.Forms.Label label7;
      private System.Windows.Forms.TextBox SDI;
      private System.Windows.Forms.Label label8;
      private System.Windows.Forms.TextBox SSM;
      private System.Windows.Forms.Label label9;
      private System.Windows.Forms.TextBox Parity;
      private System.Windows.Forms.TextBox InputPort;
      private System.Windows.Forms.GroupBox groupBox3;
      private System.Windows.Forms.Label label10;
      private System.Windows.Forms.Label label11;
      private System.Windows.Forms.TextBox OutputPort;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.labalHeader = new System.Windows.Forms.ColumnHeader();
         this.dataHeader = new System.Windows.Forms.ColumnHeader();
         this.sdiHeader = new System.Windows.Forms.ColumnHeader();
         this.ssmHeader = new System.Windows.Forms.ColumnHeader();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.ReceiveList = new System.Windows.Forms.ListView();
         this.parityHeader = new System.Windows.Forms.ColumnHeader();
         this.label4 = new System.Windows.Forms.Label();
         this.Start = new System.Windows.Forms.Button();
         this.Stop = new System.Windows.Forms.Button();
         this.Resource = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.Speed = new System.Windows.Forms.ComboBox();
         this.Quit = new System.Windows.Forms.Button();
         this.label3 = new System.Windows.Forms.Label();
         this.groupBox2 = new System.Windows.Forms.GroupBox();
         this.label9 = new System.Windows.Forms.Label();
         this.Parity = new System.Windows.Forms.TextBox();
         this.label8 = new System.Windows.Forms.Label();
         this.SSM = new System.Windows.Forms.TextBox();
         this.label7 = new System.Windows.Forms.Label();
         this.SDI = new System.Windows.Forms.TextBox();
         this.label6 = new System.Windows.Forms.Label();
         this.Data = new System.Windows.Forms.TextBox();
         this.label5 = new System.Windows.Forms.Label();
         this.Label = new System.Windows.Forms.TextBox();
         this.Send = new System.Windows.Forms.Button();
         this.label2 = new System.Windows.Forms.Label();
         this.OutputPort = new System.Windows.Forms.TextBox();
         this.InputPort = new System.Windows.Forms.TextBox();
         this.groupBox3 = new System.Windows.Forms.GroupBox();
         this.label11 = new System.Windows.Forms.Label();
         this.label10 = new System.Windows.Forms.Label();
         this.groupBox1.SuspendLayout();
         this.groupBox2.SuspendLayout();
         this.groupBox3.SuspendLayout();
         this.SuspendLayout();
         // 
         // labalHeader
         // 
         this.labalHeader.Text = "Label";
         this.labalHeader.Width = 88;
         // 
         // dataHeader
         // 
         this.dataHeader.Text = "Data";
         this.dataHeader.Width = 133;
         // 
         // sdiHeader
         // 
         this.sdiHeader.Text = "SDI";
         // 
         // ssmHeader
         // 
         this.ssmHeader.Text = "SSM";
         this.ssmHeader.Width = 51;
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.ReceiveList);
         this.groupBox1.Location = new System.Drawing.Point(8, 176);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(504, 112);
         this.groupBox1.TabIndex = 22;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Receive ARINC words";
         // 
         // ReceiveList
         // 
         this.ReceiveList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.labalHeader,
            this.dataHeader,
            this.sdiHeader,
            this.ssmHeader,
            this.parityHeader});
         this.ReceiveList.Location = new System.Drawing.Point(8, 16);
         this.ReceiveList.Name = "ReceiveList";
         this.ReceiveList.Size = new System.Drawing.Size(488, 88);
         this.ReceiveList.TabIndex = 0;
         this.ReceiveList.UseCompatibleStateImageBehavior = false;
         this.ReceiveList.View = System.Windows.Forms.View.Details;
         // 
         // parityHeader
         // 
         this.parityHeader.Text = "Parity";
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(8, 8);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(488, 32);
         this.label4.TabIndex = 12;
         this.label4.Text = "This example shows how to send ARINC-429 words out of port 0 and read those words" +
             " back from loopback port 6.";
         // 
         // Start
         // 
         this.Start.Location = new System.Drawing.Point(16, 376);
         this.Start.Name = "Start";
         this.Start.Size = new System.Drawing.Size(88, 32);
         this.Start.TabIndex = 20;
         this.Start.Text = "Start";
         this.Start.Click += new System.EventHandler(this.Start_Click);
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(224, 376);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(88, 32);
         this.Stop.TabIndex = 19;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(32, 48);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(176, 20);
         this.Resource.TabIndex = 16;
         this.Resource.Text = "pdna://192.168.100.2/Dev0/";
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(32, 32);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(100, 16);
         this.label1.TabIndex = 13;
         this.label1.Text = "Resource";
         // 
         // Speed
         // 
         this.Speed.Items.AddRange(new object[] {
            "12500",
            "100000"});
         this.Speed.Location = new System.Drawing.Point(328, 48);
         this.Speed.Name = "Speed";
         this.Speed.Size = new System.Drawing.Size(121, 21);
         this.Speed.TabIndex = 15;
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(416, 374);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(88, 32);
         this.Quit.TabIndex = 18;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(8, 40);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(488, 29);
         this.label3.TabIndex = 14;
         this.label3.Text = "Press the \"Start\" button to start the session. Received ARINC words will appear i" +
             "n the listview. Press the \"Send\" button to send ARINC words.";
         // 
         // groupBox2
         // 
         this.groupBox2.Controls.Add(this.label9);
         this.groupBox2.Controls.Add(this.Parity);
         this.groupBox2.Controls.Add(this.label8);
         this.groupBox2.Controls.Add(this.SSM);
         this.groupBox2.Controls.Add(this.label7);
         this.groupBox2.Controls.Add(this.SDI);
         this.groupBox2.Controls.Add(this.label6);
         this.groupBox2.Controls.Add(this.Data);
         this.groupBox2.Controls.Add(this.label5);
         this.groupBox2.Controls.Add(this.Label);
         this.groupBox2.Controls.Add(this.Send);
         this.groupBox2.Location = new System.Drawing.Point(8, 296);
         this.groupBox2.Name = "groupBox2";
         this.groupBox2.Size = new System.Drawing.Size(504, 72);
         this.groupBox2.TabIndex = 21;
         this.groupBox2.TabStop = false;
         this.groupBox2.Text = "Send ARINC word";
         // 
         // label9
         // 
         this.label9.Location = new System.Drawing.Point(416, 24);
         this.label9.Name = "label9";
         this.label9.Size = new System.Drawing.Size(40, 16);
         this.label9.TabIndex = 10;
         this.label9.Text = "Parity";
         // 
         // Parity
         // 
         this.Parity.Location = new System.Drawing.Point(416, 40);
         this.Parity.Name = "Parity";
         this.Parity.Size = new System.Drawing.Size(40, 20);
         this.Parity.TabIndex = 9;
         this.Parity.Text = "0x0";
         // 
         // label8
         // 
         this.label8.Location = new System.Drawing.Point(352, 24);
         this.label8.Name = "label8";
         this.label8.Size = new System.Drawing.Size(40, 16);
         this.label8.TabIndex = 8;
         this.label8.Text = "SSM";
         // 
         // SSM
         // 
         this.SSM.Location = new System.Drawing.Point(352, 40);
         this.SSM.Name = "SSM";
         this.SSM.Size = new System.Drawing.Size(40, 20);
         this.SSM.TabIndex = 7;
         this.SSM.Text = "0x2";
         // 
         // label7
         // 
         this.label7.Location = new System.Drawing.Point(288, 24);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(40, 16);
         this.label7.TabIndex = 6;
         this.label7.Text = "SDI";
         // 
         // SDI
         // 
         this.SDI.Location = new System.Drawing.Point(288, 40);
         this.SDI.Name = "SDI";
         this.SDI.Size = new System.Drawing.Size(40, 20);
         this.SDI.TabIndex = 5;
         this.SDI.Text = "0x1";
         // 
         // label6
         // 
         this.label6.Location = new System.Drawing.Point(200, 24);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(40, 16);
         this.label6.TabIndex = 4;
         this.label6.Text = "Data";
         // 
         // Data
         // 
         this.Data.Location = new System.Drawing.Point(200, 40);
         this.Data.Name = "Data";
         this.Data.Size = new System.Drawing.Size(64, 20);
         this.Data.TabIndex = 3;
         this.Data.Text = "0x102";
         // 
         // label5
         // 
         this.label5.Location = new System.Drawing.Point(112, 24);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(40, 16);
         this.label5.TabIndex = 2;
         this.label5.Text = "Label";
         // 
         // Label
         // 
         this.Label.Location = new System.Drawing.Point(112, 40);
         this.Label.Name = "Label";
         this.Label.Size = new System.Drawing.Size(64, 20);
         this.Label.TabIndex = 1;
         this.Label.Text = "0x12";
         // 
         // Send
         // 
         this.Send.Location = new System.Drawing.Point(8, 16);
         this.Send.Name = "Send";
         this.Send.Size = new System.Drawing.Size(80, 48);
         this.Send.TabIndex = 0;
         this.Send.Text = "Send";
         this.Send.Click += new System.EventHandler(this.Send_Click);
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(328, 32);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(100, 16);
         this.label2.TabIndex = 17;
         this.label2.Text = "Bus speed";
         // 
         // OutputPort
         // 
         this.OutputPort.Location = new System.Drawing.Point(224, 32);
         this.OutputPort.Name = "OutputPort";
         this.OutputPort.Size = new System.Drawing.Size(48, 20);
         this.OutputPort.TabIndex = 23;
         this.OutputPort.Text = "ATX0";
         // 
         // InputPort
         // 
         this.InputPort.Location = new System.Drawing.Point(224, 72);
         this.InputPort.Name = "InputPort";
         this.InputPort.Size = new System.Drawing.Size(48, 20);
         this.InputPort.TabIndex = 23;
         this.InputPort.Text = "ARX6";
         // 
         // groupBox3
         // 
         this.groupBox3.Controls.Add(this.label11);
         this.groupBox3.Controls.Add(this.label10);
         this.groupBox3.Controls.Add(this.Resource);
         this.groupBox3.Controls.Add(this.label1);
         this.groupBox3.Controls.Add(this.OutputPort);
         this.groupBox3.Controls.Add(this.InputPort);
         this.groupBox3.Controls.Add(this.Speed);
         this.groupBox3.Controls.Add(this.label2);
         this.groupBox3.Location = new System.Drawing.Point(8, 72);
         this.groupBox3.Name = "groupBox3";
         this.groupBox3.Size = new System.Drawing.Size(504, 96);
         this.groupBox3.TabIndex = 24;
         this.groupBox3.TabStop = false;
         this.groupBox3.Text = "Ports Configuration";
         // 
         // label11
         // 
         this.label11.Location = new System.Drawing.Point(224, 56);
         this.label11.Name = "label11";
         this.label11.Size = new System.Drawing.Size(64, 16);
         this.label11.TabIndex = 1;
         this.label11.Text = "Input port";
         // 
         // label10
         // 
         this.label10.Location = new System.Drawing.Point(224, 16);
         this.label10.Name = "label10";
         this.label10.Size = new System.Drawing.Size(64, 16);
         this.label10.TabIndex = 0;
         this.label10.Text = "Output port";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(520, 414);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.label4);
         this.Controls.Add(this.Start);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.groupBox2);
         this.Controls.Add(this.groupBox3);
         this.Name = "Form1";
         this.Text = "Form1";
         this.Load += new System.EventHandler(this.OnLoad);
         this.groupBox1.ResumeLayout(false);
         this.groupBox2.ResumeLayout(false);
         this.groupBox2.PerformLayout();
         this.groupBox3.ResumeLayout(false);
         this.groupBox3.PerformLayout();
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private Session ARINCSession;
      private ARINCReader reader;
      private ARINCWriter writer;
      private AsyncCallback readerAsyncCallback;  
      private IAsyncResult readerIAsyncResult;      
      private delegate void UpdateUIDelegate(ARINCWord[] words);

      private void InitUI(bool isRunning)
      {
         if(isRunning)
         {
            Start.Enabled = false;
            Stop.Enabled = true;
            Send.Enabled = true;
            Quit.Enabled = false;
         }
         else
         {
            Start.Enabled = true;
            Stop.Enabled = false;
            Quit.Enabled = true;
            Send.Enabled = false;
         }
      }

      private void OnLoad(object sender, System.EventArgs e)
      {
         Speed.SelectedIndex = 0;
         InitUI(false);
      }

      private void Start_Click(object sender, System.EventArgs e)
      {
         try
         {
            ARINCSession = new Session();
            ARINCSession.CreateARINCInputPort(Resource.Text + InputPort.Text, 
                                             (ARINCPortSpeed)Speed.SelectedIndex, 
                                             ARINCPortParity.None,
                                             false, 
                                             0);
            ARINCSession.CreateARINCOutputPort(Resource.Text + OutputPort.Text, 
                                             (ARINCPortSpeed)Speed.SelectedIndex, 
                                             ARINCPortParity.None);
            ARINCSession.ConfigureTimingForMessagingIO(1, 0);
            ARINCSession.GetTiming().SetTimeout(500);

            // Start the session
            ARINCSession.Start();

            // Create a reader for RX port
            reader = new ARINCReader(ARINCSession.GetDataStream(), Int32.Parse(InputPort.Text.Substring(3,1)));

            // Create a writer for TX port
            writer = new ARINCWriter(ARINCSession.GetDataStream(), Int32.Parse(OutputPort.Text.Substring(3,1)));

            // Initiate one asynchronous read, it will reinitiate itself
            // automatically
            readerAsyncCallback = new AsyncCallback(ReaderCallback);
            readerIAsyncResult = reader.BeginRead(1, readerAsyncCallback, null);

            // Clear recevied words from previous run
            ReceiveList.Items.Clear();

            // Switch UI components to start state
            InitUI(true);
         }
         catch(UeiDaqException ex)
         {
            ARINCSession.Dispose();
            ARINCSession = null;
            MessageBox.Show(this, ex.Message, "Error");
            InitUI(false);
         }
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         try
         {
            ARINCSession.Stop();
              
            // wait for current async call to complete
            // before destroying the session
            readerIAsyncResult.AsyncWaitHandle.WaitOne();
         }
         catch(UeiDaqException ex)
         {
            MessageBox.Show(this, ex.Message, "Error");
         }

         ARINCSession.Dispose();
         ARINCSession = null;
         
         // Switch UI components to stop state
         InitUI(false);
      }

      private void Send_Click(object sender, System.EventArgs e)
      {
         try
         {
            // Build the ARINCWord array to send to the ARINC TX port
            ARINCWord[] words = new ARINCWord[1];
            words[0] = new ARINCWord();

            words[0].Label = Convert.ToUInt32(Label.Text, 16);
            words[0].Data = Convert.ToUInt32(Data.Text, 16);
            words[0].Sdi = Convert.ToUInt32(SDI.Text, 16);
            words[0].Ssm = Convert.ToUInt32(SSM.Text, 16);
            words[0].Parity = Convert.ToUInt32(Parity.Text, 16);
            
            writer.Write(words);
         }
         catch(UeiDaqException ex)
         {
            ARINCSession.Dispose();
            ARINCSession = null;
            MessageBox.Show(this, ex.Message, "Error");
            InitUI(false);
         }      
      }

      private void ReaderCallback(IAsyncResult ar)
      {
         try
         {
            ARINCWord[] words = reader.EndRead(ar);

            // We can't directly access the UI from an asynchronous method
            // need to invoke a delegate that will take care of updating
            // the UI from the proper thread
            if(words != null)
            {
                UpdateReceiveUI(words);
            }

            if(ARINCSession != null && ARINCSession.IsRunning())
            {
               readerIAsyncResult = reader.BeginRead(1, readerAsyncCallback, null);
            }
         }
         catch(UeiDaqException ex)
         {
            // only handle exception if the session is running
            if(ARINCSession.IsRunning())
            {
               if(Error.Timeout == ex.Error)
               {
                  // Ignore timeout error, they will occur if the send button is not
                  // clicked on fast enough!
                  // Just reinitiate a new asynchronous read.
                  readerIAsyncResult = reader.BeginRead(1, readerAsyncCallback, null);
                  Console.WriteLine("Timeout");
               }
               else
               {
                  ARINCSession.Dispose();
                  ARINCSession = null;
                  MessageBox.Show(this, ex.Message, "Error");
                  InitUI(false);
               }
            }
         }
      }

      private void UpdateReceiveUI(ARINCWord[] words)
      {
         if (this.InvokeRequired)
         {
            UpdateUIDelegate uidlg = new UpdateUIDelegate(UpdateReceiveUI);
            Invoke(uidlg, new object[] { words });
         }
         else
         {
            foreach(ARINCWord word in words)
            {
               ListViewItem item = new ListViewItem("0x" + word.Label.ToString("X"), 0);
               item.SubItems.Add("0x" + word.Data.ToString("X"));
               item.SubItems.Add("0x" + word.Sdi.ToString("X"));
               item.SubItems.Add("0x" + word.Ssm.ToString("X"));
               item.SubItems.Add("0x" + word.Parity.ToString("X"));
               
               ReceiveList.Items.Add(item);

               item.EnsureVisible();
            }
         }
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         Application.Exit();
      }
	}
}
