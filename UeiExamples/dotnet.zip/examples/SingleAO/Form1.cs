using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using UeiDaq;

namespace SingleAO
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class SingleAO : System.Windows.Forms.Form
	{
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.TextBox ValueText;
      private System.Windows.Forms.TrackBar Value;
      private System.Windows.Forms.ComboBox Channel;
      private Session mySs;
      private AnalogScaledWriter writer;
      private Timer AOTimer;
      private double[] scan;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SingleAO()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.Resource = new System.Windows.Forms.TextBox();
         this.Stop = new System.Windows.Forms.Button();
         this.label2 = new System.Windows.Forms.Label();
         this.Quit = new System.Windows.Forms.Button();
         this.Go = new System.Windows.Forms.Button();
         this.ValueText = new System.Windows.Forms.TextBox();
         this.Value = new System.Windows.Forms.TrackBar();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.Channel = new System.Windows.Forms.ComboBox();
         ((System.ComponentModel.ISupportInitialize)(this.Value)).BeginInit();
         this.groupBox1.SuspendLayout();
         this.SuspendLayout();
         // 
         // ErrorText
         // 
         this.ErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
         this.ErrorText.Location = new System.Drawing.Point(0, 174);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(400, 48);
         this.ErrorText.TabIndex = 24;
         this.ErrorText.Text = "";
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(8, 24);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(112, 20);
         this.Resource.TabIndex = 21;
         this.Resource.Text = "simu://Dev0/Ao0:3";
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(272, 68);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(112, 32);
         this.Stop.TabIndex = 23;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(8, 8);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(120, 16);
         this.label2.TabIndex = 22;
         this.label2.Text = "Resource name";
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(272, 108);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(112, 32);
         this.Quit.TabIndex = 20;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(272, 28);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(112, 32);
         this.Go.TabIndex = 19;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // ValueText
         // 
         this.ValueText.Location = new System.Drawing.Point(96, 80);
         this.ValueText.Name = "ValueText";
         this.ValueText.ReadOnly = true;
         this.ValueText.Size = new System.Drawing.Size(64, 20);
         this.ValueText.TabIndex = 26;
         this.ValueText.Text = "";
         // 
         // Value
         // 
         this.Value.Location = new System.Drawing.Point(16, 48);
         this.Value.Maximum = 1000;
         this.Value.Minimum = -1000;
         this.Value.Name = "Value";
         this.Value.Size = new System.Drawing.Size(216, 45);
         this.Value.TabIndex = 25;
         this.Value.TickFrequency = 100;
         this.Value.Value = 10;
         this.Value.Scroll += new System.EventHandler(this.OnValue_Scroll);
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.Channel);
         this.groupBox1.Controls.Add(this.ValueText);
         this.groupBox1.Controls.Add(this.Value);
         this.groupBox1.Location = new System.Drawing.Point(8, 56);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(256, 112);
         this.groupBox1.TabIndex = 27;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Channel Value";
         // 
         // Channel
         // 
         this.Channel.Location = new System.Drawing.Point(72, 16);
         this.Channel.Name = "Channel";
         this.Channel.Size = new System.Drawing.Size(112, 21);
         this.Channel.TabIndex = 27;
         // 
         // SingleAO
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(400, 222);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.Resource);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Name = "SingleAO";
         this.Text = "SingleAO";
         ((System.ComponentModel.ISupportInitialize)(this.Value)).EndInit();
         this.groupBox1.ResumeLayout(false);
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new SingleAO());
		}

      private void OnValue_Scroll(object sender, System.EventArgs e)
      {
         ValueText.Text = (((TrackBar)(sender)).Value / 100.0).ToString();
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         Application.Exit();
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         ErrorText.Clear();
         Value.Value = 0;
         ValueText.Text = "0.0";
         Channel.Items.Clear();
                     
         try
         {
            mySs = new Session();
            mySs.CreateAOChannel(Resource.Text, -10.0, 10.0);
               
            for(int i=0; i<mySs.GetNumberOfChannels(); i++)
            {
               Channel.Items.Add("channel " + mySs.GetChannel(i).GetIndex().ToString());
            }
            Channel.SelectedIndex = 0;

            mySs.ConfigureTimingForSimpleIO();

            // Create a reader object to read data synchronously.
            writer = new AnalogScaledWriter(mySs.GetDataStream());

            scan = new double[mySs.GetNumberOfChannels()];

            mySs.Start();

            AOTimer = new Timer();
            AOTimer.Interval=100;
            AOTimer.Start();
            AOTimer.Tick+=new EventHandler(Timer_Tick);
  
            Resource.Enabled = false;
            Go.Enabled = false;
         }
         catch(UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            mySs.Dispose();
            mySs = null;
         }
      }

      public void Timer_Tick(object sender,EventArgs eArgs)
      {
         if(sender==AOTimer)
         {
            scan[Channel.SelectedIndex] = Double.Parse(ValueText.Text);
            
            writer.WriteSingleScan(scan);
         }
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         Resource.Enabled = true;
         Go.Enabled = true;

         if(mySs != null)
         {
            AOTimer.Stop();

            try
            {
               mySs.Stop();
            }
            catch(UeiDaqException exception)
            {
               ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }

            mySs.Dispose();
            mySs = null;
         }
      }  
	}
}
