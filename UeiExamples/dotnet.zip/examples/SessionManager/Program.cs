﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace SessionManager
{
   class Program
   {
      static void Main(string[] args)
      {
         Session aiSession = new Session();
         String sessionFile = "c:\\program files (x86)\\uei\\framework\\sessions\\global\\test_dev1.xml";

         try
         {
            String xmlText = System.IO.File.ReadAllText(sessionFile);

            aiSession.LoadFromXml(xmlText);
            aiSession.ConfigureTimingForSimpleIO();

            Console.WriteLine("Loaded session for device " + aiSession.GetDevice().GetResourceName());

            AnalogScaledReader reader = new AnalogScaledReader(aiSession.GetDataStream());
            double[] data;

            aiSession.Start();

            // Establish an event handler to process key press events.
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

            uint count = 0;
            stop = false;
            while (!stop)
            {
               // Read and display data
               data = reader.ReadSingleScan();

               for (int ch = 0; ch < aiSession.GetNumberOfChannels(); ch++)
               {
                  Console.WriteLine("Channel " + aiSession.GetChannel(ch).GetIndex() + " = " + data[ch]);
               }
               Console.WriteLine("");

               Thread.Sleep(500);
               count++;
            }

            aiSession.Stop();
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop= false;
   }
}
