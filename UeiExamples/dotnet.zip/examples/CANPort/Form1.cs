using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using UeiDaq;

namespace CANPort
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.ComponentModel.IContainer components = null;
      private System.Windows.Forms.GroupBox groupBox2;
      private System.Windows.Forms.Button Start;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.Button Quit;     
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.ComboBox Speed;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.ColumnHeader arbitrationIDHeader;
      private System.Windows.Forms.ColumnHeader remoteHeader;
      private System.Windows.Forms.ColumnHeader dataSizeHeader;
      private System.Windows.Forms.ColumnHeader dataHeader;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.Button Send;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.GroupBox groupBox3;
      private System.Windows.Forms.ListView ReceiveList;
      private System.Windows.Forms.TextBox ArbitrationID;
      private System.Windows.Forms.CheckBox IsRemote;
      private System.Windows.Forms.TextBox DataByte2;
      private System.Windows.Forms.TextBox DataByte3;
      private System.Windows.Forms.TextBox DataByte4;
      private System.Windows.Forms.TextBox DataByte5;
      private System.Windows.Forms.TextBox DataByte1;
      private System.Windows.Forms.TextBox DataByte6;
      private System.Windows.Forms.TextBox DataByte7;
      private System.Windows.Forms.TextBox DataByte0;

      private CANWriter writer;
      private Session CANSession;
      private CANReader reader;
      private AsyncCallback readerAsyncCallback; 
      private IAsyncResult readerIAsyncResult;      
      private delegate void UpdateUIDelegate(CANFrame[] frames);

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.label2 = new System.Windows.Forms.Label();
         this.label1 = new System.Windows.Forms.Label();
         this.label3 = new System.Windows.Forms.Label();
         this.Speed = new System.Windows.Forms.ComboBox();
         this.Resource = new System.Windows.Forms.TextBox();
         this.Quit = new System.Windows.Forms.Button();
         this.Stop = new System.Windows.Forms.Button();
         this.groupBox2 = new System.Windows.Forms.GroupBox();
         this.groupBox3 = new System.Windows.Forms.GroupBox();
         this.DataByte0 = new System.Windows.Forms.TextBox();
         this.DataByte6 = new System.Windows.Forms.TextBox();
         this.DataByte3 = new System.Windows.Forms.TextBox();
         this.DataByte2 = new System.Windows.Forms.TextBox();
         this.DataByte4 = new System.Windows.Forms.TextBox();
         this.DataByte7 = new System.Windows.Forms.TextBox();
         this.DataByte5 = new System.Windows.Forms.TextBox();
         this.DataByte1 = new System.Windows.Forms.TextBox();
         this.IsRemote = new System.Windows.Forms.CheckBox();
         this.label5 = new System.Windows.Forms.Label();
         this.ArbitrationID = new System.Windows.Forms.TextBox();
         this.Send = new System.Windows.Forms.Button();
         this.Start = new System.Windows.Forms.Button();
         this.label4 = new System.Windows.Forms.Label();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.ReceiveList = new System.Windows.Forms.ListView();
         this.arbitrationIDHeader = new System.Windows.Forms.ColumnHeader();
         this.remoteHeader = new System.Windows.Forms.ColumnHeader();
         this.dataSizeHeader = new System.Windows.Forms.ColumnHeader();
         this.dataHeader = new System.Windows.Forms.ColumnHeader();
         this.groupBox2.SuspendLayout();
         this.groupBox3.SuspendLayout();
         this.groupBox1.SuspendLayout();
         this.SuspendLayout();
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(240, 72);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(100, 16);
         this.label2.TabIndex = 5;
         this.label2.Text = "Bus speed";
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(8, 72);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(100, 16);
         this.label1.TabIndex = 1;
         this.label1.Text = "Resource";
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(8, 32);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(488, 30);
         this.label3.TabIndex = 2;
         this.label3.Text = "Press the \"Start\" button to start the session. Received CAN frames will appear in" +
             " the listview. Press the \"Send\" button to send CAN frames.";
         // 
         // Speed
         // 
         this.Speed.Items.AddRange(new object[] {
            "10K",
            "20K",
            "50K",
            "100K",
            "125K",
            "250K",
            "500K",
            "800K",
            "1M"});
         this.Speed.Location = new System.Drawing.Point(240, 88);
         this.Speed.Name = "Speed";
         this.Speed.Size = new System.Drawing.Size(121, 21);
         this.Speed.TabIndex = 3;
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(8, 88);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(216, 20);
         this.Resource.TabIndex = 4;
         this.Resource.Text = "pdna://192.168.100.2/Dev0/CAN0,1";
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(416, 328);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(88, 32);
         this.Quit.TabIndex = 6;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(224, 328);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(88, 32);
         this.Stop.TabIndex = 7;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // groupBox2
         // 
         this.groupBox2.Controls.Add(this.groupBox3);
         this.groupBox2.Controls.Add(this.IsRemote);
         this.groupBox2.Controls.Add(this.label5);
         this.groupBox2.Controls.Add(this.ArbitrationID);
         this.groupBox2.Controls.Add(this.Send);
         this.groupBox2.Location = new System.Drawing.Point(8, 248);
         this.groupBox2.Name = "groupBox2";
         this.groupBox2.Size = new System.Drawing.Size(504, 72);
         this.groupBox2.TabIndex = 10;
         this.groupBox2.TabStop = false;
         this.groupBox2.Text = "Send Frames";
         // 
         // groupBox3
         // 
         this.groupBox3.Controls.Add(this.DataByte0);
         this.groupBox3.Controls.Add(this.DataByte6);
         this.groupBox3.Controls.Add(this.DataByte3);
         this.groupBox3.Controls.Add(this.DataByte2);
         this.groupBox3.Controls.Add(this.DataByte4);
         this.groupBox3.Controls.Add(this.DataByte7);
         this.groupBox3.Controls.Add(this.DataByte5);
         this.groupBox3.Controls.Add(this.DataByte1);
         this.groupBox3.Location = new System.Drawing.Point(280, 24);
         this.groupBox3.Name = "groupBox3";
         this.groupBox3.Size = new System.Drawing.Size(208, 40);
         this.groupBox3.TabIndex = 12;
         this.groupBox3.TabStop = false;
         this.groupBox3.Text = "Data";
         // 
         // DataByte0
         // 
         this.DataByte0.Location = new System.Drawing.Point(8, 16);
         this.DataByte0.Name = "DataByte0";
         this.DataByte0.Size = new System.Drawing.Size(24, 20);
         this.DataByte0.TabIndex = 11;
         this.DataByte0.Text = "0";
         // 
         // DataByte6
         // 
         this.DataByte6.Location = new System.Drawing.Point(152, 16);
         this.DataByte6.Name = "DataByte6";
         this.DataByte6.Size = new System.Drawing.Size(24, 20);
         this.DataByte6.TabIndex = 9;
         this.DataByte6.Text = "0";
         // 
         // DataByte3
         // 
         this.DataByte3.Location = new System.Drawing.Point(80, 16);
         this.DataByte3.Name = "DataByte3";
         this.DataByte3.Size = new System.Drawing.Size(24, 20);
         this.DataByte3.TabIndex = 6;
         this.DataByte3.Text = "0";
         // 
         // DataByte2
         // 
         this.DataByte2.Location = new System.Drawing.Point(56, 16);
         this.DataByte2.Name = "DataByte2";
         this.DataByte2.Size = new System.Drawing.Size(24, 20);
         this.DataByte2.TabIndex = 5;
         this.DataByte2.Text = "0";
         // 
         // DataByte4
         // 
         this.DataByte4.Location = new System.Drawing.Point(104, 16);
         this.DataByte4.Name = "DataByte4";
         this.DataByte4.Size = new System.Drawing.Size(24, 20);
         this.DataByte4.TabIndex = 7;
         this.DataByte4.Text = "0";
         // 
         // DataByte7
         // 
         this.DataByte7.Location = new System.Drawing.Point(176, 16);
         this.DataByte7.Name = "DataByte7";
         this.DataByte7.Size = new System.Drawing.Size(24, 20);
         this.DataByte7.TabIndex = 10;
         this.DataByte7.Text = "0";
         // 
         // DataByte5
         // 
         this.DataByte5.Location = new System.Drawing.Point(128, 16);
         this.DataByte5.Name = "DataByte5";
         this.DataByte5.Size = new System.Drawing.Size(24, 20);
         this.DataByte5.TabIndex = 8;
         this.DataByte5.Text = "0";
         // 
         // DataByte1
         // 
         this.DataByte1.Location = new System.Drawing.Point(32, 16);
         this.DataByte1.Name = "DataByte1";
         this.DataByte1.Size = new System.Drawing.Size(24, 20);
         this.DataByte1.TabIndex = 4;
         this.DataByte1.Text = "0";
         // 
         // IsRemote
         // 
         this.IsRemote.Location = new System.Drawing.Point(192, 40);
         this.IsRemote.Name = "IsRemote";
         this.IsRemote.Size = new System.Drawing.Size(80, 16);
         this.IsRemote.TabIndex = 3;
         this.IsRemote.Text = "Is Remote?";
         // 
         // label5
         // 
         this.label5.Location = new System.Drawing.Point(112, 24);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(72, 16);
         this.label5.TabIndex = 2;
         this.label5.Text = "Arbitration ID";
         // 
         // ArbitrationID
         // 
         this.ArbitrationID.Location = new System.Drawing.Point(112, 40);
         this.ArbitrationID.Name = "ArbitrationID";
         this.ArbitrationID.Size = new System.Drawing.Size(64, 20);
         this.ArbitrationID.TabIndex = 1;
         this.ArbitrationID.Text = "0x123";
         // 
         // Send
         // 
         this.Send.Location = new System.Drawing.Point(8, 16);
         this.Send.Name = "Send";
         this.Send.Size = new System.Drawing.Size(80, 48);
         this.Send.TabIndex = 0;
         this.Send.Text = "Send";
         this.Send.Click += new System.EventHandler(this.Send_Click);
         // 
         // Start
         // 
         this.Start.Location = new System.Drawing.Point(16, 328);
         this.Start.Name = "Start";
         this.Start.Size = new System.Drawing.Size(88, 32);
         this.Start.TabIndex = 8;
         this.Start.Text = "Start";
         this.Start.Click += new System.EventHandler(this.Start_Click);
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(8, 8);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(488, 16);
         this.label4.TabIndex = 0;
         this.label4.Text = "This example shows how to send CAN frames out of port 0 and receive CAN frames fr" +
             "om port 1.";
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.ReceiveList);
         this.groupBox1.Location = new System.Drawing.Point(8, 120);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(504, 120);
         this.groupBox1.TabIndex = 11;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Receive Frames";
         // 
         // ReceiveList
         // 
         this.ReceiveList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.arbitrationIDHeader,
            this.remoteHeader,
            this.dataSizeHeader,
            this.dataHeader});
         this.ReceiveList.Location = new System.Drawing.Point(8, 16);
         this.ReceiveList.Name = "ReceiveList";
         this.ReceiveList.Size = new System.Drawing.Size(488, 96);
         this.ReceiveList.TabIndex = 0;
         this.ReceiveList.UseCompatibleStateImageBehavior = false;
         this.ReceiveList.View = System.Windows.Forms.View.Details;
         // 
         // arbitrationIDHeader
         // 
         this.arbitrationIDHeader.Text = "Arbitration ID";
         this.arbitrationIDHeader.Width = 77;
         // 
         // remoteHeader
         // 
         this.remoteHeader.Text = "Is Remote?";
         this.remoteHeader.Width = 73;
         // 
         // dataSizeHeader
         // 
         this.dataSizeHeader.Text = "Data Size";
         // 
         // dataHeader
         // 
         this.dataHeader.Text = "Data";
         this.dataHeader.Width = 179;
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(520, 366);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.label4);
         this.Controls.Add(this.Start);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.Resource);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.Speed);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.groupBox2);
         this.Controls.Add(this.label2);
         this.Name = "Form1";
         this.Text = "CAN Port";
         this.Load += new System.EventHandler(this.OnLoad);
         this.groupBox2.ResumeLayout(false);
         this.groupBox2.PerformLayout();
         this.groupBox3.ResumeLayout(false);
         this.groupBox3.PerformLayout();
         this.groupBox1.ResumeLayout(false);
         this.ResumeLayout(false);
         this.PerformLayout();

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private void InitUI(bool isRunning)
      {
         if(isRunning)
         {
            Start.Enabled = false;
            Stop.Enabled = true;
            Send.Enabled = true;
            Quit.Enabled = false;
            ReceiveList.Enabled = true;
         }
         else
         {
            Start.Enabled = true;
            Stop.Enabled = false;
            Quit.Enabled = true;
            Send.Enabled = false;
            ReceiveList.Enabled = false;
         }
      }

      private void OnLoad(object sender, System.EventArgs e)
      {
         Speed.SelectedIndex = 5;
         InitUI(false);
      }

      private void Start_Click(object sender, System.EventArgs e)
      {
         try
         {
            CANSession = new Session();
            CANSession.CreateCANPort(Resource.Text, 
                                     (CANPortSpeed)Speed.SelectedIndex, 
                                     CANFrameFormat.Extended,
                                     CANPortMode.Normal, 
                                     0xFFFFFFFF,
                                     0);
            CANSession.ConfigureTimingForMessagingIO(1, 0);
            CANSession.GetTiming().SetTimeout(100);

            // Create a CAN reader for second port in resource string
            reader = new CANReader(CANSession.GetDataStream(), CANSession.GetChannel(1).GetIndex());

            // Create a CAN writer for first port in resource string
            writer = new CANWriter(CANSession.GetDataStream(), CANSession.GetChannel(0).GetIndex());

            // Start the session
            CANSession.Start();

            // Initiate one asynchronous read, it will reinitiate itself
            // automatically
            readerAsyncCallback = new AsyncCallback(ReaderCallback);
            readerIAsyncResult = reader.BeginRead(1, readerAsyncCallback, null);

            // Switch UI components to start state
            InitUI(true);
         }
         catch(UeiDaqException ex)
         {
            CANSession.Dispose();
            CANSession = null;
            MessageBox.Show(this, ex.Message, "Error");
            InitUI(false);
         }
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         try
         {
            CANSession.Stop();
            // wait for current async call to complete
            // before destroying the session
            readerIAsyncResult.AsyncWaitHandle.WaitOne();
         }
         catch(UeiDaqException ex)
         {
            MessageBox.Show(this, ex.Message, "Error");
         }

         CANSession.Dispose();
         CANSession = null;
         InitUI(false);
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         Application.Exit();
      }

      private void Send_Click(object sender, System.EventArgs e)
      {
         try
         {
            // Build the CANFrame array to send to the CAN port
            CANFrame[] frames = new CANFrame[1];
            frames[0] = new CANFrame();

            frames[0].Id = Convert.ToUInt32(ArbitrationID.Text, 16);
            frames[0].Type = (IsRemote.Checked ? CANFrameType.RemoteFrame : CANFrameType.DataFrame);
            frames[0].DataSize = 8;
            frames[0].Data = new byte[]{Convert.ToByte(DataByte0.Text, 16),
                                        Convert.ToByte(DataByte1.Text, 16),
                                        Convert.ToByte(DataByte2.Text, 16),
                                        Convert.ToByte(DataByte3.Text, 16),
                                        Convert.ToByte(DataByte4.Text, 16),
                                        Convert.ToByte(DataByte5.Text, 16),
                                        Convert.ToByte(DataByte6.Text, 16),
                                        Convert.ToByte(DataByte7.Text, 16)};
            writer.Write(frames);
         }
         catch(UeiDaqException ex)
         {
            CANSession.Dispose();
            CANSession = null;
            MessageBox.Show(this, ex.Message, "Error");
            InitUI(false);
         }
      }

      private void ReaderCallback(IAsyncResult ar)
      {
         try
         {
            CANFrame[] frames = reader.EndRead(ar);

            // We can't directly access the UI from an asynchronous method
            // need to invoke a delegate that will take care of updating
            // the UI from the proper thread
            if(frames != null)
            {
               UpdateReceiveUI(frames);
            }

            if(CANSession != null && CANSession.IsRunning())
            {
               readerIAsyncResult = reader.BeginRead(1, readerAsyncCallback, null);
            }
         }
         catch(UeiDaqException ex)
         {
            // only handle exception if the session is running
            if(CANSession.IsRunning())
            {
               if(Error.Timeout == ex.Error)
               {
                  // Ignore timeout error, they will occur if the send button is not
                  // clicked on fast enough!
                  // Just reinitiate a new asynchronous read.
                  readerIAsyncResult = reader.BeginRead(1, readerAsyncCallback, null);
                  Console.WriteLine("Timeout");
               }
               else
               {
                  CANSession.Dispose();
                  CANSession = null;
                  MessageBox.Show(this, ex.Message, "Error");
                  InitUI(false);
               }
            }
         }
      }

      private void UpdateReceiveUI(CANFrame[] frames)
      {
         if (this.InvokeRequired)
         {
            UpdateUIDelegate uidlg = new UpdateUIDelegate(UpdateReceiveUI);
            Invoke(uidlg, new object[] { frames });
         }
         else
         {
            foreach(CANFrame frame in frames)
            {
               ListViewItem item = new ListViewItem("0x" + frame.Id.ToString("X"), 0);
               item.SubItems.Add(frame.Type.ToString());
               item.SubItems.Add(frame.DataSize.ToString());
               if(frame.DataSize > 0)
               {
                  string data = "";
                  for(int b=0; b<frame.DataSize; b++)
                  {
                     data = data + "0x" + frame.Data[b].ToString("X") + " ";
                  }
                  item.SubItems.Add(data);
               }

               ReceiveList.Items.Add(item);

               // scroll content of listview to new item
               item.EnsureVisible();
            }
         }
      }
	}
}
