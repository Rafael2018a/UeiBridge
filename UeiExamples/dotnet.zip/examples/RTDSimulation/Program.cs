﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace RTDSimulation
{
   class Program
   {
      static void Main(string[] args)
      {
         Session rtdSimSession = new Session();
         Session guardianSession = new Session();

         try
         {
            // Create TC simulation session with 8 channels.
            rtdSimSession.CreateSimulatedRTDChannel("pdna://192.168.100.55/dev0/ao0:7", 
                                                    RTDType.Type3850, 100.0,  TemperatureScale.Celsius);
            rtdSimSession.ConfigureTimingForSimpleIO();

            // Create 3 AI channels for each output channel to read diagnostics
            // Each TC output channel is associated with three guardian channels starting at offset tc_chan * 8
            guardianSession.CreateAIChannel("pdna://192.168.100.55/dev0/ai+16,32,17,33,18,34,19,35,20,36,21,37,22,38,23,39", -10.0, 10.0, AIChannelInputMode.Differential);
            guardianSession.ConfigureTimingForSimpleIO();

            // Create a writer to update the output channels
            AnalogScaledWriter writer = new AnalogScaledWriter(rtdSimSession.GetDataStream());
            double[] aoData = new double[rtdSimSession.GetNumberOfChannels()];

            // Create a circuit breaker object per output channel to monitor circuit breaker status and eventually reset them
            CircuitBreaker[] cbs = new CircuitBreaker[rtdSimSession.GetNumberOfChannels()];
            int[] breakCount = new int[rtdSimSession.GetNumberOfChannels()];
            for (int ch = 0; ch < rtdSimSession.GetNumberOfChannels(); ch++)
            {
               cbs[ch] = new CircuitBreaker(rtdSimSession.GetDataStream(), rtdSimSession.GetChannel(ch).GetIndex());
               breakCount[ch] = 0;
            }
           
            // Create a reader to retrieve diagnostics
            AnalogScaledReader guardianReader = new AnalogScaledReader(guardianSession.GetDataStream());
            double[] diagData;

            rtdSimSession.Start();
            guardianSession.Start();

            // Establish an event handler to process key press events.
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

            int count = 0;
            stop = false;
            while (!stop)
            {
               // Update outputs on each channel
               for (int ch = 0; ch < rtdSimSession.GetNumberOfChannels(); ch++)
               {
                  // vary temperature from -100 to +100
                  aoData[ch] = 300 + ((count*10) % 100);
               }
               writer.WriteSingleScan(aoData);

               // Read and display diagnostics
               diagData = guardianReader.ReadSingleScan();

               for (int ch = 0; ch < rtdSimSession.GetNumberOfChannels(); ch++)
               {
                  Console.WriteLine("Output Channel " + rtdSimSession.GetChannel(ch).GetIndex() + " diagnostics:");
                  Console.WriteLine("  Current = " + diagData[ch * 2]);
                  Console.WriteLine("  ADC internal temperature = " + diagData[ch * 2 + 1]);

                  // Monitor CB status
                  uint currStatus=0, stickyStatus=0;
                  cbs[ch].GetStatus(ref currStatus, ref stickyStatus);

                  if ((currStatus & (1U << rtdSimSession.GetChannel(ch).GetIndex())) > 0)
                  {
                     breakCount[ch]++;
                  }

                  Console.WriteLine("  CB Status: curr = " + currStatus.ToString("X") + " sticky = " + stickyStatus.ToString("X"));
                  
                  // reset breaker after 5 iterations
                  if (breakCount[ch] > 5)
                  {
                     Console.WriteLine("Resetting breaker for channel {0}", ch);
                     //cbs[ch].Reset(1U << aoSession.GetChannel(ch).GetIndex());
                     breakCount[ch] = 0;
                  }
               }

               Console.WriteLine("");

               Thread.Sleep(500);
               count++;
            }

            rtdSimSession.Stop();
            guardianSession.Stop();
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop= false;
   }
}
