﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using UeiDaq;


namespace AIMultipleSynchronizedCubes
{
    public partial class frmMain : Form
    {
        private delegate void UpdateUIDelegate(int sessionIndex, double[,] analogData);
        private delegate void UpdateErrorDelegate(int sessionIndex, string errorMessage);
        private Session[] mySs;

        private AnalogScaledReader[] analogReader;

        private Thread daqThread;

        
        private bool runFlag = false;

        TextBox[] resourceString = new TextBox[6];
        TextBox[] firstLayer = new TextBox[6];
        TextBox[] numLayers = new TextBox[6];
        TextBox[] numChannels = new TextBox[6];
        CheckBox[] enableIom = new CheckBox[6];

        int sessionCount = 0;
        int errorFlag = 0;

        public frmMain()
        {

            InitializeComponent();

            //initilize resource string text boxes
            resourceString[0] = txtResourceSlave0;
            resourceString[0].Text = Properties.Settings.Default["MasterResource"].ToString();
            resourceString[1] = txtResourceSlave1;
            resourceString[1].Text = Properties.Settings.Default["Slave1Resource"].ToString();
            resourceString[2] = txtResourceSlave2;
            resourceString[2].Text = Properties.Settings.Default["Slave2Resource"].ToString();
            resourceString[3] = txtResourceSlave3;
            resourceString[3].Text = Properties.Settings.Default["Slave3Resource"].ToString();
            resourceString[4] = txtResourceSlave4;
            resourceString[4].Text = Properties.Settings.Default["Slave4Resource"].ToString();
            resourceString[5] = txtResourceSlave5;
            resourceString[5].Text = Properties.Settings.Default["Slave5Resource"].ToString();

            //initilize num layers text boxes
            numLayers[0] = txtNumLayersSlave0;
            numLayers[0].Text = Properties.Settings.Default["MasterNumberLayers"].ToString();
            numLayers[1] = txtNumLayersSlave1;
            numLayers[1].Text = Properties.Settings.Default["Slave1NumberLayers"].ToString();
            numLayers[2] = txtNumLayersSlave2;
            numLayers[2].Text = Properties.Settings.Default["Slave2NumberLayers"].ToString();
            numLayers[3] = txtNumLayersSlave3;
            numLayers[3].Text = Properties.Settings.Default["Slave3NumberLayers"].ToString();
            numLayers[4] = txtNumLayersSlave4;
            numLayers[4].Text = Properties.Settings.Default["Slave4NumberLayers"].ToString();
            numLayers[5] = txtNumLayersSlave5;
            numLayers[5].Text = Properties.Settings.Default["Slave5NumberLayers"].ToString();

            //initilize num layers text boxes
            firstLayer[0] = txtFirstLayer0;
            firstLayer[0].Text = Properties.Settings.Default["MasterFirstLayer"].ToString();
            firstLayer[1] = txtFirstLayer1;
            firstLayer[1].Text = Properties.Settings.Default["Slave1FirstLayer"].ToString();
            firstLayer[2] = txtFirstLayer2;
            firstLayer[2].Text = Properties.Settings.Default["Slave2FirstLayer"].ToString();
            firstLayer[3] = txtFirstLayer3;
            firstLayer[3].Text = Properties.Settings.Default["Slave3FirstLayer"].ToString();
            firstLayer[4] = txtFirstLayer4;
            firstLayer[4].Text = Properties.Settings.Default["Slave4FirstLayer"].ToString();
            firstLayer[5] = txtFirstLayer5;
            firstLayer[5].Text = Properties.Settings.Default["Slave5FirstLayer"].ToString();

            //initialize num channels text boxes
            numChannels[0] = txtNumChanSlave0;
            numChannels[0].Text = Properties.Settings.Default["MasterNumberchannels"].ToString();
            numChannels[1] = txtNumChanSlave1;
            numChannels[1].Text = Properties.Settings.Default["Slave1Numberchannels"].ToString();
            numChannels[2] = txtNumChanSlave2;
            numChannels[2].Text = Properties.Settings.Default["Slave2Numberchannels"].ToString();
            numChannels[3] = txtNumChanSlave3;
            numChannels[3].Text = Properties.Settings.Default["Slave3Numberchannels"].ToString();
            numChannels[4] = txtNumChanSlave4;
            numChannels[4].Text = Properties.Settings.Default["Slave4Numberchannels"].ToString();
            numChannels[5] = txtNumChanSlave5;
            numChannels[5].Text = Properties.Settings.Default["Slave5Numberchannels"].ToString();

            //initialize enable check boxes
            enableIom[0] = chkEnabledSlave0;
            enableIom[1] = chkEnabledSlave1;
            enableIom[2] = chkEnabledSlave2;
            enableIom[3] = chkEnabledSlave3;
            enableIom[4] = chkEnabledSlave4;
            enableIom[5] = chkEnabledSlave5;

            txtSamPerChan.Text = Properties.Settings.Default["ScansPerChannel"].ToString();
            txtSampleRate.Text = Properties.Settings.Default["ScanRate"].ToString();
            txtTimeout.Text = Properties.Settings.Default["Timeout"].ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnStop.Enabled = false;

            enableIom[0].Checked = true;

            chkSyncDev.Checked = true;
        }

        private void Form1_Closing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default["MasterResource"] = resourceString[0].Text;
            Properties.Settings.Default["Slave1Resource"] = resourceString[1].Text;
            Properties.Settings.Default["Slave2Resource"] = resourceString[2].Text;
            Properties.Settings.Default["Slave3Resource"] = resourceString[3].Text;
            Properties.Settings.Default["Slave4Resource"] = resourceString[4].Text;
            Properties.Settings.Default["Slave5Resource"] = resourceString[5].Text;

            Properties.Settings.Default["MasterNumberLayers"] = numLayers[0].Text;
            Properties.Settings.Default["Slave1NumberLayers"] = numLayers[1].Text;
            Properties.Settings.Default["Slave2NumberLayers"] = numLayers[2].Text;
            Properties.Settings.Default["Slave3NumberLayers"] = numLayers[3].Text;
            Properties.Settings.Default["Slave4NumberLayers"] = numLayers[4].Text;
            Properties.Settings.Default["Slave5NumberLayers"] = numLayers[5].Text;

            Properties.Settings.Default["MasterFirstLayer"] = firstLayer[0].Text;
            Properties.Settings.Default["Slave1FirstLayer"] = firstLayer[1].Text;
            Properties.Settings.Default["Slave2FirstLayer"] = firstLayer[2].Text;
            Properties.Settings.Default["Slave3FirstLayer"] = firstLayer[3].Text;
            Properties.Settings.Default["Slave4FirstLayer"] = firstLayer[4].Text;
            Properties.Settings.Default["Slave5FirstLayer"] = firstLayer[5].Text;

            Properties.Settings.Default["MasterNumberChannels"] = numChannels[0].Text;
            Properties.Settings.Default["Slave1NumberChannels"] = numChannels[1].Text;
            Properties.Settings.Default["Slave2NumberChannels"] = numChannels[2].Text;
            Properties.Settings.Default["Slave3NumberChannels"] = numChannels[3].Text;
            Properties.Settings.Default["Slave4NumberChannels"] = numChannels[4].Text;
            Properties.Settings.Default["Slave5NumberChannels"] = numChannels[5].Text;

            Properties.Settings.Default["ScansPerChannel"] = txtSamPerChan.Text;
            Properties.Settings.Default["ScanRate"] = txtSampleRate.Text;
            Properties.Settings.Default["Timeout"] = txtTimeout.Text;

            Properties.Settings.Default.Save();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            // Clear error from previous run
            txtErrorText.Text = "";

            // Create 3 columns to display device, totalScans, AvailableScans in status list view
            lstStatusList.Columns.Clear();

            //Adding the Text "Device" as a column header
            ColumnHeader colHeader = new ColumnHeader();
            colHeader.Text = "Device";
            colHeader.Width = 200;
            lstStatusList.Columns.Add(colHeader);

            //Adding the text "totalScans" as a column header
            colHeader = new ColumnHeader();
            colHeader.Text = "Total Scans";
            colHeader.Width = 100;
            lstStatusList.Columns.Add(colHeader);

            //Adding the text Available Scans as a column header
            colHeader = new ColumnHeader();
            colHeader.Text = "Available Scans";
            colHeader.Width = 100;
            lstStatusList.Columns.Add(colHeader);

            lstStatusList.View = View.Details;
            lstStatusList.FullRowSelect = true;
            lstStatusList.GridLines = true;


            List<string> resourceStrings = new List<string>();

            //Find out how many sessions we need to create.
            //create one session per layer per rack or cube.
            //so if you had for example 2 racks "enabled" and
            //each rack the "# Layers" field is set to 6, then you 
            //have 12 sessions.

            //Find out how many racks are being used.
            for (int rackIndex = 0; rackIndex < resourceString.Length; rackIndex++)
            {
                if (enableIom[rackIndex].Checked == true)
                {
                    for (int devIndex = 0; devIndex < Convert.ToInt16(numLayers[rackIndex].Text); devIndex++)
                    {
                        int dev = (Convert.ToInt16(firstLayer[rackIndex].Text)) + devIndex;
                        string resource = resourceString[rackIndex].Text + "dev" + dev + "/" + "ai" + 0 + ":" + (Convert.ToInt16(numChannels[rackIndex].Text) - 1).ToString() + ",ts";
                        resourceStrings.Add(resource);
                    }
                }
            }

            sessionCount = resourceStrings.Count;
            mySs = new Session[sessionCount];
            analogReader = new AnalogScaledReader[sessionCount];


            string deviceName = "";

            //Adding initial values into the list view
            lstStatusList.Items.Clear();
            for (int j = 0; j < resourceStrings.Count; j++)
            {
                ListViewItem lvi = new ListViewItem(new[] { resourceStrings[j].ToString(), "0", "0" });
                lstStatusList.Items.Add(lvi);
            }



            //*************************************************
            errorFlag = 0;
            for (int i = 0; i < sessionCount; i++)
            {
                try
                {
                    mySs[i] = new Session();                    
                    mySs[i].CreateAIChannel(resourceStrings[i], -10, 10, AIChannelInputMode.Differential);
                    deviceName = mySs[i].GetDevice().GetDeviceName();
                    
                    if (chkSyncDev.Checked)
                    {
                        // Configuring timing to synchronize all clocks.
                        mySs[i].ConfigureTimingForBufferedIO(Convert.ToInt32(txtSamPerChan.Text), TimingClockSource.External, Convert.ToInt32(txtSampleRate.Text), DigitalEdge.Rising, TimingDuration.Continuous);
      
                                       
                        if (i == 0) //the first layer (first session) on the first RACK will be the master that generate clock signal output.
                        {
                            mySs[i].GetTiming().SetScanClockSourceSignal("PLL3");
                        }
                        else //all the subsequent layers on the master and slave racks are reading in the clock signal
                        {
                            mySs[i].GetTiming().SetScanClockSourceSignal("SyncIn");
                        }
                    }
                    else
                    {
                        // All devices are using their internal clock. They are not synchronized
                        mySs[i].ConfigureTimingForBufferedIO(Convert.ToInt32(txtSamPerChan.Text), TimingClockSource.Internal, Convert.ToInt32(txtSampleRate.Text), DigitalEdge.Rising, TimingDuration.Continuous);
                    }

                    mySs[i].GetTiming().SetTimeout(Convert.ToInt32(txtTimeout.Text));
                    mySs[i].GetDataStream().SetNumberOfFrames(80);
                    analogReader[i] = new AnalogScaledReader(mySs[i].GetDataStream());
                }
                catch (UeiDaqException exception)
                {
                    txtErrorText.Text = "Error configuring " + deviceName + ": " + exception.Error;
                    errorFlag++;
                    break;
                }
            }
            if (errorFlag > 0)
            {
                return;
            }

            // Start all sessions, master last
            for (int i = sessionCount-1; i >=0; i--)
            {
                try
                {
                    deviceName = mySs[i].GetDevice().GetDeviceName();
                    mySs[i].Start();
                }
                catch (UeiDaqException exception)
                {
                    txtErrorText.Text = "Error starting" + deviceName + ": " + exception.Error;
                    errorFlag++;
                    break;
                }
            }

            if (errorFlag > 0)
            {
                // Stop sessions that were already started
                for (int i = 0; i < sessionCount; i++)
                {
                    if (mySs[i].IsRunning())
                    {
                        mySs[i].Stop();
                        mySs[i].Dispose();
                    }
                }
                return;
            }

            // Create and start DAQThread
            runFlag = true;
            daqThread = new Thread(new ThreadStart(DaqThreadProc));
            daqThread.IsBackground = true;
            daqThread.Start();

            btnStop.Enabled = true;
            btnStart.Enabled = false;            
        }


        private void UpdateError(int sessionIndex, string errorMessage)
        {
            string deviceName = mySs[sessionIndex].GetDevice().GetDeviceName();
            txtErrorText.Text = "Error while acquiring from " + deviceName + ": " + errorMessage;
            StopSessions();
        }

        private void UpdateUI(int sessionIndex, double[,] analogData)
        {
            if (runFlag == true)
            {
                /*double yMaxValue = analogData[0, 0];
                double yMinValue = analogData[0, 0];
                double x = Convert.ToDouble(txtSamPerChan.Text);

                //PointPairList graphPts = new PointPairList();
                for (int i = 0; i < channelCount; i++) //# of channels
                {
                    for (int j = 1; j < x; j++) // # of scans
                    {


                        //Find the max value in the analogData array to 
                        //set up Yaxis max value
                        if (analogData[j, i] > yMaxValue)
                        {
                            yMaxValue = analogData[j, i];
                        }
                        //Find the min value in the analogData array to 
                        //set up Yaxis min value
                        if (analogData[j, i] < yMinValue)
                        {
                            yMinValue = analogData[j, i];
                        }
                        graphPts.Add((double)j, (double)analogData[j, i]);
                        
                    }
                }*/

                lstStatusList.Items[sessionIndex].SubItems[1].Text = mySs[sessionIndex].GetDataStream().GetTotalScans().ToString();
                lstStatusList.Items[sessionIndex].SubItems[2].Text = mySs[sessionIndex].GetDataStream().GetAvailableScans().ToString();

            }
        }

        private void DaqThreadProc()
        {
            while (runFlag == true)
            {
                for (int sessionIndex = 0; sessionIndex < sessionCount; sessionIndex++)
                {
                    double[,] analogData = null;

                    if (mySs[sessionIndex].IsRunning() && mySs[sessionIndex].GetType() == SessionType.AI)
                    {
                        try
                        {
                            analogData = analogReader[sessionIndex].ReadMultipleScans(Int32.Parse(txtSamPerChan.Text));
                        }
                        catch (UeiDaqException exception)
                        {
                            BeginInvoke(new UpdateErrorDelegate(UpdateError), new object[] { sessionIndex, exception.Error.ToString() });
                            // Exit thread, the update  error call will clean up the sessions
                            return;
                        }
                            
                    }

                    if (analogData != null)
                    {
                        // Can't update UI in thread, must invoke delegate to update in UI thread.
                        BeginInvoke(new UpdateUIDelegate(UpdateUI), new object[] { sessionIndex, analogData });
                    }
                }
            }

        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            StopSessions();
        }
   
        private void StopSessions()
        {
            if (runFlag)
            {
                runFlag = false;

                // Wait for daqThread to gracefully end        
                daqThread.Join();

                // Clean-up sessions
                for (int i = 0; i < sessionCount; i++)
                {
                    if (mySs != null)
                    {
                        string deviceName="";
                        try
                        {
                            deviceName = mySs[i].GetDevice().GetDeviceName();
                            mySs[i].Stop();
                            mySs[i].Dispose();
                        }
                        catch (UeiDaqException exception)
                        {
                            txtErrorText.Text = "Error stopping" + deviceName + ": " + exception.Error;
                        }
                    }
                }

                mySs = null;
            }

            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnQuit.Enabled = true;
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            StopSessions();
            Application.Exit();
        }

   
    }
}
