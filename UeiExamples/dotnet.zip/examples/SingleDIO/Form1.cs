using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using UeiDaq;

namespace SingleDIO
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.GroupBox groupBox2;
      private System.Windows.Forms.CheckBox DI0;
      private System.Windows.Forms.ImageList imageList1;
      private System.Windows.Forms.CheckBox DI1;
      private System.Windows.Forms.CheckBox DI2;
      private System.Windows.Forms.CheckBox DI3;
      private System.Windows.Forms.CheckBox DI4;
      private System.Windows.Forms.CheckBox DI5;
      private System.Windows.Forms.CheckBox DI6;
      private System.Windows.Forms.CheckBox DI7;
      private System.Windows.Forms.CheckBox DI8;
      private System.Windows.Forms.CheckBox DI13;
      private System.Windows.Forms.CheckBox DI12;
      private System.Windows.Forms.CheckBox DI11;
      private System.Windows.Forms.CheckBox DI10;
      private System.Windows.Forms.CheckBox DI9;
      private System.Windows.Forms.CheckBox DI14;
      private System.Windows.Forms.CheckBox DI15;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.CheckBox DO15;
      private System.Windows.Forms.CheckBox DO9;
      private System.Windows.Forms.CheckBox DO10;
      private System.Windows.Forms.CheckBox DO11;
      private System.Windows.Forms.CheckBox DO12;
      private System.Windows.Forms.CheckBox DO13;
      private System.Windows.Forms.CheckBox DO14;
      private System.Windows.Forms.CheckBox DO8;
      private System.Windows.Forms.CheckBox DO7;
      private System.Windows.Forms.CheckBox DO6;
      private System.Windows.Forms.CheckBox DO5;
      private System.Windows.Forms.CheckBox DO4;
      private System.Windows.Forms.CheckBox DO3;
      private System.Windows.Forms.CheckBox DO2;
      private System.Windows.Forms.CheckBox DO1;
      private System.Windows.Forms.CheckBox DO0;
      private System.ComponentModel.IContainer components;
      private Session diSs;
      private Session doSs;
      private DigitalWriter doWriter;
      private DigitalReader diReader;
      private UInt16[] diData;
      private System.Windows.Forms.Timer DITimer;
      private System.Windows.Forms.TextBox DigOutputResource;
      private System.Windows.Forms.ComboBox DigitalOutputPort;
      private System.Windows.Forms.ComboBox DigitalInputPort;
      private System.Windows.Forms.TextBox DigInputResource;
      private UInt16[] doData;
      private CheckBox[] diLines;
      private CheckBox[] doLines;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

         diLines = new CheckBox[16];
         diLines[0] = DI0;
         diLines[1] = DI1;
         diLines[2] = DI2;
         diLines[3] = DI3; 
         diLines[4] = DI4;
         diLines[5] = DI5;
         diLines[6] = DI6;
         diLines[7] = DI7;
         diLines[8] = DI8;
         diLines[9] = DI9;
         diLines[10] = DI10;
         diLines[11] = DI11;
         diLines[12] = DI12;
         diLines[13] = DI13;
         diLines[14] = DI14;
         diLines[15] = DI15;

         doLines = new CheckBox[16];
         doLines[0] = DO0;
         doLines[1] = DO1;
         doLines[2] = DO2;
         doLines[3] = DO3; 
         doLines[4] = DO4;
         doLines[5] = DO5;
         doLines[6] = DO6;
         doLines[7] = DO7;
         doLines[8] = DO8;
         doLines[9] = DO9;
         doLines[10] = DO10;
         doLines[11] = DO11;
         doLines[12] = DO12;
         doLines[13] = DO13;
         doLines[14] = DO14;
         doLines[15] = DO15;

			Stop.Enabled = false;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.components = new System.ComponentModel.Container();
         System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
         this.DigOutputResource = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.Stop = new System.Windows.Forms.Button();
         this.Quit = new System.Windows.Forms.Button();
         this.Go = new System.Windows.Forms.Button();
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.DigitalOutputPort = new System.Windows.Forms.ComboBox();
         this.DO15 = new System.Windows.Forms.CheckBox();
         this.imageList1 = new System.Windows.Forms.ImageList(this.components);
         this.DO9 = new System.Windows.Forms.CheckBox();
         this.DO10 = new System.Windows.Forms.CheckBox();
         this.DO11 = new System.Windows.Forms.CheckBox();
         this.DO12 = new System.Windows.Forms.CheckBox();
         this.DO13 = new System.Windows.Forms.CheckBox();
         this.DO14 = new System.Windows.Forms.CheckBox();
         this.DO8 = new System.Windows.Forms.CheckBox();
         this.DO7 = new System.Windows.Forms.CheckBox();
         this.DO6 = new System.Windows.Forms.CheckBox();
         this.DO5 = new System.Windows.Forms.CheckBox();
         this.DO4 = new System.Windows.Forms.CheckBox();
         this.DO3 = new System.Windows.Forms.CheckBox();
         this.DO2 = new System.Windows.Forms.CheckBox();
         this.DO1 = new System.Windows.Forms.CheckBox();
         this.DO0 = new System.Windows.Forms.CheckBox();
         this.groupBox2 = new System.Windows.Forms.GroupBox();
         this.DigitalInputPort = new System.Windows.Forms.ComboBox();
         this.DI15 = new System.Windows.Forms.CheckBox();
         this.DI9 = new System.Windows.Forms.CheckBox();
         this.DI10 = new System.Windows.Forms.CheckBox();
         this.DI11 = new System.Windows.Forms.CheckBox();
         this.DI12 = new System.Windows.Forms.CheckBox();
         this.DI13 = new System.Windows.Forms.CheckBox();
         this.DI14 = new System.Windows.Forms.CheckBox();
         this.DI8 = new System.Windows.Forms.CheckBox();
         this.DI7 = new System.Windows.Forms.CheckBox();
         this.DI6 = new System.Windows.Forms.CheckBox();
         this.DI5 = new System.Windows.Forms.CheckBox();
         this.DI4 = new System.Windows.Forms.CheckBox();
         this.DI3 = new System.Windows.Forms.CheckBox();
         this.DI2 = new System.Windows.Forms.CheckBox();
         this.DigInputResource = new System.Windows.Forms.TextBox();
         this.DI1 = new System.Windows.Forms.CheckBox();
         this.DI0 = new System.Windows.Forms.CheckBox();
         this.label1 = new System.Windows.Forms.Label();
         this.DITimer = new System.Windows.Forms.Timer(this.components);
         this.groupBox1.SuspendLayout();
         this.groupBox2.SuspendLayout();
         this.SuspendLayout();
         // 
         // DigOutputResource
         // 
         this.DigOutputResource.Location = new System.Drawing.Point(16, 48);
         this.DigOutputResource.Name = "DigOutputResource";
         this.DigOutputResource.Size = new System.Drawing.Size(112, 20);
         this.DigOutputResource.TabIndex = 17;
         this.DigOutputResource.Text = "simu://Dev2/Do0,1";
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(16, 32);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(120, 16);
         this.label2.TabIndex = 18;
         this.label2.Text = "Resource name";
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(208, 256);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(112, 32);
         this.Stop.TabIndex = 21;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(352, 256);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(112, 32);
         this.Quit.TabIndex = 20;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(64, 256);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(112, 32);
         this.Go.TabIndex = 19;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // ErrorText
         // 
         this.ErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
         this.ErrorText.Location = new System.Drawing.Point(0, 294);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(544, 48);
         this.ErrorText.TabIndex = 22;
         this.ErrorText.Text = "";
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.DigitalOutputPort);
         this.groupBox1.Controls.Add(this.DO15);
         this.groupBox1.Controls.Add(this.DO9);
         this.groupBox1.Controls.Add(this.DO10);
         this.groupBox1.Controls.Add(this.DO11);
         this.groupBox1.Controls.Add(this.DO12);
         this.groupBox1.Controls.Add(this.DO13);
         this.groupBox1.Controls.Add(this.DO14);
         this.groupBox1.Controls.Add(this.DO8);
         this.groupBox1.Controls.Add(this.DO7);
         this.groupBox1.Controls.Add(this.DO6);
         this.groupBox1.Controls.Add(this.DO5);
         this.groupBox1.Controls.Add(this.DO4);
         this.groupBox1.Controls.Add(this.DO3);
         this.groupBox1.Controls.Add(this.DO2);
         this.groupBox1.Controls.Add(this.DO1);
         this.groupBox1.Controls.Add(this.DO0);
         this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
         this.groupBox1.Location = new System.Drawing.Point(8, 8);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(528, 120);
         this.groupBox1.TabIndex = 24;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Digital Output Port";
         // 
         // DigitalOutputPort
         // 
         this.DigitalOutputPort.Location = new System.Drawing.Point(184, 40);
         this.DigitalOutputPort.Name = "DigitalOutputPort";
         this.DigitalOutputPort.Size = new System.Drawing.Size(160, 21);
         this.DigitalOutputPort.TabIndex = 16;
         // 
         // DO15
         // 
         this.DO15.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO15.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO15.ImageIndex = 0;
         this.DO15.ImageList = this.imageList1;
         this.DO15.Location = new System.Drawing.Point(488, 72);
         this.DO15.Name = "DO15";
         this.DO15.Size = new System.Drawing.Size(32, 32);
         this.DO15.TabIndex = 15;
         this.DO15.Text = "15";
         this.DO15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO15.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // imageList1
         // 
         this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
         this.imageList1.ImageSize = new System.Drawing.Size(24, 24);
         this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
         this.imageList1.TransparentColor = System.Drawing.Color.White;
         // 
         // DO9
         // 
         this.DO9.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO9.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO9.ImageIndex = 0;
         this.DO9.ImageList = this.imageList1;
         this.DO9.Location = new System.Drawing.Point(296, 72);
         this.DO9.Name = "DO9";
         this.DO9.Size = new System.Drawing.Size(32, 32);
         this.DO9.TabIndex = 14;
         this.DO9.Text = "9";
         this.DO9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO9.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO10
         // 
         this.DO10.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO10.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO10.ImageIndex = 0;
         this.DO10.ImageList = this.imageList1;
         this.DO10.Location = new System.Drawing.Point(328, 72);
         this.DO10.Name = "DO10";
         this.DO10.Size = new System.Drawing.Size(32, 32);
         this.DO10.TabIndex = 13;
         this.DO10.Text = "10";
         this.DO10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO10.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO11
         // 
         this.DO11.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO11.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO11.ImageIndex = 0;
         this.DO11.ImageList = this.imageList1;
         this.DO11.Location = new System.Drawing.Point(360, 72);
         this.DO11.Name = "DO11";
         this.DO11.Size = new System.Drawing.Size(32, 32);
         this.DO11.TabIndex = 12;
         this.DO11.Text = "11";
         this.DO11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO11.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO12
         // 
         this.DO12.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO12.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO12.ImageIndex = 0;
         this.DO12.ImageList = this.imageList1;
         this.DO12.Location = new System.Drawing.Point(392, 72);
         this.DO12.Name = "DO12";
         this.DO12.Size = new System.Drawing.Size(32, 32);
         this.DO12.TabIndex = 11;
         this.DO12.Text = "12";
         this.DO12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO12.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO13
         // 
         this.DO13.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO13.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO13.ImageIndex = 0;
         this.DO13.ImageList = this.imageList1;
         this.DO13.Location = new System.Drawing.Point(424, 72);
         this.DO13.Name = "DO13";
         this.DO13.Size = new System.Drawing.Size(32, 32);
         this.DO13.TabIndex = 10;
         this.DO13.Text = "13";
         this.DO13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO13.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO14
         // 
         this.DO14.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO14.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO14.ImageIndex = 0;
         this.DO14.ImageList = this.imageList1;
         this.DO14.Location = new System.Drawing.Point(456, 72);
         this.DO14.Name = "DO14";
         this.DO14.Size = new System.Drawing.Size(32, 32);
         this.DO14.TabIndex = 9;
         this.DO14.Text = "14";
         this.DO14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO14.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO8
         // 
         this.DO8.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO8.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO8.ImageIndex = 0;
         this.DO8.ImageList = this.imageList1;
         this.DO8.Location = new System.Drawing.Point(264, 72);
         this.DO8.Name = "DO8";
         this.DO8.Size = new System.Drawing.Size(32, 32);
         this.DO8.TabIndex = 8;
         this.DO8.Text = "8";
         this.DO8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO8.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO7
         // 
         this.DO7.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO7.ImageIndex = 0;
         this.DO7.ImageList = this.imageList1;
         this.DO7.Location = new System.Drawing.Point(232, 72);
         this.DO7.Name = "DO7";
         this.DO7.Size = new System.Drawing.Size(32, 32);
         this.DO7.TabIndex = 7;
         this.DO7.Text = "7";
         this.DO7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO7.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO6
         // 
         this.DO6.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO6.ImageIndex = 0;
         this.DO6.ImageList = this.imageList1;
         this.DO6.Location = new System.Drawing.Point(200, 72);
         this.DO6.Name = "DO6";
         this.DO6.Size = new System.Drawing.Size(32, 32);
         this.DO6.TabIndex = 6;
         this.DO6.Text = "6";
         this.DO6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO6.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO5
         // 
         this.DO5.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO5.ImageIndex = 0;
         this.DO5.ImageList = this.imageList1;
         this.DO5.Location = new System.Drawing.Point(168, 72);
         this.DO5.Name = "DO5";
         this.DO5.Size = new System.Drawing.Size(32, 32);
         this.DO5.TabIndex = 5;
         this.DO5.Text = "5";
         this.DO5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO5.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO4
         // 
         this.DO4.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO4.ImageIndex = 0;
         this.DO4.ImageList = this.imageList1;
         this.DO4.Location = new System.Drawing.Point(136, 72);
         this.DO4.Name = "DO4";
         this.DO4.Size = new System.Drawing.Size(32, 32);
         this.DO4.TabIndex = 4;
         this.DO4.Text = "4";
         this.DO4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO4.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO3
         // 
         this.DO3.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO3.ImageIndex = 0;
         this.DO3.ImageList = this.imageList1;
         this.DO3.Location = new System.Drawing.Point(104, 72);
         this.DO3.Name = "DO3";
         this.DO3.Size = new System.Drawing.Size(32, 32);
         this.DO3.TabIndex = 3;
         this.DO3.Text = "3";
         this.DO3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO3.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO2
         // 
         this.DO2.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO2.ImageIndex = 0;
         this.DO2.ImageList = this.imageList1;
         this.DO2.Location = new System.Drawing.Point(72, 72);
         this.DO2.Name = "DO2";
         this.DO2.Size = new System.Drawing.Size(32, 32);
         this.DO2.TabIndex = 2;
         this.DO2.Text = "2";
         this.DO2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO2.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO1
         // 
         this.DO1.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO1.ImageIndex = 0;
         this.DO1.ImageList = this.imageList1;
         this.DO1.Location = new System.Drawing.Point(40, 72);
         this.DO1.Name = "DO1";
         this.DO1.Size = new System.Drawing.Size(32, 32);
         this.DO1.TabIndex = 1;
         this.DO1.Text = "1";
         this.DO1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO1.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // DO0
         // 
         this.DO0.Appearance = System.Windows.Forms.Appearance.Button;
         this.DO0.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO0.ImageIndex = 0;
         this.DO0.ImageList = this.imageList1;
         this.DO0.Location = new System.Drawing.Point(8, 72);
         this.DO0.Name = "DO0";
         this.DO0.Size = new System.Drawing.Size(32, 32);
         this.DO0.TabIndex = 0;
         this.DO0.Text = "0";
         this.DO0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DO0.CheckedChanged += new System.EventHandler(this.OnDOChange);
         // 
         // groupBox2
         // 
         this.groupBox2.Controls.Add(this.DigitalInputPort);
         this.groupBox2.Controls.Add(this.DI15);
         this.groupBox2.Controls.Add(this.DI9);
         this.groupBox2.Controls.Add(this.DI10);
         this.groupBox2.Controls.Add(this.DI11);
         this.groupBox2.Controls.Add(this.DI12);
         this.groupBox2.Controls.Add(this.DI13);
         this.groupBox2.Controls.Add(this.DI14);
         this.groupBox2.Controls.Add(this.DI8);
         this.groupBox2.Controls.Add(this.DI7);
         this.groupBox2.Controls.Add(this.DI6);
         this.groupBox2.Controls.Add(this.DI5);
         this.groupBox2.Controls.Add(this.DI4);
         this.groupBox2.Controls.Add(this.DI3);
         this.groupBox2.Controls.Add(this.DI2);
         this.groupBox2.Controls.Add(this.DigInputResource);
         this.groupBox2.Controls.Add(this.DI1);
         this.groupBox2.Controls.Add(this.DI0);
         this.groupBox2.Controls.Add(this.label1);
         this.groupBox2.Location = new System.Drawing.Point(8, 136);
         this.groupBox2.Name = "groupBox2";
         this.groupBox2.Size = new System.Drawing.Size(528, 112);
         this.groupBox2.TabIndex = 25;
         this.groupBox2.TabStop = false;
         this.groupBox2.Text = "Digital Input Port";
         // 
         // DigitalInputPort
         // 
         this.DigitalInputPort.Location = new System.Drawing.Point(184, 32);
         this.DigitalInputPort.Name = "DigitalInputPort";
         this.DigitalInputPort.Size = new System.Drawing.Size(160, 21);
         this.DigitalInputPort.TabIndex = 35;
         // 
         // DI15
         // 
         this.DI15.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI15.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI15.ImageIndex = 0;
         this.DI15.ImageList = this.imageList1;
         this.DI15.Location = new System.Drawing.Point(488, 64);
         this.DI15.Name = "DI15";
         this.DI15.Size = new System.Drawing.Size(32, 32);
         this.DI15.TabIndex = 34;
         this.DI15.Text = "15";
         this.DI15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI9
         // 
         this.DI9.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI9.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI9.ImageIndex = 0;
         this.DI9.ImageList = this.imageList1;
         this.DI9.Location = new System.Drawing.Point(296, 64);
         this.DI9.Name = "DI9";
         this.DI9.Size = new System.Drawing.Size(32, 32);
         this.DI9.TabIndex = 33;
         this.DI9.Text = "9";
         this.DI9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI10
         // 
         this.DI10.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI10.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI10.ImageIndex = 0;
         this.DI10.ImageList = this.imageList1;
         this.DI10.Location = new System.Drawing.Point(328, 64);
         this.DI10.Name = "DI10";
         this.DI10.Size = new System.Drawing.Size(32, 32);
         this.DI10.TabIndex = 32;
         this.DI10.Text = "10";
         this.DI10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI11
         // 
         this.DI11.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI11.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI11.ImageIndex = 0;
         this.DI11.ImageList = this.imageList1;
         this.DI11.Location = new System.Drawing.Point(360, 64);
         this.DI11.Name = "DI11";
         this.DI11.Size = new System.Drawing.Size(32, 32);
         this.DI11.TabIndex = 31;
         this.DI11.Text = "11";
         this.DI11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI12
         // 
         this.DI12.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI12.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI12.ImageIndex = 0;
         this.DI12.ImageList = this.imageList1;
         this.DI12.Location = new System.Drawing.Point(392, 64);
         this.DI12.Name = "DI12";
         this.DI12.Size = new System.Drawing.Size(32, 32);
         this.DI12.TabIndex = 30;
         this.DI12.Text = "12";
         this.DI12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI13
         // 
         this.DI13.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI13.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI13.ImageIndex = 0;
         this.DI13.ImageList = this.imageList1;
         this.DI13.Location = new System.Drawing.Point(424, 64);
         this.DI13.Name = "DI13";
         this.DI13.Size = new System.Drawing.Size(32, 32);
         this.DI13.TabIndex = 29;
         this.DI13.Text = "13";
         this.DI13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI14
         // 
         this.DI14.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI14.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI14.ImageIndex = 0;
         this.DI14.ImageList = this.imageList1;
         this.DI14.Location = new System.Drawing.Point(456, 64);
         this.DI14.Name = "DI14";
         this.DI14.Size = new System.Drawing.Size(32, 32);
         this.DI14.TabIndex = 28;
         this.DI14.Text = "14";
         this.DI14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI8
         // 
         this.DI8.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI8.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI8.ImageIndex = 0;
         this.DI8.ImageList = this.imageList1;
         this.DI8.Location = new System.Drawing.Point(264, 64);
         this.DI8.Name = "DI8";
         this.DI8.Size = new System.Drawing.Size(32, 32);
         this.DI8.TabIndex = 27;
         this.DI8.Text = "8";
         this.DI8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI7
         // 
         this.DI7.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI7.ImageIndex = 0;
         this.DI7.ImageList = this.imageList1;
         this.DI7.Location = new System.Drawing.Point(232, 64);
         this.DI7.Name = "DI7";
         this.DI7.Size = new System.Drawing.Size(32, 32);
         this.DI7.TabIndex = 26;
         this.DI7.Text = "7";
         this.DI7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI6
         // 
         this.DI6.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI6.ImageIndex = 0;
         this.DI6.ImageList = this.imageList1;
         this.DI6.Location = new System.Drawing.Point(200, 64);
         this.DI6.Name = "DI6";
         this.DI6.Size = new System.Drawing.Size(32, 32);
         this.DI6.TabIndex = 25;
         this.DI6.Text = "6";
         this.DI6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI5
         // 
         this.DI5.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI5.ImageIndex = 0;
         this.DI5.ImageList = this.imageList1;
         this.DI5.Location = new System.Drawing.Point(168, 64);
         this.DI5.Name = "DI5";
         this.DI5.Size = new System.Drawing.Size(32, 32);
         this.DI5.TabIndex = 24;
         this.DI5.Text = "5";
         this.DI5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI4
         // 
         this.DI4.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI4.ImageIndex = 0;
         this.DI4.ImageList = this.imageList1;
         this.DI4.Location = new System.Drawing.Point(136, 64);
         this.DI4.Name = "DI4";
         this.DI4.Size = new System.Drawing.Size(32, 32);
         this.DI4.TabIndex = 23;
         this.DI4.Text = "4";
         this.DI4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI3
         // 
         this.DI3.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI3.ImageIndex = 0;
         this.DI3.ImageList = this.imageList1;
         this.DI3.Location = new System.Drawing.Point(104, 64);
         this.DI3.Name = "DI3";
         this.DI3.Size = new System.Drawing.Size(32, 32);
         this.DI3.TabIndex = 22;
         this.DI3.Text = "3";
         this.DI3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI2
         // 
         this.DI2.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI2.ImageIndex = 0;
         this.DI2.ImageList = this.imageList1;
         this.DI2.Location = new System.Drawing.Point(72, 64);
         this.DI2.Name = "DI2";
         this.DI2.Size = new System.Drawing.Size(32, 32);
         this.DI2.TabIndex = 21;
         this.DI2.Text = "2";
         this.DI2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DigInputResource
         // 
         this.DigInputResource.Location = new System.Drawing.Point(8, 40);
         this.DigInputResource.Name = "DigInputResource";
         this.DigInputResource.Size = new System.Drawing.Size(112, 20);
         this.DigInputResource.TabIndex = 36;
         this.DigInputResource.Text = "simu://Dev2/Di2,3";
         // 
         // DI1
         // 
         this.DI1.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI1.ImageIndex = 0;
         this.DI1.ImageList = this.imageList1;
         this.DI1.Location = new System.Drawing.Point(40, 64);
         this.DI1.Name = "DI1";
         this.DI1.Size = new System.Drawing.Size(32, 32);
         this.DI1.TabIndex = 20;
         this.DI1.Text = "1";
         this.DI1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // DI0
         // 
         this.DI0.Appearance = System.Windows.Forms.Appearance.Button;
         this.DI0.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
         this.DI0.ImageIndex = 0;
         this.DI0.ImageList = this.imageList1;
         this.DI0.Location = new System.Drawing.Point(8, 64);
         this.DI0.Name = "DI0";
         this.DI0.Size = new System.Drawing.Size(32, 32);
         this.DI0.TabIndex = 19;
         this.DI0.Text = "0";
         this.DI0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(8, 24);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(120, 16);
         this.label1.TabIndex = 37;
         this.label1.Text = "Resource name";
         // 
         // DITimer
         // 
         this.DITimer.Interval = 1;
         this.DITimer.Tick += new System.EventHandler(this.Timer_Tick);
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(544, 342);
         this.Controls.Add(this.groupBox2);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Controls.Add(this.DigOutputResource);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.groupBox1);
         this.Name = "Form1";
         this.Text = "Form1";
         this.groupBox1.ResumeLayout(false);
         this.groupBox2.ResumeLayout(false);
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private void Quit_Click(object sender, System.EventArgs e)
      {
         Application.Exit();
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         ErrorText.Clear();
         DigitalInputPort.Items.Clear();
         DigitalOutputPort.Items.Clear();
                              
         try
         {
            // Initializes Digital input session
            diSs = new Session();
            diSs.CreateDIChannel(DigInputResource.Text);
               
            for(int i=0; i<diSs.GetNumberOfChannels(); i++)
            {
               DigitalInputPort.Items.Add("Port " + diSs.GetChannel(i).GetIndex().ToString());
            }
            DigitalInputPort.SelectedIndex = 0;

            diSs.ConfigureTimingForSimpleIO();

            // Create a reader object to read data synchronously.
            diReader = new DigitalReader(diSs.GetDataStream());

            // Initializes Digital output session
            doSs = new Session();
            doSs.CreateDOChannel(DigOutputResource.Text);
               
            for(int i=0; i<doSs.GetNumberOfChannels(); i++)
            {
               DigitalOutputPort.Items.Add("Port " + doSs.GetChannel(i).GetIndex().ToString());
            }
            DigitalOutputPort.SelectedIndex = 0;
            doData = new UInt16[doSs.GetNumberOfChannels()];

            doSs.ConfigureTimingForSimpleIO();

            // Create a reader object to read data synchronously.
            doWriter = new DigitalWriter(doSs.GetDataStream());

            diSs.Start();
            doSs.Start();

            DITimer = new Timer();
            DITimer.Interval=10;
            DITimer.Start();
            DITimer.Tick+=new EventHandler(Timer_Tick);
  
            DigInputResource.Enabled = false;
            DigOutputResource.Enabled = false;
            Go.Enabled = false;
            Stop.Enabled = true;
         }
         catch(UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            if(diSs != null)
            {
               diSs.Dispose();
               diSs = null;
            }
            if(doSs != null)
            {
               doSs.Dispose();
               doSs = null;
            }
         }
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         try
         {
            DITimer.Stop();
            diSs.Stop();
            doSs.Stop();

            DigInputResource.Enabled = true;
            DigOutputResource.Enabled = true;
            Go.Enabled = true;
            Stop.Enabled = false;
         }
         catch(UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
         }

         diSs.Dispose();
         diSs = null;
         doSs.Dispose();
         doSs = null;
      }

      private void Timer_Tick(object sender, System.EventArgs e)
      {
         diData = diReader.ReadSingleScanUInt16();
         UInt16 state = diData[DigitalInputPort.SelectedIndex];
         for(int i=0; i<=15; i++)
         {     
            if((state & (1<<i)) != 0)
            {
               diLines[i].Checked = true;
               diLines[i].ImageIndex = 1;
            }
            else
            {
               diLines[i].Checked = false;
               diLines[i].ImageIndex = 0;
            }
         }
      }

      private void OnDOChange(object sender, System.EventArgs e)
      {
         CheckBox dol = (CheckBox)sender;
         if(dol.Checked)
            dol.ImageIndex = 1;
         else
            dol.ImageIndex = 0;

         int state = 0;
         for(int i=0; i<=15; i++)
         {   
            if(doLines[i].Checked)
            {
               state = state | (1 << i);
            }
         }

         doData[DigitalOutputPort.SelectedIndex] = (UInt16)state;
         doWriter.WriteSingleScanUInt16(doData);
      }
	}
}
