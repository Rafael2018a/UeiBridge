using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using UeiDaq;

namespace DigitalInEventAsync
{
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public class Form1 : System.Windows.Forms.Form
    {
        private System.Windows.Forms.TextBox ErrorText;
        private System.Windows.Forms.Button Stop;
        private System.Windows.Forms.Button Quit;
        private System.Windows.Forms.Button Go;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox NumEvents;
        private System.Windows.Forms.TextBox DigInValue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private Session mySs;
        private DigitalReader reader;
        private System.Windows.Forms.TextBox DigInputResource;
        private AsyncCallback readerAcb;
        private IAsyncResult readerIAsyncResult;
        private int eventCount;
        private delegate void UpdateUIDelegate(String errorMessage, Object param);


        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        public Form1()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            Stop.Enabled = false;
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ErrorText = new System.Windows.Forms.TextBox();
            this.Stop = new System.Windows.Forms.Button();
            this.Quit = new System.Windows.Forms.Button();
            this.Go = new System.Windows.Forms.Button();
            this.DigInputResource = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.NumEvents = new System.Windows.Forms.TextBox();
            this.DigInValue = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ErrorText
            // 
            this.ErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ErrorText.Location = new System.Drawing.Point(0, 150);
            this.ErrorText.Multiline = true;
            this.ErrorText.Name = "ErrorText";
            this.ErrorText.ReadOnly = true;
            this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ErrorText.Size = new System.Drawing.Size(432, 48);
            this.ErrorText.TabIndex = 28;
            this.ErrorText.Text = "";
            // 
            // Stop
            // 
            this.Stop.Location = new System.Drawing.Point(160, 104);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(112, 32);
            this.Stop.TabIndex = 27;
            this.Stop.Text = "Stop";
            this.Stop.Click += new System.EventHandler(this.Stop_Click);
            // 
            // Quit
            // 
            this.Quit.Location = new System.Drawing.Point(304, 104);
            this.Quit.Name = "Quit";
            this.Quit.Size = new System.Drawing.Size(112, 32);
            this.Quit.TabIndex = 26;
            this.Quit.Text = "Quit";
            this.Quit.Click += new System.EventHandler(this.Quit_Click);
            // 
            // Go
            // 
            this.Go.Location = new System.Drawing.Point(16, 104);
            this.Go.Name = "Go";
            this.Go.Size = new System.Drawing.Size(112, 32);
            this.Go.TabIndex = 25;
            this.Go.Text = "Go";
            this.Go.Click += new System.EventHandler(this.Go_Click);
            // 
            // DigInputResource
            // 
            this.DigInputResource.Location = new System.Drawing.Point(16, 48);
            this.DigInputResource.Name = "DigInputResource";
            this.DigInputResource.Size = new System.Drawing.Size(112, 20);
            this.DigInputResource.TabIndex = 23;
            this.DigInputResource.Text = "simu://Dev0/Di0";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(16, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 16);
            this.label2.TabIndex = 24;
            this.label2.Text = "Resource name";
            // 
            // NumEvents
            // 
            this.NumEvents.Location = new System.Drawing.Point(160, 48);
            this.NumEvents.Name = "NumEvents";
            this.NumEvents.Size = new System.Drawing.Size(112, 20);
            this.NumEvents.TabIndex = 29;
            this.NumEvents.Text = "";
            // 
            // DigInValue
            // 
            this.DigInValue.Location = new System.Drawing.Point(304, 48);
            this.DigInValue.Name = "DigInValue";
            this.DigInValue.Size = new System.Drawing.Size(112, 20);
            this.DigInValue.TabIndex = 30;
            this.DigInValue.Text = "";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(160, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 16);
            this.label1.TabIndex = 31;
            this.label1.Text = "Number of events";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(304, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 16);
            this.label3.TabIndex = 32;
            this.label3.Text = "Value";
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(432, 198);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DigInValue);
            this.Controls.Add(this.NumEvents);
            this.Controls.Add(this.ErrorText);
            this.Controls.Add(this.Stop);
            this.Controls.Add(this.Quit);
            this.Controls.Add(this.Go);
            this.Controls.Add(this.DigInputResource);
            this.Controls.Add(this.label2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new Form1());
        }

        private void Go_Click(object sender, System.EventArgs e)
        {
            try
            {
                ErrorText.Clear();

                mySs = new Session();
                DIChannel chan = mySs.CreateDIChannel(DigInputResource.Text);
                chan.SetEdgeMask(0xFF, DigitalEdge.Rising);

                mySs.ConfigureTimingForEdgeDetection(DigitalEdge.Rising);
                mySs.GetTiming().SetTimeout(5000);

                reader = new DigitalReader(mySs.GetDataStream());
                readerAcb = new AsyncCallback(ReaderCallback);

                mySs.Start();
                readerIAsyncResult = reader.BeginReadSingleScanUInt16(readerAcb, null);

                eventCount = 0;
                Go.Enabled = false;
                Stop.Enabled = true;
                DigInputResource.Enabled = false;
            }
            catch (UeiDaqException ex)
            {
                ErrorText.Text = "Error : " + ex.Message;
            }
        }

        private void ReaderCallback(IAsyncResult ar)
        {
            try
            {
                UInt16[] data = reader.EndReadSingleScanUInt16(ar);

                eventCount++;
                UpdateUI("", data);

                if(mySs != null && mySs.IsRunning())
                {
                   readerIAsyncResult = reader.BeginReadSingleScanUInt16(readerAcb, null);
                }
            }
            catch (UeiDaqException ex)
            {
                UpdateUI("Error : " + ex.Message, null);
            }
            catch (Exception e)
            {
                UpdateUI("Unknown Error" + e, null);
            }
        }

        private void UpdateUI(String errorMessage, Object param)
        {
            if (this.InvokeRequired)
            {
                UpdateUIDelegate uidlg = new UpdateUIDelegate(UpdateUI);
                Invoke(uidlg, new object[] { errorMessage, param });
            }
            else
            {
                if (mySs != null && mySs.IsRunning())
                {
                   UInt16[] data = (UInt16[])param;
                   DigInValue.Text = data[0].ToString();
                   NumEvents.Text = eventCount.ToString();
                }

                if (errorMessage.Length > 0)
                {
                    ErrorText.Text = errorMessage;
                }
            }
        }

        private void Quit_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }

        private void Stop_Click(object sender, System.EventArgs e)
        {
            DigInputResource.Enabled = true;
            Stop.Enabled = false;
            Go.Enabled = true;

            if (mySs != null)
            {
                try
                {
                    mySs.Stop();
                    // wait for current async call to complete
                    // before destroying the session
                    readerIAsyncResult.AsyncWaitHandle.WaitOne();
                }
                catch (UeiDaqException exception)
                {
                    ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
                }

                mySs.Dispose();
                mySs = null;
            }
        }
    }
}
