﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UeiDaq;

namespace BufferedQuadratureEncoder
{
   public partial class Form1 : Form
   {
      private Session mySs;
      private CounterReader ciReader;
      private AsyncCallback readerCallback;
      private IAsyncResult readerIAsyncResult;
      private delegate void UpdateUIDelegate(String errorMessage);
      private int numScansToRead;
      private UInt32[,] val;

      public Form1()
      {
         InitializeComponent();
      }

      private void Form1_Load(object sender, EventArgs e)
      {
         txtResource.Text = "pdna://192.168.100.8/dev2/ci0";
         chkEnableZeroIndex.Checked = true;
         cboDecodeType.Items.Add(QuadratureDecodingType.FourX.ToString());
         cboDecodeType.Items.Add(QuadratureDecodingType.OneX.ToString());
         cboDecodeType.Items.Add(QuadratureDecodingType.TwoX.ToString());
         cboDecodeType.SelectedIndex = 1;


         cboZeroIndexPhase.Items.Add(QuadratureZeroIndexPhase.AHighBHigh.ToString());
         cboZeroIndexPhase.Items.Add(QuadratureZeroIndexPhase.AHighBLow.ToString());
         cboZeroIndexPhase.Items.Add(QuadratureZeroIndexPhase.ALowBHigh.ToString());
         cboZeroIndexPhase.Items.Add(QuadratureZeroIndexPhase.ALowBLow.ToString());
         cboZeroIndexPhase.Items.Add(QuadratureZeroIndexPhase.ZHigh.ToString());
         cboZeroIndexPhase.SelectedIndex = 4;
         btnStart.Enabled = true;
         btnStop.Enabled = false;
         btnQuit.Enabled = true;

      }


      private void ReaderCallback(IAsyncResult ar)
      {
         try
         {
            val = ciReader.EndReadMultipleScansUInt32(ar);

            UpdateUI("");

            if (mySs != null && mySs.IsRunning())
            {
               readerIAsyncResult = ciReader.BeginReadMultipleScansUInt32(numScansToRead, readerCallback, null);
            }
         }
         catch (UeiDaqException exception)
         {
            UpdateUI("Error: (" + exception.Error + ") " + exception.Message);
         }
         catch (Exception e)
         {
            UpdateUI("Unknown Error" + e);
         }
      }

      private void UpdateUI(String errorMessage)
      {
         if (this.InvokeRequired)
         {
            UpdateUIDelegate uidlg = new UpdateUIDelegate(UpdateUI);
            Invoke(uidlg, new object[] { errorMessage });
         }
         else
         {
            if (mySs != null && mySs.IsRunning())
            {
               for (int ch = 0; ch < mySs.GetNumberOfChannels(); ch++)
               {
                  string strData = "[";
                  for (int n = 0; n < numScansToRead; n++)
                  {
                     strData = strData + " " + ((Int32)val[n, ch]).ToString();
                  }
                  strData = strData + " ]";
                  lsvData.Items[ch].SubItems[1].Text = strData;
               }
            }

            if (errorMessage.Length > 0)
            {
               ErrorText.Text = errorMessage;
               UeiDaqStop();
            }
         }
      }

      private void UeiDaqStop()
      {
         btnStart.Enabled = true;
         btnStop.Enabled = false;
         btnQuit.Enabled = true;
         txtNumScans.Enabled = true;
         txtScanRate.Enabled = true;

         ErrorText.Clear();
         if (mySs != null)
         {
            try
            {
               mySs.Stop();

               // wait for current async call to complete
               // before destroying the session
               readerIAsyncResult.AsyncWaitHandle.WaitOne();
            }
            catch (UeiDaqException exception)
            {
               ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }

            mySs.Dispose();
            mySs = null;
         }
      }

      private void btnStart_Click(object sender, EventArgs e)
      {
         lsvData.Items.Clear();
         ErrorText.Clear();
         mySs = new Session();
         try
         {
            //The line (QuadratureDecodingType)Enum.Parse(typeof(QuadratureDecodingType),cboDecodeType.SelectedItem.ToString()is type casting string to enum
            mySs.CreateQuadratureEncoderChannel(txtResource.Text,
                                                Convert.ToUInt32(txtInitCount.Text),
                                                (QuadratureDecodingType)Enum.Parse(typeof(QuadratureDecodingType), cboDecodeType.SelectedItem.ToString()),
                                                chkEnableZeroIndex.Checked,
                                                (QuadratureZeroIndexPhase)Enum.Parse(typeof(QuadratureZeroIndexPhase), cboZeroIndexPhase.SelectedItem.ToString()));


            for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
            {
               QuadratureEncoderChannel ch = (QuadratureEncoderChannel)mySs.GetChannel(i);
               ch.EnableTimestamping(chkEnableTs.Checked);
               ch.SetTimestampResolution(0.001);

               // initialize values in data view
               ListViewItem item = lsvData.Items.Add(mySs.GetChannel(i).GetIndex().ToString());
               item.SubItems.Add("[0]");
            }

            mySs.ConfigureTimingForBufferedIO(Int32.Parse(txtNumScans.Text), TimingClockSource.Internal, Double.Parse(txtScanRate.Text),
                                              DigitalEdge.Rising, TimingDuration.Continuous);

            numScansToRead = Int32.Parse(txtNumScans.Text);
            if (chkEnableTs.Checked)
            {
               numScansToRead = numScansToRead * 2;
            }

            ciReader = new CounterReader(mySs.GetDataStream());
            mySs.Start();

            readerCallback = new AsyncCallback(ReaderCallback);
            readerIAsyncResult = ciReader.BeginReadMultipleScansUInt32(numScansToRead, readerCallback, null);

            btnStop.Enabled = true;
            btnStart.Enabled = false;
            btnQuit.Enabled = false;
            txtNumScans.Enabled = false;
            txtScanRate.Enabled = false;
         }
         catch (UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
         }
      }

      private void btnQuit_Click(object sender, EventArgs e)
      {
         Application.Exit();
      }

      private void btnStop_Click(object sender, EventArgs e)
      {
         UeiDaqStop();
      }

   }
}
