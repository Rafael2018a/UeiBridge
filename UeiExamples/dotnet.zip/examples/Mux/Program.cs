﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace Mux
{
   class Program
   {
      static void Main(string[] args)
      {
         string muxResource = "pdna://192.168.100.55/dev6/mux0";
         
         try
         {
            // Configure Master session
            Session muxSession = new Session();
            MuxPort mx = muxSession.CreateMuxPort(muxResource, true);

            muxSession.ConfigureTimingForSimpleIO();
            muxSession.Start();

            // Create a writer object to configure relays and read status
            MuxWriter muxWriter = new MuxWriter(muxSession.GetDataStream());

            stop = false;
            int count = 0;
            while (!stop)
            {
               for (int ch = 0; ch < muxSession.GetDevice().GetDOResolution(); ch++)
               {
                  // Program relays on each channel one at a time
                  int[] channels = { ch };
                  int[] relays = { count % 4 }; // cycle through 0 (relays off), 1 (A), 2 (B) and 3 (C)

                  muxWriter.WriteMux(channels, relays);

                  Thread.Sleep(500);

                  uint relayA=0, relayB=0, relayC=0, status=0;
                  muxWriter.ReadStatus(ref relayA, ref relayB, ref relayC, ref status);
                  Console.WriteLine("Relays Status: A=" + relayA.ToString("X") + " B=" + relayB.ToString("X") + " C=" + relayC.ToString("X") + " st=" + status.ToString("X"));

                  double[] adcValues = muxWriter.ReadADC();
                  Console.WriteLine("ADC input=" + adcValues[0] + " ADC 3.3=" + adcValues[1] + " ADC 2.5=" + adcValues[2] + " ADC temp=" + adcValues[3] + " ADC status=" + adcValues[4]);

                  if (!stop) break;
               }

               count++;
            }

            muxSession.Stop();
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop= false;
   }
}
