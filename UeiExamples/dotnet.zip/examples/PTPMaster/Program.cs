﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace PTPMaster
{
   class Program
   {
      static void Main(string[] args)
      {
         string ptpMasterResource = "pdna://192.168.100.2/dev14/sync0";
         Session ptpMasterSession;
         string[] ptpSlaveResources = new string[]{ "pdna://192.168.100.3/dev14/Sync0" };
         Session[] ptpSlaveSessions = new Session[ptpSlaveResources.Length];
         Sync1PPSController ptpMasterController;
         Sync1PPSController[] ptpSlaveControllers = new Sync1PPSController[ptpSlaveResources.Length];

         try
         {
            // Configure Master session
            ptpMasterSession = new Session();
            Sync1PPSPort masterPort = ptpMasterSession.CreateSync1PPSPort(ptpMasterResource,
                                             Sync1PPSMode.PTP,
                                             Sync1PPSSource.Internal,
                                             100.0);
            // configure port to output 1 PPS signal out of sync connector output 0 (clock out)
            masterPort.Set1PPSOutput(Sync1PPSOutput.Output0);

            // Configure PTP master parameters
            masterPort.SetPTPSubdomain(0);
            masterPort.SetPTPPriority1(128 - 3);
            masterPort.SetPTPPriority2(128 - 3);
            masterPort.SetPTPLogSyncInterval(0);
            masterPort.SetPTPLogMinDelayRequestInterval(1);
            masterPort.SetPTPLogAnnounceInterval(4);
            masterPort.SetPTPAnnounceTimeout(3);
            masterPort.SetPTPUTCOffset(37);
            
            // Configure trigger to start session on a 1PPS edge
	        ptpMasterSession.GetStartTrigger().SetTriggerSource(Next1PPS);

            ptpMasterSession.Start();

            // Create a controller object to read PTP status and UTC time
            ptpMasterController = new Sync1PPSController(ptpMasterSession.GetDataStream());

            // Configure slave sessions
            for (int i=0; i<ptpSlaveResources.Length; i++)
            {
               ptpSlaveSessions[i] = new Session();
               Sync1PPSPort slavePort = ptpSlaveSessions[i].CreateSync1PPSPort(ptpSlaveResources[i],
                                             Sync1PPSMode.PTP,
                                             Sync1PPSSource.Internal,
                                             100.0);
               // configure port to output 1 PPS signal out of sync connector output 0 (clock out)
               slavePort.Set1PPSOutput(Sync1PPSOutput.Output0);

               // Configure PTP slave parameters
               slavePort.SetPTPSubdomain(0);
               slavePort.SetPTPPriority1(128 + 3);
               slavePort.SetPTPPriority2(128 + 3);
               slavePort.SetPTPLogSyncInterval(0);
               slavePort.SetPTPLogMinDelayRequestInterval(1);
               slavePort.SetPTPLogAnnounceInterval(4);
               slavePort.SetPTPAnnounceTimeout(3);
               slavePort.SetPTPUTCOffset(37);

               ptpSlaveSessions[i].Start();

               // Create a circuit breaker object per output channel to monitor circuit breaker status and eventually reset them
               ptpSlaveControllers[i] = new Sync1PPSController(ptpSlaveSessions[i].GetDataStream());
            }

            // Establish an event handler to process key press events.
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

            int count = 0;
            stop = false;
            while (!stop)
            {
               // Read PTP master time
               PTPTime masterTime = ptpMasterController.ReadPTPUTCTime();
               Console.WriteLine("PTP Master UTC Time = " + masterTime.sec + "s / " + masterTime.nsec + "ns (" + ptpMasterController.ReadDateTime() + ")");
               Console.WriteLine("");

               // Read PTP slave(s) status and time
               for (int i = 0; i < ptpSlaveResources.Length; i++)
               {
                  Console.WriteLine("Status for " + ptpSlaveResources[i]);
                  Sync1PPSPTPStatus status = ptpSlaveControllers[i].ReadPTPStatus();
                  Console.WriteLine("PTP slave state = " + status.State + ", Master clock ID = " + status.MasterClockID + " Mean path delay = " + status.MeanPathDelay);

                  PTPTime slaveTime = ptpSlaveControllers[i].ReadPTPUTCTime();
                  Console.WriteLine("PTP UTC Time = " + slaveTime.sec + "s / " + slaveTime.nsec + "ns(" + ptpSlaveControllers[i].ReadDateTime() + ")");

                  // Compute time delay between master and slave
                  Int64 delayNs = (slaveTime.sec * 1000000000L + slaveTime.nsec) - (masterTime.sec * 1000000000L + masterTime.nsec);
                  Console.WriteLine("Delay with master = " + delayNs + "ns");

                  Console.WriteLine("");
               }

               Console.WriteLine("");

               Thread.Sleep(500);
               count++;
            }

            foreach (Session ptpSession in ptpSlaveSessions)
            {
               ptpSession.Stop();
            }
            ptpMasterSession.Stop();
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop= false;
   }
}
