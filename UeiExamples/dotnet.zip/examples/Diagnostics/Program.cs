﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace Diagnostics
{
   class Program
   {
      static void Main(string[] args)
      {
         Session diagSession;
         String iomResource = "pdna://192.168.100.2/";

         try
         {
            // Display CPU name
            Device cpu = DeviceEnumerator.GetDeviceFromResource(iomResource + "cpu");
            if(null == cpu)
            {
               Console.WriteLine("Could not connect with " + iomResource);
               Environment.Exit(-1);
            }
            Console.WriteLine("CPU is " + cpu.GetDeviceName());

            DeviceCollection devColl = new DeviceCollection(iomResource);
            foreach (Device dev in devColl)
            {
               // look for diagnostic capable devices such as DNRP-** layers
               if (dev != null && dev.GetDeviceName().Substring(0, 4).CompareTo("DNRP") == 0)
               {
                  Console.WriteLine("Diagnostic data for device " + dev.GetDeviceName() + " at " + dev.GetResourceName());

                  diagSession = new Session();
                  diagSession.CreateAIChannel(dev.GetResourceName() + "/Ai0:15", -10, +10, AIChannelInputMode.Differential);
                  diagSession.ConfigureTimingForSimpleIO();
                  AnalogScaledReader reader = new AnalogScaledReader(diagSession.GetDataStream());

                  diagSession.Start();

                  // Read and display data
                  double[] data = reader.ReadSingleScan();

                  String[] diagChannelNames = GetDiagChannelNames(cpu.GetDeviceName(), dev.GetDeviceName());
                  for (int ch = 0; ch < diagChannelNames.Length; ch++)
                  {
                     if (diagChannelNames[ch].Length > 0)
                     {
                        Console.WriteLine(diagChannelNames[ch] + " = " + data[ch]);
                     }
                  }
                  Console.WriteLine("");

                  diagSession.Stop();
               }
            }
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static String[] GetDiagChannelNames(String cpuName, String deviceName)
      {
         switch(deviceName)
         {
            case "DNRP-20":
               if(cpuName.CompareTo("CM3006") == 0)
               {
                  return DNRP20Channels_6;
               }
               else
               {
                  return DNRP20Channels_12;
               }
            case "DNRP-40":
               if (cpuName.CompareTo("CM3006") == 0)
               {
                  return DNRP40Channels_6;
               }
               else
               {
                  return DNRP40Channels_12;
               }
            case "DNRP-41":
               return DNRP41Channels;
            case "DNRP-46":
               return DNRP46Channels;
            case "DNRP-47":
               return DNRP47Channels;
            default:
               break;
         }

         return UnknownChannels;
      }

      static string[] DNRP20Channels_6 = 
      { 
          "2.5V slots 1-3", 
          "2.5V slots 4-6", 
          "3.3V slots 1-3", 
          "3.3V slots 4-6", 
          "24V slots 1-3", 
          "24V slots 4-6", 
          "Input Voltage", 
          "1.5V slots 1-6",
          "1.2V slots 1-6", 
          "Fan Voltage", 
          "Input Current", 
          "Temperature 1",                             
          "Temperature 2"
      };

      static string[] DNRP20Channels_12 = 
      { 
          "2.5V slots 1-6", 
          "2.5V slots 7-12", 
          "3.3V slots 1-6", 
          "3.3V slots 7-12", 
          "24V slots 1-6", 
          "24V slots 7-12", 
          "Input Voltage", 
          "1.5V slots 1-12",
          "1.2V slots 1-12", 
          "Fan Voltage", 
          "Input Current", 
          "Temperature 1",                             
          "Temperature 2"
      };

      static string[] DNRP40Channels_6 = 
      { 
          "2.5V slots 4-6", 
          "Ground Reference", 
          "3.3V slots 4-6", 
          "", 
          "24V slots 4-6", 
          "", 
          "", 
          "1.5V slots 1-6",
          "1.2V slots 1-6", 
          "", 
          "", 
          "", 
          "3.3V slots 4-6", 
          "Temperature 1", 
          "", 
          "Temperature 2" 
      };


      static string[] DNRP40Channels_12 = 
      { 
          "2.5V slots 7-12", 
          "Ground Reference", 
          "3.3V slots 7-12", 
          "", 
          "24V slots 7-12", 
          "", 
          "", 
          "1.5V slots 1-12",
          "1.2V slots 1-12", 
          "", 
          "", 
          "", 
          "3.3V current slots 7-12", 
          "Temperature 1", 
          "", 
          "Temperature 2"
      };

      static string[] DNRP41Channels = 
      { 
          "2.5V layer", 
          "Ground Reference", 
          "3.3V layer", 
          "", 
          "24V layer", 
          "", 
          "Input Voltage", 
          "1.5V layer",
          "1.2V layer", 
          "Fan Voltage", 
          "Input Current", 
          "", 
          "3.3V current", 
          "Temperature 1", 
          "1.5V current", 
          "Temperature 2" 
      };

      static string[] DNRP46Channels = 
      { 
          "2.5V layer", 
          "3.3V layer", 
          "Ground Reference", 
          "", 
          "24V layer", 
          "", 
          "Input Voltage", 
          "1.5V layer",
          "1.2V layer", 
          "Fan Voltage", 
          "Input Current", 
          "Ground Reference", 
          "3.3V current", 
          "Temperature 1", 
          "1.5V current", 
          "Temperature 2" 
      };

      static string[] DNRP47Channels = 
      { 
          "2.5V", 
          "3.3V", 
          "V Hold", 
          "24V", 
          "Input Voltage", 
          "1.5V", 
          "1.2V", 
          "24V current",
          "Input current", 
          "Ground Reference", 
          "3.3V current", 
          "", 
          "1.5V current", 
          " 1", 
          "1.2V current", 
          ""
      };

      static string[] UnknownChannels =
      {
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown",
          "Unknown"
      };
   }
}
