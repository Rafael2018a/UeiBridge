﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace Protected_AO
{
   class Program
   {
      static void Main(string[] args)
      {
         Session aoSession = new Session();
         Session aiSession = new Session();

         try
         {
            aoSession.CreateAOProtectedChannel("pdna://192.168.100.2/dev5/ao0:7", 
                                               AODACMode.AConnected, 10.0, false, 0.0);
            aoSession.ConfigureTimingForSimpleIO();

            // Program diagnostic channel list (default is 0,1,2,3,4 for each of the 8 output channels)
            for (int ch = 0; ch < aoSession.GetNumberOfChannels(); ch++)
            {
               AOProtectedChannel channel = (AOProtectedChannel)aoSession.GetChannel(ch);

               channel.SetADCChannel(0, AODiagnosticChannel.Current);
               channel.SetADCChannel(1, AODiagnosticChannel.DACAVoltage);
               channel.SetADCChannel(2, AODiagnosticChannel.DACBVoltage);
               channel.SetADCChannel(3, AODiagnosticChannel.Voltage);
               channel.SetADCChannel(4, AODiagnosticChannel.Temperature);

               // Program which of the 5 AODiagnosticChannel channels will be monitored
               // The AO-318 can only monitor either or both first diag channels

               // Monitor current and trip breaker when current is above 15mA
               /*channel.EnableCircuitBreaker(0, true);
               channel.SetCircuitBreakerLowLimit(0, -0.015);
               channel.SetCircuitBreakerHighLimit(0, 0.015);*/

               if (channel.GetIndex() == 4)
               {
                  // Monitor voltage and trip breaker when voltage is above 7V
                  channel.EnableCircuitBreaker(1, true);
                  channel.SetCircuitBreakerLowLimit(1, -11.0);
                  channel.SetCircuitBreakerHighLimit(1, 7.0);
               }
               else
               {
                  channel.EnableCircuitBreaker(1, false);
               }

               // trip after reading three values out of range
               channel.SetOverUnderCount(2);
            }

            // Create 5 AI channels for each output channel to read diagnostics
            aiSession.CreateAIChannel("pdna://192.168.100.2/dev5/ai0:4,8:12,16:20,24:28,32:36,40:44,48:52,56:60", -10.0, 10.0, AIChannelInputMode.Differential);
            aiSession.ConfigureTimingForSimpleIO();

            // Create a writer to update the 8 output channels
            AnalogScaledWriter writer = new AnalogScaledWriter(aoSession.GetDataStream());
            double[] aoData = new double[aoSession.GetNumberOfChannels()];

            // Create a circuit breaker object per output channel to monitor circuit breaker status and eventually reset them
            CircuitBreaker[] cbs = new CircuitBreaker[aoSession.GetNumberOfChannels()];
            int[] breakCount = new int[aoSession.GetNumberOfChannels()];
            for (int ch = 0; ch < aoSession.GetNumberOfChannels(); ch++)
            {
               cbs[ch] = new CircuitBreaker(aoSession.GetDataStream(), aoSession.GetChannel(ch).GetIndex());
               breakCount[ch] = 0;
            }
           
            // Create a reader to retrieve diagnostics
            AnalogScaledReader diagReader = new AnalogScaledReader(aiSession.GetDataStream());
            double[] diagData;

            aoSession.Start();
            aiSession.Start();

            // Establish an event handler to process key press events.
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

            int count = 0;
            stop = false;
            while (!stop)
            {
               // Update outputs on each channel
               for (int ch = 0; ch < aoSession.GetNumberOfChannels(); ch++)
               {
                  aoData[ch] = -10 + (ch + count) % 20;
               }
               writer.WriteSingleScan(aoData);

               // Read and display diagnostics
               diagData = diagReader.ReadSingleScan();

               for (int ch = 0; ch < aoSession.GetNumberOfChannels(); ch++)
               {
                  Console.WriteLine("Output Channel " + aoSession.GetChannel(ch).GetIndex() + " diagnostics:");
                  for (int diag = 0; diag < 5; diag++)
                  {
                     Console.WriteLine("  Diag" + diag + " = " + diagData[ch * 5 + diag]);
                  }

                  // Monitor CB status
                  uint currStatus=0, stickyStatus=0;
                  cbs[ch].GetStatus(ref currStatus, ref stickyStatus);

                  if ((currStatus & (1U << aoSession.GetChannel(ch).GetIndex())) > 0)
                  {
                     breakCount[ch]++;
                  }

                  Console.WriteLine("  CB Status: curr = " + currStatus.ToString("X") + " sticky = " + stickyStatus.ToString("X"));
                  
                  // reset breaker after 5 iterations
                  if (breakCount[ch] > 5)
                  {
                     Console.WriteLine("Resetting breaker for channel {0}", ch);
                     //cbs[ch].Reset(1U << aoSession.GetChannel(ch).GetIndex());
                     breakCount[ch] = 0;
                  }
               }

               Thread.Sleep(500);
               count++;
            }

            aoSession.Stop();
            aiSession.Stop();
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop= false;
   }
}
