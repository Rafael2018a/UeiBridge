﻿using System;
using System.Collections.Generic;
using System.Threading;
using UeiDaq;


namespace AIMultipleSynchronizedCubes
{
   static class Program
   {
      public static object ErrorText { get; private set; }

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main()
      {
         double scanRate = 8000.0;
         int numScans = 500;

         int count = 0;
         String[] syncResources = { "pdna://192.168.100.8/Dev14/Sync0", "pdna://192.168.100.3/Dev14/Sync0" };
         String[] aiResources = { "pdna://192.168.100.8/Dev0/Ai0:11", "pdna://192.168.100.3/Dev0/Ai0:7" };

         List<Session> syncSessions = new List<Session>();
         List<Session> aiSessions = new List<Session>();
         List<AnalogScaledReader> readers = new List<AnalogScaledReader>();
         List<Sync1PPSController> controllers = new List<Sync1PPSController>();

         int dev;
         int aiDeviceCount = aiResources.Length;
         int syncDeviceCount = syncResources.Length;


         try
         {
            // initialize synchronization sessions. Assume first session is a master and produces 
            // the 1PPS signal
            for (dev = 0; dev < syncDeviceCount; dev++)
            {
               Session syncSession = new Session();

               // first sync device is master, configure to internally produce 1PPS and
               // make it available to slaves on output 0
               if (0 == dev)
               {
                  Sync1PPSPort masterSyncPort = syncSession.CreateSync1PPSPort(syncResources[dev],
                     Sync1PPSMode.Clock,
                     Sync1PPSSource.Internal,
                     scanRate);

                  masterSyncPort.Set1PPSOutput(Sync1PPSOutput.Output0);
               }
               else
               {
                  syncSession.CreateSync1PPSPort(syncResources[dev],
                        Sync1PPSMode.Clock,
                        Sync1PPSSource.Input0,
                        scanRate);
               }

               // When trigger command is received all sync devices will trigger their respective I/O layers
               // upon the next 1PPs edge
               syncSession.GetStartTrigger().SetTriggerSource(TriggerSource.Next1PPs);
               syncSessions.Add(syncSession);

               // Create controller object used to read status and send trigger command
               Sync1PPSController controller = new Sync1PPSController(syncSession.GetDataStream());
               controllers.Add(controller);
            }

            // Configure AI layers
            for (dev = 0; dev < aiDeviceCount; dev++)
            {
               Session aiSession = new Session();

               // Create analog input channels
               aiSession.CreateAIChannel(aiResources[dev], -10.0, 10.0, AIChannelInputMode.Differential);

               // Configure the session to acquire 1000 scans clocked by a synchronisation signal
               aiSession.ConfigureTimingForBufferedIO(numScans, TimingClockSource.Signal, scanRate, DigitalEdge.Rising, TimingDuration.Continuous);
               aiSession.GetTiming().SetTimeout(5000);

               // Program scan clock signal to come from 1PPS event module via sync line #2
               aiSession.GetTiming().SetScanClockSourceSignal("pps2");

               // The scan clock can be divided to synchronize AI layers that are over-clocked with other AI layers
               // For example the AI-217 requires a scan clock 8x faster than the data rate expected by the user
               // To synchronize an AI-207 with the AI-217, its clock needs to be divided by 8.
               aiSession.GetTiming().SetScanClockTimebaseDivisor(0);

               // Configure AI layers to wait for trigger signal on sync line #3, the event module will assert
               // line #3 on the next 1PPS edge after having received a trigger command.
               aiSession.ConfigureSignalTrigger(TriggerAction.StartSession, "pps3");

               // Create a reader object to read data synchronously from the data stream.
               AnalogScaledReader reader = new AnalogScaledReader(aiSession.GetDataStream());

               // Allocate buffer to store data frame
               double[] data = new double[aiSession.GetNumberOfChannels() * aiSession.GetDataStream().GetNumberOfScans()];

               // Store pointers for each device in vectors
               aiSessions.Add(aiSession);
               readers.Add(reader);
            }

            // Start I/O sessions first
            for (dev = 0; dev < aiDeviceCount; dev++)
            {
               aiSessions[dev].Start();
            }

            // Start sync sessions one by one and wait until ADPLL is locked on 1PPS
            for (dev = 0; dev < syncDeviceCount; dev++)
            {
               syncSessions[dev].Start();

               int lockCount = 0;
               int loopCount = 0;
               System.Console.Write("Checking Lock status on " + syncSessions[dev].GetDevice().GetResourceName() + ":");
               while (lockCount < 10 && loopCount < 30)
               {
                  bool locked = controllers[dev].ReadLockedStatus();
                  if (locked)
                  {
                     lockCount++;
                     System.Console.Write("L");
                  }
                  else
                  {
                     System.Console.Write(".");
                  }
                  Thread.Sleep(500);
               }

               if (lockCount < 10)
               {
                  System.Console.WriteLine("could not lock 1PPS");
                  return;
               }

               System.Console.WriteLine(" Locked!");
            }

            // Send trigger signal to start clocking the AI layers on the next 1PPS pulse
            controllers[0].TriggerDevices(Sync1PPSTriggerOperation.TriggerOnNextPPSBroadCast, true);

            while (count < 20)
            {
               for (dev = 0; dev < aiDeviceCount; dev++)
               {
                  double[,] data = readers[dev].ReadMultipleScans(numScans);

                  System.Console.Write(aiSessions[dev].GetDevice().GetResourceName() + ":");
                  for (int i = 0; i < aiSessions[dev].GetNumberOfChannels(); i++)
                  {
                     System.Console.Write(" ch" + i + " = " + data[0,i] + "V, ");
                  }

                  System.Console.WriteLine("");
               }
               System.Console.WriteLine("");
               count++;
            }

            for (dev = 0; dev < aiDeviceCount; dev++)
            {
               aiSessions[dev].Stop();
            }

            for (dev = 0; dev < syncDeviceCount; dev++)
            {
               syncSessions[dev].Stop();
            }
         }
         catch (UeiDaqException exception)
         {
            System.Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }

         for (dev = 0; dev < aiDeviceCount; dev++)
         {
            if (readers[dev] != null) readers[dev].Dispose();
            if (aiSessions[dev] != null) aiSessions[dev].Dispose();
         }

         for (dev = 0; dev < syncDeviceCount; dev++)
         {
            if (controllers[dev] != null) controllers[dev].Dispose();
            if (syncSessions[dev] != null) syncSessions[dev].Dispose();
         }
      }
   }
}
