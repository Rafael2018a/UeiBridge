using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data;
using UeiDaq;

namespace DmapAI
{
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public class DmapAI : System.Windows.Forms.Form
    {
        private System.Windows.Forms.TextBox ErrorText;
        private System.Windows.Forms.TextBox Resource;
        private System.Windows.Forms.Button Stop;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Quit;
        private System.Windows.Forms.Button Go;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Minimum;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Maximum;
        private System.Windows.Forms.RadioButton Differential;
        private System.Windows.Forms.RadioButton SingleEnded;
        private Session mySs;
        private AnalogScaledReader reader;
        private AsyncCallback readerCallback;
        private IAsyncResult readerIAsyncResult;
        private IAsyncResult UpdateAResult;
        private int count;
        private double[] data;
        private Stopwatch st;
        private delegate void UpdateUIDelegate(String errorMessage);
        private System.Windows.Forms.ColumnHeader Channel;
        private System.Windows.Forms.ColumnHeader Value;
        private System.Windows.Forms.ListView Data;
        private Label label5;
        private TextBox Rate;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        public DmapAI()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ErrorText = new System.Windows.Forms.TextBox();
            this.Resource = new System.Windows.Forms.TextBox();
            this.Stop = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Quit = new System.Windows.Forms.Button();
            this.Go = new System.Windows.Forms.Button();
            this.Data = new System.Windows.Forms.ListView();
            this.Channel = new System.Windows.Forms.ColumnHeader();
            this.Value = new System.Windows.Forms.ColumnHeader();
            this.label1 = new System.Windows.Forms.Label();
            this.Minimum = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Maximum = new System.Windows.Forms.TextBox();
            this.Differential = new System.Windows.Forms.RadioButton();
            this.SingleEnded = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.Rate = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ErrorText
            // 
            this.ErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ErrorText.Location = new System.Drawing.Point(0, 246);
            this.ErrorText.Multiline = true;
            this.ErrorText.Name = "ErrorText";
            this.ErrorText.ReadOnly = true;
            this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ErrorText.Size = new System.Drawing.Size(552, 48);
            this.ErrorText.TabIndex = 18;
            // 
            // Resource
            // 
            this.Resource.Location = new System.Drawing.Point(8, 24);
            this.Resource.Name = "Resource";
            this.Resource.Size = new System.Drawing.Size(112, 20);
            this.Resource.TabIndex = 15;
            this.Resource.Text = "simu://Dev0/Ai0:3";
            // 
            // Stop
            // 
            this.Stop.Location = new System.Drawing.Point(432, 72);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(112, 32);
            this.Stop.TabIndex = 17;
            this.Stop.Text = "Stop";
            this.Stop.Click += new System.EventHandler(this.Stop_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 16);
            this.label2.TabIndex = 16;
            this.label2.Text = "Resource name";
            // 
            // Quit
            // 
            this.Quit.Location = new System.Drawing.Point(432, 112);
            this.Quit.Name = "Quit";
            this.Quit.Size = new System.Drawing.Size(112, 32);
            this.Quit.TabIndex = 14;
            this.Quit.Text = "Quit";
            this.Quit.Click += new System.EventHandler(this.Quit_Click);
            // 
            // Go
            // 
            this.Go.Location = new System.Drawing.Point(432, 32);
            this.Go.Name = "Go";
            this.Go.Size = new System.Drawing.Size(112, 32);
            this.Go.TabIndex = 13;
            this.Go.Text = "Go";
            this.Go.Click += new System.EventHandler(this.Go_Click);
            // 
            // Data
            // 
            this.Data.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Channel,
            this.Value});
            this.Data.GridLines = true;
            this.Data.Location = new System.Drawing.Point(184, 32);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(192, 160);
            this.Data.TabIndex = 19;
            this.Data.UseCompatibleStateImageBehavior = false;
            this.Data.View = System.Windows.Forms.View.Details;
            // 
            // Channel
            // 
            this.Channel.Text = "Channel";
            // 
            // Value
            // 
            this.Value.Text = "Value";
            this.Value.Width = 128;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(184, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 16);
            this.label1.TabIndex = 20;
            this.label1.Text = "Acquired Data";
            // 
            // Minimum
            // 
            this.Minimum.Location = new System.Drawing.Point(8, 72);
            this.Minimum.Name = "Minimum";
            this.Minimum.Size = new System.Drawing.Size(112, 20);
            this.Minimum.TabIndex = 21;
            this.Minimum.Text = "-10.0";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 16);
            this.label3.TabIndex = 22;
            this.label3.Text = "Low Limit";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(8, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 16);
            this.label4.TabIndex = 24;
            this.label4.Text = "High Limit";
            // 
            // Maximum
            // 
            this.Maximum.Location = new System.Drawing.Point(8, 111);
            this.Maximum.Name = "Maximum";
            this.Maximum.Size = new System.Drawing.Size(112, 20);
            this.Maximum.TabIndex = 23;
            this.Maximum.Text = "10.0";
            // 
            // Differential
            // 
            this.Differential.Checked = true;
            this.Differential.Location = new System.Drawing.Point(8, 200);
            this.Differential.Name = "Differential";
            this.Differential.Size = new System.Drawing.Size(88, 16);
            this.Differential.TabIndex = 25;
            this.Differential.TabStop = true;
            this.Differential.Text = "Differential";
            // 
            // SingleEnded
            // 
            this.SingleEnded.Location = new System.Drawing.Point(8, 224);
            this.SingleEnded.Name = "SingleEnded";
            this.SingleEnded.Size = new System.Drawing.Size(104, 16);
            this.SingleEnded.TabIndex = 26;
            this.SingleEnded.Text = "Single Ended";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(8, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 16);
            this.label5.TabIndex = 28;
            this.label5.Text = "Rate";
            // 
            // Rate
            // 
            this.Rate.Location = new System.Drawing.Point(8, 163);
            this.Rate.Name = "Rate";
            this.Rate.Size = new System.Drawing.Size(112, 20);
            this.Rate.TabIndex = 27;
            this.Rate.Text = "100.0";
            // 
            // DmapAI
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(552, 294);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Rate);
            this.Controls.Add(this.SingleEnded);
            this.Controls.Add(this.Differential);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Maximum);
            this.Controls.Add(this.Minimum);
            this.Controls.Add(this.ErrorText);
            this.Controls.Add(this.Resource);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.Stop);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Quit);
            this.Controls.Add(this.Go);
            this.Name = "DmapAI";
            this.Text = "DmapAI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new DmapAI());
        }

        private void Quit_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }

        private void Go_Click(object sender, System.EventArgs e)
        {
            ErrorText.Clear();
            Data.Items.Clear();

            try
            {
                AIChannelInputMode inputMode;

                if (Differential.Checked)
                    inputMode = AIChannelInputMode.Differential;
                else
                    inputMode = AIChannelInputMode.SingleEnded;

                mySs = new Session();
                mySs.CreateAIChannel(Resource.Text, Double.Parse(Minimum.Text),
                                     Double.Parse(Maximum.Text), inputMode);



                for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
                {
                    ListViewItem item = Data.Items.Add(mySs.GetChannel(i).GetIndex().ToString());
                    item.SubItems.Add("0.0");
                }

                mySs.ConfigureTimingForDataMappingIO(TimingClockSource.Internal, Double.Parse(Rate.Text));

                // Disable overrun to force each read operation to wait for
                // the next A/D update
                mySs.GetDataStream().SetOverUnderRun(0);

                // Create a reader object to read data synchronously.
                reader = new AnalogScaledReader(mySs.GetDataStream());
                readerCallback = new AsyncCallback(DataReady);
                UpdateAResult = null;
                mySs.Start();

                count = 0;

                st = new Stopwatch();
                st.Start();

                readerIAsyncResult = reader.BeginReadSingleScan(readerCallback, null);

                Resource.Enabled = false;
                Go.Enabled = false;
            }
            catch (UeiDaqException exception)
            {
                ErrorText.AppendText("Error: (" + exception.Error + ") " + exception.Message);
                mySs.Dispose();
                mySs = null;
            }
        }

        private void DataReady(IAsyncResult ar)
        {
            try
            {
                data = reader.EndReadSingleScan(ar);

                // Invoke delegate to update UI.
                // UI compoents can only be updated in the UI thread
                UpdateUI("");

                // If session is still around, get another scan
                if (mySs != null && mySs.IsRunning())
                {
                    readerIAsyncResult = reader.BeginReadSingleScan(readerCallback, null);
                }

                count++;
            }
            catch (UeiDaqException exception)
            {
                UpdateUI("Error: (" + exception.Error + ") " + exception.Message);
            }
            catch (Exception e)
            {
                UpdateUI("Unknown Error" + e);
            }
        }

        private void UpdateUI(String errorMessage)
        {
            if (this.InvokeRequired)
            {
                // Execute display code only if the previous invoke is completed
                if (UpdateAResult == null || UpdateAResult.IsCompleted)
                {
                    UpdateUIDelegate uidlg = new UpdateUIDelegate(UpdateUI);
                    UpdateAResult = BeginInvoke(uidlg, new object[] { errorMessage });
                }
            }
            else
            {
                if (mySs != null)
                {
                    for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
                    {
                        Data.Items[i].SubItems[1].Text = data[i].ToString();
                    }
                }

                if (errorMessage.Length > 0)
                {
                    ErrorText.AppendText(errorMessage);
                }
            }
        }

        private void Stop_Click(object sender, System.EventArgs e)
        {
            String timerType;

            Resource.Enabled = true;
            Go.Enabled = true;

            if (mySs != null)
            {
                st.Stop();

                if (Stopwatch.IsHighResolution)
                {
                    timerType = "Timed with Hi res";
                }
                else
                {
                    timerType = "Not Timed with Hi res";
                }
                ErrorText.AppendText(String.Format("{0} scans in {1} ms -> {2} Hz ({3})",
                    count, st.ElapsedMilliseconds, 1000.0 * count / st.ElapsedMilliseconds, timerType));

                try
                {
                    mySs.Stop();
                    // wait for current async call to complete
                    // before destroying the session
                    readerIAsyncResult.AsyncWaitHandle.WaitOne();
                }
                catch (UeiDaqException exception)
                {
                    ErrorText.AppendText("Error: (" + exception.Error + ") " + exception.Message);
                }

                mySs.Dispose();
                mySs = null;
            }
        }
    }
}
