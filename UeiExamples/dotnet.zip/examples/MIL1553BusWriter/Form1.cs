using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text.RegularExpressions;
using UeiDaq;

namespace MIL1553BusWriter
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.Button Start;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.GroupBox groupBox2;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.Button Send;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Label label6;
      private System.Windows.Forms.Label label8;
      private System.Windows.Forms.TextBox BMPort;
      private System.Windows.Forms.GroupBox groupBox3;
      private System.Windows.Forms.Label label10;
      private System.Windows.Forms.Label label11;
      private System.Windows.Forms.TextBox BWPort;
      private Label label7;
      private TextBox Sa2;
      private Label label12;
      private TextBox Rt2;
      private TextBox WordCount;
      private TextBox Sa;
      private TextBox Rt;
      private CheckBox RandomTx;
      private Label label13;
      private ComboBox MessageType;
      private Label label9;
      private TextBox TxData;
      private Timer RxTimer;
      private Timer TxTimer;
      private ComboBox BWCoupling;
      private TextBox BM;
      private ComboBox BWBus;
      private Label label14;
      private ComboBox BMCoupling;
      private Label label16;
      private ComboBox BMBus;
      private Label label15;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.BM = new System.Windows.Forms.TextBox();
         this.label4 = new System.Windows.Forms.Label();
         this.Start = new System.Windows.Forms.Button();
         this.Stop = new System.Windows.Forms.Button();
         this.Resource = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.BWCoupling = new System.Windows.Forms.ComboBox();
         this.Quit = new System.Windows.Forms.Button();
         this.label3 = new System.Windows.Forms.Label();
         this.groupBox2 = new System.Windows.Forms.GroupBox();
         this.RandomTx = new System.Windows.Forms.CheckBox();
         this.label9 = new System.Windows.Forms.Label();
         this.TxData = new System.Windows.Forms.TextBox();
         this.label13 = new System.Windows.Forms.Label();
         this.MessageType = new System.Windows.Forms.ComboBox();
         this.label7 = new System.Windows.Forms.Label();
         this.Sa2 = new System.Windows.Forms.TextBox();
         this.label12 = new System.Windows.Forms.Label();
         this.Rt2 = new System.Windows.Forms.TextBox();
         this.label8 = new System.Windows.Forms.Label();
         this.WordCount = new System.Windows.Forms.TextBox();
         this.label6 = new System.Windows.Forms.Label();
         this.Sa = new System.Windows.Forms.TextBox();
         this.label5 = new System.Windows.Forms.Label();
         this.Rt = new System.Windows.Forms.TextBox();
         this.Send = new System.Windows.Forms.Button();
         this.label2 = new System.Windows.Forms.Label();
         this.BWPort = new System.Windows.Forms.TextBox();
         this.BMPort = new System.Windows.Forms.TextBox();
         this.groupBox3 = new System.Windows.Forms.GroupBox();
         this.BMCoupling = new System.Windows.Forms.ComboBox();
         this.label16 = new System.Windows.Forms.Label();
         this.BMBus = new System.Windows.Forms.ComboBox();
         this.label15 = new System.Windows.Forms.Label();
         this.BWBus = new System.Windows.Forms.ComboBox();
         this.label14 = new System.Windows.Forms.Label();
         this.label11 = new System.Windows.Forms.Label();
         this.label10 = new System.Windows.Forms.Label();
         this.groupBox1.SuspendLayout();
         this.groupBox2.SuspendLayout();
         this.groupBox3.SuspendLayout();
         this.SuspendLayout();
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.BM);
         this.groupBox1.Location = new System.Drawing.Point(8, 196);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(504, 223);
         this.groupBox1.TabIndex = 22;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Bus monitor";
         // 
         // BM
         // 
         this.BM.Location = new System.Drawing.Point(12, 16);
         this.BM.Multiline = true;
         this.BM.Name = "BM";
         this.BM.ReadOnly = true;
         this.BM.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.BM.Size = new System.Drawing.Size(484, 199);
         this.BM.TabIndex = 0;
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(8, 8);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(488, 44);
         this.label4.TabIndex = 12;
         this.label4.Text = "This example shows how to send generic MIL-1553 frames out of port 0 and read tho" +
    "se frames back from port 1.\r\nPort 0 is configured as a bus writer and port 1 is " +
    "configured as a bus monitor.";
         // 
         // Start
         // 
         this.Start.Location = new System.Drawing.Point(16, 587);
         this.Start.Name = "Start";
         this.Start.Size = new System.Drawing.Size(88, 32);
         this.Start.TabIndex = 20;
         this.Start.Text = "Start";
         this.Start.Click += new System.EventHandler(this.Start_Click);
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(224, 587);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(88, 32);
         this.Stop.TabIndex = 19;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(10, 48);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(176, 20);
         this.Resource.TabIndex = 16;
         this.Resource.Text = "pdna://192.168.100.2/Dev10/";
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(10, 32);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(100, 16);
         this.label1.TabIndex = 13;
         this.label1.Text = "Resource";
         // 
         // BWCoupling
         // 
         this.BWCoupling.Items.AddRange(new object[] {
            "Disconnected",
            "Transformer",
            "LocalStub",
            "Direct"});
         this.BWCoupling.Location = new System.Drawing.Point(391, 32);
         this.BWCoupling.Name = "BWCoupling";
         this.BWCoupling.Size = new System.Drawing.Size(97, 21);
         this.BWCoupling.TabIndex = 15;
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(416, 585);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(88, 32);
         this.Quit.TabIndex = 18;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(8, 54);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(488, 29);
         this.label3.TabIndex = 14;
         this.label3.Text = "Press the \"Start\" button to start the session. Received MIL-1553 frames will appe" +
    "ar in the bus monitor. Press the \"Send\" button to send frames.";
         // 
         // groupBox2
         // 
         this.groupBox2.Controls.Add(this.RandomTx);
         this.groupBox2.Controls.Add(this.label9);
         this.groupBox2.Controls.Add(this.TxData);
         this.groupBox2.Controls.Add(this.label13);
         this.groupBox2.Controls.Add(this.MessageType);
         this.groupBox2.Controls.Add(this.label7);
         this.groupBox2.Controls.Add(this.Sa2);
         this.groupBox2.Controls.Add(this.label12);
         this.groupBox2.Controls.Add(this.Rt2);
         this.groupBox2.Controls.Add(this.label8);
         this.groupBox2.Controls.Add(this.WordCount);
         this.groupBox2.Controls.Add(this.label6);
         this.groupBox2.Controls.Add(this.Sa);
         this.groupBox2.Controls.Add(this.label5);
         this.groupBox2.Controls.Add(this.Rt);
         this.groupBox2.Controls.Add(this.Send);
         this.groupBox2.Location = new System.Drawing.Point(8, 425);
         this.groupBox2.Name = "groupBox2";
         this.groupBox2.Size = new System.Drawing.Size(504, 142);
         this.groupBox2.TabIndex = 21;
         this.groupBox2.TabStop = false;
         this.groupBox2.Text = "Send MIL-1553 frame";
         // 
         // RandomTx
         // 
         this.RandomTx.AutoSize = true;
         this.RandomTx.Location = new System.Drawing.Point(375, 40);
         this.RandomTx.Name = "RandomTx";
         this.RandomTx.Size = new System.Drawing.Size(117, 17);
         this.RandomTx.TabIndex = 24;
         this.RandomTx.Text = "Auto-generate data";
         this.RandomTx.UseVisualStyleBackColor = true;
         // 
         // label9
         // 
         this.label9.AutoSize = true;
         this.label9.Location = new System.Drawing.Point(12, 70);
         this.label9.Name = "label9";
         this.label9.Size = new System.Drawing.Size(258, 13);
         this.label9.TabIndex = 18;
         this.label9.Text = "Data (comma separated list of up to 36 UIn32 values)";
         // 
         // TxData
         // 
         this.TxData.Location = new System.Drawing.Point(12, 87);
         this.TxData.Multiline = true;
         this.TxData.Name = "TxData";
         this.TxData.Size = new System.Drawing.Size(484, 49);
         this.TxData.TabIndex = 17;
         this.TxData.Text = "0x00, 0x01, 0x02, 0x03";
         // 
         // label13
         // 
         this.label13.Location = new System.Drawing.Point(101, 24);
         this.label13.Name = "label13";
         this.label13.Size = new System.Drawing.Size(74, 16);
         this.label13.TabIndex = 16;
         this.label13.Text = "Message type";
         // 
         // MessageType
         // 
         this.MessageType.FormattingEnabled = true;
         this.MessageType.Items.AddRange(new object[] {
            "BC-RT",
            "RT-BC",
            "RT-RT"});
         this.MessageType.Location = new System.Drawing.Point(103, 40);
         this.MessageType.Name = "MessageType";
         this.MessageType.Size = new System.Drawing.Size(61, 21);
         this.MessageType.TabIndex = 15;
         // 
         // label7
         // 
         this.label7.Location = new System.Drawing.Point(276, 24);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(27, 16);
         this.label7.TabIndex = 14;
         this.label7.Text = "Sa2";
         // 
         // Sa2
         // 
         this.Sa2.Location = new System.Drawing.Point(276, 40);
         this.Sa2.Name = "Sa2";
         this.Sa2.Size = new System.Drawing.Size(27, 20);
         this.Sa2.TabIndex = 13;
         this.Sa2.Text = "0x2";
         // 
         // label12
         // 
         this.label12.Location = new System.Drawing.Point(242, 24);
         this.label12.Name = "label12";
         this.label12.Size = new System.Drawing.Size(31, 13);
         this.label12.TabIndex = 12;
         this.label12.Text = "Rt2";
         // 
         // Rt2
         // 
         this.Rt2.Location = new System.Drawing.Point(242, 40);
         this.Rt2.Name = "Rt2";
         this.Rt2.Size = new System.Drawing.Size(31, 20);
         this.Rt2.TabIndex = 11;
         this.Rt2.Text = "0x12";
         // 
         // label8
         // 
         this.label8.Location = new System.Drawing.Point(315, 24);
         this.label8.Name = "label8";
         this.label8.Size = new System.Drawing.Size(76, 16);
         this.label8.TabIndex = 8;
         this.label8.Text = "Word count";
         // 
         // WordCount
         // 
         this.WordCount.Location = new System.Drawing.Point(315, 40);
         this.WordCount.Name = "WordCount";
         this.WordCount.Size = new System.Drawing.Size(40, 20);
         this.WordCount.TabIndex = 7;
         this.WordCount.Text = "0";
         // 
         // label6
         // 
         this.label6.Location = new System.Drawing.Point(212, 24);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(27, 16);
         this.label6.TabIndex = 4;
         this.label6.Text = "Sa";
         // 
         // Sa
         // 
         this.Sa.Location = new System.Drawing.Point(212, 40);
         this.Sa.Name = "Sa";
         this.Sa.Size = new System.Drawing.Size(27, 20);
         this.Sa.TabIndex = 3;
         this.Sa.Text = "0x2";
         // 
         // label5
         // 
         this.label5.Location = new System.Drawing.Point(178, 24);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(31, 13);
         this.label5.TabIndex = 2;
         this.label5.Text = "Rt";
         // 
         // Rt
         // 
         this.Rt.Location = new System.Drawing.Point(178, 40);
         this.Rt.Name = "Rt";
         this.Rt.Size = new System.Drawing.Size(31, 20);
         this.Rt.TabIndex = 1;
         this.Rt.Text = "0x12";
         // 
         // Send
         // 
         this.Send.Location = new System.Drawing.Point(8, 16);
         this.Send.Name = "Send";
         this.Send.Size = new System.Drawing.Size(80, 48);
         this.Send.TabIndex = 0;
         this.Send.Text = "Send";
         this.Send.Click += new System.EventHandler(this.Send_Click);
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(389, 15);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(100, 16);
         this.label2.TabIndex = 17;
         this.label2.Text = "BW coupling";
         // 
         // BWPort
         // 
         this.BWPort.Location = new System.Drawing.Point(192, 32);
         this.BWPort.Name = "BWPort";
         this.BWPort.Size = new System.Drawing.Size(48, 20);
         this.BWPort.TabIndex = 23;
         this.BWPort.Text = "MILB0";
         // 
         // BMPort
         // 
         this.BMPort.Location = new System.Drawing.Point(192, 72);
         this.BMPort.Name = "BMPort";
         this.BMPort.Size = new System.Drawing.Size(48, 20);
         this.BMPort.TabIndex = 23;
         this.BMPort.Text = "MILB1";
         // 
         // groupBox3
         // 
         this.groupBox3.Controls.Add(this.BMCoupling);
         this.groupBox3.Controls.Add(this.label16);
         this.groupBox3.Controls.Add(this.BMBus);
         this.groupBox3.Controls.Add(this.label15);
         this.groupBox3.Controls.Add(this.BWBus);
         this.groupBox3.Controls.Add(this.label14);
         this.groupBox3.Controls.Add(this.label11);
         this.groupBox3.Controls.Add(this.label10);
         this.groupBox3.Controls.Add(this.Resource);
         this.groupBox3.Controls.Add(this.label1);
         this.groupBox3.Controls.Add(this.BWPort);
         this.groupBox3.Controls.Add(this.BMPort);
         this.groupBox3.Controls.Add(this.BWCoupling);
         this.groupBox3.Controls.Add(this.label2);
         this.groupBox3.Location = new System.Drawing.Point(8, 92);
         this.groupBox3.Name = "groupBox3";
         this.groupBox3.Size = new System.Drawing.Size(504, 96);
         this.groupBox3.TabIndex = 24;
         this.groupBox3.TabStop = false;
         this.groupBox3.Text = "Ports Configuration";
         // 
         // BMCoupling
         // 
         this.BMCoupling.Items.AddRange(new object[] {
            "Disconnected",
            "Transformer",
            "LocalStub",
            "Direct"});
         this.BMCoupling.Location = new System.Drawing.Point(392, 72);
         this.BMCoupling.Name = "BMCoupling";
         this.BMCoupling.Size = new System.Drawing.Size(97, 21);
         this.BMCoupling.TabIndex = 28;
         // 
         // label16
         // 
         this.label16.Location = new System.Drawing.Point(390, 55);
         this.label16.Name = "label16";
         this.label16.Size = new System.Drawing.Size(100, 16);
         this.label16.TabIndex = 29;
         this.label16.Text = "BM coupling";
         // 
         // BMBus
         // 
         this.BMBus.Items.AddRange(new object[] {
            "Bus A",
            "Bus B",
            "Both"});
         this.BMBus.Location = new System.Drawing.Point(296, 72);
         this.BMBus.Name = "BMBus";
         this.BMBus.Size = new System.Drawing.Size(79, 21);
         this.BMBus.TabIndex = 26;
         // 
         // label15
         // 
         this.label15.Location = new System.Drawing.Point(294, 56);
         this.label15.Name = "label15";
         this.label15.Size = new System.Drawing.Size(66, 15);
         this.label15.TabIndex = 27;
         this.label15.Text = "BM bus";
         // 
         // BWBus
         // 
         this.BWBus.Items.AddRange(new object[] {
            "Bus A",
            "Bus B",
            "Both"});
         this.BWBus.Location = new System.Drawing.Point(296, 32);
         this.BWBus.Name = "BWBus";
         this.BWBus.Size = new System.Drawing.Size(79, 21);
         this.BWBus.TabIndex = 24;
         // 
         // label14
         // 
         this.label14.Location = new System.Drawing.Point(294, 16);
         this.label14.Name = "label14";
         this.label14.Size = new System.Drawing.Size(66, 15);
         this.label14.TabIndex = 25;
         this.label14.Text = "BW bus";
         // 
         // label11
         // 
         this.label11.Location = new System.Drawing.Point(192, 56);
         this.label11.Name = "label11";
         this.label11.Size = new System.Drawing.Size(98, 13);
         this.label11.TabIndex = 1;
         this.label11.Text = "Bus monitor port";
         // 
         // label10
         // 
         this.label10.Location = new System.Drawing.Point(192, 16);
         this.label10.Name = "label10";
         this.label10.Size = new System.Drawing.Size(80, 13);
         this.label10.TabIndex = 0;
         this.label10.Text = "Bus writer port";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(520, 623);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.label4);
         this.Controls.Add(this.Start);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.groupBox2);
         this.Controls.Add(this.groupBox3);
         this.Name = "Form1";
         this.Text = "Form1";
         this.Load += new System.EventHandler(this.OnLoad);
         this.groupBox1.ResumeLayout(false);
         this.groupBox1.PerformLayout();
         this.groupBox2.ResumeLayout(false);
         this.groupBox2.PerformLayout();
         this.groupBox3.ResumeLayout(false);
         this.groupBox3.PerformLayout();
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private Session MIL1553Session;
      private MIL1553Reader reader;
      private MIL1553Writer writer;
      private int txCount;
      
      private void InitUI(bool isRunning)
      {
         if(isRunning)
         {
            Start.Enabled = false;
            Stop.Enabled = true;
            if (!RandomTx.Checked)
            {
               Send.Enabled = true;
            }
            Quit.Enabled = false;
            RandomTx.Enabled = false;
         }
         else
         {
            Start.Enabled = true;
            Stop.Enabled = false;
            Quit.Enabled = true;
            Send.Enabled = false;
            RandomTx.Enabled = true;
         }
      }

      private void OnLoad(object sender, System.EventArgs e)
      {
         BWCoupling.SelectedIndex = 1;
         BMCoupling.SelectedIndex = 1;
         BWBus.SelectedIndex = 0;
         BMBus.SelectedIndex = 0;
         MessageType.SelectedIndex = 0;
         InitUI(false);
      }

      private void Start_Click(object sender, System.EventArgs e)
      {
         try
         {
            MIL1553Session = new Session();

            // Create Bus writer port
            MIL1553Port bwPort = MIL1553Session.CreateMIL1553Port(Resource.Text + BMPort.Text, 
                                             (MIL1553PortCoupling)BWCoupling.SelectedIndex, 
                                             MIL1553PortOpMode.BusMonitor);
            bwPort.SetTxBus((MIL1553PortActiveBus)BWBus.SelectedIndex);
            bwPort.SetRxBus((MIL1553PortActiveBus)BWBus.SelectedIndex);
            
            // Create Bus monitor port
            MIL1553Port bmPort = MIL1553Session.CreateMIL1553Port(Resource.Text + BWPort.Text,
                                             (MIL1553PortCoupling)BMCoupling.SelectedIndex,
                                             MIL1553PortOpMode.BusMonitor);
            bmPort.SetTxBus((MIL1553PortActiveBus)BMBus.SelectedIndex);
            bmPort.SetRxBus((MIL1553PortActiveBus)BMBus.SelectedIndex);

            MIL1553Session.ConfigureTimingForMessagingIO(1, 0.1);
            MIL1553Session.GetTiming().SetTimeout(10);

            // Start the session
            MIL1553Session.Start();

            // Create a reader for BM port
            reader = new MIL1553Reader(MIL1553Session.GetDataStream(), Int32.Parse(BMPort.Text.Substring(4,1)));

            // Create a writer for BW port
            writer = new MIL1553Writer(MIL1553Session.GetDataStream(), Int32.Parse(BWPort.Text.Substring(4,1)));

            // Clear received frames from previous run
            BM.Clear();

            // Switch UI components to start state
            InitUI(true);

            // Start RX timer to periodically read messages received by bus monitor
            RxTimer = new Timer();
            RxTimer.Interval = 100;
            RxTimer.Start();
            RxTimer.Tick += new EventHandler(RxTimer_Tick);

            // Start TX timer if user wants to automatically
            // generate some traffic out of bus writer port
            if (RandomTx.Checked)
            {
               txCount = 0;
               TxTimer = new Timer();
               TxTimer.Interval = 100;
               TxTimer.Start();
               TxTimer.Tick += new EventHandler(TxTimer_Tick);
            }
         }
         catch(UeiDaqException ex)
         {
            MIL1553Session.Dispose();
            MIL1553Session = null;
            MessageBox.Show(this, ex.Message, "Error");
            InitUI(false);
         }
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         try
         {
            if (RandomTx.Checked)
            {
               TxTimer.Stop();
            }
            RxTimer.Stop();
            MIL1553Session.Stop();
         }
         catch(UeiDaqException ex)
         {
            MessageBox.Show(this, ex.Message, "Error");
         }

         MIL1553Session.Dispose();
         MIL1553Session = null;
         
         // Switch UI components to stop state
         InitUI(false);
      }

      private void Send_Click(object sender, System.EventArgs e)
      {
         try
         {
            // Build the MIL-1553 bus writer frame array to send to the MIL-1553 port
            MIL1553BusWriterFrame[] frames = new MIL1553BusWriterFrame[1];
            frames[0] = new MIL1553BusWriterFrame();

            frames[0].Command = (MIL1553CommandType)MessageType.SelectedIndex; 
            frames[0].Rt = Convert.ToUInt16(Rt.Text, 16);
            frames[0].Sa = Convert.ToUInt16(Sa.Text, 16);
            frames[0].Rt2 = Convert.ToUInt16(Rt2.Text, 16);
            frames[0].Sa2 = Convert.ToUInt16(Sa2.Text, 16);
            frames[0].WordCount = Convert.ToUInt16(WordCount.Text);
            
            // parse csv data 
            if (TxData.Text.Length > 0)
            {
               string[] values = Regex.Split(TxData.Text, ",");

               frames[0].DataSize = (uint)values.Length;
               frames[0].TxData = new UInt32[values.Length];
               for (int i = 0; i < values.Length; i++)
               {
                  frames[0].TxData[i] = Convert.ToUInt32(values[i].Trim(' '), 16);
               }
            }
            else
            {
               frames[0].DataSize = 0;
            }
                        
            writer.WriteBusWriter(frames);
         }
         catch(UeiDaqException ex)
         {
            MIL1553Session.Dispose();
            MIL1553Session = null;
            MessageBox.Show(this, ex.Message, "Error");
            InitUI(false);
         }      
      }

      public void RxTimer_Tick(object sender, EventArgs eArgs)
      {
         if (sender == RxTimer)
         {
            try
            {
               MIL1553BMFrame[] frames = reader.ReadBM(1);

               foreach (MIL1553BMFrame f in frames)
               {
                  // Get string representation of BM frame and relpalce tabs with spaces
                  String frameStr = f.ToString();
                  frameStr = frameStr.Replace("\t", " ");
                  frameStr = frameStr.Replace("\n", Environment.NewLine);

                  BM.AppendText(frameStr);

                  // Make sure latest received frame is visible
                  BM.SelectionStart = BM.Text.Length;
                  BM.ScrollToCaret();
               }
            }
            catch (UeiDaqException ex)
            {
               if (Error.Timeout == ex.Error)
               {
                  // Ignore timeout error, they will occur if the send button is not
                  // clicked on fast enough!
               }
               else
               {
                  MIL1553Session.Dispose();
                  MIL1553Session = null;
                  MessageBox.Show(this, ex.Message, "Error");
                  InitUI(false);
               }
            }
         }
      }

      public void TxTimer_Tick(object sender, EventArgs eArgs)
      {
         if (sender == TxTimer)
         {
            MIL1553CommandType[] commands = { MIL1553CommandType.BCRT, MIL1553CommandType.RTBC, MIL1553CommandType.RTRT };
            try
            {
               // Build the MIL-1553 bus writer frame array to send to the MIL-1553 port
               MIL1553BusWriterFrame[] frames = new MIL1553BusWriterFrame[1];
               frames[0] = new MIL1553BusWriterFrame();

               frames[0].Command = commands[txCount % 3];
               frames[0].Rt = (ushort)(txCount % 32);
               frames[0].Sa = (ushort)(32 - frames[0].Rt+1);
               
               frames[0].DataSize = (uint)frames[0].Rt+1;
               frames[0].TxData = new UInt32[frames[0].DataSize];
               for (int i = 0; i < frames[0].DataSize; i++)
               {
                  frames[0].TxData[i] = (uint)(txCount + i);
               }

               writer.WriteBusWriter(frames);
            }
            catch (UeiDaqException ex)
            {
               MIL1553Session.Dispose();
               MIL1553Session = null;
               MessageBox.Show(this, ex.Message, "Error");
               InitUI(false);
            }

            txCount++;
         }
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         Application.Exit();
      }
	}
}
