#include <windows.h>
#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    goto on_error;}}

SessionHandle hSession;
// Maximum number of CAN frames to read at a time
#define MAX_FRAMES 2  
tUeiCANFrame framesReceived[MAX_FRAMES];

void OnEvent(tUeiEvent event, void *param)
{
   if(event == UeiEventFrameDone)
   {
      Int32 i;
      Int32 numFramesReceived = (int)(intptr_t)param;
      
      // data contains latest samples, do something with it...
      for(i=0; i<numFramesReceived;i++)
      {
         printf("received frame ID=0x%x\n", framesReceived[i].Id);
      }

      // rearm the session to generate the next asynchronous event
      // when enough new frames will be ready
      UeiDaqErrChk(UeiDaqReadCANFrameAsync(hSession, 1, MAX_FRAMES, framesReceived, OnEvent));
   }

   if(event == UeiEventError)
   {
      tUeiError error = (tUeiError)param;
      int isRunning;

      // Check whether the session is still running
      UeiDaqErrChk(UeiDaqIsSessionRunning(hSession, &isRunning));

      if(isRunning)
      {
         if(UEIDAQ_TIMEOUT_ERROR == error)
         {
            // Timeout error are expected if not enough CAN frames are received
            // Initiate a new read
            UeiDaqErrChk(UeiDaqReadCANFrameAsync(hSession, 1, MAX_FRAMES, framesReceived, OnEvent));
         }
         else
         {
            fprintf(stderr, "Error %d occurred: %s\n", error, UeiDaqTranslateError(error));
         }
      }
   }
 
on_error:

   return;
}


// This example continuously sends CAN frames on port 0 and receives them on port 1
int main(int argc, char* argv[])
{
   int i;
   TimingHandle hTiming;

   // Create Session object
   UeiDaqErrChk(UeiDaqCreateSession(&hSession));

   UeiDaqErrChk(UeiDaqCreateCANPort(hSession, "pdna://192.168.15.200/Dev0/CAN0,1",
                                    UeiCANBitsPerSecond500K,
                                    UeiCANFrameExtended,
                                    UeiCANPortModeNormal,
                                    0xFFFFFFFF,
                                    0)); 

   UeiDaqErrChk(UeiDaqConfigureTimingForMessagingIO(hSession, MAX_FRAMES, 0));
   UeiDaqErrChk(UeiDaqGetTimingHandle(hSession, &hTiming));
   UeiDaqErrChk(UeiDaqSetTimingTimeout(hTiming, 100));

   UeiDaqErrChk(UeiDaqStartSession(hSession));

   // Initiate asynchronous read from port 1
   // We will call this method from the event handler to keep listening
   // on port 1
   UeiDaqErrChk(UeiDaqReadCANFrameAsync(hSession, 1, MAX_FRAMES, framesReceived, OnEvent));

   // Send 1024 CAN frames out to port 0.
   for(i=0; i<1024; i++)
   {
      tUeiCANFrame frame;
      Int32 numFramesWritten;

      frame.Id = i++;
      frame.Type = UeiCANFrameTypeData;
      frame.DataSize = 1;
      frame.Data[0] = (uInt8)i;
      UeiDaqErrChk(UeiDaqWriteCANFrame(hSession, 0, 1, &frame, &numFramesWritten));
      Sleep(20);
   }

   UeiDaqErrChk(UeiDaqStopSession(hSession));
      
on_error:

   UeiDaqCloseSession(hSession);

   return 0;
}