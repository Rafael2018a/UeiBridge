#include <windows.h>
#include <conio.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    goto on_error;}}

SessionHandle hSession;
TimingHandle hTiming;
DeviceHandle hDevice;

// Maximum number of CAN frames to read at a time
#define CHANNEL    0   // channel 0 to use
#define CHANNELS   1    // total channels
#define FRAMES     2    // number of CUeiMIL1553RTFrame



int main(int argc, char* argv[])
{
	int error = 0;
	int cycles = 100;
	int j,f,i;
	int startRt[FRAMES] = { 4,8 };
	int startSa[FRAMES] = { 4,8 };
	int WordCount[FRAMES] = { 32, 32 };
	Int32 bwnumFramesWrite;	
	Int32 bw_chan = 0;
	tUeiMIL1553BusWriterFrame outbwFrm[FRAMES];

	tUeiMIL1553CommandType cmdType;
	const char *cmdTypeStr[] = { "UeiMIL1553CmdBCRT" };
	// Create Session object
			
	UeiDaqErrChk(UeiDaqCreateSession(&hSession));

	UeiDaqErrChk(UeiDaqCreateMIL1553Port(hSession, "pdna://192.168.100.21/Dev0/milb0", UeiMIL1553CouplingDirect, UeiMIL1553OpModeBusMonitor));
	
	UeiDaqErrChk(UeiDaqConfigureTimingForMessagingIO(hSession, 1, 0));
	UeiDaqErrChk(UeiDaqGetTimingHandle(hSession, &hTiming));
	 
	UeiDaqErrChk(UeiDaqGetDeviceHandle(hSession, &hDevice));
	
	UeiDaqErrChk(UeiDaqSetTimingTimeout(hTiming, 100));
	

	UeiDaqErrChk(UeiDaqStartSession(hSession));

	cmdType = UeiMIL1553CmdBCRT;

	for (j = 0; j < cycles; j++)
	{

		printf("Iteration: %d\n", j);

		for (f = 0; f < FRAMES; f++)
		{
			outbwFrm[f].WordCount = 32;
			outbwFrm[f].DataSize = WordCount[f];
			outbwFrm[f].Command = cmdType;
			outbwFrm[f].Rt = startRt[f];
			outbwFrm[f].Sa = startSa[f];
			outbwFrm[f].Flags = 0;
			outbwFrm[f].Delay = 0;
			for (i = 0; i < 36; i++)
			{
				outbwFrm[f].TxData[i] = i;
			}
			printf("OUTPUT - Frame %d: Command: %s RT-%d-SA-%d\n", f, cmdTypeStr[UeiMIL1553CmdBCRT],outbwFrm[f].Rt, outbwFrm[f].Rt);
		}
		UeiDaqErrChk(UeiDaqWriteMIL1553BusWriterFrames(hSession, bw_chan, FRAMES, outbwFrm, &bwnumFramesWrite));
		printf("Num Frames Written: %d\n", bwnumFramesWrite);

		Sleep(100);
	}

	UeiDaqErrChk(UeiDaqStopSession(hSession));

on_error:

	UeiDaqCloseSession(hSession);

	return 0;
}