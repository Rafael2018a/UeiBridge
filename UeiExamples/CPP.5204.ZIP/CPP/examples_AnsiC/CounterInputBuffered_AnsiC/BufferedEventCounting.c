#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}


int main(int argc, char* argv[])
{
   SessionHandle mySs;
   unsigned short countedEvents[1000];

   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&mySs));

      // Create one counter input channel on a powerdaq board to count digital 
      // events applied on the input of the counter.
      // From now on the session is CI only
      UeiDaqErrChk(UeiDaqCreateCIChannel(mySs, "pwrdaq://Dev0/ci0", 
                           UeiCounterSourceInput, 
                           UeiCounterModeCountEvents,
                           UeiCounterGateInternal,
                           1,
                           0));

      // Configure the session to acquire 1000 counts clocked by internal clock
      UeiDaqErrChk(UeiDaqConfigureTimingForBufferedIO(mySs, 1000, UeiTimingClockSourceInternal, 10000.0, UeiDigitalEdgeRising, UeiTimingDurationSingleShot));

      // Start counting
      UeiDaqErrChk(UeiDaqStartSession(mySs));

      // Read 1000 samples
      UeiDaqErrChk(UeiDaqReadRawData16(mySs, -1, 1000, countedEvents));

      UeiDaqErrChk(UeiDaqStopSession(mySs));
      UeiDaqErrChk(UeiDaqCloseSession(mySs));

   } while(0);

   return 0;
}