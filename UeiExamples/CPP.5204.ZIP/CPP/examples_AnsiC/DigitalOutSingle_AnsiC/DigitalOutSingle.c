#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}

int main(int argc, char* argv[])
{
   SessionHandle doSs;
   DeviceHandle dev;
   int portWidth;
   int numPorts;
   uInt16* datas = NULL;   // for devices with 16 or less output lines per port
   uInt32* datal = NULL;   // for devices with more than 16 output lines per port
   int p, i;

   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&doSs));
      
      // Create 1 digital input channel on a powerdaq board
      // From now on the session is DI only
      UeiDaqErrChk(UeiDaqCreateDOChannel(doSs, "pdna://192.168.15.201/Dev4/do0"));
      
      // Configure timing for simple point by point operations
      UeiDaqErrChk(UeiDaqConfigureTimingForSimpleIO(doSs));

      // Retrive the number of ports psecified in the resource string
      UeiDaqErrChk(UeiDaqGetNumberOfChannels(doSs, &numPorts));

      // get the handle on the device to be able to retrieve the
      // port width
      UeiDaqErrChk(UeiDaqGetDeviceHandle(doSs, &dev));

      UeiDaqErrChk(UeiDaqGetDeviceDOResolution(dev, &portWidth));

      // Digital data will be stored in a 16 bits or 32 bits integer buffer
      // depending on the width of the port
      // let's allocate a buffer big enough to hold one value for each configured port
      if(portWidth <= 16)
      {
         datas = (uInt16*)malloc(numPorts*sizeof(uInt16));
      }
      else
      {
         datal = (uInt32*)malloc(numPorts*sizeof(uInt32));
      }
      
      // Start the session
      UeiDaqErrChk(UeiDaqStartSession(doSs));
      
      // Read 100 events
      for(i=0; i<100; i++)
      {
         if(datas != NULL)
         {
            // Create digital patterns to generate
            for(p=0; p<numPorts; p++)
            {
               datas[p] = 1 << (i % portWidth);
            }
            UeiDaqErrChk(UeiDaqWriteRawData16(doSs, 0, numPorts, datas));
            printf("Digital output 0x%x\n", datas[0]);
         }
         else
         {
            // Create digital patterns to generate
            for(p=0; p<numPorts; p++)
            {
               datal[p] = 1 << (i % portWidth);
            }
            UeiDaqErrChk(UeiDaqWriteRawData32(doSs, 0, numPorts, datal));
            printf("Digital output 0x%x\n", datal[0]);
         }

         Sleep(100);
      }

      UeiDaqErrChk(UeiDaqStopSession(doSs));
      
      UeiDaqErrChk(UeiDaqCloseSession(doSs));
   }
   while(0);

   if(datas != NULL)
   {
      free(datas);
   }
   if(datal != NULL)
   {
      free(datal);
   }

   return 0;
}

