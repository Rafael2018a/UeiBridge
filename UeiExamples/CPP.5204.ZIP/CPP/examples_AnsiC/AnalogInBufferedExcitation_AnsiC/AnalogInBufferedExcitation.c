#include <stdlib.h>
#include <stdio.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}

int main(int argc, char* argv[])
{
   SessionHandle mySs;
   int i, numChannels;
   double data[8000];

   // This do/while loop is here to allow us to break out of the normal code flow
   // when an error occurrs 
   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&mySs));

      // Create 8 analog input channels on a powerdaq board
      // From now on the session is AI only
      UeiDaqErrChk(UeiDaqCreateAIVExChannel(mySs, "simu://Dev0/ai0:7", -10.0, 10.0, UeiSensorFullBridge, 10, 0, UeiAIChannelInputModeDifferential));

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      UeiDaqErrChk(UeiDaqConfigureTimingForBufferedIO(mySs, 1000, UeiTimingClockSourceInternal, 10000.0, UeiDigitalEdgeRising, UeiTimingDurationSingleShot));

      // The internal frame size and number of frames is automatically calculated
      // We can override it with the following function calls
      //UeiDaqErrChk(UeiDaqSetDataStreamNumberOfScans(mySs, 500));
      //UeiDaqErrChk(UeiDaqSetDataStreamNumberOfFrames(mySs, 8));

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as we start reading data.
      UeiDaqErrChk(UeiDaqStartSession(mySs));

      UeiDaqErrChk(UeiDaqReadScaledData(mySs, -1, 1000, data));

      UeiDaqErrChk(UeiDaqGetNumberOfChannels(mySs, &numChannels));
      for(i=0; i<numChannels;i++)
      {
         printf("ch %d = %f ", i, data[i]);
      }

      printf("\n");

      UeiDaqErrChk(UeiDaqStopSession(mySs));
      UeiDaqErrChk(UeiDaqCloseSession(mySs));
   }
   while(0);

   return 0;
}