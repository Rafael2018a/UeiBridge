#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}

int main(int argc, char* argv[])
{
   SessionHandle mySs;
   double data[8000];
   int running = 1;

   // This do/while loop is here to allow us to break out of the normal code flow
   // when an error occurrs 
   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&mySs));

      // Create 2 analog output channels on a powerdaq board
      // From now on the session is AO only
      UeiDaqErrChk(UeiDaqCreateAOChannel(mySs, "simu://Dev0/ao0:1", -10.0, 10.0));

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      UeiDaqErrChk(UeiDaqConfigureTimingForBufferedIO(mySs, 1000, UeiTimingClockSourceInternal, 10000.0, UeiDigitalEdgeRising, UeiTimingDurationSingleShot));

      // Fill the buffer before starting generation
      UeiDaqErrChk(UeiDaqWriteScaledData(mySs, -1, 1000, data));

      // Start the acquisition,
      UeiDaqErrChk(UeiDaqStartSession(mySs));

      // Wait until all scans are generated
      while(running)
      {
         UeiDaqErrChk(UeiDaqIsSessionRunning(mySs, &running));
      };

      UeiDaqErrChk(UeiDaqStartSession(mySs));
   }
   while(0);

   return 0;
}