#include <windows.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   int ch;
   CUeiSession vrSs;
   CUeiVRReader** readers = NULL;
   
   try
   {
      // Create VR channels on a devcie capable of reading variable reluctance sensors
      // For example a VR-608
      vrSs.CreateVRChannel("pdna://192.168.100.55/Dev1/vr0,1,2,3", UeiVRModeCounterTimed); 
      for (ch = 0; ch < vrSs.GetNumberOfChannels(); ch++)
      {
         CUeiVRChannel* channel = dynamic_cast<CUeiVRChannel*>(vrSs.GetChannel(ch));
         channel->SetAPTMode(UeiAPTModeLogic);
      }

      readers = new CUeiVRReader*[vrSs.GetNumberOfChannels()];

      // We need one reader per input channel because they are independant
      // and return data at a different rate
      for(ch=0; ch<vrSs.GetNumberOfChannels(); ch++)
      {
         int channel = vrSs.GetChannel(ch)->GetIndex();

         readers[ch] = new CUeiVRReader(vrSs.GetDataStream(), channel);
      }

      int numVrInputs = vrSs.GetNumberOfChannels();

      vrSs.CreateSimulatedVRChannel("pdna://192.168.100.55/Dev1/vr0,1,2,3", UeiVRSimulationModeContinuous, 1000, 36, 0.0);
      for (ch = numVrInputs; ch < vrSs.GetNumberOfChannels(); ch++)
      {
         CUeiSimulatedVRChannel* channel = dynamic_cast<CUeiSimulatedVRChannel*>(vrSs.GetChannel(ch));
         channel->SetRevolutionsPerMinute(ch*1000);
      }

      vrSs.ConfigureTimingForSimpleIO();

      vrSs.Start();

      // Read 100 values and return
      for (int i = 0; i<100; i++)
      {
          for (ch = 0; ch < numVrInputs; ch++)
          {
              int channel = vrSs.GetChannel(ch)->GetIndex();
              tUeiVRData vrData;

              readers[ch]->Read(1, &vrData, NULL);

              std::cout << "Ch" << channel << ": velocity= " << vrData.velocity << std::endl;
              std::cout << "Ch" << channel << ": position= " << vrData.position << std::endl;
              std::cout << "Ch" << channel << ": teeth count= " << vrData.teethCount << std::endl;
          }
          std::cout << std::endl;

          Sleep(100);
      }

      vrSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   if(readers)
   {
      for(ch=0; ch<vrSs.GetNumberOfChannels(); ch++)
      {
         delete readers[ch];
      }
      delete[] readers;
   }

   return 0;
}



