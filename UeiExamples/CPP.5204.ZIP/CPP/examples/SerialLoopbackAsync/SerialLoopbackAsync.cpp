#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include <csignal>
#include "UeiDaq.h"

using namespace UeiDaq;

#define SEND_SIZE  9         // amount of data to send each iteration
#define RECV_SIZE  4         // max amount of data to receive on each read
#define WATERMARK  5         // amount of data to trigger event
#define TIMEOUT_uS 1000000   // time without data to trigger event
                             // allows reading data leftover that is less than WATERMARK level

#define TIMESTAMP TRUE

int stop = 0;
char recvBuffer[RECV_SIZE + 1 + sizeof(uInt32)];

// SIGINT handler. Type CTRL+C to end program
void stophandler(int sig)
{
   stop = 1;
}

void readAndPrint(CUeiSerialReader* reader, bool withTimestamp)
{
   Int32 numBytesRead;
   uInt32 timestamp;

   int startIdx = 0;
   if (withTimestamp)
   {
      reader->ReadTimestamped(RECV_SIZE + sizeof(uInt32), recvBuffer, &numBytesRead);
      startIdx = sizeof(uInt32);
      timestamp = *(uInt32*)&recvBuffer[0];
      printf("  timestamp: %d", timestamp);
   }
   else
   {
      reader->Read(RECV_SIZE, recvBuffer, &numBytesRead);
   }

   printf("  NumBytesRead: %d ", numBytesRead);
   printf("  Data: ");
   for (int i = startIdx; i < numBytesRead; i++)
   {
      printf("%c", recvBuffer[i]);
   }
   printf("\n");
}

int main(int argc, char* argv[])
{
   // install stop handler
   signal(SIGINT, stophandler);

   char sendBuffer[SEND_SIZE + 1];
   int sendCount;
   int i, j;
   CUeiSession mySession;
   CUeiSerialReader** readers;
   CUeiSerialWriter** writers;

   try
   {
      CUeiSerialPort* port = mySession.CreateSerialPort("pdna://192.168.100.4/Dev0/com0,1",
         UeiSerialModeRS485FullDuplex,
         UeiSerialBitsPerSecond57600,
         UeiSerialDataBits8,
         UeiSerialParityNone,
         UeiSerialStopBits1,
         "");
      mySession.ConfigureTimingForAsynchronousIO(WATERMARK, 0, TIMEOUT_uS, 0);
      mySession.GetTiming()->SetTimeout(10);

      // Create an asynchronous listener and a writer for each port configured
      // in the resource string
      writers = new CUeiSerialWriter*[mySession.GetNumberOfChannels()];
      readers = new CUeiSerialReader*[mySession.GetNumberOfChannels()];
      for (i = 0; i < mySession.GetNumberOfChannels(); i++)
      {
         int port = mySession.GetChannel(i)->GetIndex();

         writers[i] = new CUeiSerialWriter(mySession.GetDataStream(), port);
         readers[i] = new CUeiSerialReader(mySession.GetDataStream(), port);
      }

      mySession.Start();

      sendCount = 0;
      while (!stop)
      {
         // do write for each channel
         for (i = 0; i < mySession.GetNumberOfChannels(); i++)
         {
            for (j = 0; j < SEND_SIZE; j++) {
               sendBuffer[j] = 'a' + sendCount;
               sendCount = (sendCount + 1) % 26;
            }
            sendBuffer[SEND_SIZE] = 0;
            printf("writer[%d]: %s\n", i, sendBuffer);
            writers[i]->Write(SEND_SIZE, sendBuffer, NULL);
         }
         printf("\n");

         #ifdef _WIN32
         Sleep(10);
         #else
         usleep(10*1000);
         #endif

         // do read for each channel
         for (i = 0; i < mySession.GetNumberOfChannels(); i++)
         {
            int port = mySession.GetChannel(i)->GetIndex();
            printf("reader[%d]: \n", i);
            while (true)
            {
               printf("  avail: %d", mySession.GetDataStream()->GetAvailableMessages(port));
               try
               {
                  readAndPrint(readers[i], TIMESTAMP);
               }
               catch (CUeiException &e)
               {
                  if (e.GetError() == UEIDAQ_TIMEOUT_ERROR)
                  {
                     printf("  read timeout\n");
                     break;
                  }
                  else
                  {
                     throw e;
                  }
               }
            }
         }
         printf("\n");
         #ifdef _WIN32
         Sleep(10);
         #else
         usleep(10*1000);
         #endif
      }

      mySession.Stop();

      for (int chanNum = 0; chanNum < mySession.GetNumberOfChannels(); chanNum++)
      {
         delete readers[chanNum];
         delete writers[chanNum];
      }

      delete[] readers;
      delete[] writers;
   }
   catch (CUeiException& e)
   {
      std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}
