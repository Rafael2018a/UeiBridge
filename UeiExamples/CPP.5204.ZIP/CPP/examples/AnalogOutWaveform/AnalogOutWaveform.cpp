/* This example demonstrates the AO Eaveform session usage */
/* AO wavefrom sessions only works on arbitrary waveform   */
/* generation devices such as the AO-364                   */
#include <iostream>
#include "UeiDaq.h"
 

using namespace UeiDaq;
 


 

int main(int argc, char* argv[])
{
   tUeiAOWaveformParameters wfmParams;
   CUeiSession session;
   CUeiAOWaveformWriter* writer=NULL;
   int num_wf_written=0;

 
   try
   {
        /* Notes from the Layer's manual about the arguements for CreateAOWaveformChannel()

        �Main DAC clock source: The source of the clock used to time the main DAC:
            UeiAOWaveformClockSourceSYNC2: use SYNC2 line for clock
            UeiAOWaveformClockSourceSYNC0: use SYNC0 line for clock
            UeiAOWaveformClockSourceALT0: use layer channel zero PLL
                    routed to Channel 0 trigger out to clock all channels
            UeiAOWaveformClockSourceTMR: clock from internal TMR0 timebase
            UeiAOWaveformClockSourceDIO0: use channel DIO0 line for clock
            UeiAOWaveformClockSourcePLL: clock from PLL
            UeiAOWaveformClockSourceSW: DAC is clocked by software (DC
                    offset only)

        �Offset DAC clock source: The source of the clock used to time the offset DAC:
            UeiAOWaveformOffsetClockSourceDIO0: use channel DIO0 line for clock
            UeiAOWaveformOffsetClockSourceDIO1: use channel DIO1 line for clock
            UeiAOWaveformOffsetClockSourceDAC: main DAC clock divided is the source of offset DAC
            UeiAOWaveformOffsetClockSourcePLL: PLL is the source of the offset DAC (independent of main DAC)
            UeiAOWaveformOffsetClockSourceSW: offset DAC is clocked by software (DC offset only)

        �Main DAC clock sync: Specifies where a clock signal should be routed to synchronize 
                              with other channels and/or layers.
                            Route your signal out to TrgOut to synchronize multiple channels on the same AO-364.
                            Route your signal out to the Sync lines to synchronize multiple AO-364s.
                            Only valid for channel 0 on AO-364:
            UeiAOWaveformClockRouteNone: No sync routing
            UeiAOWaveformClockRouteDIO1ToTrgOut: Route the DIO1/trigger input pin to Channel0 trigger out (channel 0 only)
            UeiAOWaveformClockRouteDIO0ToTrgOut: Route the DIO0/clock input pin to Channel0 trigger out (channel 0 only)
            UeiAOWaveformClockRoutePLLToTrgOut: Route PLL clock to Channel0 trigger out (channel 0 only)
            UeiAOWaveformClockRoutePLLToSYNC2: Route PLL clock to SYNC2 (channel 0 only)
            UeiAOWaveformClockRoutePLLToSYNC0: Route PLL clock to SYNC0 (channel 0 only)
        */

        session.CreateAOWaveformChannel("pdna://192.168.100.3/Dev1/ao0",
                                        UeiAOWaveformClockSourcePLL,
                                        UeiAOWaveformOffsetClockSourceSW,
                                        UeiAOWaveformClockRouteNone);

        /* Optional: You can tweak the waveform channel settings */
        for(int ch=0; ch<session.GetNumberOfChannels(); ch++)
        {
           CUeiAOWaveformChannel* pWfmChan = dynamic_cast<CUeiAOWaveformChannel*>(session.GetChannel(ch));

           /* Notes from the Layer's manual about adding in a trigger source
            Main DAC trigger source: source used to trigger a new period out of the main DAC:
            UeiAOWaveformTriggerSourceNone: no trigger, layer outputs when clock is available
            UeiAOWaveformTriggerSourceCH0: channel 0 will deliver clock triggered on CH0_TRIGIN line
            UeiAOWaveformTriggerSourceSYNC3: use SYNC3 line as a trigger
            UeiAOWaveformTriggerSourceSYNC1: use SYNC1 line as a trigger
            UeiAOWaveformTriggerSourceALT0: use channel 0 CH0-TIN line for trigger (needs to be connected to a source)
            UeiAOWaveformTriggerSourceDIO1: use channel DIO1 line for trigger
            UeiAOWaveformTriggerSourceSW: use software trigger (simultaneous only within single layer)
           */
           pWfmChan->SetMainDACTriggerSource(UeiAOWaveformTriggerSourceNone);

           /* Notes from the Layer's manual about adding in a trigger source offset
               �Offset DAC trigger source: source used to trigger a new period out of the offset DAC:
               UeiAOWaveformOffsetTriggerSourceNone: no trigger, layer outputs when clock is available (use with NIS clocking)
               UeiAOWaveformOffsetTriggerSourceSYNC3: use SYNC3 line as a trigger
               UeiAOWaveformOffsetTriggerSourceSYNC1: use SYNC1 line as a trigger
               UeiAOWaveformOffsetTriggerSourceALT0: use channel 0 CH0-TIN line for trigger (needs to be connected to a source)
               UeiAOWaveformOffsetTriggerSourceDIO1: use channel DIO1 line for trigger
               UeiAOWaveformOffsetTriggerSourceSW: use software trigger (simultaneous only within single layer)
           */
           pWfmChan->SetOffsetDACTriggerSource(UeiAOWaveformOffsetTriggerSourceNone);
        }

        // Create a writer object
        writer = new CUeiAOWaveformWriter(session.GetDataStream());       

        // Configure timing of input to �simple�
        session.ConfigureTimingForSimpleIO();

        // Self commenting code - start the session
        session.Start();

        // configure writer for sine waveform, 10kHz
        wfmParams.mode      = UeiAOWaveformModeDDS;
        wfmParams.type      = UeiAOWaveformTypeSine;
        wfmParams.xform     = UeiAOWaveformXformNone;
        wfmParams.frequency = 10000.0;
        wfmParams.span      = 8.0;
        wfmParams.offset    = 0.0;
        wfmParams.phase     = 0.0;
        wfmParams.riseTime  = 1.0;
        wfmParams.fallTime  = 1.0;
        wfmParams.dutyCycle = 1.0;
        wfmParams.applyTime = 0.0; 

        // write waveform configuration to the hardware
        writer->WriteWaveform(1, &wfmParams, &num_wf_written);

        // Wait until all scans are generated
        while(session.IsRunning())
        {

        }
        session.Stop();

    }
    catch(CUeiException e)
    {

        std::cout << "Error: " << e.GetErrorMessage() << std::endl;

    }
    
    //Cleaning-up the Session
    session.CleanUp();
    
    return 0;
}
