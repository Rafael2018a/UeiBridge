#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <csignal>
#include <thread>
#include <chrono>
#include "UeiDaq.h"

using namespace UeiDaq;

bool stop = false;

void sighandler(int sig)
{
    stop = true;
}

int main(int argc, char* argv[])
{
    CUeiSession session;    
    std::vector<std::string> aiResources{ "pdna://192.168.100.11/Dev0/ai0:7,ts" };
    std::vector<std::string> aoResources{ "pdna://192.168.100.11/Dev4/ao0:7" };
    std::vector<std::string> diResources{ "pdna://192.168.100.11/Dev1/di1,3,5" };
    std::vector<std::string> doResources{ "pdna://192.168.100.11/Dev1/do0,2,4" };
    std::vector<std::string> ciResources{ "pdna://192.168.100.11/Dev3/ci0,1" };
    std::vector<int> analogInputDevices;
    std::vector<int> analogOutputDevices;
    std::vector<int> digitalInputDevices;
    std::vector<int> digitalOutputDevices;
    std::vector<int> counterInputDevices;
    int i;
    int count = 0;
    double rtDmapRate = 10.0;

    
    signal(SIGINT, sighandler);

    try
    {
        int numDevices = 0;

        // Add AI channels to RTDMAP
        for (i = 0; i < aiResources.size(); i++)
        {
            CUeiAIChannel* firstAiChannel = session.CreateAIChannel(aiResources[i], -10.0, 10.0, UeiAIChannelInputModeDifferential);
            analogInputDevices.push_back(firstAiChannel->GetDeviceId());
        }
        
        for (i = 0; i < aoResources.size(); i++)
        {
           CUeiAOChannel* firstAoChannel = session.CreateAOChannel(aoResources[i], -10.0, 10.0);
           analogOutputDevices.push_back(firstAoChannel->GetDeviceId());
        }
        
        for (i = 0; i < diResources.size(); i++)
        {
           CUeiDIChannel* firstDiPort = session.CreateDIChannel(diResources[i]);
           digitalInputDevices.push_back(firstDiPort->GetDeviceId());
        }
        
        for (i = 0; i < doResources.size(); i++)
        {
           CUeiDOChannel* firstDoPort = session.CreateDOChannel(doResources[i]);
           digitalOutputDevices.push_back(firstDoPort->GetDeviceId());
        }

        for (i = 0; i < ciResources.size(); i++)
        {
           CUeiCIChannel* firstCiChannel = session.CreateCIChannel(ciResources[i], UeiCounterSourceClock, UeiCounterModeCountEvents, UeiCounterGateInternal, 0, 0);
           counterInputDevices.push_back(firstCiChannel->GetDeviceId());
        }
        
        session.ConfigureTimingForRTDMapIO(rtDmapRate);
        session.Start();
        
        while (!stop)
        {
           for (auto device = analogOutputDevices.begin(); device != analogOutputDevices.end(); device++)
           {
              double fData[64];
              CUeiDataStream* aoStream = session.GetDataStream(*device, UeiSessionTypeAO, 0);
              for (i = 0; i < session.GetNumberOfChannels(*device, UeiSessionTypeAO, 0); i++)
              {
                 fData[i] = -10.0 + ((count + i) % 21);
              }
              CUeiAnalogScaledWriter writer(aoStream);
              writer.WriteSingleScan(fData);
           }

           for (auto device = digitalOutputDevices.begin(); device != digitalOutputDevices.end(); device++)
           {
              uInt16 bData[64];
              CUeiDataStream* doStream = session.GetDataStream(*device, UeiSessionTypeDO, 0);
              for (i = 0; i < session.GetNumberOfChannels(*device, UeiSessionTypeDO, 0); i++)
              {
                 bData[i] = 1 << (count % 16);
              }
              CUeiDigitalWriter writer(doStream);
              writer.WriteSingleScan(bData);
           }

           session.RefreshOutputs();

           session.RefreshInputs();
           
           for (auto device = analogInputDevices.begin(); device != analogInputDevices.end(); device++)
           {
              double fData[64];
              CUeiDataStream* aiStream = session.GetDataStream(*device, UeiSessionTypeAI, 0);
              CUeiAnalogScaledReader reader(aiStream);
              reader.ReadSingleScan(fData);
              for (i = 0; i < session.GetNumberOfChannels(*device, UeiSessionTypeAI, 0); i++)
              {
                 CUeiChannel* pChan = session.GetChannel(*device, UeiSessionTypeAI, 0, i);
                 std::cout << pChan->GetResourceName() << " = " << fData[i] << std::endl;
              }
              std::cout << std::endl;
           }

           for (auto device = digitalInputDevices.begin(); device != digitalInputDevices.end(); device++)
           {
              uInt16 bData[64];
              CUeiDataStream* diStream = session.GetDataStream(*device, UeiSessionTypeDI, 0);
              CUeiDigitalReader reader(diStream);
              reader.ReadSingleScan(bData);
              for (i = 0; i < session.GetNumberOfChannels(*device, UeiSessionTypeDI, 0); i++)
              {
                 CUeiChannel* pChan = session.GetChannel(*device, UeiSessionTypeDI, 0, i);
                 std::cout << pChan->GetResourceName() << " = " << bData[i] << std::endl;
              }
              std::cout << std::endl;
           }

           for (auto device = counterInputDevices.begin(); device != counterInputDevices.end(); device++)
           {
              uInt32 bData[64];
              CUeiDataStream* ciStream = session.GetDataStream(*device, UeiSessionTypeCI, 0);
              CUeiCounterReader reader(ciStream);
              reader.ReadSingleScan(bData);
              for (i = 0; i < session.GetNumberOfChannels(*device, UeiSessionTypeCI, 0); i++)
              {
                 CUeiChannel* pChan = session.GetChannel(*device, UeiSessionTypeCI, 0, i);
                 std::cout << pChan->GetResourceName() << " = " << bData[i] << std::endl;
              }
              std::cout << std::endl;
           }

           std::cout << "=====================" << std::endl;
           
           std::this_thread::sleep_for(std::chrono::milliseconds((long)(1000.0/ rtDmapRate)));
           count++;
        }

    }
    catch (CUeiException e)
    {
        std::cout << "Error: " << e.GetErrorMessage() << std::endl;
    }

    return 0;
}
