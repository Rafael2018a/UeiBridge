#include <stdlib.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   const int deviceCount = 2; //sets number of devices
   bool clockSync = 0; //sets clock synchronization on (1) or off (0)

   CUeiSession mySs[deviceCount];
   double* Data[deviceCount] = { NULL };
   int count = 0;
   std::string resources[deviceCount]= { "pdna://192.168.1.101/Dev0/Ai0:11", "pdna://192.168.1.101/Dev2/Ai0:11" };
   CUeiAnalogScaledReader *reader[deviceCount];

   int deviceNum;

   try
   {
      //Set Clock source dependent on synchronization choice
      for (deviceNum=0; deviceNum < deviceCount; deviceNum++)
      {
         // Create analog input channels
         mySs[deviceNum].CreateAIChannel(resources[deviceNum], -10.0, 10.0, UeiAIChannelInputModeDifferential);

         // Configure the session to acquire 1000 scans clocked by a synchronisation signal
         mySs[deviceNum].ConfigureTimingForBufferedIO(1000, UeiTimingClockSourceSignal, 2000.0, UeiDigitalEdgeRising, UeiTimingDurationContinuous);

         // Specify the signal used to provide clock to acquisition devices.
         // The first device is clocked by a PLL routed to sync line 3 (which is automatically routed to the syncout and syncin connectors).
         // All other devices (in the same cube than the master device, or in different cubes connected via synchronization cable).

         // Program scan clock signal to come from PLL3 for first device (master) and from syncIn for all other devices (slaves)
         if(0 == deviceNum)
         {
            mySs[deviceNum].GetTiming()->SetScanClockSourceSignal("PLL3");
         }
         else
         {
            mySs[deviceNum].GetTiming()->SetScanClockSourceSignal("SyncIn");
         }

         // Create a reader object to read data synchronously from the data stream.
         reader[deviceNum] = new CUeiAnalogScaledReader(mySs[deviceNum].GetDataStream());

         // Allocate buffer to store deviceNum frame
         Data[deviceNum] = new double[mySs[deviceNum].GetNumberOfChannels()*mySs[deviceNum].GetDataStream()->GetNumberOfScans()];

      }

      // Start slave devices first (reverse order)
      for (int deviceNum=(deviceCount-1); deviceNum >= 0; deviceNum--)
      {
         mySs[deviceNum].Start();
      }

      // Acquire 20 frames then stop
      while(count < 20)
      {
         for (int deviceNum=0; deviceNum < deviceCount; deviceNum++)
         {
            reader[deviceNum]->ReadMultipleScans(mySs[deviceNum].GetDataStream()->GetNumberOfScans(), Data[deviceNum]);

            std::cout << "Dev:" << deviceNum;
            for(int i=0; i<mySs[deviceNum].GetNumberOfChannels();i++)
               std::cout << " ch" << i << " = " << Data[deviceNum][i] << "V, ";

            std::cout << std::endl;
         }
         std::cout << std::endl;
         count++;
      }

      for (int deviceNum=0; deviceNum < deviceCount; deviceNum++)
      {
         mySs[deviceNum].Stop();
      }
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   for (int deviceNum=0; deviceNum < deviceCount; deviceNum++)
   {
      if(Data[deviceNum] != NULL)
      {
         delete[] Data[deviceNum];
         delete reader[deviceNum];
      }
   }
      
   return 0;
}