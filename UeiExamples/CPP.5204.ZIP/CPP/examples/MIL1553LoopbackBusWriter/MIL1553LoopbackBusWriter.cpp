#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include "UeiDaq.h"
#include "UeiFrameUtils.h"

using namespace UeiDaq;
using namespace std;

int main(int argc, char* argv[])
   {
      int error = 0;
      CUeiSession session;
      int i;
      int channels = 1;
      int startRt = 1;
      int startSa = 1;
      int messageSize = 10;
      uInt16 data[32];
      uInt32 init_num = 0x300;
      Int32 numFramesWritten, numFramesRead;

      int cycles = 10;
      CUeiDevice* pDevice = NULL;
      try
      {
         // port 0 - remote terminal
         CUeiMIL1553Port* pPort0 = session.CreateMIL1553Port(
                                          "pdna://192.168.100.2/Dev0/MILB0",
                                          UeiMIL1553CouplingTransformer,
                                          UeiMIL1553OpModeBusMonitor
                                          );

         session.ConfigureTimingForMessagingIO(1, 0);
         session.GetTiming()->SetTimeout(1000);

         pDevice = session.GetDevice();
         pDevice->GetStatus();

         // create one reader and one writer per each port
         CUeiMIL1553Reader* reader = new CUeiMIL1553Reader(session.GetDataStream(), session.GetChannel(0)->GetIndex());
         CUeiMIL1553Writer* writer = new CUeiMIL1553Writer(session.GetDataStream(), session.GetChannel(0)->GetIndex());

         CUeiMIL1553BusWriterFrame* outFrm;
         CUeiMIL1553BMFrame* bmFrm;
         CUeiMIL1553FilterEntry* filterFrm;

         outFrm = new CUeiMIL1553BusWriterFrame;
         bmFrm = new CUeiMIL1553BMFrame;
         filterFrm = new CUeiMIL1553FilterEntry;
 
         // Set UP RT/SAs we want to operate
         pPort0->ClearFilterEntries();
         filterFrm->Set(UeiMIL1553FilterByRt, startRt, startSa);
         filterFrm->EnableCommands(true, true, true);
         pPort0->AddFilterEntry(*filterFrm);
         pPort0->EnableFilter(true);

         // In cycle
         for (Int32 c = 0; (cycles>0)?c < cycles:1; c++) {
            
            for (i = 0; i < messageSize; i++) data[i] = (uInt16)(c + i);
            outFrm->CopyData(messageSize, data);            
            outFrm->SetCommand(startRt, startSa, messageSize, UeiMIL1553CmdBCRT);
            writer->Write(1, outFrm, &numFramesWritten);

            do {
                reader->Read(1, bmFrm, &numFramesRead);
                if (numFramesRead) cout << "BM:" << bmFrm->GetBmMessageStr() << std::endl;
                if (numFramesRead) cout << bmFrm->GetBmDataStr() << std::endl;
            } while (numFramesRead);
            printf("====================================================\n");
            #ifdef _WIN32
            Sleep(1000);
            #else
            usleep(1000*1000);
            #endif
         }

   //dataError:

         session.Stop();

        delete reader;
        delete writer;


      }
      catch(CUeiException& e)
      {
         cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
         error = e.GetError();
      }

      session.CleanUp();

      return 0;
   }