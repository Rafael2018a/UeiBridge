#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession aiSs;
   CUeiSession aoSs;
   double* pAiData = NULL;
   double* pAoData = NULL;
   int count = 0;

   try
   {
      // Create LVDT input channels and add them to the AI session 
       aiSs.CreateLVDTChannel("pdna://192.168.1.104/dev0/ai0", 
                              -10.0, 
                              10.0, 
                              1000.0, // sensor sensitivity in mV/V
                              UeiLVDTFiveWires, 
                              7.0, // excitation voltage
                              1400.0, // excitation frequency
                              false); // internal excitation

      // Create simulated LVDT output channels and add them to the AO session
      aoSs.CreateSimulatedLVDTChannel("pdna://192.168.1.104/dev0/ao1", 
                                      1000.0,  // sensor sensitivity in mV/V
                                      UeiLVDTFiveWires, 
                                      7.0, // excitation voltage
                                      1400.0); // excitation frequency

      // Configure the sessions to acquire/generate point by point
      aiSs.ConfigureTimingForSimpleIO();
      aoSs.ConfigureTimingForSimpleIO();

      // Create a reader object to read data synchronously from the data stream.
      CUeiAnalogScaledReader reader(aiSs.GetDataStream());
      CUeiAnalogScaledWriter writer(aoSs.GetDataStream());

      // Allocate buffers to store current frame
      pAiData = new double[aiSs.GetNumberOfChannels()*aiSs.GetDataStream()->GetNumberOfScans()];
      pAoData = new double[aoSs.GetNumberOfChannels()*aoSs.GetDataStream()->GetNumberOfScans()];

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as the reader starts reading data.
      aiSs.Start();
      aoSs.Start();

      while(count < 200)
      {
         int j;
         // generate a ramp from -1 to +1
         for(j=0; j<aoSs.GetNumberOfChannels(); j++)
         {
            pAoData[j] = (2.0 * count / 200) - 1.0;
            std::cout << "writing " << "ch" << j << "= " << pAoData[j] << "  ";
         }  
         std::cout << std::endl;

         writer.WriteSingleScan(pAoData);

         #ifdef _WIN32
         Sleep(200);
         #else
         usleep(200*1000);
         #endif
 
         reader.ReadSingleScan(pAiData);
         for(j=0; j<aiSs.GetNumberOfChannels(); j++)
         {
            std::cout << "reading " << "ch" << j << "= " << pAiData[j] << "  ";
         }
         std::cout << std::endl;

         count++;
      }

      aiSs.Stop();
      aoSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

  if(pAiData != NULL)
  {
     delete[] pAiData;
  }

  if(pAoData != NULL)
  {
     delete[] pAoData;
  }

  return 0;
}