#include <windows.h>
#include <process.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

CUeiSession mySession;

void ReadThread(void* param)
{
   CUeiCANReader *pReader = reinterpret_cast<CUeiCANReader*>(param);
   while(mySession.IsRunning())
   {
      tUeiCANFrame frames[10];
      Int32 numFramesRead = 0;
      try
      {
         // Read 10 frames at a time
         pReader->Read(10, frames, &numFramesRead);
      }
      catch(CUeiException& e)
      {
         // if error is timeout, notify user and keep listening for new frames
         if(e.GetError() == UEIDAQ_TIMEOUT_ERROR)
         {
            std::cout << "read timeout" << std::endl;
         }
         else
         {
            std::cout << "error in ReadThread " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
            break;
         }
      }

      // Print any received frames
      for (int i = 0; i<numFramesRead; i++)
      {
         std::cout << "Received frame: ID=" << std::hex << frames[i].Id << std::endl;
      }

      Sleep(50);
   }
}


void WriteThread(void* param)
{
   int count = 0;
   try
   {
      CUeiCANWriter *pWriter = reinterpret_cast<CUeiCANWriter*>(param);
      while(mySession.IsRunning())
      {
         tUeiCANFrame frame;
         Int32 numFramesWritten;

         frame.Id = count++;
         frame.Type = UeiCANFrameTypeData;
         frame.DataSize = 1;
         frame.Data[0] = (uInt8)count;
         pWriter->Write(1, &frame, &numFramesWritten);
         Sleep(10);
      }
   }
   catch(CUeiException& e)
   {
      std::cout << "Error in WriteThread " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }
}


// This example continuously sends CAN frames on port 0 and receives them on port 1
int main(int argc, char* argv[])
{
   try
   {
      mySession.CreateCANPort("pdna://192.168.100.2/Dev0/CAN0,1",
                              UeiCANBitsPerSecond500K,
                              UeiCANFrameExtended,
                              UeiCANPortModeNormal,
                              0xFFFFFFFF,
                              0); 
      mySession.ConfigureTimingForMessagingIO(1, 0);
      mySession.GetTiming()->SetTimeout(1000);

      // Create a reader to read from port 1
      CUeiCANReader reader(mySession.GetDataStream(), 1);
      // Create a writer to write to port 0
      CUeiCANWriter writer(mySession.GetDataStream(), 0);

      mySession.Start();

      _beginthread(ReadThread, 0, &reader);
      _beginthread(WriteThread, 0, &writer);

      while(1)
      {
         std::string command;
         
         // Read next command from keyboard
         std::cin >> command;

         // if command is '.' exit program
         if(!command.compare("."))
         {
            break;
         }
      }

      mySession.Stop();
      mySession.CleanUp();
   }
   catch(CUeiException& e)
   {
      std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}