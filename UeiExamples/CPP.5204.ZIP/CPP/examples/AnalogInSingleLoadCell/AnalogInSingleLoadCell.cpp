#include <stdlib.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   bool scaleData = 1; //Scale Data with excitation
   double fsforce = 50; //Full Scale Force (lbs)
   double fsout = 1.861; //Full Scale output (mV/V)

   CUeiSession mySs;
   double* pData = NULL;
   int count = 0;

   try
   {
     
      // Create 8 analog input channels on a powerdaq board
      // From now on the session is AI only
      mySs.CreateAIVExChannel("simu://Dev0/ai0:6", -0.05, 0.05, UeiSensorFullBridge, 10, scaleData, UeiAIChannelInputModeDifferential);

      // Configure the session to run in immediate mode (software timing)
      mySs.ConfigureTimingForSimpleIO();

      // Create a reader object to read data synchronously from the data stream.
      CUeiAnalogScaledReader reader(mySs.GetDataStream());

      // Allocate buffer to store current frame
      pData = new double[mySs.GetNumberOfChannels()];

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as the reader starts reading data.
      mySs.Start();

      // Acquire 20 frames then stop
      while(count < 20)
      {
         reader.ReadSingleScan(pData);

         for(int i=0; i<mySs.GetNumberOfChannels();i++)
       {
          if (scaleData)
             pData[i]=pData[i]*(fsforce/fsout);
            std::cout << "ch" << i << " = " << pData[i] << ", ";
       }

         std::cout << std::endl;
         count++;
      }

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

  if(pData != NULL)
  {
     delete[] pData;
  }

   return 0;
}