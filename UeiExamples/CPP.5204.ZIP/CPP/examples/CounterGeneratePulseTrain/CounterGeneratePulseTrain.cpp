#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession mySs;

   try
   {
      // Create one counter output channel on a powerdaq board to generate a pulse train 
      // using the internal clock as a reference. Each pulse will be low for 50000 ticks and
      // high for another 50000 ticks
      // From now on the session is CI only
      mySs.CreateCOChannel("pdna://192.168.100.3/Dev1/co0", UeiCounterSourceClock, UeiCounterModeGeneratePulseTrain, 
                           UeiCounterGateInternal, 20000, 50000, 1, false);

      mySs.ConfigureTimingForSimpleIO();

      CUeiCounterWriter writer(mySs.GetDataStream());
      
      // Start generating the pulse train for one second
      mySs.Start();

      for (int i = 0; i < 100; i++)
      {
         #ifdef _WIN32
         Sleep(500);
         #else
         usleep(500*1000);
         #endif
         uInt32 pwm[2];

         // Ticks are specified in 66Mhz period intervals

         // low time for 10us * i
         pwm[0] = 10 * i * 66;
         // high time for 20us * i
         pwm[1] = 5 * i * 66;

         writer.WriteSingleScan(pwm);
      }

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}