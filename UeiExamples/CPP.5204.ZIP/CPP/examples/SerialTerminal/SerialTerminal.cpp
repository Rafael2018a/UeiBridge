#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

CUeiSession mySession;
CUeiSerialReader* reader;
CUeiSerialWriter* writer;
#define RECV_SIZE 1024
char recvbuffer[RECV_SIZE];

class CSerialListener: public IUeiEventListener
{
public:
   void OnEvent(tUeiEvent event, void *param)
   {
      if(event == UeiEventFrameDone)
      {
         try
         {
            Int32 numBytesRead = (Int32)(uintptr_t)param;
            recvbuffer[numBytesRead] = '\0';
            printf(recvbuffer);
            
            // Read data from serial port until a line feed is found
            // then print it on the console
            reader->ReadAsync(100, recvbuffer);
         }
         catch(CUeiException e)
         {
            mySession.Stop();
            std::cout << "SerialTerminal UeiEventFrameDone: Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
         }
      }

      if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)(uintptr_t)param;
         if(mySession.IsRunning())
         {
            if(UEIDAQ_TIMEOUT_ERROR == error)
            {
               // Timeout is not a fatal error, it just means that hey was no incoming serial 
               reader->ReadAsync(100, recvbuffer);
            }
            else
            {
               std::cout << "SerialTerminal UeiEventError: Error " << std::hex << error << ": " << CUeiException::TranslateError(error) << std::endl;
            }
         }
      }
   }
};

int main(int argc, char* argv[])
{
   CSerialListener listener;

   try
   {
      CUeiSerialPort* port = mySession.CreateSerialPort("pdna://192.168.15.200/Dev0/com0,1",
                                                        UeiSerialModeRS232,
                                                        UeiSerialBitsPerSecond57600,
                                                        UeiSerialDataBits8,
                                                        UeiSerialParityNone,
                                                        UeiSerialStopBits1,
                                                        "\n"); 
      // Configure session to complete read operation after 100 bytes have been received or every 10ms (whichever happens first)
      mySession.ConfigureTimingForSimpleIO();
      mySession.GetTiming()->SetTimeout(100);

      reader = new CUeiSerialReader(mySession.GetDataStream(), mySession.GetChannel(0)->GetIndex());
      reader->AddEventListener(&listener);
      writer = new CUeiSerialWriter(mySession.GetDataStream(), mySession.GetChannel(1)->GetIndex());

      mySession.Start();

      reader->ReadAsync(100, recvbuffer);

      std::cout << "type '.' to exit" << std::endl;

      char sendbyte;
      while((sendbyte = (char)getchar()) != '.')
      {
         // Send character to serial port
         writer->Write(1, &sendbyte, NULL);
      }

      mySession.CleanUp();

      delete reader;
      delete writer;
   }
   catch(CUeiException& e)
   {
      std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}