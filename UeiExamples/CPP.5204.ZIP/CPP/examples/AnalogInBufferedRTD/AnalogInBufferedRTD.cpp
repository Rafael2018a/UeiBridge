#include <stdlib.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession mySs;
   double* pData = NULL;
   int count = 0;

   try
   {
      // Create RTD channels. 
      mySs.CreateRTDChannel("simu://Dev0/ai0:7", -10.0, 10.0, UeiTwoWires, 0, UeiRTDType3850, 100, UeiTemperatureScaleCelsius, UeiAIChannelInputModeDifferential);

      // Configure the session to acquire 100 scans clocked by internal scan clock
      mySs.ConfigureTimingForBufferedIO(100, UeiTimingClockSourceInternal, 200.0, UeiDigitalEdgeRising, UeiTimingDurationContinuous);

      // The number of frames is automatically calculated
      // We can override it with the following function calls
      // mySs.GetDataStream()->SetNumberOfFrames(2);

      // Create a reader object to read data synchronously from the data stream.
      CUeiAnalogScaledReader reader(mySs.GetDataStream());

      // Allocate buffer to store current frame
      pData = new double[mySs.GetNumberOfChannels()*mySs.GetDataStream()->GetNumberOfScans()];

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as the reader starts reading data.
      mySs.Start();

      // Acquire 20 frames then stop
      while(count < 20)
      {
         reader.ReadMultipleScans(mySs.GetDataStream()->GetNumberOfScans(), pData);

         for(int i=0; i<mySs.GetNumberOfChannels();i++)
            std::cout << "ch" << i << " = " << pData[i] << ", ";

         std::cout << std::endl;
         count++;
      }

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

  if(pData != NULL)
  {
     delete[] pData;
  }

   return 0;
}