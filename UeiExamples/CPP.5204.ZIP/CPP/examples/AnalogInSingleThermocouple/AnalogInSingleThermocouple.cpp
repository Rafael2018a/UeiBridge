#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession mySs;
   double data[800];

   try
   {
      // Create 2 analog input channels on a powerdaq board
      // Thermocouple, temperature, and CJC definitions located in UeiConstants.h
      mySs.CreateTCChannel("pdna://192.168.100.2/Dev1/ai0:1 ", -100.0, 100.0, UeiThermocoupleTypeK, UeiTemperatureScaleFahrenheit, UeiCJCTypeBuiltIn, 25, "", UeiAIChannelInputModeDifferential);

      // By default the timing object is configured for simple I/O so
      // no need to do anything here.
      mySs.ConfigureTimingForSimpleIO();
      
      // Set low scan rate for thermocouple measurement(default is 100Hz)
      mySs.GetTiming()->SetScanClockRate(20.0);

      // Create a reader object to read data synchronously.
      CUeiAnalogScaledReader reader(mySs.GetDataStream());

      mySs.Start();

      // Read 100 scans
      for(int i=0; i<100; i++)
      {
         reader.ReadSingleScan(&data[i*mySs.GetNumberOfChannels()]);
         std::cout << "Ch0 = " << data[i*mySs.GetNumberOfChannels()] << std::endl;
      }

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}