#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include <csignal>
#include "UeiDaq.h"

using namespace UeiDaq;

#define SEND_SIZE 100
#define RECV_SIZE 1024

int stop = 0;

// SIGINT handler. Type CTRL+C to end program
void stophandler(int sig)
{
   stop = 1;
}

int main(int argc, char* argv[])
{
   int p, count;
   CUeiSession mySession;
   CUeiSerialReader** readers;
   CUeiSerialWriter** writers;
   char sendBuffer[SEND_SIZE];
   char recvBuffer[RECV_SIZE];


   // install stop handler
   signal(SIGINT, stophandler);

   try
   {
      CUeiSerialPort* port = mySession.CreateSerialPort("pdna://192.168.100.55/Dev3/com0",
                                                        UeiSerialModeRS485FullDuplex,
                                                        UeiSerialBitsPerSecond57600,
                                                        UeiSerialDataBits8,
                                                        UeiSerialParityNone,
                                                        UeiSerialStopBits1,
                                                        ""); 
      // Configure session to complete read operation after 100 bytes have been received or every 10ms (whichever happens first)
      mySession.ConfigureTimingForSimpleIO();
      mySession.GetTiming()->SetTimeout(100);

      // Create an asynchronous listener and a writer for each port configured
      // in the resource string
      writers = new CUeiSerialWriter*[mySession.GetNumberOfChannels()];
      readers = new CUeiSerialReader*[mySession.GetNumberOfChannels()];
      for(p=0; p<mySession.GetNumberOfChannels(); p++)
      {
         int port = mySession.GetChannel(p)->GetIndex();

         writers[p] = new CUeiSerialWriter(mySession.GetDataStream(), port);
         readers[p] = new CUeiSerialReader(mySession.GetDataStream(), port);
      }
      
      mySession.Start();

      count = 0;
      while(!stop && count < 10)
      {
         for(p=0; p<mySession.GetNumberOfChannels(); p++)
         {
            int port = mySession.GetChannel(p)->GetIndex();

            sprintf(sendBuffer, "%d%0*d\n", port, SEND_SIZE-3, count);

            // Send character to serial port
            writers[p]->Write(SEND_SIZE-1, sendBuffer, NULL);
         }

         #ifdef _WIN32
         Sleep(100);
         #else
         usleep(100*1000);
         #endif

         for(p=0; p<mySession.GetNumberOfChannels(); p++)
         {
            Int32 numBytesRead;
            int port = mySession.GetChannel(p)->GetIndex();

            readers[p]->Read(RECV_SIZE, recvBuffer, &numBytesRead);
            recvBuffer[numBytesRead] = '\0';
            printf("port%d received %d bytes: %s\n", port, numBytesRead, recvBuffer);
         }

         count++;
      }

      mySession.Stop();

      for(p=0; p<mySession.GetNumberOfChannels(); p++)
      {
         delete readers[p];
         delete writers[p];
      }

      delete[] readers;
      delete[] writers;
   }
   catch(CUeiException& e)
   {
      std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}