#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include <string.h>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   int ch;
   CUeiSession aowfmSs;
   tUeiAOWaveformParameters wfmParams;
   tUeiAOWaveformSweepParameters swpParams;
   CUeiAOWaveformWriter** writers = NULL;
   
   try
   {
      // Create a AO waveform channel on a function genreator device (AO-364)
      // This type of channels gives access to waveform shape parameters and frequency/amplitude/offset/phase
      // sweep.
 
      // Use channel 0 as master clock to synchronize all channels
      aowfmSs.CreateAOWaveformChannel("pdna://192.168.100.3/Dev4/ao0", 
                                      // use alternate trig out signal as clock for main DAC
                                      UeiAOWaveformClockSourceALT0,   
                                      // use software clock for offset DAC (DC only)
                                      UeiAOWaveformOffsetClockSourceSW,  
                                      // Route channel 0 PLL clock to trigout
                                      UeiAOWaveformClockRoutePLLToTrgOut);     
      // Configure channels 1, 2 and 3 to pick-up clock from channel 0
      aowfmSs.CreateAOWaveformChannel("pdna://192.168.100.3/Dev4/ao1,2,3", 
                                      // use alternate trig out signal as clock for main DAC
                                      UeiAOWaveformClockSourceALT0,   
                                      // use software clock for offset DAC (DC only)
                                      UeiAOWaveformOffsetClockSourceSW,  
                                      UeiAOWaveformClockRouteNone);     
      aowfmSs.ConfigureTimingForSimpleIO();

      writers = new CUeiAOWaveformWriter*[aowfmSs.GetNumberOfChannels()];

      // Function generator channels can generate different waveforms at different rates.
      // We need one writer per channel to configure them independantly
      // Create a writer and configure different waveform shape on each channel
      for(ch=0; ch<aowfmSs.GetNumberOfChannels(); ch++)
      {
         int channel = aowfmSs.GetChannel(ch)->GetIndex();

         writers[ch] = new CUeiAOWaveformWriter(aowfmSs.GetDataStream(), channel);

         // Initialize waveform parameters
         memset(&wfmParams, 0, sizeof(wfmParams));

         // Use DDS mode which allows to dial-in exact output frequency within 0.1Hz or better 
         // but has slightly higher level of harmonics than PLL mode
         wfmParams.mode = UeiAOWaveformModeDDS;

         switch(ch)
         {
         case 0:
            // First channel will output a 100Hz, 5V peak to peak sine wave
            wfmParams.type = UeiAOWaveformTypeSine;
            wfmParams.frequency = 100.0;
            wfmParams.span = 5.0;
            break;
         case 1:
            // Second channel will output a 50Hz, 7V peak to peak triangle wave
            wfmParams.type = UeiAOWaveformTypeTriangle;
            wfmParams.frequency = 50.0;
            wfmParams.span = 7.0;
            break;
         case 2:
            // Third channel will output a 200Hz, 3V peak to peak pulse wave 
            // with 20% duty cycle and sharp edges
            wfmParams.type = UeiAOWaveformTypePulse;
            wfmParams.frequency = 200.0;
            wfmParams.span = 3.0;
            wfmParams.dutyCycle = 0.2f;
            wfmParams.riseTime = 0.0f;
            wfmParams.fallTime = 0.0f;
            break;
         case 3:
            // Fourth channel will output a 100Hz, 10V peak to peak sawtooth wave
            // rising for 80% of the period and falling for 20% of the period
            wfmParams.type = UeiAOWaveformTypeSine;
            wfmParams.frequency = 100.0;
            wfmParams.span = 10.0;
            wfmParams.riseTime = 0.8f;
            wfmParams.fallTime = 0.2f;
            break;
         }

         // Don't set any offset or phase on any channel
         wfmParams.offset = 0.0;
         wfmParams.phase = 0.0;
         writers[ch]->WriteWaveform(1, &wfmParams, NULL);
      }

      std::cout << "All channels are started" << std::endl;
      
      // Wait for 5 secs then program channel 0 to sweep its frequency 
      // between 1Hz and 1kHz in 2 secs
      #ifdef _WIN32
      Sleep(5000);
      #else
      usleep(5000*1000);
      #endif
      
      memset(&swpParams, 0, sizeof(swpParams));
      swpParams.control = UeiAOWaveformSweepUpStart;
      swpParams.mode = UeiTimingDurationSingleShot;
      swpParams.sweepTime = 2.0;
      swpParams.lowerFrequency = 1.0;
      swpParams.upperFrequency = 1000.0;
      writers[0]->WriteSweep(1, &swpParams, NULL);

      std::cout << "Sweep started" << std::endl;

      #ifdef _WIN32
      Sleep(4000);
      #else
      usleep(4000*1000);
      #endif

      swpParams.control = UeiAOWaveformSweepStop;
      writers[0]->WriteSweep(1, &swpParams, NULL);

      std::cout << "Sweep stopped" << std::endl;

      #ifdef _WIN32
      Sleep(3000);
      #else
      usleep(3000*1000);
      #endif

      aowfmSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   if(writers)
   {
      for(ch=0; ch<aowfmSs.GetNumberOfChannels(); ch++)
      {
         delete writers[ch];
      }
      delete[] writers;
   }

   return 0;
}



