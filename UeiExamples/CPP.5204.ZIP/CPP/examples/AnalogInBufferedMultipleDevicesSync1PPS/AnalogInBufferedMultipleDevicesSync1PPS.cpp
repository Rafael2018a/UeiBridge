#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <stdlib.h>
#include <iostream>
#include <vector>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   double scanRate = 8000.0;
   int numScans = 500;
   
   int count = 0;
   std::string syncResources[] = { "pdna://192.168.100.8/Dev14/Sync0", "pdna://192.168.100.3/Dev14/Sync0" };
   std::string aiResources[]= { "pdna://192.168.100.8/Dev0/Ai0:11", "pdna://192.168.100.3/Dev0/Ai0:7" };

   std::vector<CUeiSession*> syncSessions;
   std::vector<CUeiSession*> aiSessions;
   std::vector<CUeiAnalogScaledReader*> readers;
   std::vector<CUeiSync1PPSController*> controllers;
   std::vector<double*> aiDataBuffers;

   int dev;
   int aiDeviceCount = std::size(aiResources);
   int syncDeviceCount = std::size(syncResources);

   try
   {
      // initialize synchronization sessions. Assume first session is a master and produces 
      // the 1PPS signal
      for (dev = 0; dev < syncDeviceCount; dev++)
      {
         CUeiSession* syncSession = new CUeiSession();

         // first sync device is master, configure to internally produce 1PPS and
         // make it available to slaves on output 0
         if (0 == dev)
         {
            CUeiSync1PPSPort* masterSyncPort = syncSession->CreateSync1PPSPort(syncResources[dev],
                  UeiSyncClock,
                  UeiSync1PPSInternal,
                  scanRate);

            masterSyncPort->Set1PPSOutput(UeiSync1PPSOutput0);
         }
         else
         {
            CUeiSync1PPSPort* slaveSyncPort = syncSession->CreateSync1PPSPort(syncResources[dev],
                  UeiSyncClock,
                  UeiSync1PPSInput0,
                  scanRate);
            slaveSyncPort->SetSyncInputDebounceTime(1000);
         }

         // When trigger command is received all sync devices will trigger their respective I/O layers
         // upon the next 1PPs edge
         syncSession->GetStartTrigger()->SetTriggerSource(UeiTriggerSourceNext1PPS);
         syncSessions.push_back(syncSession);

         // Create controller object used to read status and send trigger command
         CUeiSync1PPSController* controller = new CUeiSync1PPSController(syncSession->GetDataStream());
         controllers.push_back(controller);
      }

      // Configure AI layers
      for (dev=0; dev < aiDeviceCount; dev++)
      {
         CUeiSession* aiSession = new CUeiSession();

         // Create analog input channels
         aiSession->CreateAIChannel(aiResources[dev], -10.0, 10.0, UeiAIChannelInputModeDifferential);

         // Configure the session to acquire 1000 scans clocked by a synchronisation signal
         aiSession->ConfigureTimingForBufferedIO(numScans, UeiTimingClockSourceSignal, scanRate, UeiDigitalEdgeRising, UeiTimingDurationContinuous);
         aiSession->GetTiming()->SetTimeout(5000);

         // Program scan clock signal to come from 1PPS event module via sync line #2
         aiSession->GetTiming()->SetScanClockSourceSignal("pps2");

         // The scan clock can be divided to synchronize AI layers that are over-clocked with other AI layers
         // For example the AI-217 requires a scan clock 8x faster than the data rate expected by the user
         // To synchronize an AI-207 with the AI-217, its clock needs to be divided by 8.
         aiSession->GetTiming()->SetScanClockTimebaseDivisor(0);

         // Configure AI layers to wait for trigger signal on sync line #3, the event module will assert
         // line #3 on the next 1PPS edge after having received a trigger command.
         aiSession->ConfigureSignalTrigger(UeiTriggerActionStartSession, "pps3");         

         // Create a reader object to read data synchronously from the data stream.
         CUeiAnalogScaledReader* reader = new CUeiAnalogScaledReader(aiSession->GetDataStream());

         // Allocate buffer to store data frame
         double* data = new double[aiSession->GetNumberOfChannels()*aiSession->GetDataStream()->GetNumberOfScans()];

         // Store pointers for each device in vectors
         aiSessions.push_back(aiSession);
         readers.push_back(reader);
         aiDataBuffers.push_back(data);
      }

      // Start I/O sessions first
      for (dev = 0; dev < aiDeviceCount; dev++)
      {
         aiSessions[dev]->Start();
      }

      // Start sync sessions one by one and wait until ADPLL is locked on 1PPS
      for (dev = 0; dev < syncDeviceCount; dev++)
      {
         syncSessions[dev]->Start();

         int lockCount = 0;
         int loopCount = 0;
         std::cout << "Checking Lock status on " << syncSessions[dev]->GetDevice()->GetResourceName() << ":";
         while (lockCount < 10 && loopCount < 30)
         {
            bool locked;
            controllers[dev]->ReadLockedStatus(&locked);
            if (locked)
            {
               lockCount++;
               std::cout << "L";
            }
            else
            {
               std::cout << ".";
            }
            #ifdef _WIN32
            Sleep(500);
            #else
            usleep(500*1000);
            #endif
         }

         if (lockCount < 10)
         {
            std::cout << "could not lock 1PPS" << std::endl;
            return -1;
         }

         std::cout << " Locked!" << std::endl;
      }

      // Send trigger signal to start clocking the AI layers on the next 1PPS pulse
      controllers[0]->TriggerDevices(UeiSync1PPSTriggerOnNextPPSBroadCast, true);

      std::cout << "Devices triggered..." << std::endl;

      // Acquire 20 frames then stop
      while(count < 20)
      {
         for (dev=0; dev < aiDeviceCount; dev++)
         {
            readers[dev]->ReadMultipleScans(numScans, aiDataBuffers[dev]);

            std::cout << aiSessions[dev]->GetDevice()->GetResourceName() << ":";
            for(int i=0; i<aiSessions[dev]->GetNumberOfChannels();i++)
               std::cout << " ch" << i << " = " << aiDataBuffers[dev][i] << "V, ";

            std::cout << std::endl;
         }
         std::cout << std::endl;
         count++;
      }

      for (int dev=0; dev < aiDeviceCount; dev++)
      {
         aiSessions[dev]->Stop();
      }

      for (int dev = 0; dev < syncDeviceCount; dev++)
      {
         syncSessions[dev]->Stop();
      }
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   for (int dev=0; dev < aiDeviceCount; dev++)
   {
      if(aiDataBuffers.size() > dev) delete[] aiDataBuffers[dev];
      if(readers.size() > dev) delete readers[dev];
      if(aiSessions.size() > dev) delete aiSessions[dev];
   }

   for (int dev = 0; dev < syncDeviceCount; dev++)
   {
      if(controllers.size() > dev) delete controllers[dev];
      if(syncSessions.size() > dev) delete syncSessions[dev];
   }
      
   return 0;
}