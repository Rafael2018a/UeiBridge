// DigitalInMFCDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DigitalInMFC.h"
#include "DigitalInMFCDlg.h"
#include ".\digitalinmfcdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define WM_UPDATE_STATUS   (WM_USER+1)

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CDigitalInMFCDlg dialog



CDigitalInMFCDlg::CDigitalInMFCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDigitalInMFCDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

   m_NbScans= 1000;
   m_Frequency = 50000;
   m_pReader = NULL;
   m_pData = NULL;
}

void CDigitalInMFCDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

   DDX_Control(pDX, IDC_RESOURCE, m_Resources);
   DDX_Text(pDX, IDC_NBSCANS, m_NbScans);
   DDX_Text(pDX, IDC_FREQUENCY, m_Frequency);
   DDX_Control(pDX, IDC_DURATION, m_Duration);
   DDX_Control(pDX, IDC_TRIGGER, m_Trigger);
   DDX_Control(pDX, IDC_GRAPH, m_Graph);

   DDX_Control(pDX, IDC_NBSCANS_STATUS, m_TotalScans);
   DDX_Control(pDX, IDC_NBSCANSAVAILABLE, m_AvailScans);
   DDX_Control(pDX, IDC_LOG, m_Log);
}

BEGIN_MESSAGE_MAP(CDigitalInMFCDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
   ON_BN_CLICKED(ID_GO, OnBnClickedGo)
   ON_BN_CLICKED(ID_STOP, OnBnClickedStop)
   ON_WM_DESTROY()
   ON_MESSAGE(WM_UPDATE_STATUS, OnUpdateStatus)
END_MESSAGE_MAP()


// CDigitalInMFCDlg message handlers

BOOL CDigitalInMFCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_Resources.SetWindowText("simu://Dev2/Di0");
   m_NbScans= 1000;
   m_Frequency = 50000;
   m_Duration.SetCheck(1);
   m_Trigger.SetCheck(0);
   m_AvailScans.SetWindowText("0");
   m_TotalScans.SetWindowText("0");

   m_Graph.setType(Digital);
   m_Graph.addPlot(RGB(255,255,0), "");

   UpdateData(FALSE);

   GetDlgItem(ID_GO)->EnableWindow(TRUE);
   GetDlgItem(ID_STOP)->EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDigitalInMFCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDigitalInMFCDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDigitalInMFCDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CDigitalInMFCDlg::OnBnClickedGo()
{
   UpdateData();

   try
   {
      CString str;
      m_Resources.GetWindowText(str);
      m_Session.CreateDIChannel(LPCSTR(str));

      tUeiTimingDuration duration;
      if(m_Duration.GetCheck())
         duration = UeiTimingDurationContinuous;
      else
         duration = UeiTimingDurationSingleShot;

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      m_Session.ConfigureTimingForBufferedIO(m_NbScans, UeiTimingClockSourceInternal, m_Frequency, UeiDigitalEdgeRising, duration);

      // Create a reader object to read data synchronously.
      m_pReader = new CUeiDigitalReader(m_Session.GetDataStream());

      m_pReader->AddEventListener(this);

      // allocate buffer to receive acquired data
      m_pData = (uInt16*)malloc(m_Session.GetNumberOfChannels() * m_NbScans * sizeof(uInt16));

      // adjust scales of the graph
      m_Graph.xAxis()->setMinimum(0.0);
      m_Graph.xAxis()->setMaximum((double)m_NbScans / (double)m_Frequency);

      m_Session.Start();

      m_pReader->ReadMultipleScansAsync(m_NbScans, m_pData);

      GetDlgItem(ID_GO)->EnableWindow(FALSE);
      GetDlgItem(ID_STOP)->EnableWindow(TRUE);
      m_Log.SetWindowText("");
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("Go Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CDigitalInMFCDlg::OnEvent(tUeiEvent event, void *param)
{
   try
   {
      if(event == UeiEventFrameDone)
      {
         m_Graph.yplotmultiple(m_Session.GetNumberOfChannels(), m_pData,
                              m_NbScans, 0.0, 1.0/m_Frequency, PlotDataColumn, true); 

         int totalScans = m_Session.GetDataStream()->GetTotalScans();
         int availScans = m_Session.GetDataStream()->GetAvailableScans();
         PostMessage(WM_UPDATE_STATUS, (WPARAM)availScans, (LPARAM)totalScans); 

         m_pReader->ReadMultipleScansAsync(m_NbScans, m_pData);
      }
      else if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)((INT_PTR)(param));
         throw CUeiException(error);
      }
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("OnEvent Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}


void CDigitalInMFCDlg::OnBnClickedStop()
{
   try
   {
      m_Session.CleanUp();

      if(m_pReader != NULL)
      {
         delete m_pReader;
         m_pReader = NULL;
      }

      if(m_pData != NULL)
      {
         free(m_pData);
         m_pData = NULL;
      }

      GetDlgItem(ID_GO)->EnableWindow(TRUE);
      GetDlgItem(ID_STOP)->EnableWindow(FALSE);
   }
   catch(CUeiException e)
   {
      CString str;
      str.Format("Stop Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CDigitalInMFCDlg::OnDestroy()
{
   __super::OnDestroy();

   OnBnClickedStop();
}

LRESULT CDigitalInMFCDlg::OnUpdateStatus(WPARAM wParam, LPARAM lParam)
{
   CString statstr;
   statstr.Format("%d", (int)lParam);
   m_TotalScans.SetWindowText(statstr);
   statstr.Format("%d", (int)wParam);
   m_AvailScans.SetWindowText(statstr);

   return 0;
}
