#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include <csignal>
#include "UeiDaq.h"

using namespace UeiDaq;

#define SLAVE_ADDR (0x12)
#define RX_SIZE (255)

int stop = 0;

// SIGINT handler. Type CTRL+C to end program
void stophandler(int sig)
{
   stop = 1;
}

int main(int argc, char* argv[])
{
   int count;
   CUeiSession mySession;
   CUeiI2CWriter *masterWriter, *slaveWriter;
   CUeiI2CReader *masterReader, *slaveReader;
   int masterChannel, slaveChannel;

   // install stop handler
   signal(SIGINT, stophandler);

   try
   {
      CUeiI2CMasterPort* masterPort = mySession.CreateI2CMasterPort("pdna://192.168.100.4/Dev0/I2C0",
         UeiI2CBitsPerSecond100K,
         UeiI2CTTLLevel3_3V,
         false);
      CUeiI2CSlavePort* slavePort = mySession.CreateI2CSlavePort("pdna://192.168.100.4/Dev0/I2C0",
         UeiI2CTTLLevel3_3V,
         (SLAVE_ADDR & 0x380) ? UeiI2CSlaveAddress10bit : UeiI2CSlaveAddress7bit,
         SLAVE_ADDR);

      mySession.ConfigureTimingForMessagingIO(1, 0);

      // Get master and slave channel
      masterChannel = masterPort->GetIndex();
      slaveChannel = slavePort->GetIndex();

      // Allows master and slave on the same channel to communicate without external wiring
      // Relay loopback mode will still generate external signals
      masterPort->SetLoopbackMode(UeiI2CLoopbackRelay);

      // configure reader and writer for master
      masterWriter = new CUeiI2CWriter(mySession.GetDataStream(), masterChannel);
      masterReader = new CUeiI2CReader(mySession.GetDataStream(), masterChannel);

      // configure reader and writer for slave
      slaveWriter = new CUeiI2CWriter(mySession.GetDataStream(), slaveChannel);
      slaveReader = new CUeiI2CReader(mySession.GetDataStream(), slaveChannel);
      
      mySession.Start();

      count = 0;

      tUeiI2CMasterMessage masterRx[RX_SIZE];
      tUeiI2CSlaveMessage slaveRx[RX_SIZE];
      while(!stop && count < 10)
      {
         Int32 numElementsRead = 0;

         // alternate between write and read commands
         if (count % 2 == 0)
         {
            printf("Write Command\n");

            tUeiI2CMasterCommand params;
            params.type = UeiI2CCommandWrite;
            params.slaveAddress = SLAVE_ADDR;
            params.numWriteElements = 4;
            for (int i = 0; i < params.numWriteElements; i++)
            {
               params.data[i] = i * 2;
            }
            params.numReadElements = 0; // not used for Write command

            // Transmit Write command
            masterWriter->WriteMasterCommand(&params);

            #ifdef _WIN32
            Sleep(1);
            #else
            usleep(1*1000);
            #endif

            // Read data slave received
            slaveReader->ReadSlave(RX_SIZE, slaveRx, &numElementsRead);

            printf("Read %d elements from slave\n", numElementsRead);
            for (int i = 0; i < numElementsRead; i++)
            {
               printf("[%d]: type=%d, data=0x%x\n", i, slaveRx[i].busCode, slaveRx[i].data);
            }

            printf("\n");
         }
         else
         {
            printf("Read Command\n");

            // Provide slave with data to transmit when receiving a read request
            int numElementsWritten;
            uInt16 txBuf[255];

            for (int i = 0; i < 4; i++)
            {
               txBuf[i] = 0xffff - i;
            }
            slaveWriter->WriteSlaveData(4, txBuf, &numElementsWritten);

            tUeiI2CMasterCommand params;
            params.type = UeiI2CCommandRead;
            params.slaveAddress = SLAVE_ADDR;
            params.numReadElements = 6; // read more than what was written to slave to show default value
            params.data[0]; // not used for Read command
            params.numWriteElements = 0; // not used for Read command

            // Transmit Read command
            masterWriter->WriteMasterCommand(&params);

            #ifdef _WIN32
            Sleep(1);
            #else
            usleep(1*1000);
            #endif

            // Read data returned to master from slave
            masterReader->ReadMaster(RX_SIZE, masterRx, &numElementsRead);

            printf("Read %d elements from master\n", numElementsRead);
            for (int i = 0; i < numElementsRead; i++)
            {
               printf("[%d]: stopBit=%d, data=0x%x\n", i, masterRx[i].stopBit, masterRx[i].data);
            }

            // Slave stores read request, read the request data here
            slaveReader->ReadSlave(RX_SIZE, slaveRx, &numElementsRead);

            printf("Read %d elements from slave\n", numElementsRead);
            for (int i = 0; i < numElementsRead; i++)
            {
               printf("[%d]: type=%d, data=0x%x\n", i, slaveRx[i].busCode, slaveRx[i].data);
            }
            printf("\n");
         }

         #ifdef _WIN32
         Sleep(1);
         #else
         usleep(1*1000);
         #endif

         count++;
      }

      mySession.Stop();

      delete masterWriter, masterReader;
      delete slaveWriter, slaveReader;
   }
   catch(CUeiException& e)
   {
      std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }

   getchar();
   return 0;
}