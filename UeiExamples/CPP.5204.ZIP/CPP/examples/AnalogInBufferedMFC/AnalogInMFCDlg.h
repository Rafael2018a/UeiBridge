// AnalogInMFCDlg.h : header file
//

#pragma once

#include "LabGraph.h"
#include "UeiDaq.h"

using namespace UeiDaq;

// CAnalogInMFCDlg dialog
class CAnalogInMFCDlg : public CDialog, IUeiEventListener
{
// Construction
public:
	CAnalogInMFCDlg(CWnd* pParent = NULL);	// standard constructor

   virtual void OnEvent(tUeiEvent event, void *param);

// Dialog Data
	enum { IDD = IDD_ANALOGINMFC_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

   CEdit    m_Resources;
   int      m_NbScans;
   int      m_Frequency;
   CButton  m_Duration;
   CButton  m_DigTrigger;
   CButton  m_SwTrigger;
   CLabGraph m_Graph;

   CEdit    m_TotalScans;
   CEdit    m_AvailScans;
   CString  m_Log;
   CSliderCtrl m_SwTriggerLevel;
   CEdit    m_LogFilePath;
   CButton  m_LogToFile;

private:
   CUeiSession m_Session;
   CUeiAnalogScaledReader *m_pReader;
   double *m_pData;
   FILE   *m_hLogFile;
   int      m_NbChannels;

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
   afx_msg LRESULT OnUpdateStatus(WPARAM wParam, LPARAM lParam);
   afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

	DECLARE_MESSAGE_MAP()
public:
   afx_msg void OnBnClickedGo();
   afx_msg void OnBnClickedStop();
   afx_msg void OnDestroy();
};
