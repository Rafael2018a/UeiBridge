#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include <csignal>
#include "UeiDaq.h"

using namespace UeiDaq;

#define SEND_SIZE 10
#define RECV_SIZE 1024

int stop = 0;

// SIGINT handler. Type CTRL+C to end program
void stophandler(int sig)
{
   stop = 1;
}

int main(int argc, char* argv[])
{
   int count;
   CUeiSession mySession;  
   uInt32 sendBuffer[SEND_SIZE];
   uInt32 recvBuffer[RECV_SIZE];

   // install stop handler
   signal(SIGINT, stophandler);

   try
   {

	  CUeiSSIMasterPort* master = mySession.CreateSSIMasterPort("pdna://192.168.100.26/dev2/SSI0", 100000, 16, true, false, 10000, 16.03, 0.455);
	  CUeiSSISlavePort* slave = mySession.CreateSSISlavePort("pdna://192.168.100.26/dev2/SSI1", 100000, 16, true, false, 10000, 16.03, 0.455);
      
	  // Configure session to complete read operation after 2 bytes have been received or every 100ms (whichever happens first)  
	  mySession.ConfigureTimingForMessagingIO(2, 10.0);         
	  mySession.GetTiming()->SetTimeout(1000);
	  

      // Create an asynchronous listener and a writer for each port configured
      // in the resource string	  
      CUeiSSIReader reader(mySession.GetDataStream(), 0);
	  CUeiSSIWriter writer(mySession.GetDataStream(), 1);
     
      
	  mySession.Start();
	  

      count = 0;
      while(!stop && count < 10)
      {

		 for (int p = 0; p < SEND_SIZE; p++) 
         {
             sendBuffer[p] = 0x1234 + count;
         }			 
		 writer.Write(false, SEND_SIZE, sendBuffer, NULL);		 

      #ifdef _WIN32
      Sleep(100);
      #else
      usleep(100*1000);
      #endif
		 Int32 numWordsRead;
		 reader.Read(false, RECV_SIZE, recvBuffer, &numWordsRead);

		 for (int p = 0; p < numWordsRead; p++) 
         {
			 std::cout << "Word[" << p << "] = " << recvBuffer[p] << std::endl;			
		 }     	

         count++;
      }

	  mySession.Stop();
	  
      
   }
   catch(CUeiException& e)
   {
      std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}