#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession rtdSimSession;
   CUeiSession guardianSession;

   try
   {
      // Create TC simulation session with 8 channels.
      rtdSimSession.CreateSimulatedRTDChannel("pdna://192.168.100.55/dev0/ao0:7",
                                             UeiRTDType3850, 100.0, UeiTemperatureScaleCelsius);
      rtdSimSession.ConfigureTimingForSimpleIO();

      // Create 3 AI channels for each output channel to read diagnostics
      // Each TC output channel is associated with three guardian channels starting at offset tc_chan * 8
      guardianSession.CreateAIChannel("pdna://192.168.100.55/dev0/ai+16,32,17,33,18,34,19,35,20,36,21,37,22,38,23,39", -10.0, 10.0, UeiAIChannelInputModeDifferential);
      guardianSession.ConfigureTimingForSimpleIO();

      // Create a writer to update the output channels
      CUeiAnalogScaledWriter writer(rtdSimSession.GetDataStream());
      
      double* aoData = new double[rtdSimSession.GetNumberOfChannels()];

      // Create a circuit breaker object per output channel to monitor circuit breaker status and eventually reset them
      CUeiCircuitBreaker** cbs = new CUeiCircuitBreaker*[rtdSimSession.GetNumberOfChannels()];
      int* breakCount = new int[rtdSimSession.GetNumberOfChannels()];
      for (int ch = 0; ch < rtdSimSession.GetNumberOfChannels(); ch++)
      {
         cbs[ch] = new CUeiCircuitBreaker(rtdSimSession.GetDataStream(), rtdSimSession.GetChannel(ch)->GetIndex());
         breakCount[ch] = 0;
      }

      // Create a reader to retrieve diagnostics
      CUeiAnalogScaledReader guardianReader(guardianSession.GetDataStream());
      double* diagData = new double[guardianSession.GetNumberOfChannels()];

      rtdSimSession.Start();
      guardianSession.Start();

      int count = 0;
      bool stop = false;
      while (!stop)
      {
         // Update outputs on each channel
         for (int ch = 0; ch < rtdSimSession.GetNumberOfChannels(); ch++)
         {
            // vary resistance from 300 to 400
            aoData[ch] = 300 + ((count*10) % 100);
         }
         writer.WriteSingleScan(aoData);

         // Read and display diagnostics
         guardianReader.ReadSingleScan(diagData);

         for (int ch = 0; ch < rtdSimSession.GetNumberOfChannels(); ch++)
         {
            std::cout << "Output Channel " << rtdSimSession.GetChannel(ch)->GetIndex() << " diagnostics:" << std::endl;
            std::cout << "  Current = " << diagData[ch * 2] << std::endl;
            std::cout << "  Internal temperature = " << diagData[ch * 2 + 1] << std::endl;

            // Monitor CB status
            uInt32 currStatus = 0, stickyStatus = 0;
            cbs[ch]->ReadStatus(&currStatus, &stickyStatus);

            if ((currStatus & (1U << rtdSimSession.GetChannel(ch)->GetIndex())) > 0)
            {
               breakCount[ch]++;
            }

            std::cout << "  CB Status: curr = " << std::hex << currStatus << " sticky = " << stickyStatus << std::dec << std::endl;

            // reset breaker after 5 iterations
            if (breakCount[ch] > 5)
            {
               std::cout << "Resetting breaker for channel " << rtdSimSession.GetChannel(ch)->GetIndex() << std::endl;
               //cbs[ch]->Reset(1U << aoSession.GetChannel(ch)->GetIndex());
               breakCount[ch] = 0;
            }
         }

         std::cout << std::endl;

         #ifdef _WIN32
         Sleep(500);
         #else
         usleep(500*1000);
         #endif
         count++;
      }

      rtdSimSession.Stop();
      guardianSession.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }



   return 0;
}



