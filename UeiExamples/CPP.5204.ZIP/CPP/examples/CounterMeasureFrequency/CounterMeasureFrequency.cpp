#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession ciSs;
   uInt16* datas = NULL;   // for devices with 16 bit or less counter resolution 
   uInt32* datal = NULL;   // for devices with counter resolution greater than 16 bit
   

   try
   {
      // Create one counter input channel on a powerdaq board to measure the grequency
      // of the signal applied to the input of the selected counter.
      // From now on the session is CI only
      ciSs.CreateCIChannel("pdna://192.168.15.200/Dev5/ci0", 
                           UeiCounterSourceInput, 
                           UeiCounterModeMeasurePeriod, 
                           UeiCounterGateInternal,
                           1,
                           false);

      ciSs.ConfigureTimingForSimpleIO();

      // Configure debounce filter for each channel. 
      // This step is optional and is only needed if your signal 
      // is noisy and you want to filter out unwanted spikes
      for(int ch=0; ch<ciSs.GetNumberOfChannels(); ch++)
      {
         CUeiCIChannel* pChannel = dynamic_cast<CUeiCIChannel*>(ciSs.GetChannel(ch));

         // filter out pulses shorter than 1ms
         pChannel->SetMinimumSourcePulseWidth(1.0);
      }

      // Measurement data will be stored in a 16 bits or 32 bits integer buffer
      // depending on the counter resolution
      // let's allocate a buffer big enough to hold one value for each configured port
      if(ciSs.GetDevice()->GetCIResolution() <= 16)
      {
         datas = new uInt16[ciSs.GetNumberOfChannels()];
      }
      else
      {
         datal = new uInt32[ciSs.GetNumberOfChannels()];
      }

      // Create a reader object to read data synchronously.
      CUeiCounterReader reader(ciSs.GetDataStream());

      // Start period measurement
      ciSs.Start();

      // Read period 100 times
      for(int i=0; i<100; i++)
      {
         double period;

         if(datas != NULL)
         {
            reader.ReadSingleScan(datas);
            std::cout << "period width = " << datas[0] << " ticks" << std::endl;
         }
         else
         {
            reader.ReadSingleScan(datal);

            // Use counter base frequency to convert reading to secs.
            // CT-601 base frequency is 66MHz
            period = datal[0]/66000000.0;
            std::cout << "period width = " << datal[0] << " ticks, " 
                      << period << " secs, " << 1.0/period << "Hz" << std::endl;
         }
      }

      ciSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   if(datas != NULL)
   {
      delete[] datas;
   }
   if(datal != NULL)
   {
      delete[] datal;
   }

   return 0;
}