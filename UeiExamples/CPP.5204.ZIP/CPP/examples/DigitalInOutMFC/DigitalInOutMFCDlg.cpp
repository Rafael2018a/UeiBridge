// DigitalInOutMFCDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DigitalInOutMFC.h"
#include "DigitalInOutMFCDlg.h"
#include ".\digitalinoutmfcdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define SIZEOFARRAY(x) sizeof(x)/sizeof(x[0])

DWORD DOutLines[] = { IDC_DOUT0, IDC_DOUT1, IDC_DOUT2, IDC_DOUT3, IDC_DOUT4, IDC_DOUT5, IDC_DOUT6, IDC_DOUT7,
                     IDC_DOUT8, IDC_DOUT9, IDC_DOUT10, IDC_DOUT11, IDC_DOUT12, IDC_DOUT13, IDC_DOUT14, IDC_DOUT15 };

DWORD DInLines[] = { IDC_DIN0, IDC_DIN1, IDC_DIN2, IDC_DIN3, IDC_DIN4, IDC_DIN5, IDC_DIN6, IDC_DIN7,
                      IDC_DIN8, IDC_DIN9, IDC_DIN10, IDC_DIN11, IDC_DIN12, IDC_DIN13, IDC_DIN14, IDC_DIN15 };

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CDigitalInOutMFCDlg dialog



CDigitalInOutMFCDlg::CDigitalInOutMFCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDigitalInOutMFCDlg::IDD, pParent),
   m_pReader(NULL),
   m_pDinData(NULL),
   m_pWriter(NULL),
   m_pDoutData(NULL)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CDigitalInOutMFCDlg::~CDigitalInOutMFCDlg()
{
   if(m_pReader != NULL)
   {
      delete m_pReader;
      m_pReader = NULL;
   }

   if(m_pDinData != NULL)
   {
      free(m_pDinData);
      m_pDinData = NULL;
   }

   if(m_pWriter != NULL)
   {
      delete m_pWriter;
      m_pWriter = NULL;
   }

   if(m_pDoutData != NULL)
   {
      free(m_pDoutData);
      m_pDoutData = NULL;
   }
}

void CDigitalInOutMFCDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   DDX_Control(pDX, IDC_DOUT_RESOURCE, m_DinResource);
   DDX_Control(pDX, IDC_DIN_RESOURCE, m_DoutResource);
   DDX_Control(pDX, IDC_DIGITALOUTPORT, m_DigitalOutPort);
   DDX_Control(pDX, IDC_DIGITALINPORT, m_DigitalInPort);
}

BEGIN_MESSAGE_MAP(CDigitalInOutMFCDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
   ON_BN_CLICKED(ID_GO, OnBnClickedGo)
   ON_BN_CLICKED(ID_STOP, OnBnClickedStop)
   ON_BN_CLICKED(IDC_DOUT0, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT1, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT2, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT3, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT4, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT5, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT6, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT7, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT8, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT9, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT10, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT11, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT12, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT13, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT14, OnDigLineToggle)
   ON_BN_CLICKED(IDC_DOUT15, OnDigLineToggle)
   ON_WM_TIMER()
END_MESSAGE_MAP()


// CDigitalInOutMFCDlg message handlers

BOOL CDigitalInOutMFCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_DinResource.SetWindowText("simu://Dev2/Di0:1");
   m_DoutResource.SetWindowText("simu://Dev2/Do2:3");
   
   GetDlgItem(ID_GO)->EnableWindow(TRUE);
   GetDlgItem(ID_STOP)->EnableWindow(FALSE);
   for(int i=0; i<SIZEOFARRAY(DOutLines); i++)
         GetDlgItem(DOutLines[i])->EnableWindow(FALSE);
   m_DigitalInPort.EnableWindow(FALSE);
   m_DigitalOutPort.EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDigitalInOutMFCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDigitalInOutMFCDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDigitalInOutMFCDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CDigitalInOutMFCDlg::DisplayError(CUeiException e)
{
   ::MessageBox(m_hWnd, e.GetErrorMessage(), "Error", MB_OK | MB_ICONERROR);
}

void CDigitalInOutMFCDlg::OnBnClickedGo()
{
   try
   {
      CString resstr;
      m_DinResource.GetWindowText(resstr);
      m_DinSession.CreateDIChannel(LPCSTR(resstr));
      m_DinSession.ConfigureTimingForSimpleIO();

      // Create a reader object to read data synchronously.
      m_pReader = new CUeiDigitalReader(m_DinSession.GetDataStream());
      if(m_DinSession.GetDevice()->GetDIResolution() <= 16)
      {
         m_pDinData = malloc(sizeof(uInt16)*m_DinSession.GetNumberOfChannels());
      }
      else
      {
         m_pDinData = malloc(sizeof(uInt32)*m_DinSession.GetNumberOfChannels());
      }
      m_DinSession.Start();

      m_DoutResource.GetWindowText(resstr);
      m_DoutSession.CreateDOChannel(LPCSTR(resstr));
      m_DoutSession.ConfigureTimingForSimpleIO();

      m_pWriter = new CUeiDigitalWriter(m_DoutSession.GetDataStream());
      if(m_DoutSession.GetDevice()->GetDOResolution() <= 16)
      {
         m_pDoutData = malloc(sizeof(uInt16)*m_DoutSession.GetNumberOfChannels());
      }
      else
      {
         m_pDoutData = malloc(sizeof(uInt32)*m_DoutSession.GetNumberOfChannels());
      }
      m_DoutSession.Start();

      GetDlgItem(ID_GO)->EnableWindow(FALSE);
      GetDlgItem(ID_STOP)->EnableWindow(TRUE);
      for(int i=0; i<SIZEOFARRAY(DOutLines); i++)
         GetDlgItem(DOutLines[i])->EnableWindow(TRUE);

      // fill the combo-box with the configured ports
      m_DigitalInPort.ResetContent();
      for(int i=0; i<m_DinSession.GetNumberOfChannels(); i++)
      {
         CUeiChannel* pChan = m_DinSession.GetChannel(i);
         CString label; 
         label.Format("Port %d", pChan->GetIndex());
         m_DigitalInPort.AddString(label);
      }
      m_DigitalInPort.SetCurSel(0);

      m_DigitalOutPort.ResetContent();
      for(int i=0; i<m_DoutSession.GetNumberOfChannels(); i++)
      {
         CUeiChannel* pChan = m_DoutSession.GetChannel(i);
         CString label; 
         label.Format("Port %d", pChan->GetIndex());
         m_DigitalOutPort.AddString(label);
      }
      m_DigitalOutPort.SetCurSel(0);

      m_DigitalInPort.EnableWindow(TRUE);
      m_DigitalOutPort.EnableWindow(TRUE);

      // Start the readi timer to periodically refresh the input ports
      m_TimerID = SetTimer(1, 100, NULL);  
   }
   catch(CUeiException e)
   {
      m_DinSession.CleanUp();
      m_DoutSession.CleanUp();
      DisplayError(e);
   }
}

void CDigitalInOutMFCDlg::OnBnClickedStop()
{
   try
   {
      KillTimer(m_TimerID);

      m_DinSession.Stop();
      m_DinSession.CleanUp();

      m_DoutSession.Stop();
      m_DoutSession.CleanUp();

      delete m_pReader;
      m_pReader = NULL;
      free(m_pDinData);
      m_pDinData = NULL;
      delete m_pWriter;
      m_pWriter = NULL;
      free(m_pDoutData);
      m_pDoutData = NULL;

      GetDlgItem(ID_GO)->EnableWindow(TRUE);
      GetDlgItem(ID_STOP)->EnableWindow(FALSE);
      for(int i=0; i<SIZEOFARRAY(DOutLines); i++)
         GetDlgItem(DOutLines[i])->EnableWindow(FALSE);

      m_DigitalInPort.EnableWindow(FALSE);
      m_DigitalOutPort.EnableWindow(FALSE);
   }
   catch(CUeiException e)
   {
      DisplayError(e);
   }
}

void CDigitalInOutMFCDlg::OnDigLineToggle()
{
   uInt16 doutMask = 0;

   try
   {
      for(int i=0; i<SIZEOFARRAY(DOutLines); i++)
      {
         BOOL bState = ((CButton*)GetDlgItem(DOutLines[i]))->GetCheck() == BST_CHECKED;
         if(bState)
            doutMask = doutMask | (1 << i);

         
      }

      if(m_DoutSession.GetDevice()->GetDOResolution() <= 16)
      {
         ((uInt16*)m_pDoutData)[m_DigitalOutPort.GetCurSel()] = doutMask;
         m_pWriter->WriteSingleScan((uInt16*)m_pDoutData);
      }
      else
      {
         ((uInt32*)m_pDoutData)[m_DigitalOutPort.GetCurSel()] = doutMask;
         m_pWriter->WriteSingleScan((uInt32*)m_pDoutData);
      }
   }
   catch(CUeiException e)
   {
      DisplayError(e);
   }
}

void CDigitalInOutMFCDlg::OnTimer(UINT_PTR nIDEvent)
{
   CDialog::OnTimer(nIDEvent);
   uInt16 value;

   try
   {
      if(m_DinSession.GetDevice()->GetDIResolution() <= 16)
      {
         m_pReader->ReadSingleScan((uInt16*)m_pDinData);
         value = ((uInt16*)m_pDinData)[m_DigitalInPort.GetCurSel()];
      }
      else
      {
         m_pReader->ReadSingleScan((uInt32*)m_pDinData);
         value = (uInt16)((uInt32*)m_pDinData)[m_DigitalInPort.GetCurSel()];
      }

      for(int i=0; i<SIZEOFARRAY(DInLines); i++)
      {
         if(value & (1 << i))
            ((CButton*)GetDlgItem(DInLines[i]))->SetCheck(BST_CHECKED);
         else
            ((CButton*)GetDlgItem(DInLines[i]))->SetCheck(BST_UNCHECKED);
      }
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      DisplayError(e);
   }
}
