#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession dmmSession;

   try
   {
      dmmSession.CreateDMMChannel("pdna://192.168.100.2/dev0/ai0", 150, UeiDMMModeDCVoltage);
      dmmSession.ConfigureTimingForSimpleIO();

      // Create a reader to retrieve diagnostics
      CUeiAnalogScaledReader dmmReader(dmmSession.GetDataStream());
      double* dmmData = new double[dmmSession.GetNumberOfChannels()];

      dmmSession.Start();

      bool stop = false;
      while (!stop)
      {
         // Read and display diagnostics
         dmmReader.ReadSingleScan(dmmData);

         for (int ch = 0; ch < dmmSession.GetNumberOfChannels(); ch++)
         {
            std::cout << "DMM Measurement for channel " << dmmSession.GetChannel(ch) << " = " << dmmData[ch] << std::endl;
         }

         std::cout << std::endl;

         #ifdef _WIN32
         Sleep(500);
         #else
         usleep(500*1000);
         #endif
      }

      dmmSession.Stop();
   }
   catch (CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }



   return 0;
}


