#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

double* data;
int numScans = 50000;
double scanRate = 500000;
CUeiSession mySs;
CUeiAnalogScaledReader* reader;

class CAnalogInEvent : public IUeiEventListener
{
   void OnEvent(tUeiEvent event, void *param)
   {
      if(event == UeiEventFrameDone)
      {
         try
         {
            // data contains latest samples, do something with it...
            for(int i=0; i<mySs.GetNumberOfChannels();i++)
            {
               std::cout << "ch" << i << " = " << data[i] << "V, ";
            }
            std::cout << std::endl;

            // rearm the session to generate the next asynchronous event
            // once enough new samples are ready
            reader->ReadMultipleScansAsync(numScans, data);
         }
         catch(CUeiException e)
         {
            std::cout << "Error: " << e.GetErrorMessage() << std::endl;
         }
      }
      else if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)(uintptr_t)param;
         std::cout << "Error event: " << CUeiException::TranslateError(error) << std::endl;
      }
   }
};


int main(int argc, char* argv[])
{
   CAnalogInEvent eventListener;

   try
   {
      // Create 8 analog input channels on a powerdaq board
      // From now on the session is AI only
      mySs.CreateAIChannel("pwrdaq://Dev0/ai0", -10.0, 10.0, UeiAIChannelInputModeDifferential);

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      mySs.ConfigureTimingForBufferedIO(numScans, UeiTimingClockSourceInternal, scanRate, UeiDigitalEdgeRising, UeiTimingDurationContinuous);

      // Allocate a buffer to hold each acquired frame
      data = new double[mySs.GetNumberOfChannels()*mySs.GetDataStream()->GetNumberOfScans()];

      // Create a reader object to read data synchronously.
      reader = new CUeiAnalogScaledReader(mySs.GetDataStream());

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as the reader starts reading data.
      mySs.Start();

      // Configure an asynchronous event handler that will be called
      // by the reader object each time the required number of scans is available
      reader->AddEventListener(&eventListener);

      // Arm the reader so that it acquire and store samples in the
      // data array and call our handler once the array is full
      reader->ReadMultipleScansAsync(numScans, data);
      
      // Wait for the user to press the enter key to end the program
      getchar();

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   delete reader;
   delete[] data;

   return 0;
}