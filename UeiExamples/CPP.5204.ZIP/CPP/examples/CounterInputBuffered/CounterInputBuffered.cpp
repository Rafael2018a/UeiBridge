#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession mySs;
   unsigned short countedEvents[1000];

   try
   {
      // Create one counter input channel on a powerdaq board to count digital 
      // events applied on the input of the counter.
      // From now on the session is CI only
      mySs.CreateCIChannel("pwrdaq://Dev0/ci0", 
                           UeiCounterSourceInput, 
                           UeiCounterModeCountEvents,
                           UeiCounterGateInternal,
                           1,
                           false);

      // Configure the session to acquire 1000 counts clocked by internal clock
      mySs.ConfigureTimingForBufferedIO(1000, UeiTimingClockSourceInternal, 10000.0, UeiDigitalEdgeRising, UeiTimingDurationSingleShot);

      // Create a reader object to read data synchronously.
      CUeiCounterReader reader(mySs.GetDataStream());

      // Start counting
      mySs.Start();

      // Read 100 samples
      reader.ReadMultipleScans(100, countedEvents);

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}