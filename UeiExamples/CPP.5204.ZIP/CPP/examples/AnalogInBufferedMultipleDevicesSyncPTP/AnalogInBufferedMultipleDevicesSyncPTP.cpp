#include <Windows.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   double scanRate = 1000.0;
   int numScans = 500;
   
   int count = 0;
   std::string syncResources[] = { "pdna://192.168.100.2/Dev14/Sync0" };
   std::string aiResources[]= {"pdna://192.168.100.2/Dev2/Ai0:7,ts" , "pdna://192.168.100.2/Dev3/Ai0:7,ts", "pdna://192.168.100.2/Dev1/Ai0:7,ts" };

   std::vector<CUeiSession*> syncSessions;
   std::vector<CUeiSession*> aiSessions;
   std::vector<CUeiAnalogScaledReader*> readers;
   std::vector<CUeiSync1PPSController*> controllers;
   std::vector<double*> aiDataBuffers;

   std::size_t aiDeviceCount = std::size(aiResources);
   std::size_t syncDeviceCount = std::size(syncResources);

   char timeStr[80];
   tUeiPTPTime ptpTriggerTime;
   time_t triggerUnixTime;


   // Open data file
   std::ofstream dataFs("data.csv", std::ofstream::out);
   if (!dataFs.is_open())
   {
      std::cerr << "Error creting data file" << std::endl;
      return -1;
   }

   try
   {
      // initialize synchronization sessions. Assume first session is a master and produces 
      // the 1PPS signal
      for (std::size_t dev = 0; dev < syncDeviceCount; dev++)
      {
         CUeiSession* syncSession = new CUeiSession();      
         CUeiSync1PPSPort* ptpPort =  syncSession->CreateSync1PPSPort(syncResources[dev],
                                                                     UeiSync1588,
                                                                     UeiSync1PPSInternal,
                                                                     scanRate);

         // Set priorities to values > 128 to avoid becoming grandmaster
         ptpPort->SetPTPPriority1(128 + 3);
         ptpPort->SetPTPPriority2(128 + 3);

         // When trigger command is received all sync devices will trigger their respective I/O layers
         // upon the next 1PPs edge
         syncSession->GetStartTrigger()->SetTriggerSource(UeiTriggerSourceNext1PPS);
         syncSessions.push_back(syncSession);

         // Create controller object used to read status and send trigger command
         CUeiSync1PPSController* controller = new CUeiSync1PPSController(syncSession->GetDataStream());
         controllers.push_back(controller);
      }

      // Configure AI layers
      for (std::size_t dev=0; dev < aiDeviceCount; dev++)
      {
         CUeiSession* aiSession = new CUeiSession();

         // Create analog input channels
         aiSession->CreateAIChannel(aiResources[dev], -10.0, 10.0, UeiAIChannelInputModeDifferential);

         // Name channels (optional)
         for (int ch = 0; ch < aiSession->GetNumberOfChannels(); ch++)
         {
            CUeiAIChannel* pAIChan = dynamic_cast<CUeiAIChannel*>(aiSession->GetChannel(ch));
            CUeiTimestampChannel* pTSChan = dynamic_cast<CUeiTimestampChannel*>(aiSession->GetChannel(ch));

            if (pAIChan)
            {
               std::ostringstream chName;
               chName << "Dev" << aiSession->GetDevice()->GetIndex() << "/Channel" << pAIChan->GetIndex();
               pAIChan->SetAliasName(chName.str());
            }
            else if (pTSChan)
            {
               std::ostringstream chName;
               chName << "Dev" << aiSession->GetDevice()->GetIndex() << "/Timestamp";
               pTSChan->SetAliasName(chName.str());
            }
         }

         // Configure the session to acquire 1000 scans clocked by a synchronisation signal
         aiSession->ConfigureTimingForBufferedIO(numScans, UeiTimingClockSourceSignal, scanRate, UeiDigitalEdgeRising, UeiTimingDurationContinuous);
         aiSession->GetTiming()->SetTimeout(5000);
         aiSession->GetTiming()->SetTimestampResolution(1.0 / scanRate);

         if(syncDeviceCount > 0)
         {
            // Program scan clock signal to come from 1PPS event module via sync line #2
            if (!aiSession->GetDevice()->GetDeviceName().compare("AI-217"))
            {
               aiSession->GetTiming()->SetScanClockSourceSignal("pps2/mode1");
            }
            else
            {
               aiSession->GetTiming()->SetScanClockSourceSignal("pps2");
            }

            // The scan clock can be divided to synchronize AI layers that are over-clocked with other AI layers
            // For example the AI-217 requires a scan clock 8x faster than the data rate expected by the user
            // To synchronize an AI-207 with the AI-217, its clock needs to be divided by 8.
            aiSession->GetTiming()->SetScanClockTimebaseDivisor(0);

            // Configure AI layers to wait for trigger signal on sync line #3, the event module will assert
            // line #3 on the next 1PPS edge after having received a trigger command.
            aiSession->ConfigureSignalTrigger(UeiTriggerActionStartSession, "pps3");   
         }

         // Create a reader object to read data synchronously from the data stream.
         CUeiAnalogScaledReader* reader = new CUeiAnalogScaledReader(aiSession->GetDataStream());

         // Allocate buffer to store data frame
         double* data = new double[aiSession->GetNumberOfChannels()*aiSession->GetDataStream()->GetNumberOfScans()];

         // Store pointers for each device in vectors
         aiSessions.push_back(aiSession);
         readers.push_back(reader);
         aiDataBuffers.push_back(data);
      }

      // Write headers to CSV file
      for (std::size_t dev = 0; dev < aiDeviceCount; dev++)
      {
         for (int ch = 0; ch < aiSessions[dev]->GetNumberOfChannels(); ch++)
         {
            dataFs << aiSessions[dev]->GetChannel(ch)->GetAliasName() << ",";
         }
      }
      dataFs << std::endl;
      
      // Start sync sessions one by one and wait until ADPLL is locked on 1PPS
      for (std::size_t dev = 0; dev < syncDeviceCount; dev++)
      {
         syncSessions[dev]->Start();
      }

      // Start I/O sessions first
      for (std::size_t dev = 0; dev < aiDeviceCount; dev++)
      {
         aiSessions[dev]->Start();
      }

      for (std::size_t dev = 0; dev < syncDeviceCount; dev++)
      {
         int lockCount = 0;
         int loopCount = 0;
         std::cout << "Checking Lock status on " << syncSessions[dev]->GetDevice()->GetResourceName() << ":";
         while (lockCount < 10 && loopCount < 30)
         {
            bool locked;
            controllers[dev]->ReadLockedStatus(&locked);
            if (locked)
            {
               lockCount++;
               std::cout << "L";
            }
            else
            {
               std::cout << ".";
            }
            Sleep(500);
         }

         if (lockCount < 10)
         {
            std::cout << "could not lock 1PPS" << std::endl;
            return -1;
         }

         std::cout << " Locked!" << std::endl;
      }

      if(syncDeviceCount)
      {
         struct tm* triggerTime;

         // Read PTP time of next 1PPS, which will be the absolute timestamp of the trigger.
         // To do this we read in a loop until nsec is less than 100000000 (100ms)
         do
         {
            controllers[0]->ReadPTPUTCTime(&ptpTriggerTime);
            Sleep(10);
         } while (ptpTriggerTime.nsec > 100000000);

         // trigger time will ne next second
         ptpTriggerTime.sec = ptpTriggerTime.sec + 1;
         // trim nanoseconds
         ptpTriggerTime.nsec = 0;

         triggerUnixTime = (time_t)ptpTriggerTime.sec;
         // convert calendar time to struct tm
         triggerTime = localtime(&triggerUnixTime);

         // format date and time to look pretty
         strftime(timeStr, sizeof(timeStr) - 1, "%Y-%m-%d_%Hh%Mm%Ss", triggerTime);
         
         // Send trigger signal to start clocking the AI layers on the next 1PPS pulse
         controllers[0]->TriggerDevices(UeiSync1PPSTriggerOnNextPPSBroadCast, true);

         std::cout << "Devices triggered at " << timeStr << " (" << ptpTriggerTime.sec << "seconds since 01/01/1970)" << std::endl;
      }

      // Acquire 20 frames then stop
      while(count < 200)
      {
         for (std::size_t dev=0; dev < aiDeviceCount; dev++)
         {
            readers[dev]->ReadMultipleScans(numScans, aiDataBuffers[dev]);
         }

         // log data to file
         for (int scan = 0; scan < numScans; scan++)
         {
            for (std::size_t dev = 0; dev < aiDeviceCount; dev++)
            {
               for (int ch = 0; ch < aiSessions[dev]->GetNumberOfChannels(); ch++)
               {
                  dataFs << aiDataBuffers[dev][scan* aiSessions[dev]->GetNumberOfChannels()+ch];
                  
                  // if this is a timestamp channel log absolute timestamp 
                  if (dynamic_cast<CUeiTimestampChannel*>(aiSessions[dev]->GetChannel(ch)) != NULL)
                  {
                     // separate seconds and microsecs from timestamp value
                     double tsSecs;
                     double tsMicroSecs = modf(aiDataBuffers[dev][scan * aiSessions[dev]->GetNumberOfChannels() + ch], &tsSecs) * 1000000.0;

                     time_t scanUnixTime = triggerUnixTime + (time_t)tsSecs;
                     struct tm* scanTime = localtime(&scanUnixTime);
                     strftime(timeStr, sizeof(timeStr) - 1, "%Y-%m-%d_%Hh%Mm%Ss", scanTime);

                     dataFs << "==" << timeStr << tsMicroSecs << "us,";
                  }
                  else
                  {
                     dataFs << ",";
                  }
               }
            }
            dataFs << std::endl;
         }

         std::cout << "*";

         count++;
      }

      for (std::size_t dev=0; dev < aiDeviceCount; dev++)
      {
         aiSessions[dev]->Stop();
      }

      for (std::size_t dev = 0; dev < syncDeviceCount; dev++)
      {
         syncSessions[dev]->Stop();
      }
   }
   catch(CUeiException e)
   {
      std::cerr << "Error: " << e.GetErrorMessage() << std::endl;
   }

   for (std::size_t dev=0; dev < aiDeviceCount; dev++)
   {
      if(aiDataBuffers.size() > dev) delete[] aiDataBuffers[dev];
      if(readers.size() > dev) delete readers[dev];
      if(aiSessions.size() > dev) delete aiSessions[dev];
   }

   for (std::size_t dev = 0; dev < syncDeviceCount; dev++)
   {
      if(controllers.size() > dev) delete controllers[dev];
      if(syncSessions.size() > dev) delete syncSessions[dev];
   }

   dataFs.close();
      
   return 0;
}