#ifndef __UEISTRUCTS_H__
#define __UEISTRUCTS_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

#ifdef __cplusplus
namespace UeiDaq
{
#endif

/// \brief Structure represents a CAN frame 
/// 
/// Structure represents a CAN frame
typedef struct _tUeiCanFrame
{
   /// \brief CAN Frame arbitration id
   uInt32   Id;  
   /// \brief Specifies whether this is a data, remote or error frame
   tUeiCANFrameType   Type;
   /// \brief The number of significant bytes in the payload
   uInt32   DataSize;
   /// \brief The frame's payload. It can contain up to 8 bytes
   uInt8    Data[8];
} tUeiCANFrame;

/// \brief Structure represents a CAN filter entry 
/// 
/// Each filter entry is a range of arbitration IDs
/// IDs greater or equal to first and less or equal to last will pass through
/// All others will be rejected
typedef struct _tUeiCanFilterEntry
{
   /// \brief First ID that delimits the range of IDs to accept
   uInt32   First;  
   /// \brief Last ID that delimits the range of IDs to accept
   uInt32   Last;
}
tUeiCANFilterEntry;

/// \brief Structure represents a MIL-1553 command 
/// 
/// Structure represents a 1553 command
typedef struct _tUeiMIL1553Command
{
    /// \brief Command type
    tUeiMIL1553CommandType Command;
    /// \brief Second terminal for UeiMIL1553CmdRTRT type 
    uInt16 Rt2;
    /// \brief Second subaddress for UeiMIL1553CmdRTRT type
    uInt16 Sa2;
    /// \brief Number of data words in the &lt;Command&gt; or status word from the bus or Mode Code
    uInt16 WordCount;
    /// \brief Flags if requested
    uInt32 Flags;
    /// \brief Delay in us before the command or timestamp
    uInt32 Delay;
} tUeiMIL1553Command;

/// \brief Structure represents a MIL-1553 frame 
/// 
/// Structure represents a 1553 frame (W/R)
typedef struct _tUeiMIL1553Frame
{
   /// \brief Specifies the type of 1553 frame
   tUeiMIL1553FrameType   Type;
   /// \brief Remote terminal frame belongs to
   uInt16   Rt;
   /// \brief Sub-address frame belongs to
   uInt16   Sa;
   /// \brief I/O block terminal frame belongs to
   uInt16   Block;
   /// \brief Command is required for BC functionality (for UeiMIL1553FrameTypeBusWriter)
   tUeiMIL1553Command   Command;
   /// \brief The number of bytes in the payload (also size of data from BusWriter frame)
   uInt32   DataSize;
   /// \brief The frame, bus monitor and TxFIFO frame payload. It can contain up to 36 uInt32s
   uInt32   RxTxData[36];
} tUeiMIL1553Frame;

/// \brief Structure represents a bus monitor MIL-1553 frame (R/O)
/// 
/// Structure represents a 1553 frame
typedef struct _tUeiMIL1553BMFrame
{
   /// \brief Command type
   tUeiMIL1553CommandType Command;
   /// \brief Remote terminal frame belongs to
   uInt16   Rt;
   /// \brief Sub-address frame belongs to
   uInt16   Sa;
   /// \brief Number of data words in the &lt;Command&gt; or status word from the bus or Mode Code
   uInt16   WordCount;
   /// \brief First command status
   uInt16   CmdStatusRaw;
   /// \brief Flags if requested
   uInt32   Flags;
   /// \brief Delay in us before the command or timestamp
   uInt32   Delay;
   /// \brief The number of bytes in the payload (also size of data from BusWriter frame)
   uInt32   DataSize;
   /// \brief The frame, bus monitor and TxFIFO frame payload. It can contain up to 36 uInt32s - command/status, 32 points of data, timestamp and flags
   uInt32   BmData[36];
} tUeiMIL1553BMFrame;

/// \brief Structure represents a MIL-1553 BM frame with decoded command sequence (R/O)
/// 
/// Structure represents a MIL-1553 BM frame with decoded command sequence (R/O)
typedef struct _tUeiMIL1553BMCmdFrame
{
   /// \brief Which bus the message was received on; 1 = A, 0 = B
   uInt8    Bus;
   /// \brief Remote terminal frame belongs to
   uInt16   Rt;
   /// \brief Sub-address frame belongs to
   uInt16   Sa;
   /// \brief Number of data words in the &lt;Command&gt; or status word from the bus or Mode Code
   uInt16   WordCount;
   /// \brief Command type
   tUeiMIL1553CommandType Command;
   /// \brief Second Remote terminal, in the case of an RT-RT command
   uInt16   Rt2;
   /// \brief Second Sub-address, in the case of an RT-RT command
   uInt16   Sa2;
   /// \brief First status
   uInt16   Status;
   /// \brief Second status, in the case of an RT-RT command
   uInt16   Status2;
   /// \brief Timestamp of message start, in tens of microseconds
   uInt32   Timestamp;
   /// \brief Delay in us before the command or timestamp
   uInt32   Delay;
   /// \brief An index into &lt;BmData&gt; where the first data word of the message is located, or -1 if the message has no data.
   /// If a Mode Code command, the number of data words is 1; otherwise, &lt;WordCount&gt; indicates the data word count (where 0 means 32).
   Int8	DataWordStartIdx; 
   /// \brief The number of words that make up the entire frame (i.e. the size of the &lt;BmData&gt; field)
   uInt32   BmDataSize;
   /// \brief The frame, bus monitor and TxFIFO frame payload. It can contain up to 42 uInt32s:
   /// 32 points of data plus 2 commands 2 statuses and 3 timestamps and 3 flags
   uInt32   BmData[42];
} tUeiMIL1553BMCmdFrame;

/// \brief Structure represents a MIL-1553 RT frame Data (W/R)
/// 
/// Structure represents a 1553 frame to read/write RT data
typedef struct _tUeiMIL1553RTFrame
{
   /// \brief Remote terminal frame belongs to
   uInt16   Rt;
   /// \brief Sub-address frame belongs to
   uInt16   Sa;
   /// \brief I/O block terminal frame belongs to
   uInt16   Block;
   /// \brief The number of bytes in the payload (also size of data from BusWriter frame)
   uInt32   DataSize;
   /// \brief Status flags associated with this data
   uInt32   Flags;
   /// \brief The frame, bus monitor and TxFIFO frame payload. It can contain up to 32 uInt32s
   uInt32   RxTxData[36];
} tUeiMIL1553RTFrame;


/// \brief Structure represents a MIL-1553 RT status data (R/O)
/// 
/// Structure represents a 1553 frame to read status RT data
typedef struct _tUeiMIL1553RTStatusFrame
{
   /// \brief Remote terminal frame belongs to
   uInt16   Rt;
   /// \brief Remote tesminal bus status
   uInt32   BusStatus;
   /// \brief Bitmask for SAs which received data from BC (Rx command)
   uInt32   DataReady;
   /// \brief Bitmask for SAs which sent data to BC or another RT (Tx command)
   uInt32   DataSent;
   /// \brief Status 0 field
   uInt32   Status0;
   /// \brief Status 1 field
   uInt32   Status1;
   /// \brief Channel status
   uInt32   ChStatus;

} tUeiMIL1553RTStatusFrame;


/// \brief Structure extends MIL-1553 RT status data (R/O)
/// 
/// This structure extends tUeiMIL1553RTStatusFrame with extra status words
typedef struct _tUeiMIL1553RTStatusFrameExt
{
   /// \brief 
   tUeiMIL1553RTStatusFrame rtStatusFrame;
   /// \brief Status 2 field
   uInt32   Status2;
   /// \brief Status 3 field
   uInt32   Status3;
} tUeiMIL1553RTStatusFrameExt;


/// \brief Structure represents a MIL-1553 RT control data (W/O)
/// 
/// Structure represents a 1553 frame to write control RT data
typedef struct _tUeiMIL1553RTControlFrame
{
   /// \brief Remote terminal frame belongs to
   uInt16   Rt;
   /// \brief Subaddress frame belongs to (optional)
   uInt16   Sa;
   /// \brief Flags, what control data is
   tUeiMIL1553RTControlType Flags;
   /// \brief Which Tx (RT-&gt;BC) block to select
   uInt32   BlockSelectRtBc;
   /// \brief Which Rx (BC-&gt;RT) block to select
   uInt32   BlockSelectBcRt;
   /// \brief Control 0 field
   uInt32   Control0;
   /// \brief Control 1 field
   uInt32   Control1;
   /// \brief Defines rt response timing
   uInt32   GapBetweenDataWords;
} tUeiMIL1553RTControlFrame;

/// \brief Structure represents a MIL-1553 RT parameter (W/O)
/// 
/// Structure represents a 1553 frame to write RT parameters
typedef struct _tUeiMIL1553RTParametersFrame
{
   /// \brief Remote terminal frame belongs to
   uInt16   Rt;
   /// \brief Sub-address frame belongs to
   uInt16   Sa;
   /// \brief Flags, what control data it is; possibly we need emumerator
   uInt32   Flags;
   /// \brief Parameter type
   uInt32   Parameter;
   /// \brief Size of data to transmit
   uInt32   DataSize;
   /// \brief Parameter data
   uInt32   Data[32];
} tUeiMIL1553RTParametersFrame;

/// \brief Structure represents a MIL-1553 bus writer data (W/O)
/// 
/// Structure represents a 1553 frame to write the bus
typedef struct _tUeiMIL1553BusWriterFrame
{
   /// \brief Remote terminal frame belongs to
   uInt16   Rt;
   /// \brief Sub-address frame belongs to
   uInt16   Sa;
   /// \brief Number of data words in the &lt;Command&gt; or status word from the bus or Mode Code
   uInt16   WordCount;
   /// \brief Command type
   tUeiMIL1553CommandType Command;
   /// \brief Remote terminal frame belongs to
   uInt16   Rt2;
   /// \brief Sub-address frame belongs to
   uInt16   Sa2;
   /// \brief Flags if requested
   uInt32   Flags;
   /// \brief Delay in us before the command or timestamp
   uInt32   Delay;
   /// \brief The number of bytes in the payload (also size of data from BusWriter frame)
   uInt32   DataSize;
   /// \brief The frame, bus monitor and TxFIFO frame payload. It can contain up to 36 uInt32s
   uInt32   TxData[36];
} tUeiMIL1553BusWriterFrame;

/// \brief Structure represents a MIL-1553 BCCB (W/O)
/// 
/// Structure represents a 1553 frame to write BCCB data
typedef struct _tUeiMIL1553BCCBDataFrame
{
    /// \brief Minor frame # for this BCCB
    uInt16   MNFrame;
    /// \brief Index in the minor frame
    uInt16   Index;
    /// \brief I/O block frame belongs to
    uInt16   Block;
    /// \brief FLAGS0 word in the BC control block
    uInt16   flags0;    
    /// \brief FLAGS1 word in the BC control block
    uInt16   flags1;    
    /// \brief Delay in us before command execution (bit15 is enable)
    uInt16   flags2;    
    /// \brief Reserved for future flags
    uInt16   flags3;
    /// \brief First 1553 command word
    uInt16   cmd1;      
    /// \brief Second 1553 command word
    uInt16   cmd2;      
    /// \brief "OR" mask for the first status word
    uInt16   sts1_or;   
    /// \brief "AND" mask for the first status word
    uInt16   sts1_and;  
    /// \brief Compare "VALUE" for the first status word 
    uInt16   sts1_val;  
    /// \brief "OR" mask for the second status word
    uInt16   sts2_or;   
    /// \brief "AND" mask for the second status word
    uInt16   sts2_and;  
    /// \brief Compare "VALUE" for the second status word 
    uInt16   sts2_val;  
    /// \brief RX data (from BC to RT) or minimum compare values for TX
    uInt16   rx_data[32];
    /// \brief minimum compare values for TX 
    uInt16   tmin[32];        
    /// \brief maximum compare values for TX 
    uInt16   tmax[32];        
} tUeiMIL1553BCCBDataFrame;

/// \brief Structure represents a MIL-1553 read BCCB status (R/O)
/// 
/// Structure represents a 1553 frame to read BCCB status
typedef struct _tUeiMIL1553BCCBStatusFrame
{
    /// \brief Minor frame # for this BCCB
    uInt16   MNFrame;
    /// \brief Index in the minor frame
    uInt16   Index;
    /// \brief I/O block frame belongs to
    uInt16   Block;
    /// \brief First status reply from the RT
    uInt16   sts1;        
    /// \brief Second status reply from the RT
    uInt16   sts2;        
    /// \brief Timestamp of last access to the RT, 16 MSBs 
    uInt16   tsmsb;       
    /// \brief Timestamp of last access to the RT, 16 LSBs 
    uInt16   tslsb;       
    /// \brief error status 0
    uInt16   errsts0;     
    /// \brief error status 1
    uInt16   errsts1;
    /// \brief transmit data (from RT to BC)
    uInt16   tx_data[32]; 
} tUeiMIL1553BCCBStatusFrame;

/// \brief Structure represents a MIL-1553 BC status (R/O)
/// 
/// Structure represents a MIL-1553 BC status
typedef struct _tUeiMIL1553BCStatusFrame
{
    /// \brief BC status word
    uInt32   BCStatus;
    /// \brief Port status word
    uInt32   PortStatus;
    /// \brief Current MJ position
    uInt32   MJPos;
    /// \brief Current minor position
    uInt32   MNPos;
    /// \brief Current block
    uInt32   Block;
    /// \brief BC ISR status word
    uInt32   IsrStatus;
    /// \brief BC ERR status word
    uInt32   ErrStatus;

} tUeiMIL1553BCStatusFrame;


/// \brief Structure represents a MIL-1553 BCCB scheduler frame (W/R)
/// 
/// Structure represents a MIL-1553 BCCB scheduler frame 
typedef struct _tUeiMIL1553BCSchedFrame
{
   /// \brief Frame type (major or minor)
   tUeiMIL1553BCFrameType FrameType;
   /// \brief I/O block terminal frame belongs to
   uInt16   Block;
   /// \brief Frame index 
   uInt32   FrameIndex;
   /// \brief First entry to write to (offset)
   uInt32   DataOffset;  
   /// \brief The number of words in the payload
   uInt32   DataSize;
   /// \brief The frame payload. It can contain up to 36 uInt32s (content of entries)
   uInt32   data[36];
} tUeiMIL1553BCSchedFrame;

/// \brief Structure represents a MIL-1553 BCCB control frame (W/O)
/// 
/// Structure represents a MIL-1553 BCCB control frame
typedef struct _tUeiMIL1553BCControlFrame
{
   /// \brief Operation
   tUeiMIL1553BCOps Operation;
   /// \brief major clock rate: 0 == software clock
   double MinorClock;
   /// \brief minor clock rate: 0 == software clock
   double MajorClock;
   /// \brief major parameter
   uInt32 MajorParam;
   /// \brief minor parameter
   uInt32 MinorParam;
} tUeiMIL1553BCControlFrame;

/// \brief Structure represents an ARINC-708 data frame (W/R)
/// 
/// Structure represents a an ARINC-708 data frame
typedef struct _tUeiMIL1553A708DataFrame
{
   /// \brief Timestamp in 10us resolution
   uInt32 Timestamp;
   /// \brief Available bumber of 16-bit words in the FIFO after the operation
   uInt32 Available;
   /// \brief Data Size (returned on read, uses declared frame size on write)
   uInt32 DataSize;
   /// \brief ARINC-708 data
   uInt16 data[100]; 

} tUeiMIL1553A708DataFrame;

/// \brief Structure represents an ARINC-708 control frame (W/O)
/// 
/// Structure represents an ARINC-708 control frame
typedef struct _tUeiMIL1553A708ControlFrame
{
   /// \brief Operation
   tUeiMIL1553A708Ops Operation;
   /// \brief major clock rate: 0 == software clock
   double MinorClock;
   /// \brief minor clock rate: 0 == software clock
   double MajorClock;
   /// \brief major parameter
   uInt32 MajorParam;
   /// \brief minor parameter
   uInt32 MinorParam;
} tUeiMIL1553A708ControlFrame;

/// \brief Structure represents a synchronization signal 
/// 
/// Structure represents a synchronization signal
typedef struct _tUeiSignal
{
   /// \brief Source of the signal
   tUeiSignalSource  Source;
   /// \brief Device where this signal is located (used only if source is "*Trigger" or "*Clock")
   int               Device;     
   /// \brief Index of the signal (used only if source is "Backplane")
   int               Index;      
   /// \brief Mode enables device dependant timing modes
   int               Mode;  
} tUeiSignal;

/// \brief Structure represents an ARINC word 
/// 
/// Structure represents an ARINC word
typedef struct _tUeiARINCWord
{
   /// \brief The label of the word. It is used to determine the data type of the Data field, 
   /// therefore, the method of data translation to use.
   uInt32   Label;
   /// \brief Sign/Status Matrix or SSM. This field contains hardware equipment condition, 
   /// operational mode, or validity of data content.
   uInt32   Ssm;
   /// \brief Source/Destination Identifier or SDI. 
   /// This is used for multiple receivers to identify the receiver for
   /// which the data is destined.
   uInt32   Sdi;
   /// \brief The parity bit.
   /// The parity bit is automatically set on transmitted words. 
   /// The parity bit on received words is actually a parity status.
   /// It is set to 0, when parity is odd and the receiver counts an odd number of 1s (all Ok).
   /// It is set to 1, when parity is odd and the receiver counts an even number of 1s (parity error)
   /// It is set to 1, when parity is even and the receiver counts an even number of 1s (all Ok).
   /// It is set to 0, when parity is even and the receiver counts an odd number of 1s (parity error)
   uInt32   Parity;
   /// \brief The payload of the word. Its format depends on the label.
   /// Most common formats are BCD (binary-coded-decimal) encoding,
   /// BNR (binary) encoding or discrete format where each bit represents
   /// a Pass/Fail, True/False or Activated/Non-Activated condition.
   uInt32   Data;
} tUeiARINCWord;

/// \brief Structure represents an ARINC scheduler entry
///
/// Structure represents an ARINC scheduler entry. 
/// The scheduler is used to emit ARINC frames periodically 
/// or when a specified frame is received. 
/// Only Master entries are scheduled followed by any adjacent slave entries. 
typedef struct _tUeiARINCSchedulerEntry
{
   /// \brief Specifies whether this is a master or slave entry
   /// All slave entries following a master entry (until the
   /// next master entry) are scheduled at the same time
   Int32                      Master;
   /// \brief Specifies whether this master entry should be scheduled periodically 
   /// Ignored for slave entries
   Int32                      Periodic;
   /// \brief Sets time interval in us for the output of master entries
   uInt32                     Delay;
   /// \brief Word to be sent when this entry is processed.
   tUeiARINCWord              Word;
   /// \brief Minor frame mapping (one bit per frame)
   uInt32                     MinorFrameMask;
} tUeiARINCSchedulerEntry;

/// \brief Structure represents an ARINC filter entry
///
/// Structure represents an ARINC filter entry. 
/// ARINC frames whose label doesn't match any of the filter entry 
/// are discarded.
typedef struct _tUeiARINCFilterEntry
{
   /// \brief Label to accept 
   uInt32                     Label;
   /// \brief Accept word only if it carries different data from a previous received one.
   Int32                      NewData;
   /// \brief Trigger the scheduler entry with the same index as this
   /// filter entry in the scheduler table of the output port 
   /// that has the same index as this input port.
   Int32                      TriggerSchedulerEntry;
} tUeiARINCFilterEntry;

typedef struct _tUeiARINCMinorFrameEntry
{
   /// \brief sets the delay (in us) of minor frame relative to the start of the major frame
   uInt32 Delay;
   /// \brief sets the period (in us) of the minor frame
   uInt32 Period;
} tUeiARINCMinorFrameEntry;

/// \brief Structure represents an 1553 filter entry
///
/// Structure represents an 1553 filter entry. 1553 messages outside of enabled are ignored
typedef struct _tUeiMIL1553FilterEntry
{
   /// \brief Type of the filtering to apply
   tUeiMIL1553FilterType   FilterType;    
   /// \brief Remote terminal to allow
   int                     RemoteTerminal;
   /// \brief Subaddress to allow
   int                     SubAddress;
   /// \brief Minimal RT message data length for Rx command (0=32 words, -1=Any)
   int                     MinRxLength;
   /// \brief Maximum RT message data length for Rx command (0=32 words, -1=Any)
   int                     MaxRxLength;
   /// \brief Minimal RT message data length for Tx command (0=32 words, -1=Any)
   int                     MinTxLength;
   /// \brief Maximum RT message data length for Tx command (0=32 words, -1=Any)
   int                     MaxTxLength;
   /// \brief Enable Rx requests
   int                     EnableRxRequests;
   /// \brief Enable Tx requests
   int                     EnableTxRequests;
   /// \brief Enable mode commands or Raw validation table value
   int                     EnableModeCommands;
} tUeiMIL1553FilterEntry;

/// \brief Structure represents an 1553 scheduler entry
///
/// Structure represents an 1553 scheduler entry. 
/// The scheduler is used to emit 1553 frames periodically 
/// or when a specified frame is received. 
/// Only Master entries are scheduled followed by any adjacent slave entries. 
typedef struct _tUeiMIL1553SchedulerEntry
{
   /// \brief Specifies whether this is a master or slave entry
   Int32                      Master;
   /// \brief Specifies whether this entry should be scheduled periodically 
   Int32                      Periodic;
   /// \brief Scheduling delay count in us
   uInt32                     Delay;
   /// \brief Command to send
   tUeiMIL1553CommandType     Command;
   /// \brief Remote terminal to to send to
   uInt32                     RemoteTerminal;
   /// \brief Subaddress to send to
   uInt32                     SubAddress;
   /// \brief Word to be sent when this entry is processed.
   uInt32                     EntrySize;
} tUeiMIL1553SchedulerEntry;

/// \brief Structure represents time in BCD format
///
/// Structure represents time in BCD (Binary Coded Decimal) format 
typedef struct _tUeiBCDTime
{
   /// \brief Number of microseconds within the last second
   uInt32 microseconds;  
   /// \brief 100's of a second (4 bits)
   uInt32 s100;    
   /// \brief 10's of a second (4 bits)
   uInt32 s10;     
   /// \brief seconds (7 bits)
   uInt32 seconds;      
   /// \brief minutes (7 bits)
   uInt32 minutes;      
   /// \brief hours (7 bits)
   uInt32 hours;    
   /// \brief days
   uInt32 days;     
   /// \brief years
   uInt32 years;     
} tUeiBCDTime;

/// \brief Structure represents time in SBS format
///
/// Structure represents time in SBS (Straight Binary Seconds) format 
typedef struct _tUeiSBSTime
{
   /// \brief Number of seconds since beginning of the day
   uInt32 seconds;    
   /// \brief Number of microseconds within the last second
   uInt32 microseconds;     
   /// \brief day of the year
   uInt32 dayofyear;      
   /// \brief year
   uInt32 year;           
} tUeiSBSTime;

/// \brief Structure represents time in C ANSI format with the addition of microseconds
///
/// Structure represents time in C ANSI format with the addition of microseconds
typedef struct _tUeiANSITime
{
#ifndef UEIIDL
   /// \brief C ANSI time structure
   struct tm tm;  
#endif

   /// \brief Number of microseconds within the last second
   uInt32 microseconds;       
} tUeiANSITime;

/// \brief Structure represents time in secs and nsecs
///
/// Structure represents time in seconds since UNIX epoch time and nanoseconds remainder
typedef struct _tUeiPTPTime
{
   /// \brief Number of seconds since 01/01/1970
   uInt32 sec;

   /// \brief Number of nanoseconds elapsed before next second
   uInt32 nsec;
} tUeiPTPTime;

/// \brief Structure represents waveform shape parameters
///
/// Structure used to update waveform shape parameters on the fly.
typedef struct _tUeiAOWaveformParameters
{
   /// \brief waveform type/shape
   tUeiAOWaveformType type;
   /// \brief waveform mode affects timing
   tUeiAOWaveformMode mode;
   /// \brief waveform xform affects shape
   tUeiAOWaveformXform xform;
   /// \brief waveform frequency
   double frequency; 
   /// \brief waveform span
   double span;      
   /// \brief waveform offset 
   double offset;    
   /// \brief waveform phase
   double phase;     
   /// \brief apply parameters gradually over time interval 
   double applyTime;
   /// \brief the duty cycle (for pulse waveform only)
   float dutyCycle; 
   /// \brief the time it takes to transition from low to high state, % [0..1] (for pulse and sawtooth only)
   float riseTime;        
   /// \brief the time it takes to transition from high to low state, % [0..1] (for pulse and sawtooth only)
   float fallTime;        
} tUeiAOWaveformParameters;

/// \brief Structure represents waveform sweep parameters
///
/// Structure used to update waveform sweep parameters on the fly.
typedef struct _tUeiAOWaveformSweepParameters
{
   /// \brief sweep control
   tUeiAOWaveformSweepControl control;
   /// \brief sweep mode, continuous or single shot
   tUeiTimingDuration mode;
   /// \brief number of steps used to sweep up during N periods
   uInt32 stepsUp;      
   /// \brief number of steps used to sweep down during N periods
   uInt32 stepsDown;       
   /// \brief Specify duration of the sweep in number of periods 
   uInt32 numberOfPeriods;
   /// \brief lower frequency
   double lowerFrequency;    
   /// \brief upper frequency
   double upperFrequency;      
   /// \brief lower amplitude
   double lowerAmplitude;     
   /// \brief upper amplitude
   double upperAmplitude;     
   /// \brief lower offset
   double lowerOffset;     
   /// \brief upper offset
   double upperOffset;      
   /// \brief lower phase
   double lowerPhase;     
   /// \brief upper phase
   double upperPhase;       
   /// \brief Specify duration of the sweep in ms
   double sweepTime;    
} tUeiAOWaveformSweepParameters;

/// \brief Structure represents variable reluctance data
///
/// Structure used to store data measured on variable reluctance input channels.
typedef struct _tUeiVRData
{
   /// \brief velocity of the encoder wheel
   double velocity;    
   /// \brief position as tooth index relative to the Z index tooth
   uInt32 position;    
   /// \brief number of teeth detected since last read
   uInt32 teethCount;  
   /// \brief timestamp of measurement
   uInt32 timestamp; 
   /// \brief status flags
   uInt32 flags;
} tUeiVRData;

/// \brief Structure represents simulated variable reluctance data
///
/// Structure used to store data simulated on variable reluctance output channels.
typedef struct _tUeiSimulatedVRData
{
   /// \brief The number of revolution per minute simulated
   double rpm;
   /// \brief The number of pulses per revolution simulated
   uInt32 ppr;
   /// \brief The percent of 1 period that the odd channel is delayed from the even channel
   double percentDelay;
} tUeiSimulatedVRData;

/// \brief CSDB message 
/// 
/// This structure represents a CSDB message
typedef struct _UeiCSDBMessage
{
   /// \brief address byte for the message
   unsigned char address;
   /// \brief status byte for the message
   unsigned char status;
   /// \brief data bytes for the message. Number of bytes is block size - 2
   unsigned char data[10];
} tUeiCSDBMessage;


/// \brief Structure used to read ADPLL, event module and sync lines status
///
/// This structure represents 1PPS synchronization hardware status
typedef struct _UeiSync1PPSStatus 
{
   /// \brief ADPLL status register
   uInt32 ADPLLStatus;  
   /// \brief Minimum period length for the input clock
   uInt32 ADPLLMinInputClockPeriod; 
   /// \brief Averaged detected length of the VALIDATED input period
   uInt32 ADPLLAvgInputClockPeriod;
   /// \brief Maximum period length for the input clock
   uInt32 ADPLLMaxInputClockPeriod;
   /// \brief Measured length of the last input period
   uInt32 ADPLLLastInputClockPeriod;
   /// \brief Accumulated pulse position error in system clocks
   uInt32 ADPLLAccumulatedError; 
   /// \brief whether PLLs are locked (8347/5200 "classic" have only one PLL)
   uInt32 PLLStatus;   
   /// \brief status of nPPS signal
   uInt32 PPSStatus;                  
   /// \brief event module status
   uInt32 EventModuleStatus;
   /// \brief snapshot of the SYNC lines
   uInt32 SyncLinesStatus;                  
   /// \brief snapshot of the SyncIn/SyncOut lines 
   uInt32 SyncConnectorStatus;                   
} tUeiSync1PPSStatus;

/// \brief Structure used to read PTP status
///
/// This structure represents PTP status
typedef struct _UeiSync1PPSPTPStatus
{
   /// \brief PTP state
   tUeiPTPState State;
   /// \brief PTP clock ID of the grand master of the system.
   uInt64 GrandMasterClockID;
   /// \brief PTP clock ID of the current master.
   uInt64 MasterClockID;
   /// \brief The value of the PTP data set stepsRemoved.
   uInt32 StepsFromGrandMaster;
   /// \brief The PTP grand master clock class taken from the master's announce messages.
   uInt32 GrandMasterClockClass;
   /// \brief Current calculated mean path delay.
   Int32 MeanPathDelay;
   /// \brief Last calculated time offset from master
   Int32 LastMeasuredOffset;
   /// \brief Maximum calculated time offset from master.
   Int32 MaxMeasuredOffset;
   /// \brief Minimum calculated time offset from master.
   Int32 MinMeasuredOffset;
   /// \brief Average calculated time offset from master.
   Int32 AvgMeasuredOffset;
} tUeiSync1PPSPTPStatus;

/// \brief Outout channel short/open simulation 
/// 
/// This structure specifes which channel should be shorted or opened
typedef struct _UeiAOShortOpenCircuitParameters
{
   /// \brief open circuit bitmask
   unsigned int openBitmask;
   /// \brief short circuit bitmask
   unsigned int shortBitmask;
   /// \brief amount of time in us that the output(s) will stay shorted (0 to stay shorted)
   unsigned int shortDuration;
} tUeiAOShortOpenCircuitParameters;

/// \brief Parameters for a master command
///
/// Structure specifies parameters for a master command
typedef struct _tUeiI2CMasterCommand
{
   /// \brief Type of I2C command for master to transmit
   tUeiI2CCommand type;
   /// \brief Address of slave to send command to
   Int32 slaveAddress;
   /// \brief Data for write command
   uInt8 data[255];
   /// \brief Number of elements in data for write command
   Int32 numWriteElements;
   /// \brief Number of elements to request for read command
   Int32 numReadElements;
   /// \brief Send command as 7 or 10-bit address command. If slaveAddress is greater than 7-bit, 10-bit will be used by default
   tUeiI2CSlaveAddressWidth slaveAddressWidth;
} tUeiI2CMasterCommand;

/// \brief Data stored by and read from master
///
/// Structure specifies format for data read from master
typedef struct _tUeiI2CMasterMessage
{
   /// \brief Bit to determine if this message is the last from an I2C transaction.
   uInt8 stopBit;
   /// \brief 8-bit data
   uInt8 data;
} tUeiI2CMasterMessage;

/// \brief Data stored by and read from slave
///
/// Structure specifies format for data read from slave
typedef struct _tUeiI2CSlaveMessage
{
   /// \brief Context of the data or status code
   tUeiI2CBusCode busCode;
   /// \brief 8-bit data
   uInt8 data;
} tUeiI2CSlaveMessage;

/// \brief DMM extended data to include status information
///
/// This structure specifies format for DMM data including status information
typedef struct _tUeiDMMDataExt
{
   /// \brief Scaled DMM data
   double data;
   /// \brief If data is new
   int isNewData;
   /// \brief If value is overrange
   int isOverrange;
   /// \brief If DMM is in autoranging mode or has autoranged due to protection
   int isAutorange;
   /// \brief DMM index of range entered due to autorange. Mode specific bits. For the DMM-261, refer to DQ_DMM261_ channel list range defines in powerdna.h.
   uInt8 autorangeIdx;
   /// \brief Is protection is currently tripped
   int isProtectionTripped;
} tUeiDMMDataExt;

#ifdef __cplusplus
}
#endif

#endif // __UEISTRUCTS_H__
