#ifndef __UEI_MESSAGING_H__
#define __UEI_MESSAGING_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif


#include <memory>
#include "UeiConstants.h"
#include "UeiStructs.h"

namespace UeiDaq
{

// Private classes
class CUeiSerialReaderImpl;
class CUeiSerialWriterImpl;
class CUeiCANReaderImpl;
class CUeiCANWriterImpl;
class CUeiARINCRawReaderImpl;
class CUeiARINCRawWriterImpl;
class CUeiARINCReaderImpl;
class CUeiARINCWriterImpl;
class CUeiMIL1553ReaderImpl;
class CUeiMIL1553WriterImpl;
class CUeiIRIGReaderImpl;
class CUeiHDLCReaderImpl;
class CUeiHDLCWriterImpl;
class CUeiAOWaveformWriterImpl;
class CUeiCircuitBreakerImpl;
class CUeiVariableReluctanceReaderImpl;
class CUeiVariableReluctanceWriterImpl;
class CUeiCSDBReaderImpl;
class CUeiCSDBWriterImpl;
class CUeiSync1PPSControllerImpl;
class CUeiSSIReaderImpl;
class CUeiSSIWriterImpl;
class CUeiMuxWriterImpl;
class CUeiI2CWriterImpl;
class CUeiI2CReaderImpl;

// Forward declaration
class CUeiDataStream;
class CUeiException;
class IUeiEventListener;

/// \brief Serial Reader class
/// 
/// Class that handles reading data messages of 
/// a stream coming from a serial interface
class CUeiSerialReader
{
public:
   /// \brief Constructor
   /// \param pDataStream represents the source of data to read
   /// \param port The serial port to read data from
   UeiDaqAPI CUeiSerialReader(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSerialReader();

   /// \brief Read data from the serial port
   /// 
   /// Read a data message from the input stream
   /// \param bufferSize the size of the destination buffer
   /// \param pBuffer destination buffer
   /// \param numBytesRead the actual number of bytes read from the serial port
   UeiDaqAPI void Read(Int32 bufferSize, Int8* pBuffer, Int32* numBytesRead);

   /// \brief Read data from the serial port, returning the timestamp as the first sizeof(uInt32) bytes in the pBuffer
   ///
   /// Read a data message from the input stream placing the timestamp in the first sizeof(uInt32) bytes of pBuffer.
   /// An additional sizeof(uInt32) bytes should be added to bufferSize and the size of pBuffer to accomodate for
   /// the timestamp.
   /// \param bufferSize the size of the destination buffer
   /// \param pBuffer destination buffer
   /// \param numBytesRead the actual number of bytes read from the serial port
   UeiDaqAPI void ReadTimestamped(Int32 bufferSize, Int8* pBuffer, Int32* numBytesRead);

   /// \brief Read data from the serial port asynchronously
   /// 
   /// Read a data message from the input stream
   /// \param bufferSize the size of the destination buffer
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadAsync(Int32 bufferSize, Int8* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSerialReaderImpl> m_pImpl;
};

/// \brief Serial Writer class
/// 
/// Class that handles writing data messages to 
/// a stream going through a serial interface
class CUeiSerialWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   /// \param port the serial port to write data to
   UeiDaqAPI CUeiSerialWriter(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSerialWriter();

   /// \brief Write 8-bit data to the serial port
   /// 
   /// Write 8-bit data message to the serial port
   /// \param bufferSize the size of the source buffer
   /// \param pBuffer source buffer
   /// \param numBytesWritten the actual number of bytes written to the serial port
   UeiDaqAPI void Write(Int32 bufferSize, Int8* pBuffer, Int32* numBytesWritten);

   /// \brief Write 16-bit data to the serial port
   /// 
   /// Write 16-bit data message to the serial port, useful when setting parity bit on the fly
   /// \param bufferSize the size of the source buffer
   /// \param pBuffer source buffer
   /// \param numBytesWritten the actual number of bytes written to the serial port
   UeiDaqAPI void Write(Int32 bufferSize, Int16* pBuffer, Int32* numBytesWritten);

   /// \brief Write data to the serial port asynchronously
   /// 
   /// Write a data message to the serial port
   /// \param bufferSize the size of the source buffer
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteAsync(Int32 bufferSize, Int8* pBuffer);

   /// \brief Send serial break
   /// 
   /// Write a break to the serial port
   /// \param durationMs break duration in ms
   UeiDaqAPI void SendBreak(uInt32 durationMs);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSerialWriterImpl> m_pImpl;
};


/// \brief CAN bus Reader class
/// 
/// Class that handles reading data frames of 
/// a stream coming from a CAN bus interface
class CUeiCANReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   /// \param port the CAN port 
   UeiDaqAPI CUeiCANReader(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCANReader();

   /// \brief Read frame(s) from the CAN port
   /// 
   /// Read CAN frames from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numFramesRead the actual number of frames read from the CAN bus
   UeiDaqAPI void Read(Int32 numFrames, tUeiCANFrame* pBuffer, Int32* numFramesRead);

   /// \brief Read frame(s) from the CAN port
   /// 
   /// Read CAN frames from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param numFramesRead the actual number of frames read from the CAN bus
   //UeiDaqAPI std::vector<tUeiCANFrame> Read2(Int32 numFrames, Int32* numFramesRead);

   /// \brief Read frame(s) asynchronously from the CAN port
   /// 
   /// Read CAN frames from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadAsync(Int32 numFrames, tUeiCANFrame* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCANReaderImpl> m_pImpl;
};


/// \brief CAN bus Writer class
/// 
/// Class that handles writing data frames to 
/// a stream going through a CAN bus
class CUeiCANWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   /// \param port the CAN port to write to
   UeiDaqAPI CUeiCANWriter(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCANWriter();

   /// \brief Write frame(s) to the CAN bus
   /// 
   /// Send one or more frames over the CAN bus.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the CAN bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiCANFrame* pBuffer, Int32* numFramesWritten);

   /// \brief Write frame(s) to the CAN bus
   /// 
   /// Send one or more frames over the CAN bus.
   /// \param numFrames the number of frames to send
   /// \param numFramesWritten the actual number of frames sent over the CAN bus
   //UeiDaqAPI void Write2(std::vector<tUeiCANFrame> frames, Int32* numFramesWritten);

   /// \brief Write frame(s) asynchronously to the CAN bus
   /// 
   /// Send one or more frames over the CAN bus.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteAsync(Int32 numFrames, tUeiCANFrame* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCANWriterImpl> m_pImpl;
};


/// \brief ARINC-429 Reader class
/// 
/// Class that handles reading data words of 
/// a stream coming from an ARINC-429 interface.
/// It takes care of converting the raw 32bit ARINC words
/// to ARINC fields such as label, data, SDI and SSM 
class CUeiARINCReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   /// \param port the ARINC port 
   UeiDaqAPI CUeiARINCReader(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiARINCReader();

   /// \brief Read word(s) from the ARINC port
   /// 
   /// Read and parse ARINC words from the input stream
   /// \param numWords the number of words that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numWordsRead the actual number of frames read from the ARINC port
   UeiDaqAPI void Read(Int32 numWords, tUeiARINCWord* pBuffer, Int32* numWordsRead);

   /// \brief Read word(s) asynchronously from the ARINC port
   /// 
   /// Read and parse ARINC words from the input stream
   /// \param numWords the number of words that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadAsync(Int32 numWords, tUeiARINCWord* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiARINCReaderImpl> m_pImpl;
};


/// \brief ARINC-429 Writer class
/// 
/// Class that handles writing ARINC-429 words to 
/// a stream going through an ARINC-429 interface.
/// It takes care of converting ARINC fields such as label, 
/// data, SDI and SSM to 32-bit ARINC words.
class CUeiARINCWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   /// \param port the ARINC port to write to
   UeiDaqAPI CUeiARINCWriter(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiARINCWriter();

   /// \brief Write formatted word(s) to the ARINC bus
   /// 
   /// Format and send one or more word(s) to the ARINC interface.
   /// \param numWords the number of words to send
   /// \param pBuffer source buffer
   /// \param numWordsWritten the actual number of words sent over the ARINC bus
   UeiDaqAPI void Write(Int32 numWords, tUeiARINCWord* pBuffer, Int32* numWordsWritten);

   /// \brief Update word in ARINC scheduler table
   /// 
   /// Update word in ARINC scheduler table.
   /// \param firstWord Index of the first word to modify in the scheduler table
   /// \param numWords the number of words to update in the scheduler
   /// \param pBuffer source buffer
   /// \param numWordsWritten the actual number of words sent to the ARINC scheduler
   UeiDaqAPI void WriteScheduler(Int32 firstWord, Int32 numWords, tUeiARINCWord* pBuffer, Int32* numWordsWritten);

   /// \brief Enable scheduler
   ///
   /// Enable or disable scheduler
   /// \param enable true to enable, false to disable scheduler
   UeiDaqAPI void EnableScheduler(bool enable);

   /// \brief Set the writing page/transmit page for all channels at once
   ///
   /// Major/Minor scheduler features two copies of the scheduler entries. Page 0 and page 1.
   /// This call specifies which channel should be written to and which channel should be transmitting.
   /// This is designed to configure or update a page while the other is being transmitted.
   /// But it is still possible to both write and transmit a channel at the same time.
   /// \param immediate Specifies when the page configuration will be updated (true to update immediately, false to wait for the next major frame clock) 
   /// \param writeMask Bit mask specifying the writing page for each channel (bit set to 0 for page 0 or 1 for page 1)
   /// \param txMask Bit mask specifying the transmitting page for each channel (bit set to 0 for page 0 or 1 for page 1)
   UeiDaqAPI void SetTransmitPage(bool immediate, uInt32 writeMask, uInt32 txMask);

   /// \brief Write formatted word(s) asynchronously to the ARINC bus
   /// 
   /// Format and send one or more word(s) to the ARINC interface.
   /// \param numWords the number of words to send
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteAsync(Int32 numWords, tUeiARINCWord* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiARINCWriterImpl> m_pImpl;
};


/// \brief ARINC-429 Raw Reader class
/// 
/// This class handles reading raw data words of 
/// a stream coming from an ARINC-429 interface.
/// It returns raw 32-bit ARINC word(s).
class CUeiARINCRawReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   /// \param port the ARINC port 
   UeiDaqAPI CUeiARINCRawReader(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiARINCRawReader();

   /// \brief Read word(s) from the ARINC port
   /// 
   /// Read raw 32-bit ARINC words from the input stream
   /// \param numWords the number of words that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numWordsRead the actual number of frames read from the ARINC port
   UeiDaqAPI void Read(Int32 numWords, uInt32* pBuffer, Int32* numWordsRead);

   /// \brief Read word(s) asynchronously from the ARINC port
   /// 
   /// Read raw 32-bit ARINC words from the input stream
   /// \param numWords the number of words that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadAsync(Int32 numWords, uInt32* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiARINCRawReaderImpl> m_pImpl;
};


/// \brief ARINC-429 Writer class
/// 
/// Class that handles writing ARINC-429 words to 
/// a stream going through an ARINC-429 interface.
/// It expects raw 32-bit ARINC words.
class CUeiARINCRawWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   /// \param port the ARINC port to write to
   UeiDaqAPI CUeiARINCRawWriter(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiARINCRawWriter();

   /// \brief Write word(s) to the ARINC bus
   /// 
   /// Send one or more raw 32-bit word(s) to the ARINC interface.
   /// \param numWords the number of words to send
   /// \param pBuffer source buffer
   /// \param numWordsWritten the actual number of words sent over the ARINC bus
   UeiDaqAPI void Write(Int32 numWords, uInt32* pBuffer, Int32* numWordsWritten);

   /// \brief Update word in ARINC scheduler table
   /// 
   /// Update word in ARINC scheduler table.
   /// \param firstWord Index of the first word to modify in the scheduler table
   /// \param numWords the number of words to update in the scheduler
   /// \param pBuffer source buffer
   /// \param numWordsWritten the actual number of words sent to the ARINC scheduler
   UeiDaqAPI void WriteScheduler(Int32 firstWord, Int32 numWords, uInt32* pBuffer, Int32* numWordsWritten);

   /// \brief Write word(s) asynchronously to the ARINC bus
   /// 
   /// Send one or more raw 32-bit word(s) to the ARINC interface.
   /// \param numWords the number of words to send
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteAsync(Int32 numWords, uInt32* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiARINCRawWriterImpl> m_pImpl;
};


/// \brief MIL-1553B Reader class
/// 
/// Class that handles reading data frames of 
/// a stream coming from an MIL-1553B interface.
class CUeiMIL1553Reader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   /// \param port the MIL1553 port 
   UeiDaqAPI CUeiMIL1553Reader(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiMIL1553Reader();

   /// \brief Read tUeiMIL1553Frame(s) from the MIL1553 port
   /// 
   /// Read and parse MIL1553 tUeiMIL1553Frame(s) from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numFramesRead the actual number of frames read from the 1553 bus
   UeiDaqAPI void Read(Int32 numFrames, tUeiMIL1553Frame* pBuffer, Int32* numFramesRead);

   /// \brief Read tUeiMIL1553BMFrame(s) from the MIL1553 port
   /// 
   /// Read and parse MIL1553 tUeiMIL1553BMFrame(s) from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numFramesRead the actual number of frames read from the 1553 bus
   UeiDaqAPI void Read(Int32 numFrames, tUeiMIL1553BMFrame* pBuffer, Int32* numFramesRead);

   /// \brief Read tUeiMIL1553BMCmdFrame(s) from the MIL1553 port
   /// 
   /// Read and parse MIL1553 tUeiMIL1553BMCmdFrame(s) from the input stream.
   /// The difference between tUeiMIL1553BMFrame and tUeiMIL1553BMCmdFrame is that the later takes care of
   /// following 1553 messaging protocol and stuffing Command[Command2][data][status][status2] into a single
   /// frame and also provides tools to convert data from the frame into string representation
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numFramesRead the actual number of frames read from the 1553 bus
   UeiDaqAPI void Read(Int32 numFrames, tUeiMIL1553BMCmdFrame* pBuffer, Int32* numFramesRead);

   /// \brief Read tUeiMIL1553RTFrame(s) from the MIL1553 port
   /// 
   /// Read and parse MIL1553 tUeiMIL1553RTFrame(s) from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numFramesRead the actual number of frames read from the 1553 bus
   UeiDaqAPI void Read(Int32 numFrames, tUeiMIL1553RTFrame* pBuffer, Int32* numFramesRead);

   /// \brief Read tUeiMIL1553RTStatusFrame(s) from the MIL1553 port
   /// 
   /// Read and parse MIL1553 tUeiMIL1553RTStatusFrame(s) from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numFramesRead the actual number of frames read from the 1553 bus
   UeiDaqAPI void Read(Int32 numFrames, tUeiMIL1553RTStatusFrame* pBuffer, Int32* numFramesRead);

   /// \brief Read tUeiMIL1553BCCBStatusFrame(s) from the MIL1553 port
   /// 
   /// Read and parse MIL1553 tUeiMIL1553BCCBStatusFrame(s) from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numFramesRead the actual number of frames read from the 1553 bus
   UeiDaqAPI void Read(Int32 numFrames, tUeiMIL1553BCCBStatusFrame* pBuffer, Int32* numFramesRead);

   /// \brief Read tUeiMIL1553BCSchedFrame(s) from the MIL1553 port
   /// 
   /// Read and parse MIL1553 tUeiMIL1553BCSchedFrame(s) from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numFramesRead the actual number of frames read from the 1553 bus
   UeiDaqAPI void Read(Int32 numFrames, tUeiMIL1553BCSchedFrame* pBuffer, Int32* numFramesRead);

   /// \brief Read tUeiMIL1553BCStatusFrame(s) from the MIL1553 port
   /// 
   /// Read and parse MIL1553 tUeiMIL1553BCStatusFrame(s) from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numFramesRead the actual number of frames read from the 1553 bus
   UeiDaqAPI void Read(Int32 numFrames, tUeiMIL1553BCStatusFrame* pBuffer, Int32* numFramesRead);

   /// \brief Read tUeiMIL1553A708DataFrame(s) from the ARINC-708 port
   /// 
   /// Read and parse ARINC-708 tUeiMIL1553A708DataFrame(s) from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numFramesRead the actual number of frames read from the ARINC-708 bus
   UeiDaqAPI void Read(Int32 numFrames, tUeiMIL1553A708DataFrame* pBuffer, Int32* numFramesRead);

   /// \brief Read frame(s) asynchronously from the MIL1553 port
   /// 
   /// Read and parse MIL1553 frames from the input stream
   /// \param numFrames the number of frames that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadAsync(Int32 numFrames, tUeiMIL1553Frame* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiMIL1553ReaderImpl> m_pImpl;
};


/// \brief MIL-1553B Writer class
/// 
/// Class that handles writing MIL-1553B frames to 
/// a stream going through an MIL-1553B interface.
class CUeiMIL1553Writer
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   /// \param port the MIL1553 port to write to
   UeiDaqAPI CUeiMIL1553Writer(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiMIL1553Writer();

   /// \brief Write formatted tUeiMIL1553Frame(s) to the MIL1553 bus
   /// 
   /// Format and send one or more tUeiMIL1553Frame(s) to the MIL1553 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the MIL1553 bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiMIL1553Frame* pBuffer, Int32* numFramesWritten);

   /// \brief Write formatted tUeiMIL1553RTFrame(s) to the MIL1553 bus
   /// 
   /// Format and send one or more tUeiMIL1553RTFrame(s) to the MIL1553 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the MIL1553 bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiMIL1553RTFrame* pBuffer, Int32* numFramesWritten);

   /// \brief Write formatted tUeiMIL1553RTControlFrame(s) to the MIL1553 bus
   /// 
   /// Format and send one or more tUeiMIL1553RTControlFrame(s) to the MIL1553 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the MIL1553 bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiMIL1553RTControlFrame* pBuffer, Int32* numFramesWritten);

   /// \brief Write formatted tUeiMIL1553RTParametersFrame(s) to the MIL1553 bus
   /// 
   /// Format and send one or more tUeiMIL1553RTParametersFrame(s) to the MIL1553 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the MIL1553 bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiMIL1553RTParametersFrame* pBuffer, Int32* numFramesWritten);

   /// \brief Write formatted tUeiMIL1553BusWriterFrame(s) to the MIL1553 bus
   /// 
   /// Format and send one or more tUeiMIL1553BusWriterFrame(s) to the MIL1553 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the MIL1553 bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiMIL1553BusWriterFrame* pBuffer, Int32* numFramesWritten);

   /// \brief Write formatted tUeiMIL1553BCCBDataFrame(s) to the MIL1553 bus
   /// 
   /// Format and send one or more tUeiMIL1553BCCBDataFrame(s) to the MIL1553 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the MIL1553 bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiMIL1553BCCBDataFrame* pBuffer, Int32* numFramesWritten);

   /// \brief Write formatted tUeiMIL1553BCSchedFrame(s) to the MIL1553 bus
   /// 
   /// Format and send one or more tUeiMIL1553BCSchedFrame(s) to the MIL1553 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the MIL1553 bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiMIL1553BCSchedFrame* pBuffer, Int32* numFramesWritten);

   /// \brief Write formatted tUeiMIL1553BCControlFrame(s) to the MIL1553 bus
   /// 
   /// Format and send one or more tUeiMIL1553BCControlFrame(s) to the MIL1553 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the MIL1553 bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiMIL1553BCControlFrame* pBuffer, Int32* numFramesWritten);

   /// \brief Write formatted tUeiMIL1553A708ControlFrame(s) to the ARINC-708 bus
   /// 
   /// Format and send one or more tUeiMIL1553A708ControlFrame(s) to the ARINC-708 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the ARINC-708 bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiMIL1553A708ControlFrame* pBuffer, Int32* numFramesWritten);

   /// \brief Write formatted tUeiMIL1553A708DataFrame(s) to the ARINC-708 bus
   /// 
   /// Format and send one or more tUeiMIL1553A708DataFrame(s) to the ARINC-708 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   /// \param numFramesWritten the actual number of frames sent over the ARINC-708 bus
   UeiDaqAPI void Write(Int32 numFrames, tUeiMIL1553A708DataFrame* pBuffer, Int32* numFramesWritten);

   /// \brief Write formatted frames(s) asynchronously to the MIL1553 bus
   /// 
   /// Format and send one or more frames(s) to the MIL1553 interface.
   /// \param numFrames the number of frames to send
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteAsync(Int32 numFrames, tUeiMIL1553Frame* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiMIL1553WriterImpl> m_pImpl;
};


/// \brief IRIG Reader class
/// 
/// This class handles reading time out of 
/// a stream coming from an IRIG interface.
/// It returns time as BCD, SBS or C-ANSI.
class CUeiIRIGReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   /// \param port the ARINC port 
   UeiDaqAPI CUeiIRIGReader(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiIRIGReader();

   /// \brief Read time from the IRIG port in BCD format
   /// 
   /// Read time from the IRIG port in Binary Coded Decimal format
   /// \param pBuffer destination buffer
   /// \param status Time keeper status
   UeiDaqAPI void Read(tUeiBCDTime* pBuffer, Int32* status=NULL);

   /// \brief Read time from the IRIG port in SBS format
   /// 
   /// Read time from the IRIG port in Straight Binary Seconds format
   /// \param pBuffer destination buffer
   /// \param status Time keeper status
   UeiDaqAPI void Read(tUeiSBSTime* pBuffer, Int32* status=NULL);
   
   /// \brief Read time from the IRIG port in C-ANSI format
   /// 
   /// Read time from the IRIG port in C ANSI format
   /// \param pBuffer destination buffer
   /// \param status Time keeper status
   UeiDaqAPI void Read(tUeiANSITime* pBuffer, Int32* status=NULL);

   /// \brief Read time from the IRIG port as the number of seconds since
   /// 
   /// Read time from the IRIG port in seconds since UNIX EPOCH 00:00:00 UTC 01/01/1970
   /// \param pBuffer destination buffer
   /// \param status Time keeper status
   UeiDaqAPI void Read(double* pBuffer, Int32* status=NULL);

   /// \brief Read NMEA strings from the GPS receiver associated with the IRIG port
   /// 
   /// Read NMEA string from the GPS receiver associated with the IRIG port
   /// \param numBytes maximum number of bytes to read
   /// \param pBuffer destination buffer
   /// \param numBytesRead Number of bytes read from GPS receiver
   UeiDaqAPI void Read(Int32 numBytes, char* pBuffer, Int32* numBytesRead=NULL);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiIRIGReaderImpl> m_pImpl;
};


/// \brief HDLC Reader class
/// 
/// Class that handles reading data messages of 
/// a stream coming from a HDLC interface
class CUeiHDLCReader
{
public:
   /// \brief Constructor
   /// \param pDataStream represents the source of data to read
   /// \param port The HDLC port to read data from
   UeiDaqAPI CUeiHDLCReader(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiHDLCReader();

   /// \brief Read data from the HDLC port
   /// 
   /// Read a data message from the input stream
   /// \param bufferSize the size of the destination buffer
   /// \param pBuffer destination buffer
   /// \param numBytesRead the actual number of bytes read from the HDLC port
   UeiDaqAPI void Read(Int32 bufferSize, Int8* pBuffer, Int32* numBytesRead);

   /// \brief Read data from the HDLC port asynchronously
   /// 
   /// Read a data message from the input stream
   /// \param bufferSize the size of the destination buffer
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadAsync(Int32 bufferSize, Int8* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiHDLCReaderImpl> m_pImpl;
};

/// \brief HDLC Writer class
/// 
/// Class that handles writing data messages to 
/// a stream going through a HDLC interface
class CUeiHDLCWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   /// \param port the HDLC port to write data to
   UeiDaqAPI CUeiHDLCWriter(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiHDLCWriter();

   /// \brief Write data to the HDLC port
   /// 
   /// Write a data message to the HDLC poirt
   /// \param bufferSize the size of the source buffer
   /// \param pBuffer source buffer
   /// \param numBytesWritten the actual number of bytes written to the HDLC port
   UeiDaqAPI void Write(Int32 bufferSize, Int8* pBuffer, Int32* numBytesWritten);

   /// \brief Write data to the HDLC port asynchronously
   /// 
   /// Write a data message to the HDLC port
   /// \param bufferSize the size of the source buffer
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteAsync(Int32 bufferSize, Int8* pBuffer);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiHDLCWriterImpl> m_pImpl;
};


/// \brief AO Waveform Writer class
/// 
/// Class that handles writing waveform commands to 
/// a stream going through a AO waveform device
class CUeiAOWaveformWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   /// \param channel the AO waveform channel to send command to
   UeiDaqAPI CUeiAOWaveformWriter(CUeiDataStream* pDataStream, Int32 channel = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAOWaveformWriter();

   /// \brief Write waveform to the AO device
   /// 
   /// Format and send one or more tUeiAOWaveformParameters(s) to the AO device.
   /// \param numWfms the number of waveforms to send
   /// \param pBuffer source buffer
   /// \param numWfmsWritten the actual number of waveforms sent 
   UeiDaqAPI void WriteWaveform(Int32 numWfms, tUeiAOWaveformParameters* pBuffer, Int32* numWfmsWritten);

   /// \brief Write sweep command to the AO device
   /// 
   /// Format and send one or more tUeiAOWaveformSweepParameters(s) to the AO device.
   /// \param numSwps the number of sweep commands to send
   /// \param pBuffer source buffer
   /// \param numSwpsWritten the actual number of sweep commands sent 
   UeiDaqAPI void WriteSweep(Int32 numSwps, tUeiAOWaveformSweepParameters* pBuffer, Int32* numSwpsWritten);
   
   /// \brief Write arbitrary waveform data to the AO device
   /// 
   /// Send arbitrary data to the AO device.
   /// \param numValues the number of values to send
   /// \param pBuffer source buffer
   /// \param numValsWritten the actual number of values sent 
   UeiDaqAPI void WriteArbitraryData(Int32 numValues, double* pBuffer, Int32* numValsWritten);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAOWaveformWriterImpl> m_pImpl;
};


/// \brief Circuit Breaker class
/// 
/// Class that handles CB commands to 
/// a stream associated with a protected device
class CUeiCircuitBreaker
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to access data
   /// \param port the port on which circuit breakers are manipulated
   UeiDaqAPI CUeiCircuitBreaker(CUeiDataStream* pDataStream, Int32 port = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCircuitBreaker();

   /// \brief Resets circuit breaker
   /// 
   /// Reset a circuit breaker, in case it was tripped.
   ///
   /// \param mask the mask specifying which circuit breaker to reset (1 to reset, 0 to leave alone) 
   UeiDaqAPI void Reset(uInt32 mask);

   /// \brief Enable/disable short or open state on output devices that support it
   /// 
   /// Enable/disable open or short state.
   ///
   /// \param params the open/short simulation parameters 
   UeiDaqAPI void WriteOpenShortSimulation(tUeiAOShortOpenCircuitParameters params);

   /// \brief Get current circuit breaker status
   /// 
   /// Get circuit breaker status masks. 
   /// Each bit in the current status mask correspond to a circuit breaker. 1 if CB is currently tripped, 0 otherwise
   /// Each bit in the sticky status mask correspond to a circuit breaker. 1 if CB was tripped at least once since last time status was read, 0 otherwise
   ///
   /// \param current the current circuit breaker status bits (1 if tripped, 0 otherwise) 
   /// \param sticky the sticky circuit breaker status bits (1 if tripped, 0 otherwise) 
   UeiDaqAPI void ReadStatus(uInt32* current, uInt32* sticky);

   /// \brief Read detailed status about each circuit breaker
   ///
   /// Read detailed status about each cicuit breaker. The meaning of each status bits
   /// depends on the type of the I/O device. Refer to the device's user manual for 
   /// detailed description of each status bit
   ///
   /// \param numStatus the number of status to read 
   /// \param pBuffer destination buffer for the channel(s) status
   /// \param numStatusRead the actual number of status retrieved 
   UeiDaqAPI void ReadAllStatus(Int32 numStatus, uInt32* pBuffer, Int32* numStatusRead);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCircuitBreakerImpl> m_pImpl;
};

/// \brief Variable Reluctance reader class
/// 
/// Class that handles reading variable reluctance measurements from 
/// a stream associated with a VR input channel
class CUeiVRReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source where to read data
   /// \param channel the VR channel to read from
   UeiDaqAPI CUeiVRReader(CUeiDataStream* pDataStream, Int32 channel = 0);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiVRReader();

   /// \brief Read data from VR device
   /// 
   /// Read position, velocity, number of counted teeth and timestamp.
   /// \param numVals the number of values to read
   /// \param pBuffer destination buffer
   /// \param numValsRead the actual number of values read 
   UeiDaqAPI void Read(Int32 numVals, tUeiVRData* pBuffer, Int32* numValsRead);

   /// \brief Read variable reluctance FIFO data
   ///
   /// Variable reluctance FIFO data can be used to calculate a map of the inter-tooth delays 
   /// around the encoder wheel. this is useful to calculate acceleration.
   ///
   /// \param numValues number of values to read
   /// \param pBuffer destination buffer
   /// \param numValuesRead Number of values actually read
   UeiDaqAPI void Read(Int32 numValues, uInt32 *pBuffer, Int32* numValuesRead);

   /// \brief Read ADC data 
   /// 
   /// Read ADC FIFO data, this is used as a diagnostic to visualize the shape of the signal
   /// as it is acquired on the VR input device.
   /// There is one FIFO for each pair of channel. this function reads the ADC data
   /// for both even and odd channels
   /// \param numVals the number of values to read
   /// \param pBuffer destination buffer for even and odd channel ADC data
   /// \param numValsRead the actual number of values read 
   UeiDaqAPI void Read(Int32 numVals, double* pBuffer, Int32* numValsRead);

   /// \brief Read ADC status 
   /// 
   /// Read ADC status, this is used as a diagnostic to troubleshoot VR inputs
   /// \param pStatus destination buffer for even and odd channel ADC data
   UeiDaqAPI void ReadADCStatus(uInt32* pStatus);

   /// \brief Read variable reluctance torque
   ///
   /// Read variable reluctance torque. 
   /// Torque measurement requires two VR sensors wired to a channel pair (0/1, 2/3, 4/5, or 6/7). 
   /// Odd channel must be configured in torque mode and even channel must be configured in N pulse mode.
   /// Torque measurement is returned as the duty cycle on the Torque mode channel (ratio of pulse width to period).
   /// 
   /// \param numVals number of values to read
   /// \param pBuffer destination buffer
   /// \param numValsRead Number of values actually read
   UeiDaqAPI void ReadTorque(Int32 numVals, double* pBuffer, Int32* numValsRead);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiVariableReluctanceReaderImpl> m_pImpl;
};

/// \brief Variable Reluctance writer class
/// 
/// Class that handles writing simualted variable reluctance to 
/// a stream associated with a VR output channel
class CUeiVRWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source where to read data
   /// \param channel the VR channel to read from
   UeiDaqAPI CUeiVRWriter(CUeiDataStream* pDataStream, Int32 channel = 0);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiVRWriter();

   /// \brief Read data from VR device
   /// 
   /// Read position, velocity, number of counted teeth and timestamp.
   /// \param numVals the number of values to write
   /// \param pBuffer source buffer
   /// \param numValsWritten the actual number of values written 
   UeiDaqAPI void Write(Int32 numVals, tUeiSimulatedVRData* pBuffer, Int32* numValsWritten);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiVariableReluctanceWriterImpl> m_pImpl;
};


/// \brief CSDB reader class
/// 
/// Class that handles reading CSDB frames from 
/// a stream associated with a CSDB input device
class CUeiCSDBReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source where to read data
   /// \param channel the CSDB channel to read from
   UeiDaqAPI CUeiCSDBReader(CUeiDataStream* pDataStream, Int32 channel = 0);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCSDBReader();

   /// \brief Read entire frame
   /// 
   /// Read latest frame.
   /// \param numVals the number of messages to read
   /// \param pBuffer destination buffer
   /// \param numValsRead the actual number of messages read 
   UeiDaqAPI void ReadFrame(Int32 numVals, tUeiCSDBMessage* pBuffer, Int32* numValsRead);

   /// \brief Read message block by index
   /// 
   /// Read latest received message block selected by index.
   /// \param index the index of the message to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMessageByIndex(Int32 index, tUeiCSDBMessage* pBuffer);

   /// \brief Read message block by address
   /// 
   /// Read latest received message selected block by address.
   /// \param address the address of of the message to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMessageByAddress(uInt8 address, tUeiCSDBMessage* pBuffer);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCSDBReaderImpl> m_pImpl;
};


/// \brief CSDB writer class
/// 
/// Class that handles writing CSDB frames to 
/// a stream associated with a CSDB output device
class CUeiCSDBWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source where to read data
   /// \param channel the CSDB channel to write to
   UeiDaqAPI CUeiCSDBWriter(CUeiDataStream* pDataStream, Int32 channel = 0);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCSDBWriter();

   /// \brief Write entire frame
   /// 
   /// Write all message blocks of a frame.
   /// \param numVals the number of messages to write
   /// \param pBuffer source buffer
   /// \param numValsWritten the actual number of messages written 
   UeiDaqAPI void WriteFrame(Int32 numVals, tUeiCSDBMessage* pBuffer, Int32* numValsWritten);

   /// \brief Write message block by index
   /// 
   /// Update a message block selected by index.
   /// \param index the index of the message to write or update
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMessageByIndex(Int32 index, tUeiCSDBMessage* pBuffer);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCSDBWriterImpl> m_pImpl;
};

/// \brief 1PPS synchronization controller class
/// 
/// Class that handles reading 1PPS status and sending trigger messages via 
/// a stream associated with a sync capable CPU device
class CUeiSync1PPSController
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source where to read data
   /// \param channel Unused
   UeiDaqAPI CUeiSync1PPSController(CUeiDataStream* pDataStream, Int32 channel = 0);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSync1PPSController();

   /// \brief Read latest status
   /// 
   /// Read latest status.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadStatus(tUeiSync1PPSStatus* pBuffer);

   /// \brief Read event module status
   ///
   /// Event module status is true when the event module output clock
   /// is stable enough
   /// \param isLocked true if the event module output is stable, false otherwise
   UeiDaqAPI void ReadLockedStatus(bool* isLocked);

   /// \brief Read PTP status
   ///
   /// Read latest PTP status
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadPTPStatus(tUeiSync1PPSPTPStatus* pBuffer);

   /// \brief Read PTP UTC time
   ///
   /// Read current UTC time from PTP clock
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadPTPUTCTime(tUeiPTPTime* pBuffer);

   /// \brief Trigger slave devices
   ///
   /// Trigger devices configured to use clock signal generated by the
   /// 1PPs circuitry
   /// \param trigOp specify the method used to send the trigger signal to all slave devices
   /// \param resetTimestamp True if all slave devices should reset their timestamp counter upon receiving the trigger signal
   UeiDaqAPI void TriggerDevices(tUeiSync1PPSTriggerOperation trigOp, bool resetTimestamp);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSync1PPSControllerImpl> m_pImpl;
};

/// \brief SSI Reader class
/// 
/// This class handles reading data words of 
/// a stream coming from an SSI master interface.
/// It returns 32-bit data word(s).
class CUeiSSIReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   /// \param port the SSI master port 
   UeiDaqAPI CUeiSSIReader(CUeiDataStream* pDataStream, Int32 port = 0);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSSIReader();

   /// \brief Read word(s) from the SSI master port
   /// 
   /// Read 32-bit data words from the input stream
   /// \param grayDecoding true to convert gray encoded values to binary
   /// \param numWords the number of words that can be stored in the destination buffer
   /// \param pBuffer destination buffer
   /// \param numWordsRead the actual number of frames read from the SSI port
   UeiDaqAPI void Read(bool grayDecoding, Int32 numWords, uInt32* pBuffer, Int32* numWordsRead);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSSIReaderImpl> m_pImpl;
};

/// \brief SSI Writer class
/// 
/// This class handles writing data words of 
/// a stream associated with an SSI slave interface.
/// It write 32-bit data word(s).
class CUeiSSIWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where data is written to
   /// \param port the SSI slave port 
   UeiDaqAPI CUeiSSIWriter(CUeiDataStream* pDataStream, Int32 port = 0);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSSIWriter();

   /// \brief Write word(s) to the SSI slave port
   /// 
   /// Write 32-bit data words to the output stream
   /// \param grayEncoding true to convert binary values to gray
   /// \param numWords the number of words to write
   /// \param pBuffer source buffer
   /// \param numWordsWritten the actual number of frames sent to the SSI port
   UeiDaqAPI void Write(bool grayEncoding, Int32 numWords, uInt32* pBuffer, Int32* numWordsWritten);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSSIWriterImpl> m_pImpl;
};

/// \brief Mux Writer class
/// 
/// Class that handles writing data to 
/// a stream going to a counter output
class CUeiMuxWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   UeiDaqAPI CUeiMuxWriter(CUeiDataStream* pDataStream);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiMuxWriter();

   /// \brief Set relays individually
   ///
   /// Set relays individually (use with care to avoid short circuits and damaging your equipment)
   /// One bit per relay [channel 0 relay A, channel 0 relay B, channel 0 relay C, channel 1 relay A, channel 1 relay B, etc...]
   /// \param numValues Number of values to write
   /// \param relayBuffer Data buffer to write
   UeiDaqAPI void WriteRelays(int numValues, uInt32* relayBuffer);

   /// \brief Set mux
   ///
   /// Set mux on a set of channels
   /// \param numChannels The number of channels to set mux on
   /// \param channels The list of channels to set mux on
   /// \param relayIndices The index of the relay to close for each channel in the channel list (0 for relay A, 1 for relay B etc...)
   UeiDaqAPI void WriteMux(int numChannels, int* channels, int* relayIndices);

   /// \brief Set low-level format mux values
   ///
   /// Set mux on each channel using the same representation than the low-level API
   /// Two bits per channels: 00 relays off, 01 relay A ON, 10 relay B on, 11 relay C on
   /// [ channel 0 mux, channel 1 mux, channel 2 mux, etc...]
   /// \param numValues Number of values to write
   /// \param muxBuffer Data buffer to write
   UeiDaqAPI void WriteMuxRaw(int numValues, uInt32* muxBuffer);

   /// \brief Set single channel on MUX for use with DMM
   ///
   /// Set mux on a single channel and select output to DMM
   /// \param channelNum Channel to set
   /// \param relaySelect Relay to enable
   /// \param dmmMode Select output to DMM
   UeiDaqAPI void WriteMuxDmm(Int32 channelNum, tUeiMuxRelaySelect relaySelect, tUeiMuxDmmMode dmmMode);

   /// \brief Get Mux status
   /// 
   /// Get status of each relay on the MUX device
   UeiDaqAPI void ReadStatus(uInt32* relayA, uInt32* relayB, uInt32* relayC, uInt32* status);

   /// \brief Read ADC
   ///
   /// Read diagnostic ADC values
   UeiDaqAPI void ReadADC(Int32 numVals, double* pBuffer, Int32* numValsRead);

   /// \brief Read current count of times each relay has been energized
   ///
   /// Read current count of times each relay has been energized
   /// \param countsBufferSize Number of relay counts to read and store in countsBuffer
   /// \param pCountsBuffer Data buffer to store relay counts
   /// \param numCountsRead Number of relay counts read and stored in countsBuffer
   UeiDaqAPI void ReadRelayCounts(Int32 countsBufferSize, Int32* pCountsBuffer, Int32* numCountsRead);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiMuxWriterImpl> m_pImpl;
};

class CUeiI2CWriter
{
public:
   /// \brief Constructor
   ///
   /// \param pDataStream represents the destination where to write data
   /// \param channel Channel to write to
   UeiDaqAPI CUeiI2CWriter(CUeiDataStream* pDataStrem, Int32 channel);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiI2CWriter();

   /// \brief Writes data to slave
   ///
   /// Writes data to slave FIFO that is transmitted when a
   /// master requests data using a read command.
   /// \param numElements Number of data elements in the buffer
   /// \param pBuffer Data buffer
   /// \param numElementsWritten Number of elements actually written to the slave
   UeiDaqAPI void WriteSlaveData(Int32 numElements, uInt16* pBuffer, Int32* numElementsWritten);

   /// \brief Writes data to slave asynchronously
   ///
   /// Writes data to slave FIFO that is transmitted when a
   /// master requests data using a read command.
   /// \param numElements Number of data elements in the buffer
   /// \param pBuffer Data buffer
   UeiDaqAPI void WriteSlaveDataAsync(Int32 numElements, uInt16* pBuffer);

   /// \brief Write command for master to transmit
   ///
   /// \param command Command for master to transmit
   UeiDaqAPI void WriteMasterCommand(tUeiI2CMasterCommand* command);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiI2CWriterImpl> m_pImpl;
};

class CUeiI2CReader
{
public:
   /// \brief Constructor
   ///
   /// \param pDataStream represents the destination where to write data
   /// \param channel Channel to read from
   UeiDaqAPI CUeiI2CReader(CUeiDataStream* pDataStream, Int32 channel);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiI2CReader();

   /// \brief Read messages received by slave
   ///
   /// Read messages received by slave.
   /// \param numMessages The number of messages to read
   /// \param pBuffer Destination buffer
   /// \param numMessagesRead The number of received messages
   UeiDaqAPI void ReadSlave(Int32 numMessages, tUeiI2CSlaveMessage* pBuffer, Int32* numMessagesRead);

   /// \brief Read messages received by slave asynchronously
   ///
   /// Read messages received by slave.
   /// \param numMessages The number of messages to read
   /// \param pBuffer Destination buffer
   UeiDaqAPI void ReadSlaveAsync(Int32 numMessages, tUeiI2CSlaveMessage* pBuffer);

   /// \brief Read messages received by master
   ///
   /// Read messages received by master.
   /// \param numMessages The number of messages to read
   /// \param pBuffer Destination buffer
   /// \param numMessagesRead The number of received messages
   UeiDaqAPI void ReadMaster(Int32 numMessages, tUeiI2CMasterMessage* pBuffer, Int32* numMessagesRead);

   /// \brief Read the number of available input messages from the slave
   ///
   /// Read the number of available input messages from the slave
   /// \param numAvailableMessages The number of available input messages
   UeiDaqAPI void ReadNumberOfInputSlaveMessages(Int32* numAvailableMessages);

   /// \brief Read the number of available input messages from the master
   ///
   /// Read the number of available input messages from the master
   /// \param numAvailableMessages The number of available input messages
   UeiDaqAPI void ReadNumberOfInputMasterMessages(Int32* numAvailableMessages);

   /// \brief Read the number of available output messages from the slave
   ///
   /// Read the number of available output messages from the slave
   /// \param numAvailableMessages The number of available output messages
   UeiDaqAPI void ReadNumberOfOutputSlaveMessages(Int32* numAvailableMessages);

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiI2CReaderImpl> m_pImpl;
};

}

#endif // __UEI_MESSAGING_H__