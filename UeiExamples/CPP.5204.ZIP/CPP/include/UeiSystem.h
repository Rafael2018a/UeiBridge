#ifndef __UEISYSTEM_H__
#define __UEISYSTEM_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

namespace UeiDaq
{

/// \brief This class contains static functions to retrieve informations
/// about your system
class CUeiSystem
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiSystem(void);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSystem(void);

   /// \brief Get the framework major version number
   ///
   /// Get the first part of the four parts version number.
   /// major.minor.extra.build
   ///
   /// \return The major version number.
   UeiDaqAPI static uInt32 GetFrameworkMajorVersion();

   /// \brief Get the framework minor version number
   ///
   /// Get the second part of the four parts version number.
   /// major.minor.extra.build
   ///
   /// \return The minor version number.
   UeiDaqAPI static uInt32 GetFrameworkMinorVersion();

   /// \brief Get the framework extra version number
   ///
   /// Get the third part of the four parts version number.
   /// major.minor.extra.build
   ///
   /// \return The extra version number.
   UeiDaqAPI static uInt32 GetFrameworkExtraVersion();

   /// \brief Get the framework build version number
   ///
   /// Get the fourth part of the four parts version number.
   /// major.minor.extra.build
   ///
   /// \return The build version number.
   UeiDaqAPI static uInt32 GetFrameworkBuildVersion();

   /// \brief Get the framework version string
   ///
   /// Get the the four parts version string.
   /// "major.minor.extra.build"
   ///
   /// \return The version string.
   UeiDaqAPI static std::string GetFrameworkVersion();

   /// \brief Get a driver plugin major version number
   ///
   /// Get the first part of the four parts version number of the specified
   /// driver plugin.
   /// major.minor.extra.build
   ///
   /// \param driverName The name of the driver plugin
   /// \return The major version number.
   UeiDaqAPI static uInt32 GetPluginLowLevelDriverMajorVersion(std::string driverName);

   /// \brief Get a driver plugin minor version number
   ///
   /// Get the second part of the four parts version number of the specified
   /// driver plugin.
   /// major.minor.extra.build
   ///
   /// \param driverName The name of the driver plugin
   /// \return The minor version number.
   UeiDaqAPI static uInt32 GetPluginLowLevelDriverMinorVersion(std::string driverName);

   /// \brief Get a driver plugin version string
   ///
   /// Get the the four parts version string of the specified
   /// driver plugin.
   /// "major.minor.extra.build"
   ///
   /// \param driverName The name of the driver plugin
   /// \return The major version string.
   UeiDaqAPI static std::string GetPluginLowLevelDriverVersion(std::string driverName);

   /// \brief Get the framework installation directory
   ///
   /// Get the framework installation directory
   ///
   /// \return The framework installation directory.
   UeiDaqAPI static std::string GetFrameworkInstallationDirectory();

   /// \brief Get the framework plugins directory
   ///
   /// Get the framework plugins directory
   ///
   /// \return The framework plugins directory.
   UeiDaqAPI static std::string GetPluginsInstallationDirectory();

   /// \brief Get a session group directory
   ///
   /// Get a session group directory
   ///
   /// \param sessionGroup the name of the session group
   /// \return The session group directory.
   UeiDaqAPI static std::string GetSessionGroupDirectory(std::string sessionGroup);

   /// \brief Get the operating system type
   ///
   /// Get the type of the operating system installed on this computer
   ///
   /// \return The operating system type.
   UeiDaqAPI static tUeiOSType GetOperatingSystemType();

   /// \brief Reload driver plugins
   ///
   /// Un-load/re-load driver plugins
   UeiDaqAPI static void ReloadDrivers();
};

}

#endif