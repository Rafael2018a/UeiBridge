#ifndef __UEIDEVICE_H__
#define __UEIDEVICE_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif


#include "UeiObject.h"
#include "UeiStructs.h"
#include <vector>

namespace UeiDaq
{

typedef struct _tRange
{
   double min;
   double max;
   std::string unit;
#ifdef __cplusplus
   bool operator==(const _tRange& r) const { return min==r.min && max==r.max; }
#endif
} tRange;
typedef std::vector<tRange> tRanges;
typedef std::vector<double> tGains;

// private classes
class CUeiDeviceImpl;

// Forward declaration
class CUeiException;

/// A device object

///
/// Store informations about a device
class CUeiDevice : public CUeiObject
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiDevice();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDevice();

   /// \brief Get the device name   
   ///
   /// Get the name from the device database  
   ///
   /// \return a string that contains the name of the device.  
   UeiDaqAPI std::string GetDeviceName();
   
   /// \brief Get the serial number  
   ///
   /// Get the serial number from the device EEPROM  
   ///
   /// \return a string that contains the serial number.
   UeiDaqAPI std::string GetSerialNumber();

   /// \brief Get the resource descriptor
   /// 
   /// get the device resource descriptor
   ///
   /// \return a string that contains the resource descriptor
   UeiDaqAPI std::string GetResourceName();
   
   /// \brief Get the index  
   ///
   /// Get the index of this device in the device class  
   ///
   /// \return the index.
   UeiDaqAPI Int32 GetIndex();

   /// \brief Get the number of subsystems of the specified type
   ///
   /// Get the number of subsystems available on the device 
   ///
   /// \return the number of subsystems.
   UeiDaqAPI Int32 GetNumberOfSubsystems(tUeiSessionType type);

   /// \brief Get the number of channel of the specified subsystem
   ///
   /// Get the number of channels available on the device 
   ///
   /// \return the number of channels.
   UeiDaqAPI Int32 GetNumberOfChannels(tUeiSessionType type, int subSytemIndex, int channelGroupIndex=0);

   /// \brief Get the maximum rate of the specified subsystem
   ///
   /// Get the maximum rate of the specified subsystem on the device 
   ///
   /// \return the maximum rate
   UeiDaqAPI Int32 GetMaxRate(tUeiSessionType type, int index);

   /// \brief Get the resolution of the specified subsystem 
   ///
   /// Get the resolution of the specified subsystem
   ///
   /// \return the resolution.
   UeiDaqAPI Int32 GetResolution(tUeiSessionType type, int index);

   /// \brief Get the input (or output) ranges of the specified subsystem 
   ///
   /// Get the ranges of the specified subsystem
   ///
   /// \return the resolution.
   UeiDaqAPI void GetRanges(tUeiSessionType type, int index, tRanges& ranges);

   /// \brief Get the input gains of the specified subsystem 
   ///
   /// Get the gains of the specified subsystem
   ///
   /// \return the resolution.
   UeiDaqAPI void GetGains(tUeiSessionType type, int index, tGains& gains);
   
   /// \brief Get the number of Analog Input differential channels   
   ///
   /// Get the number of Analog Input differential channels 
   ///
   /// \return the number of AI differential channels.
   UeiDaqAPI Int32 GetNumberOfAIDifferentialChannels();

   /// \brief Get the number of Analog Input single-ended channels  
   ///
   /// Get the number of Analog Input single-ended channels 
   ///
   /// \return the number of AI single-ended channels.
   UeiDaqAPI Int32 GetNumberOfAISingleEndedChannels();

   /// \brief Get the number of Analog Input channels  
   ///
   /// Get the number of Analog Input channels available in the specified mode 
   ///
   /// \param mode the input mode.
   /// \return the number of AI channels.
   UeiDaqAPI Int32 GetNumberOfAIChannels(tUeiAIChannelInputMode mode);
   
   /// \brief Get the number of Analog Outout channels  
   ///
   /// Get the number of Analog Output channels 
   ///
   /// \return the number of AO channels.
   UeiDaqAPI Int32 GetNumberOfAOChannels();

   /// \brief Get the number of Digital Input channels   
   ///
   /// Get the number of Digital Input channels 
   ///
   /// \return the number of DI channels.
   UeiDaqAPI Int32 GetNumberOfDIChannels();

   /// \brief Get the number of Digital Output channels   
   ///
   /// Get the number of Digital Output channels 
   ///
   /// \return the number of DO channels.
   UeiDaqAPI Int32 GetNumberOfDOChannels();

   /// \brief Get the number of Counter Input channels  
   ///
   /// Get the number of Counter Input channels 
   ///
   /// \return the number of CI channels.
   UeiDaqAPI Int32 GetNumberOfCIChannels();
   
   /// \brief Get the number of Counter Output channels   
   ///
   /// Get the number of Counter Output channels 
   ///
   /// \return the number of CO channels.
   UeiDaqAPI Int32 GetNumberOfCOChannels();
   
   /// \brief Get the maximum AI rate  
   ///
   /// Get the maximum rate of the Analog Input subsystem
   ///
   /// \return the maximum rate.
   UeiDaqAPI Int32 GetMaxAIRate();
   
   /// \brief Get the maximum AO rate   
   ///
   /// Get the maximum rate of the Analog Output subsystem
   ///
   /// \return the maximum rate.
   UeiDaqAPI Int32 GetMaxAORate();
   
   /// \brief Get the maximum DI rate  
   ///
   /// Get the maximum rate of the Digital Input subsystem
   ///
   /// \return the maximum rate.
   UeiDaqAPI Int32 GetMaxDIRate();
   
   /// \brief Get the maximum DO rate   
   ///
   /// Get the maximum rate of the Digital Output subsystem
   ///
   /// \return the maximum rate.
   UeiDaqAPI Int32 GetMaxDORate();
   
   /// \brief Get the maximum CI rate   
   ///
   /// Get the maximum rate of the Counter Input subsystem
   ///
   /// \return the maximum rate.
   UeiDaqAPI Int32 GetMaxCIRate();
   
   /// \brief Get the maximum CO rate   
   ///
   /// Get the maximum rate of the Counter Output subsystem
   ///
   /// \return the maximum rate.
   UeiDaqAPI Int32 GetMaxCORate();
   
   /// \brief Get the AI resolution  
   ///
   /// Get the resolution of the Analog Input channels
   ///
   /// \return the resolution.
   UeiDaqAPI Int32 GetAIResolution();
   
   /// \brief Get the AO resolution   
   ///
   /// Get the resolution of the Analog Output channels
   ///
   /// \return the resolution.
   UeiDaqAPI Int32 GetAOResolution();

   /// \brief Get the DI resolution   
   ///
   /// Get the number of lines in a digital input port
   ///
   /// \return the resolution.
   UeiDaqAPI Int32 GetDIResolution();
   
   /// \brief Get the DO resolution   
   ///
   /// Get the number of lines in a digital output port
   ///
   /// \return the resolution.
   UeiDaqAPI Int32 GetDOResolution();

   /// \brief Get the CI resolution   
   ///
   /// Get the input resolution of the counter/timer
   ///
   /// \return the resolution.
   UeiDaqAPI Int32 GetCIResolution();
   
   /// \brief Get the CO resolution   
   ///
   /// Get the output resolution of the counter/timer
   ///
   /// \return the resolution.
   UeiDaqAPI Int32 GetCOResolution();

   /// \brief Get the AI raw data size   
   ///
   /// Get the number of bytes needed to store each Analog input sample
   ///
   /// \return the data size.
   UeiDaqAPI Int32 GetAIDataSize();

   /// \brief Get the AO raw data size   
   ///
   /// Get the number of bytes needed to store each Analog output sample
   ///
   /// \return the data size.
   UeiDaqAPI Int32 GetAODataSize();

   /// \brief Get the DI data size   
   ///
   /// Get the number of bytes needed to store each Digital input sample
   ///
   /// \return the data size.
   UeiDaqAPI Int32 GetDIDataSize();

   /// \brief Get the DO data size   
   ///
   /// Get the number of bytes needed to store each Digital output sample
   ///
   /// \return the data size.
   UeiDaqAPI Int32 GetDODataSize();

   /// \brief Get the CI data size   
   ///
   /// Get the number of bytes needed to store each Counter input sample
   ///
   /// \return the data size.
   UeiDaqAPI Int32 GetCIDataSize();

   /// \brief Get the CO data size   
   ///
   /// Get the number of bytes needed to store each Counter output sample
   ///
   /// \return the data size.
   UeiDaqAPI Int32 GetCODataSize();

   /// \brief Get the AI range vector  
   ///
   /// Get the vector containing the Analog input ranges
   ///
   /// \param ranges the range vector
   UeiDaqAPI void GetAIRanges(tRanges& ranges);

   /// \brief Get the AO range vector   
   ///
   /// Get the vector containing the Analog output ranges
   ///
   /// \param ranges the range vector
   UeiDaqAPI void GetAORanges(tRanges& ranges);

   /// \brief Get the DI range vector   
   ///
   /// Get the vector containing the Digital input ranges
   /// The first member of each pair is the low threshold
   /// level and the second member is the high threshold
   /// level.
   ///
   /// \param ranges the range vector
   UeiDaqAPI void GetDIRanges(tRanges& ranges);

   /// \brief Get the DO range vector  
   ///
   /// Get the vector containing the Digital output ranges
   /// The first member of each pair is the low threshold
   /// level and the second member is the high threshold
   /// level.
   ///
   /// \param ranges the range vector
   UeiDaqAPI void GetDORanges(tRanges& ranges);

   /// \brief Get the AI gain vector   
   ///
   /// Get the vector containing the Analog input gains
   ///
   /// \param gains the gain vector
   UeiDaqAPI void GetAIGains(tGains& gains);

   /// \brief Check if the device supports simultaneous sampling
   ///
   /// Check if the device can do simultaneous analog input sampling
   ///
   /// \return true if the device supports simulataneous sampling
   UeiDaqAPI bool IsAISimultaneous();

   /// \brief Check if the device supports simultaneous update
   ///
   /// Check if the device can do simultaneous analog output update
   ///
   /// \return true if the device supports simulataneous update
   UeiDaqAPI bool IsAOSimultaneous();

   /// \brief Get the size of the input FIFO 
   ///
   /// Get the size of the input FIFO in number of samples
   ///
   /// \return the number of samples that can be stored in the input FIFO
   UeiDaqAPI Int32 GetInputFIFOSize();

   /// \brief Get the size of the output FIFO
   ///
   /// Get the size of the output FIFO in number of samples
   ///
   /// \return the number of samples that can be stored in the output FIFO
   UeiDaqAPI Int32 GetOutputFIFOSize();

   /// \brief Check if the device supports output regeneration
   ///
   /// Check if the device supports output regeneration
   ///
   /// \return true if the device supports ouput regeneration
   UeiDaqAPI bool CanRegenerate();

   /// \brief Check if the device digital ports are bidirectional
   ///
   /// Check if the device digital ports are bidirectional
   ///
   /// \return true if the device has bidirectional digital ports
   UeiDaqAPI bool BidirectionalDigitalPorts();

   /// \brief Check if the device supports programmable hysteresis
   /// on its digital ports
   ///
   /// Check if the device supports programmable hysteresis
   /// on its digital ports
   ///
   /// \return true if the device supports programmable hysteresis
   UeiDaqAPI bool SupportsDigitalPortHysteresis();

   /// \brief Check if the device has programmable digital FIR filters
   ///
   /// Check if the device has programmable digital FIR filters
   ///
   /// \return true if the device has digital FIR filters
   UeiDaqAPI bool HasFIRFilters();

   /// \brief Get the number of serial ports available on the device
   ///
   /// Get the number of serial ports available on the device
   ///
   /// \return The number of serial ports
   UeiDaqAPI Int32 GetNumberOfSerialPorts();

   /// \brief Get the number of synchronous serial ports available on the device
   ///
   /// Get the number of synchronous serial ports available on the device
   ///
   /// \return The number of serial ports
   UeiDaqAPI Int32 GetNumberOfSynchronousSerialPorts();

   /// \brief Get the number of CAN ports available on the device
   ///
   /// Get the number of CAN ports available on the device
   ///
   /// \return The number of serial ports
   UeiDaqAPI Int32 GetNumberOfCANPorts();

   /// \brief Get the number of ARINC input ports available on the device
   ///
   /// Get the number of ARINC input ports available on the device
   ///
   /// \return The number of ARINC input ports
   UeiDaqAPI Int32 GetNumberOfARINCInputPorts();

   /// \brief Get the number of ARINC output ports available on the device
   ///
   /// Get the number of ARINC output ports available on the device
   ///
   /// \return The number of ARINC output ports
   UeiDaqAPI Int32 GetNumberOfARINCOutputPorts();

   /// \brief Get the number of MIL-1553 ports available on the device
   ///
   /// Get the number of MIL-1553 ports available on the device
   ///
   /// \return The number of MIL-1553 ports
   UeiDaqAPI Int32 GetNumberOfMIL1553Ports();

   /// \brief Get the number of IRIG input ports available on the device
   ///
   /// Get the number of IRIG input ports available on the device
   ///
   /// \return The number of IRIG input ports
   UeiDaqAPI Int32 GetNumberOfIRIGInputPorts();

   /// \brief Get the number of IRIG output ports available on the device
   ///
   /// Get the number of IRIG output ports available on the device
   ///
   /// \return The number of IRIG output ports
   UeiDaqAPI Int32 GetNumberOfIRIGOutputPorts();

   /// \brief Get the number of SSI input ports available on the device
   ///
   /// Get the number of SSI input ports available on the device
   ///
   /// \return The number of SSI input ports
   UeiDaqAPI Int32 GetNumberOfSSIInputPorts();

   /// \brief Get the number of SSI output ports available on the device
   ///
   /// Get the number of SSI output ports available on the device
   ///
   /// \return The number of SSI output ports
   UeiDaqAPI Int32 GetNumberOfSSIOutputPorts();

   /// \brief Get the number of I2C master ports available on the device
   ///
   /// Get the number of I2C master ports available on the device
   ///
   /// \return The number of I2C master ports
   UeiDaqAPI Int32 GetNumberOfI2CMasterPorts();

   /// \brief Get the number of I2C slave ports available on the device
   ///
   /// Get the number of I2C slave ports available on the device
   ///
   /// \return The number of I2C slave ports
   UeiDaqAPI Int32 GetNumberOfI2CSlavePorts();

   /// \brief Get the number of diagnostic channels available on the device
   ///
   /// Get the number of diagnostic channels available on the device
   ///
   /// \return The number of diagnostic channels
   UeiDaqAPI Int32 GetNumberOfDiagnosticChannels();

   /// \brief Check if the device supports digital filtering (debouncing)
   ///
   /// Check if the device supports digital filtering on its
   /// Counter/timer inputs
   ///
   /// \return true if the device has digital filters
   UeiDaqAPI bool SupportsDigitalFiltering();

   /// \brief Get hardware information string
   ///
   /// Get low-level hardware information string.
   /// It contains informations such as firmware revision, logic revision,
   /// base address and interrupt configuration.
   ///
   /// \return A string containing hardware informations about the device.
   UeiDaqAPI std::string GetHardwareInformation();

   /// \brief Get the slot number occupied by the device
   ///
   /// Get the slot number occupied by the device
   ///
   /// \return The slot device is inserted in
   UeiDaqAPI Int32 GetSlot();

   /// \brief Checks whether the device support a session type
   /// 
   /// Checks whether the device supports the specified session type
   /// 
   /// \param sessionType the session type
   /// \return true if the session type is supported, false otherwise
   UeiDaqAPI bool IsSessionTypeSupported(tUeiSessionType sessionType);

   /// \brief Get device status string
   ///    
   /// Read the device status string, the status string contains 
   /// status information specific to each device. It is for
   /// internal use only.
   /// 
   /// \return A string containing the of status the device.
   UeiDaqAPI virtual std::string GetStatus();

   /// \brief Read Device EEPROM
   ///    
   /// Read the device EEPROM content. EEPROM contains informations
   /// such as Manufacture date, calibration date and calibration data
   /// The EEPROM content is returned as an opaque array of bytes. 
   /// Each device has a unique way of storing informations in its EEPROM
   /// and it is up to the calling application to interpret its content.
   ///
   /// Some devices have multiple EEPROM areas. Use the bank parameter to
   /// specify which EEPROM you wish to read from
   /// 
   /// \param bank The EEPROM bank to read from
   /// \param subSystem The sub-system to read EEPROM from
   /// \param area The area to access in the EEPROM 
   /// \param buffer Buffer big enough to store the EEPROM content
   
   /// \return The number of bytes read
   UeiDaqAPI virtual int ReadEEPROM(int bank, int subSystem, tUeiEEPROMArea area, uInt8* buffer);

   /// \brief Write Device EEPROM
   ///    
   /// Write the device EEPROM content. EEPROM contains informations
   /// such as Manufacture date, calibration date and calibration data
   /// The EEPROM content is sent as an opaque array of bytes. 
   /// Each device has a unique way of storing informations in its EEPROM
   /// and it is up to the calling application to prepare the buffer to
   /// match the EEPROM structure.
   ///
   /// Some devices have multiple EEPROM areas. Use the bank parameter to
   /// specify which EEPROM you wish to write to
   /// 
   /// \param bank The EEPROM bank to write to
   /// \param subSystem The sub-system to write to
   /// \param area The area to access in the EEPROM
   /// \param size The number of bytes to write
   /// \param buffer Buffer containing the new EEPROM content
   
   /// \param saveEEPROM True to commit changes to EEPROM
   UeiDaqAPI virtual void WriteEEPROM(int bank, int subSystem, tUeiEEPROMArea area, int size, uInt8* buffer, bool saveEEPROM);

   /// \brief Read Device register
   ///    
   /// Read a device register as a 32 bits value. 
   /// 
   /// \param offset Offset of the register relative to device's base address
   /// \return The register content
   UeiDaqAPI virtual uInt32 ReadRegister32(uInt32 offset);

   /// \brief Write Device register
   ///    
   /// Write a device register as a 32 bits value. 
   /// 
   /// \param offset Offset of the register relative to device's base address
   /// \param value The value to write to the register
   UeiDaqAPI virtual void WriteRegister32(uInt32 offset, uInt32 value);

   /// \brief Performs a write and read of multiple values into the address space of the Device.
   /// 
   /// \param writeAddr Start of address offset that will be written to. Length determined by writeData.Length.
   /// \param writeSize Number of 32-bit values to write to Device.
   /// \param writeData Buffer containing data to be written, up to 361 elements.
   /// \param readAddr Start of address offset that will be read from.
   /// \param readSize Number of 32-bit values to read from Device.
   /// \param readData Buffer to store data read from the device, up to 361 elements.
   /// \param doReadFirst Perform the read before the write.
   /// \param noIncrement Does not increment to next address (useful for FIFOs).
   UeiDaqAPI virtual void WriteReadRegisters32(uInt32 writeAddr, uInt32 writeSize, uInt32* writeData, uInt32 readAddr, uInt32 readSize, uInt32* readData, bool doReadFirst, bool noIncrement);

   /// \brief Read from device RAM
   ///    
   /// Read from the device RAM. Only for devices that actually have RAM.
   ///
   /// \param address address of the first element to read
   /// \param buffer Buffer to store the RAM content
   /// \param size The number of bytes to read from RAM
   /// \return The number of bytes read
   UeiDaqAPI virtual int ReadRAM(uInt32 address, int size, uInt8* buffer);

   /// \brief Write to device RAM
   ///    
   /// Write to the device RAM. Only for devices that actually have RAM.
   /// 
   /// \param address address of the first element to write
   /// \param size The number of bytes to write
   /// \param buffer Buffer containing the new value to store in RAM
   UeiDaqAPI virtual void WriteRAM(uInt32 address, int size, uInt8* buffer);

   /// \brief Get the low-level access timeout
   ///
   /// Get the maximum amount of time (in ms) for a low-level access request to complete.
   ///
   /// \return the timeout
   /// \sa SetTimeout
   UeiDaqAPI Int32 GetTimeout();
   
   /// \brief Set the low-level access timeout
   ///
   /// Set the maximum amount of time (in ms) for a low-level access request to complete.
   /// Set to -1 to use default value (depends on hardware)
   ///
   /// \param timeout the timeout
   /// \sa GetTimeout
   UeiDaqAPI void SetTimeout(Int32 timeout);

   /// \brief Reset device
   ///
   /// Executes a hardware reset on the device.
   /// To reboot a PowerDNA or PowerDNR unit call this method on the 
   /// CPU device (device 14).
   UeiDaqAPI virtual void Reset(void);

   /// \brief Set watchdog command
   ///
   /// Enable/Disable watchdog and configure mode.
   /// This is only supported on PowerDNA/DNR/DNF CPU devices (device 14)
   /// \param cmd the watchdog command
   /// \param timeout the watchdog expiration timeout
   UeiDaqAPI virtual void SetWatchDogCommand(tUeiWatchDogCommand cmd, int timeout);

   /// \brief Write calibration value in device's EEPROM
   ///
   /// Write/Replace calibration value in the EEPROM area reserved for the specified channel
   /// \param channel The channel 
   /// \param dacMode The DAC mode
   /// \param value The new calibration value
   /// \param saveEEPROM True to commit all changes to EEPROM
   UeiDaqAPI virtual void WriteCalibration(int channel, uInt8 dacMode, uInt32 value, bool saveEEPROM);

   /// \brief Calibrate
   ///    
   /// Run device low level self-calibration if implemented
   /// It is for internal use only.
   /// 
   /// \return An int indicating status on return. Device specific.
   UeiDaqAPI virtual int Calibrate();

   /// \brief WriteChannel
   ///    
   /// Write data to channel. 
   /// It is for internal use only.
   /// \param channel The channel 
   /// \param data The data to write to channel
   /// \return An int indicating status on return. Device specific.
   UeiDaqAPI virtual int WriteChannel(int channel, uInt32 data);

   /// \brief EnableChannels
   ///
   /// Enable channels on device.
   /// It is for internal use only.
   /// \return An int indicating status on return. Device specific.
   UeiDaqAPI virtual int EnableChannels();

   /// \brief Read device init parameter
   ///
   /// Read the device init parameter content.
   ///
   /// \param parameter The parameter to read
   /// \param buffer Buffer big enough to store the init parameter
   UeiDaqAPI virtual void ReadInitParameter(tUeiInitParameter parameter, uInt8* buffer);

   /// \brief Write device init parameter
   ///
   /// Write to the device init parameter.
   ///
   /// \param parameter The init parameter to write to
   /// \param buffer Buffer containing data to write to the init parameter
   /// \param saveInitPrm True to store changes of parameter changes for parameters stored in flash
   UeiDaqAPI virtual void WriteInitParameter(tUeiInitParameter parameter, uInt8* buffer, bool saveInitPrm);


   /// \cond DO_NOT_DOCUMENT
   CUeiDeviceImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDeviceImpl> m_pImpl;
};

}

#endif // __UEIDEVICE_H__
