#ifndef __UEIDATASTREAM_H__
#define __UEIDATASTREAM_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif


#include "UeiObject.h"
#include "UeiStructs.h"

namespace UeiDaq
{

// private classes
class CUeiDataStreamImpl;
class IUeiEventListener;

// Forward declaration
class CUeiException;

/// Stream class

///
/// Represents the data streaming in or out of the device
class CUeiDataStream : public CUeiObject
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiDataStream();
   UeiDaqAPI CUeiDataStream(CUeiDataStreamImpl* pImpl);
   UeiDaqAPI CUeiDataStream(const CUeiDataStream& t);
   CUeiDataStream& operator=(const CUeiDataStream& t);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDataStream();

   
   /// \brief Get the number of scans to read at a time 
   ///
   /// Get the number of scans to read at a time  
   ///
   /// \return the number of scans.
   UeiDaqAPI Int32 GetNumberOfScans();
   
   /// \brief Set the number of scans to read at a time  
   ///
   /// Set the number of scans to read at a time  
   ///
   /// \param numScans the number of scans.
   UeiDaqAPI void SetNumberOfScans(Int32 numScans);

   /// \brief Get the size of a scan  
   ///
   /// Get the size of a scan, usually equal to the number
   /// of channels in the session's channel list.
   ///
   /// \return the number of samples per scan.
   UeiDaqAPI Int32 GetScanSize();
   
   /// \brief Set the size of a scan   
   ///
   /// Set the size of a scan, usually equal to the number
   /// of channels in the session's channel list.
   ///
   /// \param scanSize the number of samples per scan.
   UeiDaqAPI void SetScanSize(Int32 scanSize);
   
   /// \brief Get the size of a raw sample
   ///
   /// Get the size of a raw sample in bytes.
   ///
   /// \return the number of bytes in one sample.
   UeiDaqAPI Int32 GetSampleSize();

   /// \brief Get the session type associated with this data stream
   ///
   /// Get the session type associated with this data stream
   /// 
   /// \return the session type
   UeiDaqAPI tUeiSessionType GetSessionType();
     
   /// \brief Get the number of frames
   ///
   /// Get the number of frames. Each frame is accessed
   /// independently by the device.
   ///
   /// \return the number of frames.
   UeiDaqAPI Int32 GetNumberOfFrames();
   
   /// \brief Set the number of frames  
   ///
   /// Set the number of frames. Each frame is accessed
   /// independently by the device.
   ///
   /// \param numFrames the number of frames.
   UeiDaqAPI void SetNumberOfFrames(Int32 numFrames);
   
   /// \brief Get the regenerate setting 
   ///
   /// Get the parameter that determines whether the output device 
   /// continuously regenerate the first buffer it received.
   ///
   /// \return the regenerate setting value.
   UeiDaqAPI Int32 GetRegenerate();
   
   /// \brief Set the regenerate setting 
   ///
   /// Specifies whether the output device will continuously regenerate 
   /// the first buffer it received.
   ///
   /// \param regen the regenerate setting value.
   UeiDaqAPI void SetRegenerate(Int32 regen);

   /// \brief Get the burst setting 
   ///
   /// Get the parameter that determines whether the input device 
   /// should acquire all the requested data in its internal memory
   /// before transferring it to the host PC.
   ///
   /// \return the burst setting value.
   UeiDaqAPI Int32 GetBurst();
   
   /// \brief Set the burst setting 
   ///
   /// Specifies whether the input device will acquire all the 
   /// requested data in its internal memory before transferring 
   /// it to the host PC.
   ///
   /// \param burst the burst setting value.
   UeiDaqAPI void SetBurst(Int32 burst);

   /// \brief Get the Overrun/underrun setting  
   ///
   /// For an input session, Determines whether the device overwrite 
   /// acquired data if it was not read fast enough.
   /// For an output session, Determines whether the device regenerate  
   /// previously generated data if it didn't receive new data fast enough.
   ///
   /// \return the overrun setting value.
   UeiDaqAPI Int32 GetOverUnderRun();
   
   /// \brief Set the Overrun/underrun setting
   ///
   /// For an input session, Specifies whether the device overwrite 
   /// acquired data if it was not read fast enough.
   /// For an output session, Specifies whether the device regenerate  
   /// previously generated data if it didn't receive new data fast enough.
   /// If overUnderRun is set to 1, the framework ignore the overrun or underrun
   /// condition. If it is set to 0 an exception is thrown upon overrun or underrun.
   ///
   /// \param overUnderRun the overrun setting value.
   UeiDaqAPI void SetOverUnderRun(Int32 overUnderRun);

   /// \brief Get the value of the blocking setting  
   ///
   /// When enabled, read operations will block until the requested amount
   /// of data is received from the device.
   /// when disabled, read operations return immediately with the amount
   /// of data available.
   ///
   /// \return the blocking setting value.
   UeiDaqAPI bool IsBlockingEnabled();

   /// \brief Set the value of the blocking setting
   ///
   /// When enabled, read operations will block until the requested amount
   /// of data is received from the device.
   /// when disabled, read operations return immediately with the amount
   /// of data available.
   ///
   /// \param blocking the blocking setting value.
   UeiDaqAPI void EnableBlocking(bool blocking);

   /// \brief Get the current scan position
   ///
   /// Get the latest acquired scan position in the 
   /// acquisition buffer.
   ///
   /// \return the current scan position.
   UeiDaqAPI Int32 GetCurrentScan();
   
   /// \brief Get the number of available scans
   ///
   /// Get the number of scans ready to be read or written 
   ///
   /// \return the number of available scans.
   UeiDaqAPI Int32 GetAvailableScans();
   
   /// \brief Get the total number of scans 
   ///
   /// Get the total number of scans read or written since 
   /// the session started.
   ///
   /// \return the total number of scans.
   UeiDaqAPI Int32 GetTotalScans();
   
   /// \brief Get the pointer position
   /// 
   /// Get the position of the next scan to read or write.
   /// The offset is relative to the reference specified with SetRelativeTo().
   /// Use a negative offset to read or write scans below the reference position.
   ///
   /// \return the offset.
   UeiDaqAPI Int32 GetOffset();

   /// \brief Change the pointer position
   /// 
   /// Move the position of the next scan to read or write.
   /// The offset is relative to the reference specified with SetRelativeTo().
   /// Use a negative offset to read or write scans below the reference position.
   ///
   /// \param offset the offset.
   UeiDaqAPI void SetOffset(Int32 offset);
   
   /// \brief Get the reference position  
   /// 
   /// Get the position used as a reference in the framework's internal buffer
   ///
   /// \return the reference.
   UeiDaqAPI tUeiDataStreamRelativeTo GetRelativeTo();
   
   /// \brief Set the reference position
   /// 
   /// Set the position to use as a reference in the framework's internal buffer
   ///
   /// \param relativeTo the new reference.
   UeiDaqAPI void SetRelativeTo(tUeiDataStreamRelativeTo relativeTo);

   /// \brief Get the stream status
   ///
   /// Get the status of the data stream
   ///
   /// \return the status
   UeiDaqAPI bool IsStreamActive();

   /// \brief Read 16 bits wide raw scans from the stream 
   /// 
   /// Read the specified number of raw scans from the stream.
   /// This function can work synchronously or asynchronously
   /// if a listener interface pointer is provided
   ///
   /// \param numScans Number of scans to read
   /// \param pBuffer Destination buffer for the scans
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void ReadRawData(Int32 numScans, uInt16 *pBuffer, IUeiEventListener *pListener = NULL);
   
   /// \brief Read 32 bits wide raw scans from the stream
   /// 
   /// Read the specified number of raw scans from the stream.
   /// This function can work synchronously or asynchronously
   /// if a listener interface pointer is provided
   ///
   /// \param numScans Number of scans to read
   /// \param pBuffer Destination buffer for the scans
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void ReadRawData(Int32 numScans, uInt32 *pBuffer, IUeiEventListener *pListener = NULL);

   /// \brief Read 16 bits wide calibrated raw scans from the stream 
   /// 
   /// Read the specified number of calibrated scans from the stream.
   /// This function can work synchronously or asynchronously
   /// if a listener interface pointer is provided
   ///
   /// \param numScans Number of scans to read
   /// \param pBuffer Destination buffer for the scans
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void ReadCalibratedRawData(Int32 numScans, uInt16 *pBuffer, IUeiEventListener *pListener = NULL);
   
   /// \brief Read 32 bits wide calibrated raw scans from the stream
   /// 
   /// Read the specified number of calibrated scans from the stream.
   /// This function can work synchronously or asynchronously
   /// if a listener interface pointer is provided
   ///
   /// \param numScans Number of scans to read
   /// \param pBuffer Destination buffer for the scans
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void ReadCalibratedRawData(Int32 numScans, uInt32 *pBuffer, IUeiEventListener *pListener = NULL);
   
   /// \brief Read scaled scans from the stream
   /// 
   /// Read the specified number of scaled scans from the stream.
   /// This function can work synchronously or asynchronously
   /// if a listener interface pointer is provided
   ///
   /// \param numScans Number of scans to read
   /// \param pBuffer Destination buffer for the scans
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void ReadScaledData(Int32 numScans, f64 *pBuffer, IUeiEventListener *pListener = NULL);
   
   /// \brief Write 16 bits wide raw scans to the stream
   /// 
   /// Write the specified number of raw scans to the stream.
   /// This function can work synchronously or asynchronously
   /// if a listener interface pointer is provided
   ///
   /// \param numScans Number of scans to write
   /// \param pBuffer Source buffer for the scans
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void WriteRawData(Int32 numScans, uInt16 *pBuffer, IUeiEventListener *pListener = NULL);
   
   /// \brief Write 32 bits raw scans to the stream
   /// 
   /// Write the specified number of raw scans to the stream.
   /// This function can work synchronously or asynchronously
   /// if a listener interface pointer is provided
   ///
   /// \param numScans Number of scans to write
   /// \param pBuffer Source buffer for the scans
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void WriteRawData(Int32 numScans, uInt32 *pBuffer, IUeiEventListener *pListener = NULL);
   
   /// \brief Write scaled scans to the stream
   /// 
   /// Write the specified number of scaled scans to the stream.
   /// This function can work synchronously or asynchronously
   /// if a listener interface pointer is provided
   ///
   /// \param numScans Number of scans to write
   /// \param pBuffer Source buffer for the scans
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void WriteScaledData(Int32 numScans, f64 *pBuffer, IUeiEventListener *pListener = NULL);

   /// \brief Read a data message from the stream
   /// 
   /// Read a data message from the stream.
   /// The device assiociated with this data stream
   /// must support message based operations (such as a serial port or a bus)
   ///
   /// \param port The port to read from
   /// \param messageType The type of message stored in the buffer
   /// \param bufferSize Maximum number of bytes that can be stored in the buffer
   /// \param pBuffer Destination buffer for the message
   /// \param numBytesRead The actual number of bytes read
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void ReadMessage(Int32 port, Int32 messageType, Int32 bufferSize, Int8 *pBuffer, Int32* numBytesRead, IUeiEventListener *pListener = NULL);

   /// \brief Write a data message to the stream
   /// 
   /// Write a data message to the stream.
   /// The device assiociated with this data stream
   /// must support message based operations (such as a serial port or a bus)
   ///
   /// \param port the port to write to
   /// \param messageType The type of message stored in the buffer
   /// \param bufferSize Maximum number of bytes that can be stored in the buffer
   /// \param pBuffer Destination buffer for the message
   /// \param numBytesWritten The number of actual bytes written
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void WriteMessage(Int32 port, Int32 messageType, Int32 bufferSize, Int8 *pBuffer, Int32* numBytesWritten, IUeiEventListener *pListener = NULL);
   
   /// \brief Read ARINC words from the stream
   /// 
   /// Read ARINC words from the stream.
   /// The device assiociated with this data stream
   /// must support ARINC-429
   ///
   /// \param port The port to read from
   /// \param bufferSize Maximum number of words that can be stored in the buffer
   /// \param pBuffer Destination buffer for the words
   /// \param numWordsRead The actual number of words read
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void ReadARINCWords(Int32 port, Int32 bufferSize, tUeiARINCWord *pBuffer, Int32* numWordsRead, IUeiEventListener *pListener = NULL);

   /// \brief Write ARINC words to the stream
   /// 
   /// Write ARINC words to the stream.
   /// The device assiociated with this data stream
   /// must support ARINC-429
   ///
   /// \param port the port to write to
   /// \param bufferSize Maximum number of words that can be stored in the buffer
   /// \param pBuffer Source buffer of the words
   /// \param numWordsWritten The number of actual Words written
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void WriteARINCWords(Int32 port, Int32 bufferSize, tUeiARINCWord *pBuffer, Int32* numWordsWritten, IUeiEventListener *pListener = NULL);
   
   /// \brief Write scheduled ARINC words
   /// 
   /// Updated scheduled ARINC words with new data.
   /// The device assiociated with this data stream
   /// must support ARINC-429
   ///
   /// \param port the port to write to
   /// \param firstWord Index of the first word to update in the scheduler table
   /// \param bufferSize Maximum number of words that can be stored in the buffer
   /// \param pBuffer Source buffer of the words
   /// \param numWordsWritten The number of actual Words written
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void WriteScheduledARINCWords(Int32 port, Int32 firstWord, Int32 bufferSize, tUeiARINCWord *pBuffer, Int32* numWordsWritten, IUeiEventListener *pListener = NULL);
   
   /// \brief Write scheduled ARINC raw words
   /// 
   /// Updated scheduled ARINC words with new data.
   /// The device assiociated with this data stream
   /// must support ARINC-429
   ///
   /// \param port the port to write to
   /// \param firstWord Index of the first word to update in the scheduler table
   /// \param bufferSize Maximum number of words that can be stored in the buffer
   /// \param pBuffer Source buffer of the words
   /// \param numWordsWritten The number of actual Words written
   /// \param pListener Interface pointer for asynchronous callback
   UeiDaqAPI void WriteScheduledARINCRawWords(Int32 port, Int32 firstWord, Int32 bufferSize, uInt32 *pBuffer, Int32* numWordsWritten, IUeiEventListener *pListener = NULL);
   
   /// \brief Flush I/O buffers associated with the specifed port
   ///
   /// Flush transmit and or receive buffer(s) associated with the specified port
   ///
   /// \param port the port to flush
   /// \param action the action to be taken while flushing the buffer(s)
   UeiDaqAPI void Flush(Int32 port, tUeiFlushAction action);

   /// \brief Get the number of available input messages
   ///
   /// Get the number of messages ready to be read from the specified port
   ///
   /// \param port the port to query
   /// \return the number of available input messages.
   UeiDaqAPI Int32 GetAvailableInputMessages(Int32 port);

   /// \brief Get the number of available output slots
   ///
   /// Get the number of slots ready to accept new messages to the specified port
   ///
   /// \param port the port to query
   /// \return the number of available outputs slots.
   UeiDaqAPI Int32 GetAvailableOutputSlots(Int32 port);
   
   /// \brief Get the total number of messages received 
   ///
   /// Get the total number of messages read from the specified port since 
   /// the session started.
   ///
   /// \param port the port to query
   /// \return the total number of messages.
   UeiDaqAPI Int32 GetTotalMessages(Int32 port);

   /// \cond DO_NOT_DOCUMENT
   UeiDaqAPI CUeiDataStreamImpl* GetImpl() const { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDataStreamImpl> m_pImpl;
};

}

#endif // __UEIDATASTREAM_H__
