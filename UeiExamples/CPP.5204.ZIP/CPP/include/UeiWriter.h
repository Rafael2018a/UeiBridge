#ifndef __UEIWRITER_H__
#define __UEIWRITER_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif


#include <memory>
#include "UeiConstants.h"

namespace UeiDaq
{

// private classes
class CUeiAnalogRawWriterImpl;
class CUeiDigitalWriterImpl;
class CUeiCounterWriterImpl;
class CUeiDMMWriterImpl;
class CUeiAnalogScaledWriterImpl;
class CUeiDataStream;
class IUeiEventListener;
class CUeiLVDTWriterImpl;
class CUeiSynchroResolverWriterImpl;

// Forward declaration
class CUeiException;

/// \brief Analog Raw Writer class
/// 
/// Class that handles writing raw data to 
/// a stream going to an analog output
class CUeiAnalogRawWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   UeiDaqAPI CUeiAnalogRawWriter(CUeiDataStream* pDataStream);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAnalogRawWriter();

   /// \brief Write a 16 bits wide scan
   ///
   /// Write only one scan to the output stream
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScan(uInt16* pBuffer);

   /// \brief Write a 32 bits wide scan
   ///
   /// Write only one scan to the output stream
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScan(uInt32* pBuffer);
   
   /// \brief Write multiple 16 bits wide scans
   ///
   /// Write several scans to the output stream
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScans(Int32 numScans, uInt16* pBuffer);

   /// \brief Write multiple 32 bits wide scans
   ///
   /// Write several scans to the output stream
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScans(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Write a 16 bits wide scan asynchronously
   ///
   /// Write only one scan asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScanAsync(uInt16* pBuffer);

   /// \brief Write a 32 bits wide scan asynchronously
   ///
   /// Write only one scan asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScanAsync(uInt32* pBuffer);
   
   /// \brief Write multiple 16 bits wide scans asynchronously
   ///
   /// Write several scans asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScansAsync(Int32 numScans, uInt16* pBuffer);

   /// \brief Write multiple 32 bits wide scans asynchronously
   ///
   /// Write several scans asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScansAsync(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);

   /// \brief Get Scan size
   ///
   /// Get the number of samples in each scan
   /// \returns The number of samples per scan
   UeiDaqAPI int GetScanSize();
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAnalogRawWriterImpl> m_pImpl;
};


/// \brief Analog Scaled Writer class
/// 
/// Class that handles writing scaled data to 
/// a stream going to an analog output
class CUeiAnalogScaledWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   UeiDaqAPI CUeiAnalogScaledWriter(CUeiDataStream* pDataStream);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAnalogScaledWriter();

   /// \brief Write a scan
   ///
   /// Write only one scan to the output stream
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScan(f64* pBuffer);
   
   /// \brief Write multiple scans
   ///
   /// Write several scans to the output stream
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScans(Int32 numScans, f64* pBuffer);
   
   /// \brief Write a scan asynchronously
   ///
   /// Write only one scan asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScanAsync(f64* pBuffer);
   
   /// \brief Write multiple scans asynchronously
   ///
   /// Write several scans asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScansAsync(Int32 numScans, f64* pBuffer);
   
   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);

   /// \brief Get Scan size
   ///
   /// Get the number of samples in each scan
   /// \returns The number of samples per scan
   UeiDaqAPI int GetScanSize();
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAnalogScaledWriterImpl> m_pImpl;
};


/// \brief LVDT Writer class
/// 
/// Class that handles writing scaled data to 
/// a stream going to a simulated LVDT output
class CUeiLVDTWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   UeiDaqAPI CUeiLVDTWriter(CUeiDataStream* pDataStream);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiLVDTWriter();

   /// \brief Write displacement to simulated LVDT sensor
   ///
   /// Write one displacement scan to the output stream
   /// Displacement is divided by the simulated LVDT
   /// sensor sensitivity to obtain a ratiometric value
   /// \param pBuffer destination buffer
   UeiDaqAPI void WriteSingleDisplacement(f64* pBuffer);

   /// \brief Write primary coil (P1) and secondary coil (P2) amplitudes
   ///
   /// Set both primary and secondary amplitudes as a ratiometric value. 
   /// The actual amplitude depends on the excitation amplitude.
   /// Possible values must be between 0.0 (full attenuation) and 1.0 (no attenuation)
   /// \param pPrimaryCoilsBuffer destination buffer for primary coils amplitudes
   /// \param pSecondaryCoilsBuffer destination buffer for secondary coils amplitudes
   UeiDaqAPI void WriteCoilAmplitudes(f64* pPrimaryCoilsBuffer, f64* pSecondaryCoilsBuffer);

   /// \brief Get Scan size
   ///
   /// Get the number of samples in each scan
   /// \returns The number of samples per scan
   UeiDaqAPI int GetScanSize();

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiLVDTWriterImpl> m_pImpl;
};


/// \brief Synchro/Resolver Writer class
/// 
/// Class that handles writing scaled data to 
/// a stream going to a simulated LVDT output
class CUeiSynchroResolverWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   UeiDaqAPI CUeiSynchroResolverWriter(CUeiDataStream* pDataStream);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSynchroResolverWriter();

   /// \brief Write angle of simulated synchro/resolver
   ///
   /// Write one angle scan (one value per channel) to the output stream
   /// This is equivalent to CAnalogScaledWriter::WriteSingleScan()
   /// \param pBuffer destination buffer
   UeiDaqAPI void WriteSingleAngle(f64* pBuffer);

   /// \brief Write multiple angles to be generated with fixed delay to device FIFO
   ///
   /// Write multiple angles to simulate velocity/acceleration on simulated synchro/resolver
   /// Each angle is associated with a delay (in microseconds)
   /// The angles are staged to be sent to the device. Actual send happens upon calling Update()
   /// \param channel the channel to update
   /// \param numberOfValues numberOfValues in the buffer
   /// \param pDelayBuffer destination buffer for delays
   /// \param pAngleBuffer destination buffer for angles
   UeiDaqAPI void WriteMultipleAnglesToChannel(int channel, int numberOfValues, uInt32* pDelayBuffer, f64* pAngleBuffer);

   /// \brief Update all channels with staged angles and delays
   ///
   /// Update all channels with staged angles and delays
   /// \param written array containing the number of values actually written for each channel
   /// \param available array containing the space available in FIFO for each channel
   UeiDaqAPI void Update(Int32* written, Int32* available);

   /// \brief Get Scan size
   ///
   /// Get the number of samples in each scan
   /// \returns The number of samples per scan
   UeiDaqAPI int GetScanSize();

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSynchroResolverWriterImpl> m_pImpl;
};


/// \brief Digital Writer class
/// 
/// Class that handles writing digital data to 
/// a stream going to a digital output
class CUeiDigitalWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   UeiDaqAPI CUeiDigitalWriter(CUeiDataStream* pDataStream);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDigitalWriter();

   /// \brief Write a 16 bits wide scan
   ///
   /// Write only one scan to the output stream
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScan(uInt16* pBuffer);

   /// \brief Write a 32 bits wide scan
   ///
   /// Write only one scan to the output stream
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScan(uInt32* pBuffer);
   
   /// \brief Write multiple 16 bits wide scans
   ///
   /// Write several scans to the output stream
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScans(Int32 numScans, uInt16* pBuffer);

   /// \brief Write multiple 32 bits wide scans
   ///
   /// Write several scans to the output stream
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScans(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Write a 16 bits wide scan asynchronously
   ///
   /// Write only one scan asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScanAsync(uInt16* pBuffer);

   /// \brief Write a 32 bits wide scan asynchronously
   ///
   /// Write only one scan asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScanAsync(uInt32* pBuffer);
   
   /// \brief Write multiple 16 bits wide scans asynchronously
   ///
   /// Write several scans asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScansAsync(Int32 numScans, uInt16* pBuffer);

   /// \brief Write multiple 32 bits wide scans asynchronously
   ///
   /// Write several scans asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScansAsync(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);

   /// \brief Get Scan size
   ///
   /// Get the number of samples in each scan
   /// \returns The number of samples per scan
   UeiDaqAPI int GetScanSize();
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDigitalWriterImpl> m_pImpl;
};


/// \brief Counter Writer class
/// 
/// Class that handles writing data to 
/// a stream going to a counter output
class CUeiCounterWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   UeiDaqAPI CUeiCounterWriter(CUeiDataStream* pDataStream);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCounterWriter();

   /// \brief Write a 16 bits wide scan
   ///
   /// Write only one scan to the output stream
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScan(uInt16* pBuffer);

   /// \brief Write a 32 bits wide scan
   ///
   /// Write only one scan to the output stream
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScan(uInt32* pBuffer);
   
   /// \brief Write multiple 16 bits wide scans
   ///
   /// Write several scans to the output stream
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScans(Int32 numScans, uInt16* pBuffer);

   /// \brief Write multiple 32 bits wide scans
   ///
   /// Write several scans to the output stream
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScans(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Write a 16 bits wide scan asynchronously
   ///
   /// Write only one scan asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScanAsync(uInt16* pBuffer);

   /// \brief Write a 32 bits wide scan asynchronously
   ///
   /// Write only one scan asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteSingleScanAsync(uInt32* pBuffer);
   
   /// \brief Write multiple 16 bits wide scans asynchronously
   ///
   /// Write several scans asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScansAsync(Int32 numScans, uInt16* pBuffer);

   /// \brief Write multiple 32 bits wide scans asynchronously
   ///
   /// Write several scans asynchronously to the output stream.
   /// The source buffer can be reused once the listener
   /// is called.
   /// \param numScans number of scans to write
   /// \param pBuffer source buffer
   UeiDaqAPI void WriteMultipleScansAsync(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);

   /// \brief Get Scan size
   ///
   /// Get the number of samples in each scan
   /// \returns The number of samples per scan
   UeiDaqAPI int GetScanSize();
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCounterWriterImpl> m_pImpl;
};

/// \brief DMM Writer class
/// 
/// Class that handles writing data to 
/// a stream going to a DMM output
class CUeiDMMWriter
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the destination where to write data
   UeiDaqAPI CUeiDMMWriter(CUeiDataStream* pDataStream);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDMMWriter();

   /// \brief Configure a Mux device connection to the DMM
   ///
   /// Configure a Mux device connection to the DMM. Requires
   /// a compatible Mux layer and configuring the DMM channel
   /// with the number of Mux devices before the session is started
   /// through the SetMuxDeviceCount method. This uses the MuxGroup
   /// API to safely configure between Mux channels.
   ///
   /// \param muxDeviceNum The device number of the Mux layer in the IOM
   /// \param muxChannel The Mux layer channel to connect
   /// \param muxRelay The Mux layer relay on muxChannel to connect
   UeiDaqAPI void WriteDMMMuxConfig(Int32 muxDeviceNum, Int32 muxChannel, tUeiMuxRelaySelect muxRelay);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDMMWriterImpl> m_pImpl;
};

}

#endif // __UEIWRITER_H__
