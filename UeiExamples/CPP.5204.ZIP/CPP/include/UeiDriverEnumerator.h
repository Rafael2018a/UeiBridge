// UeiDeviceEnumerator.h: interface for the CUeiDeviceEnumerator class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __UEIDRIVERENUMERATOR_H__
#define __UEIDRIVERENUMERATOR_H__

#include <string>
#include <vector>

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

namespace UeiDaq
{
/// \brief Driver enumerator
///
/// Enumerates drivers detected by the framework
class CUeiDriverEnumerator  
{
public:
   /// \brief Constructor
   ///
   /// Build a driver enumerator
   ///
   UeiDaqAPI CUeiDriverEnumerator();
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDriverEnumerator();

   /// \brief Get a driver resource string from its index
   ///
   /// Enumerates a driver.  
   ///
   /// \return a string containing the driver resource or empty if there is no more devices to enumerate.
   /// \sa GetNumberOfDriverss  
   UeiDaqAPI std::string GetDriver(int deviceIndex);
   
   /// \brief Get the number of drivers
   ///
   /// Get the number of enumerated drivers  
   ///
   /// \return the number of enumerated drivers.
   /// \sa GetDriver  
   UeiDaqAPI int GetNumberOfDrivers();
};

}

#endif // __UEIDRIVERENUMERATOR_H__
