#ifndef __UEIDAQ_H__
#define __UEIDAQ_H__

#if defined(WIN32)
   #pragma warning(disable : 4290)

   // auto_ptr is deprecated starting with VS2010
   // replaced with unique_ptr but keeps backward compatibility for older versions of Visual Studio
   #if (_MSC_VER < 1600)
   #define unique_ptr auto_ptr
   #endif
#elif defined(__LINUX__)
   // keep backward compatibility with older versions of GCC
   #if __cplusplus <= 199711L 
   #define unique_ptr auto_ptr
   #endif
#endif

#if defined(UEIDAQSTATIC) || defined(__linux__)
   #define UeiDaqAPI

   void UeiDaqInitLib();
   void UeiDaqCleanUpLib();
#endif

#ifdef __cplusplus
   #include "UeiConstants.h"
   #include "UeiStructs.h"
   #include "UeiChannel.h"
   #include "UeiException.h"
   #include "UeiTiming.h"
   #include "UeiTrigger.h"
   #include "UeiEvent.h"
   #include "UeiSession.h"
   #include "UeiDataStream.h"
   #include "UeiReader.h"
   #include "UeiWriter.h"
   #include "UeiMessaging.h"
   #include "UeiDevice.h"
   #include "UeiDeviceEnumerator.h"
   #include "UeiDriverEnumerator.h"
   #include "UeiSystem.h"
   #include "UeiFrameUtils.h"
#else
   #include "UeiConstants.h"
   #include "UeiStructs.h"
   #include "UeiDaqAnsiC.h"
   #include "UeiDaqError.h"
#endif


#if defined(UEIDAQSTATIC) || defined(__linux__)
   #if defined(__PHARLAP_ETS__)
      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqETSSD.lib")
      #else
         #pragma comment(lib, "UeiDaqETSS.lib")
      #endif
   #elif defined (__BORLANDC__)
      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqBCSD.lib")
      #else
         #pragma comment(lib, "UeiDaqBCS.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER < 1300)
      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC6SD.lib")
      #else
         #pragma comment(lib, "UeiDaqVC6S.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1300) && (_MSC_VER < 1400)
      #if defined(_MD) || defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded static run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC7SD.lib")
      #else
         #pragma comment(lib, "UeiDaqVC7S.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1400) && (_MSC_VER < 1500)
      #if defined(_MD) || defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded static run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC8SD.lib")
      #else
         #pragma comment(lib, "UeiDaqVC8S.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1500) && (_MSC_VER < 1600)
      #if defined(_MD) || defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded static run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC9SD.lib")
      #else
         #pragma comment(lib, "UeiDaqVC9S.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1600) && (_MSC_VER < 1700)
      #if defined(_MD) || defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded static run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC10SD.lib")
      #else
         #pragma comment(lib, "UeiDaqVC10S.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1700) && (_MSC_VER < 1800)
      #if defined(_MD) || defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded static run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC11SD.lib")
      #else
         #pragma comment(lib, "UeiDaqVC11S.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1800) && (_MSC_VER < 1900)
      #if defined(_MD) || defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded static run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC12SD.lib")
      #else
         #pragma comment(lib, "UeiDaqVC12S.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1900) && (_MSC_VER < 1910)
      #if defined(_MD) || defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded static run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC14SD.lib")
      #else
         #pragma comment(lib, "UeiDaqVC14S.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1910) && (_MSC_VER < 1920)
      #if defined(_MD) || defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded static run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC15SD.lib")
      #else
         #pragma comment(lib, "UeiDaqVC15S.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1920) && (_MSC_VER < 1940)
      #if defined(_MD) || defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded static run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC16SD.lib")
      #else
         #pragma comment(lib, "UeiDaqVC16S.lib")
      #endif
   #elif defined (__linux__)
   #else
      #error This version of Visual Studio is not supported
   #endif
#else
   #if defined(__PHARLAP_ETS__)
      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqETSD.lib")
      #else
         #pragma comment(lib, "UeiDaqETS.lib")
      #endif
   #elif defined (__BORLANDC__)
      #error The UEI Framework C++ API can only be used from Visual Studio
   #elif defined (_CVI_)
   #elif defined (__CYGWIN__)
      #error The UEI Framework C++ API can only be used from Visual Studio
   #elif defined (__MINGW32__)
      #error The UEI Framework C++ API can only be used from Visual Studio
   #elif defined (WIN32) && (_MSC_VER < 1500)
      #error This version of Visual Studio is not longer supported
   #elif defined (WIN32) && (_MSC_VER >= 1500) && (_MSC_VER < 1600)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC9D.lib")
      #else
         #pragma comment(lib, "UeiDaqVC9.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1600) && (_MSC_VER < 1700)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC10D.lib")
      #else
         #pragma comment(lib, "UeiDaqVC10.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1700) && (_MSC_VER < 1800)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC11D.lib")
      #else
         #pragma comment(lib, "UeiDaqVC11.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1800) && (_MSC_VER < 1900)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC12D.lib")
      #else
         #pragma comment(lib, "UeiDaqVC12.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1900) && (_MSC_VER < 1910)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC14D.lib")
      #else
         #pragma comment(lib, "UeiDaqVC14.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1910) && (_MSC_VER < 1920)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC15D.lib")
      #else
         #pragma comment(lib, "UeiDaqVC15.lib")
      #endif
   #elif defined (WIN32) && (_MSC_VER >= 1920) && (_MSC_VER < 1940)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqVC16D.lib")
      #else
         #pragma comment(lib, "UeiDaqVC16.lib")
      #endif
   #else 
      #error This new version of Visual Studio is not supported yet
   #endif
#endif

#endif // __UEIDAQ_H__
