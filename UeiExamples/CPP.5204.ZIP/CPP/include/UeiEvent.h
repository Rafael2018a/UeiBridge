#ifndef __UEIEVENT_H__
#define __UEIEVENT_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

namespace UeiDaq
{

/// \brief Interface called when an event occurs. 
///
/// Implement this interface to receive asynchronous
/// notifications
class IUeiEventListener
{
public:
   /// \brief Event callback method
   /// 
   /// This method is called by the framework when an event occurs
   ///
   /// \param event Event that triggered the callback
   /// \param param data pointer, dependent on the event
   virtual void OnEvent(tUeiEvent event, void* param) = 0;
};

}

#endif // __UEIEVENT_H__
