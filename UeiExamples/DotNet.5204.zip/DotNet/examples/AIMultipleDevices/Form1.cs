using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using UeiDaq;

namespace AIMultipleDevices
{
   /// <summary>
   /// Summary description for Form1.
   /// </summary>
   public class AIMultipleDevices : System.Windows.Forms.Form
   {
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.TextBox Minimum;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.TextBox Maximum;
      private System.Windows.Forms.RadioButton Differential;
      private System.Windows.Forms.RadioButton SingleEnded;
      private Session[] mySs;
      private AnalogScaledReader[] reader;
      private Timer AITimer;
      private System.Windows.Forms.ColumnHeader Channel;
      private System.Windows.Forms.ColumnHeader Value;
      private System.Windows.Forms.ListView Data;
      private System.Windows.Forms.ColumnHeader Device;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public AIMultipleDevices()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         //
         // TODO: Add any constructor code after InitializeComponent call
         //
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose(bool disposing)
      {
         if (disposing)
         {
            if (components != null)
            {
               components.Dispose();
            }
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.Resource = new System.Windows.Forms.TextBox();
         this.Stop = new System.Windows.Forms.Button();
         this.label2 = new System.Windows.Forms.Label();
         this.Quit = new System.Windows.Forms.Button();
         this.Go = new System.Windows.Forms.Button();
         this.Data = new System.Windows.Forms.ListView();
         this.Device = new System.Windows.Forms.ColumnHeader();
         this.Channel = new System.Windows.Forms.ColumnHeader();
         this.Value = new System.Windows.Forms.ColumnHeader();
         this.label1 = new System.Windows.Forms.Label();
         this.Minimum = new System.Windows.Forms.TextBox();
         this.label3 = new System.Windows.Forms.Label();
         this.label4 = new System.Windows.Forms.Label();
         this.Maximum = new System.Windows.Forms.TextBox();
         this.Differential = new System.Windows.Forms.RadioButton();
         this.SingleEnded = new System.Windows.Forms.RadioButton();
         this.SuspendLayout();
         // 
         // ErrorText
         // 
         this.ErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
         this.ErrorText.Location = new System.Drawing.Point(0, 303);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(578, 48);
         this.ErrorText.TabIndex = 18;
         // 
         // Resource
         // 
         this.Resource.AcceptsReturn = true;
         this.Resource.Location = new System.Drawing.Point(8, 24);
         this.Resource.Multiline = true;
         this.Resource.Name = "Resource";
         this.Resource.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.Resource.Size = new System.Drawing.Size(203, 47);
         this.Resource.TabIndex = 15;
         this.Resource.Text = "simu://Dev0/Ai0:3\r\npdna://192.168.100.3/Dev5/Ai0:1,ts";
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(454, 73);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(112, 32);
         this.Stop.TabIndex = 17;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(8, 8);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(120, 16);
         this.label2.TabIndex = 16;
         this.label2.Text = "Resource name";
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(454, 113);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(112, 32);
         this.Quit.TabIndex = 14;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(454, 33);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(112, 32);
         this.Go.TabIndex = 13;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // Data
         // 
         this.Data.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Device,
            this.Channel,
            this.Value});
         this.Data.GridLines = true;
         this.Data.Location = new System.Drawing.Point(220, 24);
         this.Data.Name = "Data";
         this.Data.Size = new System.Drawing.Size(215, 160);
         this.Data.TabIndex = 19;
         this.Data.UseCompatibleStateImageBehavior = false;
         this.Data.View = System.Windows.Forms.View.Details;
         // 
         // Device
         // 
         this.Device.Text = "Device";
         this.Device.Width = 47;
         // 
         // Channel
         // 
         this.Channel.Text = "Channel";
         this.Channel.Width = 53;
         // 
         // Value
         // 
         this.Value.Text = "Value";
         this.Value.Width = 111;
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(217, 8);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(112, 16);
         this.label1.TabIndex = 20;
         this.label1.Text = "Acquired Data";
         // 
         // Minimum
         // 
         this.Minimum.Location = new System.Drawing.Point(8, 124);
         this.Minimum.Name = "Minimum";
         this.Minimum.Size = new System.Drawing.Size(112, 20);
         this.Minimum.TabIndex = 21;
         this.Minimum.Text = "-10.0";
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(8, 108);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(96, 16);
         this.label3.TabIndex = 22;
         this.label3.Text = "Low Limit";
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(8, 156);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(96, 16);
         this.label4.TabIndex = 24;
         this.label4.Text = "High Limit";
         // 
         // Maximum
         // 
         this.Maximum.Location = new System.Drawing.Point(8, 172);
         this.Maximum.Name = "Maximum";
         this.Maximum.Size = new System.Drawing.Size(112, 20);
         this.Maximum.TabIndex = 23;
         this.Maximum.Text = "10.0";
         // 
         // Differential
         // 
         this.Differential.Checked = true;
         this.Differential.Location = new System.Drawing.Point(8, 80);
         this.Differential.Name = "Differential";
         this.Differential.Size = new System.Drawing.Size(88, 16);
         this.Differential.TabIndex = 25;
         this.Differential.TabStop = true;
         this.Differential.Text = "Differential";
         // 
         // SingleEnded
         // 
         this.SingleEnded.Location = new System.Drawing.Point(92, 80);
         this.SingleEnded.Name = "SingleEnded";
         this.SingleEnded.Size = new System.Drawing.Size(104, 18);
         this.SingleEnded.TabIndex = 26;
         this.SingleEnded.Text = "Single Ended";
         // 
         // AIMultipleDevices
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(578, 351);
         this.Controls.Add(this.SingleEnded);
         this.Controls.Add(this.Differential);
         this.Controls.Add(this.label4);
         this.Controls.Add(this.Maximum);
         this.Controls.Add(this.Minimum);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.Resource);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.Data);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Name = "AIMultipleDevices";
         this.Text = "AI Multiple Devices";
         this.ResumeLayout(false);
         this.PerformLayout();

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main()
      {
         Application.Run(new AIMultipleDevices());
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         Application.Exit();
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         ErrorText.Clear();
         Data.Items.Clear();

         try
         {
            AIChannelInputMode inputMode;

            if (Differential.Checked)
               inputMode = AIChannelInputMode.Differential;
            else
               inputMode = AIChannelInputMode.SingleEnded;

            int deviceTotal = Resource.Lines.Length;
            mySs = new Session[deviceTotal];
            reader = new AnalogScaledReader[deviceTotal];

            for (int deviceNum = 0; deviceNum < deviceTotal; deviceNum++)
            {

               mySs[deviceNum] = new Session();
               mySs[deviceNum].CreateAIChannel(Resource.Lines[deviceNum], Double.Parse(Minimum.Text),
                                   Double.Parse(Maximum.Text), inputMode);

               for (int i = 0; i < mySs[deviceNum].GetNumberOfChannels(); i++)
               {
                  ListViewItem item = Data.Items.Add(deviceNum.ToString());
                  Channel chan = mySs[deviceNum].GetChannel(i);

                  item.SubItems.Add(chan.GetIndex().ToString());
                  item.SubItems.Add("0.0");

                  // Set TS resolution (default is 10ms)
                  TimestampChannel tsChan = chan as TimestampChannel;
                  if (tsChan != null)
                  {
                     tsChan.SetResolution(0.00001);
                  }
               }

               mySs[deviceNum].ConfigureTimingForSimpleIO();

               // Create a reader object to read data synchronously.
               reader[deviceNum] = new AnalogScaledReader(mySs[deviceNum].GetDataStream());

               mySs[deviceNum].Start();
            }
            AITimer = new Timer();
            AITimer.Interval = 100;
            AITimer.Start();
            AITimer.Tick += new EventHandler(Timer_Tick);

            Resource.Enabled = false;
            Go.Enabled = false;


         }
         catch (UeiDaqException exception)
         {
            int deviceTotal = Resource.Lines.Length;
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            for (int deviceNum = 0; deviceNum < deviceTotal; deviceNum++)
            {
               mySs[deviceNum].Dispose();
               mySs[deviceNum] = null;
            }
         }
      }

      public void Timer_Tick(object sender, EventArgs eArgs)
      {
         int deviceTotal = Resource.Lines.Length;
         int itemNum = 0;
         for (int deviceNum = 0; deviceNum < deviceTotal; deviceNum++)
         {
            if (sender == AITimer)
            {
               double[] scan = reader[deviceNum].ReadSingleScan();
               for (int i = 0; i < mySs[deviceNum].GetNumberOfChannels(); i++)
               {
                  Data.Items[itemNum].SubItems[2].Text = scan[i].ToString();
                  itemNum++;
               }
            }
         }
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         Resource.Enabled = true;
         Go.Enabled = true;
         int deviceTotal = Resource.Lines.Length;

         for (int deviceNum = 0; deviceNum < deviceTotal; deviceNum++)
         {

            if (mySs[deviceNum] != null)
            {
               AITimer.Stop();

               try
               {
                  mySs[deviceNum].Stop();
               }
               catch (UeiDaqException exception)
               {
                  ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
               }

               mySs[deviceNum].Dispose();
               mySs[deviceNum] = null;
            }
         }
      }
   }
}
