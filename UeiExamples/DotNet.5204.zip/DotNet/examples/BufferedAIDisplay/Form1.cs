using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using UeiDaq;

namespace BufferedAI
{
   /// <summary>
   /// Summary description for Form1.
   /// </summary>
   public class Form1 : System.Windows.Forms.Form
   {
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Label NbSc_label;
      private System.Windows.Forms.TrackBar Frequency;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.TextBox FrequencyText;
      private Session mySs = null;
      private AnalogScaledReader reader;
      private double[,] scan;
      private AsyncCallback readerCallback;
      private IAsyncResult readerIAsyncResult;
      private delegate void UpdateUIDelegate(String errorMessage);
      private IAsyncResult UpdateAResult;
      private System.Windows.Forms.TextBox NbScans;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.TextBox TotalScansText;
      private System.Windows.Forms.TextBox AvailableScansText;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.TextBox NbScansReadText;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.Label label6;
      private System.Windows.Forms.TextBox NbFramesText;
      private System.Windows.Forms.ListView Data;
      private System.Windows.Forms.ColumnHeader Channel;
      private System.Windows.Forms.ColumnHeader Value;
      private System.Windows.Forms.Label DataLabel;
      private System.Windows.Forms.TextBox Minimum;
      private System.Windows.Forms.TextBox Maximum;
      private System.Windows.Forms.Label label7;
      private System.Windows.Forms.Label label8;
      private System.Windows.Forms.RadioButton Differential;
      private System.Windows.Forms.RadioButton SingleEnded;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public Form1()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         FrequencyText.Text = Frequency.Value.ToString();
         Go.Enabled = true;
         Stop.Enabled = false;
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose(bool disposing)
      {
         if (disposing)
         {
            if (components != null)
            {
               components.Dispose();
            }
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
         this.Go = new System.Windows.Forms.Button();
         this.Quit = new System.Windows.Forms.Button();
         this.Resource = new System.Windows.Forms.TextBox();
         this.NbScans = new System.Windows.Forms.TextBox();
         this.NbSc_label = new System.Windows.Forms.Label();
         this.Frequency = new System.Windows.Forms.TrackBar();
         this.FrequencyText = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.Stop = new System.Windows.Forms.Button();
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.TotalScansText = new System.Windows.Forms.TextBox();
         this.AvailableScansText = new System.Windows.Forms.TextBox();
         this.label3 = new System.Windows.Forms.Label();
         this.label4 = new System.Windows.Forms.Label();
         this.NbFramesText = new System.Windows.Forms.TextBox();
         this.NbScansReadText = new System.Windows.Forms.TextBox();
         this.label5 = new System.Windows.Forms.Label();
         this.label6 = new System.Windows.Forms.Label();
         this.Data = new System.Windows.Forms.ListView();
         this.Channel = new System.Windows.Forms.ColumnHeader();
         this.Value = new System.Windows.Forms.ColumnHeader();
         this.DataLabel = new System.Windows.Forms.Label();
         this.Minimum = new System.Windows.Forms.TextBox();
         this.Maximum = new System.Windows.Forms.TextBox();
         this.label7 = new System.Windows.Forms.Label();
         this.label8 = new System.Windows.Forms.Label();
         this.Differential = new System.Windows.Forms.RadioButton();
         this.SingleEnded = new System.Windows.Forms.RadioButton();
         ((System.ComponentModel.ISupportInitialize)(this.Frequency)).BeginInit();
         this.SuspendLayout();
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(440, 16);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(144, 40);
         this.Go.TabIndex = 1;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(440, 112);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(144, 40);
         this.Quit.TabIndex = 2;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(8, 24);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(112, 20);
         this.Resource.TabIndex = 3;
         this.Resource.Text = "simu://Dev0/Ai0:3";
         // 
         // NbScans
         // 
         this.NbScans.Location = new System.Drawing.Point(8, 64);
         this.NbScans.Name = "NbScans";
         this.NbScans.Size = new System.Drawing.Size(112, 20);
         this.NbScans.TabIndex = 4;
         this.NbScans.Text = "1000";
         // 
         // NbSc_label
         // 
         this.NbSc_label.Location = new System.Drawing.Point(8, 48);
         this.NbSc_label.Name = "NbSc_label";
         this.NbSc_label.Size = new System.Drawing.Size(96, 16);
         this.NbSc_label.TabIndex = 5;
         this.NbSc_label.Text = "Number of Scans";
         // 
         // Frequency
         // 
         this.Frequency.Location = new System.Drawing.Point(320, 48);
         this.Frequency.Maximum = 100000;
         this.Frequency.Name = "Frequency";
         this.Frequency.Orientation = System.Windows.Forms.Orientation.Vertical;
         this.Frequency.Size = new System.Drawing.Size(42, 84);
         this.Frequency.TabIndex = 6;
         this.Frequency.TickFrequency = 10000;
         this.Frequency.Value = 20000;
         this.Frequency.Scroll += new System.EventHandler(this.Frequency_Scroll);
         // 
         // FrequencyText
         // 
         this.FrequencyText.Location = new System.Drawing.Point(304, 24);
         this.FrequencyText.Name = "FrequencyText";
         this.FrequencyText.Size = new System.Drawing.Size(64, 20);
         this.FrequencyText.TabIndex = 8;
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(8, 8);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(120, 16);
         this.label2.TabIndex = 9;
         this.label2.Text = "Resource name";
         // 
         // groupBox1
         // 
         this.groupBox1.Location = new System.Drawing.Point(296, 8);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(80, 124);
         this.groupBox1.TabIndex = 10;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Frequency";
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(440, 64);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(144, 40);
         this.Stop.TabIndex = 11;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // ErrorText
         // 
         this.ErrorText.Location = new System.Drawing.Point(8, 246);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(576, 48);
         this.ErrorText.TabIndex = 12;
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(8, 227);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(104, 16);
         this.label1.TabIndex = 13;
         this.label1.Text = "Error Message";
         // 
         // TotalScansText
         // 
         this.TotalScansText.Location = new System.Drawing.Point(8, 155);
         this.TotalScansText.Name = "TotalScansText";
         this.TotalScansText.ReadOnly = true;
         this.TotalScansText.Size = new System.Drawing.Size(112, 20);
         this.TotalScansText.TabIndex = 14;
         // 
         // AvailableScansText
         // 
         this.AvailableScansText.Location = new System.Drawing.Point(8, 195);
         this.AvailableScansText.Name = "AvailableScansText";
         this.AvailableScansText.ReadOnly = true;
         this.AvailableScansText.Size = new System.Drawing.Size(112, 20);
         this.AvailableScansText.TabIndex = 15;
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(8, 139);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(88, 16);
         this.label3.TabIndex = 16;
         this.label3.Text = "Total scans";
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(8, 179);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(96, 16);
         this.label4.TabIndex = 17;
         this.label4.Text = "Available scans";
         // 
         // NbFramesText
         // 
         this.NbFramesText.Location = new System.Drawing.Point(134, 24);
         this.NbFramesText.Name = "NbFramesText";
         this.NbFramesText.Size = new System.Drawing.Size(112, 20);
         this.NbFramesText.TabIndex = 18;
         this.NbFramesText.Text = "8";
         // 
         // NbScansReadText
         // 
         this.NbScansReadText.Location = new System.Drawing.Point(8, 112);
         this.NbScansReadText.Name = "NbScansReadText";
         this.NbScansReadText.Size = new System.Drawing.Size(112, 20);
         this.NbScansReadText.TabIndex = 19;
         this.NbScansReadText.Text = "1000";
         // 
         // label5
         // 
         this.label5.Location = new System.Drawing.Point(134, 8);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(104, 16);
         this.label5.TabIndex = 20;
         this.label5.Text = "Number of Frames";
         // 
         // label6
         // 
         this.label6.Location = new System.Drawing.Point(8, 96);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(128, 16);
         this.label6.TabIndex = 21;
         this.label6.Text = "Number of scans to read";
         // 
         // Data
         // 
         this.Data.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Channel,
            this.Value});
         this.Data.GridLines = true;
         this.Data.Location = new System.Drawing.Point(134, 78);
         this.Data.Name = "Data";
         this.Data.Size = new System.Drawing.Size(146, 137);
         this.Data.TabIndex = 22;
         this.Data.UseCompatibleStateImageBehavior = false;
         this.Data.View = System.Windows.Forms.View.Details;
         // 
         // Channel
         // 
         this.Channel.Text = "Channel";
         // 
         // Value
         // 
         this.Value.Text = "Value";
         this.Value.Width = 82;
         // 
         // DataLabel
         // 
         this.DataLabel.AutoSize = true;
         this.DataLabel.Location = new System.Drawing.Point(134, 62);
         this.DataLabel.Name = "DataLabel";
         this.DataLabel.Size = new System.Drawing.Size(77, 13);
         this.DataLabel.TabIndex = 23;
         this.DataLabel.Text = "Gathered Data";
         // 
         // Minimum
         // 
         this.Minimum.Location = new System.Drawing.Point(296, 155);
         this.Minimum.Name = "Minimum";
         this.Minimum.Size = new System.Drawing.Size(100, 20);
         this.Minimum.TabIndex = 24;
         this.Minimum.Text = "-10.0";
         // 
         // Maximum
         // 
         this.Maximum.Location = new System.Drawing.Point(296, 195);
         this.Maximum.Name = "Maximum";
         this.Maximum.Size = new System.Drawing.Size(100, 20);
         this.Maximum.TabIndex = 25;
         this.Maximum.Text = "10.0";
         // 
         // label7
         // 
         this.label7.AutoSize = true;
         this.label7.Location = new System.Drawing.Point(298, 139);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(51, 13);
         this.label7.TabIndex = 26;
         this.label7.Text = "Low Limit";
         // 
         // label8
         // 
         this.label8.AutoSize = true;
         this.label8.Location = new System.Drawing.Point(298, 179);
         this.label8.Name = "label8";
         this.label8.Size = new System.Drawing.Size(53, 13);
         this.label8.TabIndex = 27;
         this.label8.Text = "High Limit";
         // 
         // Differential
         // 
         this.Differential.Checked = true;
         this.Differential.Location = new System.Drawing.Point(444, 173);
         this.Differential.Name = "Differential";
         this.Differential.Size = new System.Drawing.Size(104, 24);
         this.Differential.TabIndex = 28;
         this.Differential.TabStop = true;
         this.Differential.Text = "Differential";
         this.Differential.UseVisualStyleBackColor = true;
         // 
         // SingleEnded
         // 
         this.SingleEnded.AutoSize = true;
         this.SingleEnded.Location = new System.Drawing.Point(444, 196);
         this.SingleEnded.Name = "SingleEnded";
         this.SingleEnded.Size = new System.Drawing.Size(88, 17);
         this.SingleEnded.TabIndex = 29;
         this.SingleEnded.Text = "Single Ended";
         this.SingleEnded.UseVisualStyleBackColor = true;
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(592, 303);
         this.Controls.Add(this.SingleEnded);
         this.Controls.Add(this.Differential);
         this.Controls.Add(this.label8);
         this.Controls.Add(this.label7);
         this.Controls.Add(this.Maximum);
         this.Controls.Add(this.Minimum);
         this.Controls.Add(this.Data);
         this.Controls.Add(this.label6);
         this.Controls.Add(this.label5);
         this.Controls.Add(this.NbScansReadText);
         this.Controls.Add(this.NbFramesText);
         this.Controls.Add(this.AvailableScansText);
         this.Controls.Add(this.TotalScansText);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.FrequencyText);
         this.Controls.Add(this.NbScans);
         this.Controls.Add(this.Resource);
         this.Controls.Add(this.label4);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.Frequency);
         this.Controls.Add(this.NbSc_label);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.DataLabel);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.Name = "Form1";
         this.Text = "BufferedAI";
         ((System.ComponentModel.ISupportInitialize)(this.Frequency)).EndInit();
         this.ResumeLayout(false);
         this.PerformLayout();

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main()
      {
         Application.Run(new Form1());
      }

      private void Frequency_Scroll(object sender, System.EventArgs e)
      {
         FrequencyText.Text = ((TrackBar)(sender)).Value.ToString();
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();

         Application.Exit();
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         UeiDaqStart();
      }

      private void ReaderCallback(IAsyncResult ar)
      {
         try
         {
            scan = reader.EndReadMultipleScans(ar);

            UpdateUI("");

            if (mySs != null && mySs.IsRunning())
            {
               readerIAsyncResult = reader.BeginReadMultipleScans(mySs.GetDataStream().GetNumberOfScans(), readerCallback, null);
            }
         }
         catch (UeiDaqException exception)
         {
            UpdateUI("Error: (" + exception.Error + ") " + exception.Message);
         }
         catch (Exception e)
         {
            UpdateUI("Unknown Error" + e);
         }
      }

      private void UpdateUI(String errorMessage)
      {
         if (this.InvokeRequired)
         {
            // Execute display code only if the previous invoke is completed
            if (UpdateAResult == null || UpdateAResult.IsCompleted)
            {
				UpdateUIDelegate uidlg = new UpdateUIDelegate(UpdateUI);
				UpdateAResult = BeginInvoke(uidlg, new object[] { errorMessage });
			}
         }
         else
         {
            if (mySs != null)
            {
               if (mySs.IsRunning())
               {
                  AvailableScansText.Text = mySs.GetDataStream().GetAvailableScans().ToString();
                  TotalScansText.Text = mySs.GetDataStream().GetTotalScans().ToString();
               }

			   for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
			   {
				   Data.Items[i].SubItems[1].Text = scan[0, i].ToString();
				   //For demo purposes will only display first value acquired of total scans 
			   }
            }
			
            if (errorMessage.Length > 0)
            {
               ErrorText.Text = errorMessage;
               UeiDaqStop();
            }
         }
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();
      }

      private void UeiDaqStart()
      {
         ErrorText.Clear();
         Data.Items.Clear();

         try
         {

            AIChannelInputMode inputMode;

            if (Differential.Checked)
               inputMode = AIChannelInputMode.Differential;
            else
               inputMode = AIChannelInputMode.SingleEnded;

            mySs = new Session();

            mySs.CreateAIChannel(Resource.Text, Double.Parse(Minimum.Text), Double.Parse(Maximum.Text), inputMode);

            for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
            {
               ListViewItem item = Data.Items.Add(mySs.GetChannel(i).GetIndex().ToString());
               item.SubItems.Add("0.0");
            }

            mySs.ConfigureTimingForBufferedIO(Int32.Parse(NbScans.Text),
               TimingClockSource.Internal, Frequency.Value,
               DigitalEdge.Rising, TimingDuration.Continuous);

            mySs.GetTiming().SetTimeout(5000);

            mySs.GetDataStream().SetNumberOfFrames(Int32.Parse(NbFramesText.Text));
            //mySs.GetDataStream().SetOverUnderRun(1);

            // Create a reader object to read data synchronously.
            reader = new AnalogScaledReader(mySs.GetDataStream());

			UpdateAResult = null;
			
            mySs.Start();
            
            readerCallback = new AsyncCallback(ReaderCallback);
            readerIAsyncResult = reader.BeginReadMultipleScans(Int32.Parse(NbScansReadText.Text), readerCallback, null);

            NbScans.Enabled = false;
            Frequency.Enabled = false;
            FrequencyText.Enabled = false;
            Resource.Enabled = false;
            Go.Enabled = false;
            Stop.Enabled = true;
         }
         catch (UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            mySs.Dispose();
            mySs = null;
         }
      }

      private void UeiDaqStop()
      {
         if (mySs != null)
         {
            try
            {
               mySs.Stop();
               // wait for current async call to complete
               // before destroying the session
               readerIAsyncResult.AsyncWaitHandle.WaitOne();
            }
            catch (UeiDaqException exception)
            {
               ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }

            mySs.Dispose();
            mySs = null;
         }

         NbScans.Enabled = true;
         Frequency.Enabled = true;
         FrequencyText.Enabled = true;
         Resource.Enabled = true;
         Go.Enabled = true;
         Stop.Enabled = false;
      }
   }
}
