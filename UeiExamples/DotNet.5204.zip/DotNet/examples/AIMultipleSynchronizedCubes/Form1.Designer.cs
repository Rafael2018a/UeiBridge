﻿namespace AIMultipleSynchronizedCubes
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           this.txtResourceSlave0 = new System.Windows.Forms.TextBox();
           this.groupBox1 = new System.Windows.Forms.GroupBox();
           this.label27 = new System.Windows.Forms.Label();
           this.label26 = new System.Windows.Forms.Label();
           this.label25 = new System.Windows.Forms.Label();
           this.label24 = new System.Windows.Forms.Label();
           this.label23 = new System.Windows.Forms.Label();
           this.label19 = new System.Windows.Forms.Label();
           this.txtFirstLayer5 = new System.Windows.Forms.TextBox();
           this.txtFirstLayer4 = new System.Windows.Forms.TextBox();
           this.txtFirstLayer3 = new System.Windows.Forms.TextBox();
           this.txtFirstLayer2 = new System.Windows.Forms.TextBox();
           this.txtFirstLayer1 = new System.Windows.Forms.TextBox();
           this.txtFirstLayer0 = new System.Windows.Forms.TextBox();
           this.txtResourceSlave3 = new System.Windows.Forms.TextBox();
           this.txtTimeout = new System.Windows.Forms.TextBox();
           this.label22 = new System.Windows.Forms.Label();
           this.label21 = new System.Windows.Forms.Label();
           this.label20 = new System.Windows.Forms.Label();
           this.txtSampleRate = new System.Windows.Forms.TextBox();
           this.chkSyncDev = new System.Windows.Forms.CheckBox();
           this.label16 = new System.Windows.Forms.Label();
           this.label17 = new System.Windows.Forms.Label();
           this.label18 = new System.Windows.Forms.Label();
           this.label13 = new System.Windows.Forms.Label();
           this.label14 = new System.Windows.Forms.Label();
           this.label15 = new System.Windows.Forms.Label();
           this.label10 = new System.Windows.Forms.Label();
           this.label11 = new System.Windows.Forms.Label();
           this.label12 = new System.Windows.Forms.Label();
           this.label8 = new System.Windows.Forms.Label();
           this.label9 = new System.Windows.Forms.Label();
           this.label7 = new System.Windows.Forms.Label();
           this.label5 = new System.Windows.Forms.Label();
           this.label6 = new System.Windows.Forms.Label();
           this.label4 = new System.Windows.Forms.Label();
           this.label3 = new System.Windows.Forms.Label();
           this.label2 = new System.Windows.Forms.Label();
           this.label1 = new System.Windows.Forms.Label();
           this.txtNumChanSlave5 = new System.Windows.Forms.TextBox();
           this.txtNumLayersSlave5 = new System.Windows.Forms.TextBox();
           this.txtNumChanSlave4 = new System.Windows.Forms.TextBox();
           this.txtNumLayersSlave4 = new System.Windows.Forms.TextBox();
           this.txtNumChanSlave3 = new System.Windows.Forms.TextBox();
           this.txtNumLayersSlave3 = new System.Windows.Forms.TextBox();
           this.txtNumChanSlave2 = new System.Windows.Forms.TextBox();
           this.txtNumLayersSlave2 = new System.Windows.Forms.TextBox();
           this.txtNumChanSlave1 = new System.Windows.Forms.TextBox();
           this.txtNumLayersSlave1 = new System.Windows.Forms.TextBox();
           this.txtNumChanSlave0 = new System.Windows.Forms.TextBox();
           this.txtNumLayersSlave0 = new System.Windows.Forms.TextBox();
           this.chkEnabledSlave5 = new System.Windows.Forms.CheckBox();
           this.chkEnabledSlave4 = new System.Windows.Forms.CheckBox();
           this.chkEnabledSlave3 = new System.Windows.Forms.CheckBox();
           this.txtResourceSlave5 = new System.Windows.Forms.TextBox();
           this.txtResourceSlave4 = new System.Windows.Forms.TextBox();
           this.txtSamPerChan = new System.Windows.Forms.TextBox();
           this.chkEnabledSlave2 = new System.Windows.Forms.CheckBox();
           this.chkEnabledSlave1 = new System.Windows.Forms.CheckBox();
           this.chkEnabledSlave0 = new System.Windows.Forms.CheckBox();
           this.txtResourceSlave2 = new System.Windows.Forms.TextBox();
           this.txtResourceSlave1 = new System.Windows.Forms.TextBox();
           this.Status = new System.Windows.Forms.GroupBox();
           this.btnQuit = new System.Windows.Forms.Button();
           this.btnStop = new System.Windows.Forms.Button();
           this.btnStart = new System.Windows.Forms.Button();
           this.lstStatusList = new System.Windows.Forms.ListView();
           this.txtErrorText = new System.Windows.Forms.TextBox();
           this.groupBox1.SuspendLayout();
           this.Status.SuspendLayout();
           this.SuspendLayout();
           // 
           // txtResourceSlave0
           // 
           this.txtResourceSlave0.Location = new System.Drawing.Point(111, 56);
           this.txtResourceSlave0.Name = "txtResourceSlave0";
           this.txtResourceSlave0.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave0.TabIndex = 0;
           this.txtResourceSlave0.Text = "pdna://192.168.100.2/";
           // 
           // groupBox1
           // 
           this.groupBox1.Controls.Add(this.label27);
           this.groupBox1.Controls.Add(this.label26);
           this.groupBox1.Controls.Add(this.label25);
           this.groupBox1.Controls.Add(this.label24);
           this.groupBox1.Controls.Add(this.label23);
           this.groupBox1.Controls.Add(this.label19);
           this.groupBox1.Controls.Add(this.txtFirstLayer5);
           this.groupBox1.Controls.Add(this.txtFirstLayer4);
           this.groupBox1.Controls.Add(this.txtFirstLayer3);
           this.groupBox1.Controls.Add(this.txtFirstLayer2);
           this.groupBox1.Controls.Add(this.txtFirstLayer1);
           this.groupBox1.Controls.Add(this.txtFirstLayer0);
           this.groupBox1.Controls.Add(this.txtResourceSlave3);
           this.groupBox1.Controls.Add(this.txtTimeout);
           this.groupBox1.Controls.Add(this.label22);
           this.groupBox1.Controls.Add(this.label21);
           this.groupBox1.Controls.Add(this.label20);
           this.groupBox1.Controls.Add(this.txtSampleRate);
           this.groupBox1.Controls.Add(this.chkSyncDev);
           this.groupBox1.Controls.Add(this.label16);
           this.groupBox1.Controls.Add(this.label17);
           this.groupBox1.Controls.Add(this.label18);
           this.groupBox1.Controls.Add(this.label13);
           this.groupBox1.Controls.Add(this.label14);
           this.groupBox1.Controls.Add(this.label15);
           this.groupBox1.Controls.Add(this.label10);
           this.groupBox1.Controls.Add(this.label11);
           this.groupBox1.Controls.Add(this.label12);
           this.groupBox1.Controls.Add(this.label8);
           this.groupBox1.Controls.Add(this.label9);
           this.groupBox1.Controls.Add(this.label7);
           this.groupBox1.Controls.Add(this.label5);
           this.groupBox1.Controls.Add(this.label6);
           this.groupBox1.Controls.Add(this.label4);
           this.groupBox1.Controls.Add(this.label3);
           this.groupBox1.Controls.Add(this.label2);
           this.groupBox1.Controls.Add(this.label1);
           this.groupBox1.Controls.Add(this.txtNumChanSlave5);
           this.groupBox1.Controls.Add(this.txtNumLayersSlave5);
           this.groupBox1.Controls.Add(this.txtNumChanSlave4);
           this.groupBox1.Controls.Add(this.txtNumLayersSlave4);
           this.groupBox1.Controls.Add(this.txtNumChanSlave3);
           this.groupBox1.Controls.Add(this.txtNumLayersSlave3);
           this.groupBox1.Controls.Add(this.txtNumChanSlave2);
           this.groupBox1.Controls.Add(this.txtNumLayersSlave2);
           this.groupBox1.Controls.Add(this.txtNumChanSlave1);
           this.groupBox1.Controls.Add(this.txtNumLayersSlave1);
           this.groupBox1.Controls.Add(this.txtNumChanSlave0);
           this.groupBox1.Controls.Add(this.txtNumLayersSlave0);
           this.groupBox1.Controls.Add(this.chkEnabledSlave5);
           this.groupBox1.Controls.Add(this.chkEnabledSlave4);
           this.groupBox1.Controls.Add(this.chkEnabledSlave3);
           this.groupBox1.Controls.Add(this.txtResourceSlave5);
           this.groupBox1.Controls.Add(this.txtResourceSlave4);
           this.groupBox1.Controls.Add(this.txtSamPerChan);
           this.groupBox1.Controls.Add(this.chkEnabledSlave2);
           this.groupBox1.Controls.Add(this.chkEnabledSlave1);
           this.groupBox1.Controls.Add(this.chkEnabledSlave0);
           this.groupBox1.Controls.Add(this.txtResourceSlave2);
           this.groupBox1.Controls.Add(this.txtResourceSlave1);
           this.groupBox1.Controls.Add(this.txtResourceSlave0);
           this.groupBox1.ForeColor = System.Drawing.Color.Blue;
           this.groupBox1.Location = new System.Drawing.Point(12, 12);
           this.groupBox1.Name = "groupBox1";
           this.groupBox1.Size = new System.Drawing.Size(499, 484);
           this.groupBox1.TabIndex = 1;
           this.groupBox1.TabStop = false;
           this.groupBox1.Text = "Cubes Configuration";
           // 
           // label27
           // 
           this.label27.AutoSize = true;
           this.label27.Location = new System.Drawing.Point(282, 322);
           this.label27.Name = "label27";
           this.label27.Size = new System.Drawing.Size(55, 13);
           this.label27.TabIndex = 64;
           this.label27.Text = "First Layer";
           // 
           // label26
           // 
           this.label26.AutoSize = true;
           this.label26.Location = new System.Drawing.Point(282, 260);
           this.label26.Name = "label26";
           this.label26.Size = new System.Drawing.Size(55, 13);
           this.label26.TabIndex = 63;
           this.label26.Text = "First Layer";
           // 
           // label25
           // 
           this.label25.AutoSize = true;
           this.label25.Location = new System.Drawing.Point(282, 202);
           this.label25.Name = "label25";
           this.label25.Size = new System.Drawing.Size(55, 13);
           this.label25.TabIndex = 62;
           this.label25.Text = "First Layer";
           // 
           // label24
           // 
           this.label24.AutoSize = true;
           this.label24.Location = new System.Drawing.Point(282, 148);
           this.label24.Name = "label24";
           this.label24.Size = new System.Drawing.Size(55, 13);
           this.label24.TabIndex = 61;
           this.label24.Text = "First Layer";
           // 
           // label23
           // 
           this.label23.AutoSize = true;
           this.label23.Location = new System.Drawing.Point(282, 96);
           this.label23.Name = "label23";
           this.label23.Size = new System.Drawing.Size(55, 13);
           this.label23.TabIndex = 60;
           this.label23.Text = "First Layer";
           // 
           // label19
           // 
           this.label19.AutoSize = true;
           this.label19.Location = new System.Drawing.Point(282, 40);
           this.label19.Name = "label19";
           this.label19.Size = new System.Drawing.Size(55, 13);
           this.label19.TabIndex = 59;
           this.label19.Text = "First Layer";
           // 
           // txtFirstLayer5
           // 
           this.txtFirstLayer5.Location = new System.Drawing.Point(285, 338);
           this.txtFirstLayer5.Name = "txtFirstLayer5";
           this.txtFirstLayer5.Size = new System.Drawing.Size(50, 20);
           this.txtFirstLayer5.TabIndex = 58;
           this.txtFirstLayer5.Text = "0";
           // 
           // txtFirstLayer4
           // 
           this.txtFirstLayer4.Location = new System.Drawing.Point(285, 276);
           this.txtFirstLayer4.Name = "txtFirstLayer4";
           this.txtFirstLayer4.Size = new System.Drawing.Size(50, 20);
           this.txtFirstLayer4.TabIndex = 55;
           this.txtFirstLayer4.Text = "0";
           // 
           // txtFirstLayer3
           // 
           this.txtFirstLayer3.Location = new System.Drawing.Point(285, 218);
           this.txtFirstLayer3.Name = "txtFirstLayer3";
           this.txtFirstLayer3.Size = new System.Drawing.Size(50, 20);
           this.txtFirstLayer3.TabIndex = 57;
           this.txtFirstLayer3.Text = "0";
           // 
           // txtFirstLayer2
           // 
           this.txtFirstLayer2.Location = new System.Drawing.Point(285, 164);
           this.txtFirstLayer2.Name = "txtFirstLayer2";
           this.txtFirstLayer2.Size = new System.Drawing.Size(50, 20);
           this.txtFirstLayer2.TabIndex = 56;
           this.txtFirstLayer2.Text = "0";
           // 
           // txtFirstLayer1
           // 
           this.txtFirstLayer1.Location = new System.Drawing.Point(285, 111);
           this.txtFirstLayer1.Name = "txtFirstLayer1";
           this.txtFirstLayer1.Size = new System.Drawing.Size(50, 20);
           this.txtFirstLayer1.TabIndex = 55;
           this.txtFirstLayer1.Text = "0";
           // 
           // txtFirstLayer0
           // 
           this.txtFirstLayer0.Location = new System.Drawing.Point(285, 56);
           this.txtFirstLayer0.Name = "txtFirstLayer0";
           this.txtFirstLayer0.Size = new System.Drawing.Size(50, 20);
           this.txtFirstLayer0.TabIndex = 54;
           this.txtFirstLayer0.Text = "0";
           // 
           // txtResourceSlave3
           // 
           this.txtResourceSlave3.Location = new System.Drawing.Point(111, 218);
           this.txtResourceSlave3.Name = "txtResourceSlave3";
           this.txtResourceSlave3.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave3.TabIndex = 53;
           this.txtResourceSlave3.Text = "pdna://192.168.100.5/";
           // 
           // txtTimeout
           // 
           this.txtTimeout.Location = new System.Drawing.Point(349, 392);
           this.txtTimeout.Name = "txtTimeout";
           this.txtTimeout.Size = new System.Drawing.Size(105, 20);
           this.txtTimeout.TabIndex = 49;
           this.txtTimeout.Text = "5000";
           // 
           // label22
           // 
           this.label22.AutoSize = true;
           this.label22.Location = new System.Drawing.Point(176, 375);
           this.label22.Name = "label22";
           this.label22.Size = new System.Drawing.Size(94, 13);
           this.label22.TabIndex = 48;
           this.label22.Text = "Samples Per Chan";
           // 
           // label21
           // 
           this.label21.AutoSize = true;
           this.label21.Location = new System.Drawing.Point(346, 376);
           this.label21.Name = "label21";
           this.label21.Size = new System.Drawing.Size(45, 13);
           this.label21.TabIndex = 47;
           this.label21.Text = "Timeout";
           // 
           // label20
           // 
           this.label20.AutoSize = true;
           this.label20.Location = new System.Drawing.Point(31, 375);
           this.label20.Name = "label20";
           this.label20.Size = new System.Drawing.Size(68, 13);
           this.label20.TabIndex = 46;
           this.label20.Text = "Sample Rate";
           // 
           // txtSampleRate
           // 
           this.txtSampleRate.Location = new System.Drawing.Point(34, 392);
           this.txtSampleRate.Name = "txtSampleRate";
           this.txtSampleRate.Size = new System.Drawing.Size(105, 20);
           this.txtSampleRate.TabIndex = 45;
           this.txtSampleRate.Text = "1000";
           // 
           // chkSyncDev
           // 
           this.chkSyncDev.AutoSize = true;
           this.chkSyncDev.ForeColor = System.Drawing.Color.Red;
           this.chkSyncDev.Location = new System.Drawing.Point(349, 443);
           this.chkSyncDev.Name = "chkSyncDev";
           this.chkSyncDev.Size = new System.Drawing.Size(137, 17);
           this.chkSyncDev.TabIndex = 42;
           this.chkSyncDev.Text = "Synchronize all devices";
           this.chkSyncDev.UseVisualStyleBackColor = true;
           // 
           // label16
           // 
           this.label16.AutoSize = true;
           this.label16.Location = new System.Drawing.Point(422, 322);
           this.label16.Name = "label16";
           this.label16.Size = new System.Drawing.Size(61, 13);
           this.label16.TabIndex = 41;
           this.label16.Text = "# Channels";
           // 
           // label17
           // 
           this.label17.AutoSize = true;
           this.label17.Location = new System.Drawing.Point(346, 322);
           this.label17.Name = "label17";
           this.label17.Size = new System.Drawing.Size(48, 13);
           this.label17.TabIndex = 40;
           this.label17.Text = "# Layers";
           // 
           // label18
           // 
           this.label18.AutoSize = true;
           this.label18.Location = new System.Drawing.Point(108, 322);
           this.label18.Name = "label18";
           this.label18.Size = new System.Drawing.Size(92, 13);
           this.label18.TabIndex = 39;
           this.label18.Text = "Slave 5 Resource";
           // 
           // label13
           // 
           this.label13.AutoSize = true;
           this.label13.Location = new System.Drawing.Point(422, 260);
           this.label13.Name = "label13";
           this.label13.Size = new System.Drawing.Size(61, 13);
           this.label13.TabIndex = 38;
           this.label13.Text = "# Channels";
           // 
           // label14
           // 
           this.label14.AutoSize = true;
           this.label14.Location = new System.Drawing.Point(346, 260);
           this.label14.Name = "label14";
           this.label14.Size = new System.Drawing.Size(48, 13);
           this.label14.TabIndex = 37;
           this.label14.Text = "# Layers";
           // 
           // label15
           // 
           this.label15.AutoSize = true;
           this.label15.Location = new System.Drawing.Point(108, 260);
           this.label15.Name = "label15";
           this.label15.Size = new System.Drawing.Size(92, 13);
           this.label15.TabIndex = 36;
           this.label15.Text = "Slave 4 Resource";
           // 
           // label10
           // 
           this.label10.AutoSize = true;
           this.label10.Location = new System.Drawing.Point(422, 201);
           this.label10.Name = "label10";
           this.label10.Size = new System.Drawing.Size(61, 13);
           this.label10.TabIndex = 35;
           this.label10.Text = "# Channels";
           // 
           // label11
           // 
           this.label11.AutoSize = true;
           this.label11.Location = new System.Drawing.Point(346, 201);
           this.label11.Name = "label11";
           this.label11.Size = new System.Drawing.Size(48, 13);
           this.label11.TabIndex = 34;
           this.label11.Text = "# Layers";
           // 
           // label12
           // 
           this.label12.AutoSize = true;
           this.label12.Location = new System.Drawing.Point(108, 201);
           this.label12.Name = "label12";
           this.label12.Size = new System.Drawing.Size(92, 13);
           this.label12.TabIndex = 33;
           this.label12.Text = "Slave 3 Resource";
           // 
           // label8
           // 
           this.label8.AutoSize = true;
           this.label8.Location = new System.Drawing.Point(422, 148);
           this.label8.Name = "label8";
           this.label8.Size = new System.Drawing.Size(61, 13);
           this.label8.TabIndex = 32;
           this.label8.Text = "# Channels";
           // 
           // label9
           // 
           this.label9.AutoSize = true;
           this.label9.Location = new System.Drawing.Point(346, 148);
           this.label9.Name = "label9";
           this.label9.Size = new System.Drawing.Size(48, 13);
           this.label9.TabIndex = 31;
           this.label9.Text = "# Layers";
           // 
           // label7
           // 
           this.label7.AutoSize = true;
           this.label7.Location = new System.Drawing.Point(108, 148);
           this.label7.Name = "label7";
           this.label7.Size = new System.Drawing.Size(92, 13);
           this.label7.TabIndex = 30;
           this.label7.Text = "Slave 2 Resource";
           // 
           // label5
           // 
           this.label5.AutoSize = true;
           this.label5.Location = new System.Drawing.Point(422, 96);
           this.label5.Name = "label5";
           this.label5.Size = new System.Drawing.Size(61, 13);
           this.label5.TabIndex = 29;
           this.label5.Text = "# Channels";
           // 
           // label6
           // 
           this.label6.AutoSize = true;
           this.label6.Location = new System.Drawing.Point(346, 96);
           this.label6.Name = "label6";
           this.label6.Size = new System.Drawing.Size(48, 13);
           this.label6.TabIndex = 28;
           this.label6.Text = "# Layers";
           // 
           // label4
           // 
           this.label4.AutoSize = true;
           this.label4.Location = new System.Drawing.Point(108, 96);
           this.label4.Name = "label4";
           this.label4.Size = new System.Drawing.Size(92, 13);
           this.label4.TabIndex = 27;
           this.label4.Text = "Slave 1 Resource";
           // 
           // label3
           // 
           this.label3.AutoSize = true;
           this.label3.Location = new System.Drawing.Point(422, 40);
           this.label3.Name = "label3";
           this.label3.Size = new System.Drawing.Size(61, 13);
           this.label3.TabIndex = 26;
           this.label3.Text = "# Channels";
           // 
           // label2
           // 
           this.label2.AutoSize = true;
           this.label2.Location = new System.Drawing.Point(346, 40);
           this.label2.Name = "label2";
           this.label2.Size = new System.Drawing.Size(48, 13);
           this.label2.TabIndex = 25;
           this.label2.Text = "# Layers";
           // 
           // label1
           // 
           this.label1.AutoSize = true;
           this.label1.Location = new System.Drawing.Point(108, 40);
           this.label1.Name = "label1";
           this.label1.Size = new System.Drawing.Size(119, 13);
           this.label1.TabIndex = 24;
           this.label1.Text = "Master Cube  Resource";
           // 
           // txtNumChanSlave5
           // 
           this.txtNumChanSlave5.Location = new System.Drawing.Point(425, 338);
           this.txtNumChanSlave5.Name = "txtNumChanSlave5";
           this.txtNumChanSlave5.Size = new System.Drawing.Size(50, 20);
           this.txtNumChanSlave5.TabIndex = 23;
           this.txtNumChanSlave5.Text = "16";
           // 
           // txtNumLayersSlave5
           // 
           this.txtNumLayersSlave5.Location = new System.Drawing.Point(349, 338);
           this.txtNumLayersSlave5.Name = "txtNumLayersSlave5";
           this.txtNumLayersSlave5.Size = new System.Drawing.Size(50, 20);
           this.txtNumLayersSlave5.TabIndex = 22;
           this.txtNumLayersSlave5.Text = "6";
           // 
           // txtNumChanSlave4
           // 
           this.txtNumChanSlave4.Location = new System.Drawing.Point(425, 276);
           this.txtNumChanSlave4.Name = "txtNumChanSlave4";
           this.txtNumChanSlave4.Size = new System.Drawing.Size(50, 20);
           this.txtNumChanSlave4.TabIndex = 21;
           this.txtNumChanSlave4.Text = "16";
           // 
           // txtNumLayersSlave4
           // 
           this.txtNumLayersSlave4.Location = new System.Drawing.Point(349, 276);
           this.txtNumLayersSlave4.Name = "txtNumLayersSlave4";
           this.txtNumLayersSlave4.Size = new System.Drawing.Size(50, 20);
           this.txtNumLayersSlave4.TabIndex = 20;
           this.txtNumLayersSlave4.Text = "6";
           // 
           // txtNumChanSlave3
           // 
           this.txtNumChanSlave3.Location = new System.Drawing.Point(425, 218);
           this.txtNumChanSlave3.Name = "txtNumChanSlave3";
           this.txtNumChanSlave3.Size = new System.Drawing.Size(50, 20);
           this.txtNumChanSlave3.TabIndex = 19;
           this.txtNumChanSlave3.Text = "16";
           // 
           // txtNumLayersSlave3
           // 
           this.txtNumLayersSlave3.Location = new System.Drawing.Point(349, 218);
           this.txtNumLayersSlave3.Name = "txtNumLayersSlave3";
           this.txtNumLayersSlave3.Size = new System.Drawing.Size(50, 20);
           this.txtNumLayersSlave3.TabIndex = 18;
           this.txtNumLayersSlave3.Text = "6";
           // 
           // txtNumChanSlave2
           // 
           this.txtNumChanSlave2.Location = new System.Drawing.Point(425, 164);
           this.txtNumChanSlave2.Name = "txtNumChanSlave2";
           this.txtNumChanSlave2.Size = new System.Drawing.Size(50, 20);
           this.txtNumChanSlave2.TabIndex = 17;
           this.txtNumChanSlave2.Text = "16";
           // 
           // txtNumLayersSlave2
           // 
           this.txtNumLayersSlave2.Location = new System.Drawing.Point(349, 164);
           this.txtNumLayersSlave2.Name = "txtNumLayersSlave2";
           this.txtNumLayersSlave2.Size = new System.Drawing.Size(50, 20);
           this.txtNumLayersSlave2.TabIndex = 16;
           this.txtNumLayersSlave2.Text = "6";
           // 
           // txtNumChanSlave1
           // 
           this.txtNumChanSlave1.Location = new System.Drawing.Point(425, 112);
           this.txtNumChanSlave1.Name = "txtNumChanSlave1";
           this.txtNumChanSlave1.Size = new System.Drawing.Size(50, 20);
           this.txtNumChanSlave1.TabIndex = 15;
           this.txtNumChanSlave1.Text = "10";
           // 
           // txtNumLayersSlave1
           // 
           this.txtNumLayersSlave1.Location = new System.Drawing.Point(349, 112);
           this.txtNumLayersSlave1.Name = "txtNumLayersSlave1";
           this.txtNumLayersSlave1.Size = new System.Drawing.Size(50, 20);
           this.txtNumLayersSlave1.TabIndex = 14;
           this.txtNumLayersSlave1.Text = "1";
           // 
           // txtNumChanSlave0
           // 
           this.txtNumChanSlave0.Location = new System.Drawing.Point(425, 56);
           this.txtNumChanSlave0.Name = "txtNumChanSlave0";
           this.txtNumChanSlave0.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
           this.txtNumChanSlave0.Size = new System.Drawing.Size(50, 20);
           this.txtNumChanSlave0.TabIndex = 13;
           this.txtNumChanSlave0.Text = "10";
           // 
           // txtNumLayersSlave0
           // 
           this.txtNumLayersSlave0.Location = new System.Drawing.Point(349, 56);
           this.txtNumLayersSlave0.Name = "txtNumLayersSlave0";
           this.txtNumLayersSlave0.Size = new System.Drawing.Size(50, 20);
           this.txtNumLayersSlave0.TabIndex = 12;
           this.txtNumLayersSlave0.Text = "1";
           // 
           // chkEnabledSlave5
           // 
           this.chkEnabledSlave5.AutoSize = true;
           this.chkEnabledSlave5.Location = new System.Drawing.Point(34, 341);
           this.chkEnabledSlave5.Name = "chkEnabledSlave5";
           this.chkEnabledSlave5.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave5.TabIndex = 11;
           this.chkEnabledSlave5.Text = "Enabled";
           this.chkEnabledSlave5.UseVisualStyleBackColor = true;
           // 
           // chkEnabledSlave4
           // 
           this.chkEnabledSlave4.AutoSize = true;
           this.chkEnabledSlave4.Location = new System.Drawing.Point(34, 279);
           this.chkEnabledSlave4.Name = "chkEnabledSlave4";
           this.chkEnabledSlave4.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave4.TabIndex = 10;
           this.chkEnabledSlave4.Text = "Enabled";
           this.chkEnabledSlave4.UseVisualStyleBackColor = true;
           // 
           // chkEnabledSlave3
           // 
           this.chkEnabledSlave3.AutoSize = true;
           this.chkEnabledSlave3.Location = new System.Drawing.Point(34, 221);
           this.chkEnabledSlave3.Name = "chkEnabledSlave3";
           this.chkEnabledSlave3.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave3.TabIndex = 9;
           this.chkEnabledSlave3.Text = "Enabled";
           this.chkEnabledSlave3.UseVisualStyleBackColor = true;
           // 
           // txtResourceSlave5
           // 
           this.txtResourceSlave5.Location = new System.Drawing.Point(111, 338);
           this.txtResourceSlave5.Name = "txtResourceSlave5";
           this.txtResourceSlave5.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave5.TabIndex = 8;
           this.txtResourceSlave5.Text = "pdna://192.168.100.7/";
           // 
           // txtResourceSlave4
           // 
           this.txtResourceSlave4.Location = new System.Drawing.Point(111, 276);
           this.txtResourceSlave4.Name = "txtResourceSlave4";
           this.txtResourceSlave4.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave4.TabIndex = 7;
           this.txtResourceSlave4.Text = "pdna://192.168.100.6/";
           // 
           // txtSamPerChan
           // 
           this.txtSamPerChan.Location = new System.Drawing.Point(179, 391);
           this.txtSamPerChan.Name = "txtSamPerChan";
           this.txtSamPerChan.Size = new System.Drawing.Size(97, 20);
           this.txtSamPerChan.TabIndex = 6;
           this.txtSamPerChan.Text = "20";
           // 
           // chkEnabledSlave2
           // 
           this.chkEnabledSlave2.AutoSize = true;
           this.chkEnabledSlave2.Location = new System.Drawing.Point(34, 167);
           this.chkEnabledSlave2.Name = "chkEnabledSlave2";
           this.chkEnabledSlave2.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave2.TabIndex = 5;
           this.chkEnabledSlave2.Text = "Enabled";
           this.chkEnabledSlave2.UseVisualStyleBackColor = true;
           // 
           // chkEnabledSlave1
           // 
           this.chkEnabledSlave1.AutoSize = true;
           this.chkEnabledSlave1.Location = new System.Drawing.Point(34, 114);
           this.chkEnabledSlave1.Name = "chkEnabledSlave1";
           this.chkEnabledSlave1.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave1.TabIndex = 4;
           this.chkEnabledSlave1.Text = "Enabled";
           this.chkEnabledSlave1.UseVisualStyleBackColor = true;
           // 
           // chkEnabledSlave0
           // 
           this.chkEnabledSlave0.AutoSize = true;
           this.chkEnabledSlave0.Location = new System.Drawing.Point(34, 59);
           this.chkEnabledSlave0.Name = "chkEnabledSlave0";
           this.chkEnabledSlave0.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave0.TabIndex = 3;
           this.chkEnabledSlave0.Text = "Enabled";
           this.chkEnabledSlave0.UseVisualStyleBackColor = true;
           // 
           // txtResourceSlave2
           // 
           this.txtResourceSlave2.Location = new System.Drawing.Point(111, 164);
           this.txtResourceSlave2.Name = "txtResourceSlave2";
           this.txtResourceSlave2.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave2.TabIndex = 2;
           this.txtResourceSlave2.Text = "pdna://192.168.100.4/";
           // 
           // txtResourceSlave1
           // 
           this.txtResourceSlave1.Location = new System.Drawing.Point(111, 111);
           this.txtResourceSlave1.Name = "txtResourceSlave1";
           this.txtResourceSlave1.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave1.TabIndex = 1;
           this.txtResourceSlave1.Text = "pdna://192.168.100.3/";
           // 
           // Status
           // 
           this.Status.Controls.Add(this.btnQuit);
           this.Status.Controls.Add(this.btnStop);
           this.Status.Controls.Add(this.btnStart);
           this.Status.Controls.Add(this.lstStatusList);
           this.Status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
           this.Status.Location = new System.Drawing.Point(12, 516);
           this.Status.Name = "Status";
           this.Status.Size = new System.Drawing.Size(499, 257);
           this.Status.TabIndex = 2;
           this.Status.TabStop = false;
           this.Status.Text = "Status";
           // 
           // btnQuit
           // 
           this.btnQuit.Location = new System.Drawing.Point(337, 190);
           this.btnQuit.Name = "btnQuit";
           this.btnQuit.Size = new System.Drawing.Size(126, 42);
           this.btnQuit.TabIndex = 8;
           this.btnQuit.Text = "Quit";
           this.btnQuit.UseVisualStyleBackColor = true;
           this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
           // 
           // btnStop
           // 
           this.btnStop.Location = new System.Drawing.Point(196, 189);
           this.btnStop.Name = "btnStop";
           this.btnStop.Size = new System.Drawing.Size(126, 42);
           this.btnStop.TabIndex = 7;
           this.btnStop.Text = "Stop";
           this.btnStop.UseVisualStyleBackColor = true;
           this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
           // 
           // btnStart
           // 
           this.btnStart.Location = new System.Drawing.Point(48, 189);
           this.btnStart.Name = "btnStart";
           this.btnStart.Size = new System.Drawing.Size(126, 42);
           this.btnStart.TabIndex = 6;
           this.btnStart.Text = "Start";
           this.btnStart.UseVisualStyleBackColor = true;
           this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
           // 
           // lstStatusList
           // 
           this.lstStatusList.Location = new System.Drawing.Point(29, 31);
           this.lstStatusList.Name = "lstStatusList";
           this.lstStatusList.Size = new System.Drawing.Size(457, 141);
           this.lstStatusList.TabIndex = 0;
           this.lstStatusList.UseCompatibleStateImageBehavior = false;
           // 
           // txtErrorText
           // 
           this.txtErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
           this.txtErrorText.Location = new System.Drawing.Point(0, 761);
           this.txtErrorText.Multiline = true;
           this.txtErrorText.Name = "txtErrorText";
           this.txtErrorText.ReadOnly = true;
           this.txtErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
           this.txtErrorText.Size = new System.Drawing.Size(550, 48);
           this.txtErrorText.TabIndex = 19;
           // 
           // frmMain
           // 
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.ClientSize = new System.Drawing.Size(550, 809);
           this.Controls.Add(this.txtErrorText);
           this.Controls.Add(this.Status);
           this.Controls.Add(this.groupBox1);
           this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
           this.Name = "frmMain";
           this.Text = "AIMultipleSynchronizedCubes";
           this.Load += new System.EventHandler(this.Form1_Load);
           this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_Closing);
           this.groupBox1.ResumeLayout(false);
           this.groupBox1.PerformLayout();
           this.Status.ResumeLayout(false);
           this.ResumeLayout(false);
           this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtResourceSlave0;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtNumChanSlave5;
        private System.Windows.Forms.TextBox txtNumLayersSlave5;
        private System.Windows.Forms.TextBox txtNumChanSlave4;
        private System.Windows.Forms.TextBox txtNumLayersSlave4;
        private System.Windows.Forms.TextBox txtNumChanSlave3;
        private System.Windows.Forms.TextBox txtNumLayersSlave3;
        private System.Windows.Forms.TextBox txtNumChanSlave2;
        private System.Windows.Forms.TextBox txtNumLayersSlave2;
        private System.Windows.Forms.TextBox txtNumChanSlave1;
        private System.Windows.Forms.TextBox txtNumLayersSlave1;
        private System.Windows.Forms.TextBox txtNumChanSlave0;
        private System.Windows.Forms.TextBox txtNumLayersSlave0;
        private System.Windows.Forms.CheckBox chkEnabledSlave5;
        private System.Windows.Forms.CheckBox chkEnabledSlave4;
        private System.Windows.Forms.CheckBox chkEnabledSlave3;
        private System.Windows.Forms.TextBox txtResourceSlave5;
        private System.Windows.Forms.TextBox txtResourceSlave4;
        private System.Windows.Forms.TextBox txtSamPerChan;
        private System.Windows.Forms.CheckBox chkEnabledSlave2;
        private System.Windows.Forms.CheckBox chkEnabledSlave1;
        private System.Windows.Forms.CheckBox chkEnabledSlave0;
        private System.Windows.Forms.TextBox txtResourceSlave2;
        private System.Windows.Forms.TextBox txtResourceSlave1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox chkSyncDev;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtSampleRate;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtTimeout;
        private System.Windows.Forms.TextBox txtResourceSlave3;
        private System.Windows.Forms.GroupBox Status;
        private System.Windows.Forms.ListView lstStatusList;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.TextBox txtErrorText;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.TextBox txtFirstLayer0;
        private System.Windows.Forms.TextBox txtFirstLayer5;
        private System.Windows.Forms.TextBox txtFirstLayer4;
        private System.Windows.Forms.TextBox txtFirstLayer3;
        private System.Windows.Forms.TextBox txtFirstLayer2;
        private System.Windows.Forms.TextBox txtFirstLayer1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
    }
}

