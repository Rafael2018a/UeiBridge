﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace I2CLoopback
{
    class Program
    {
        static void Main(string[] args)
        {
            int rxSize = 255;
            int slaveTxSize = 4;
            int slaveAddress = 0x12;
            string i2cMasterResource = "pdna://192.168.100.4/Dev0/i2c0";
            string i2cSlaveResource = "pdna://192.168.100.4/Dev0/i2c0";

            I2CReader masterReader, slaveReader;
            I2CWriter masterWriter, slaveWriter;

            // register CTRL + c handler
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

            try {
                // Configure Master session
                Session mySession = new Session();
                I2CMasterPort masterPort = mySession.CreateI2CMasterPort(i2cMasterResource,
                                                                   I2CPortSpeed.BitsPerSecond100K,
                                                                   I2CTTLLevel.TTLLevel3_3V,
                                                                   false);
                I2CSlavePort slavePort = mySession.CreateI2CSlavePort(i2cSlaveResource,
                                                                      I2CTTLLevel.TTLLevel3_3V,
                                                                      (slaveAddress & 0x380) != 0 ?
                                                                        I2CSlaveAddressWidth.SlaveAddress10bit :
                                                                        I2CSlaveAddressWidth.SlaveAddress7bit,
                                                                      slaveAddress);

                mySession.ConfigureTimingForMessagingIO(1, 0);

                masterPort.SetLoopbackMode(UeiDaq.I2CLoopback.Relay);

                // Configure writer and reader for each channel
                masterWriter = new I2CWriter(mySession.GetDataStream(), masterPort.GetIndex());
                masterReader = new I2CReader(mySession.GetDataStream(), masterPort.GetIndex());

                slaveWriter = new I2CWriter(mySession.GetDataStream(), slavePort.GetIndex());
                slaveReader = new I2CReader(mySession.GetDataStream(), slavePort.GetIndex());

                mySession.Start();

                int sendCount = 0;
                while (!stop && sendCount < 10) {

                    if (sendCount % 2 == 0) {
                        Console.WriteLine("Write Command");

                        I2CMasterCommand comParams = new I2CMasterCommand();
                        comParams.type = I2CCommand.Write;
                        comParams.slaveAddress = slaveAddress;
                        comParams.numWriteElements = 4;
                        comParams.data = new byte[comParams.numWriteElements];
                        for (int i = 0; i < comParams.numWriteElements; i++) {
                            comParams.data[i] = (byte)(i * 2);
                        }
                        // comParams.numReadElements - not used for Write command

                        // Transmit Write command
                        masterWriter.WriteMasterCommand(comParams);

                        Thread.Sleep(1);

                        // Read data slave received
                        I2CSlaveMessage[] slaveBuf = slaveReader.ReadSlave(rxSize);

                        Console.WriteLine("Read {0} elements from slave", slaveBuf.Length);
                        for (int i = 0; i < slaveBuf.Length; i++) {
                            Console.WriteLine("[{0}]: Type={1} Data=0x{2:X}", i, slaveBuf[i].busCode, slaveBuf[i].data);
                        }
                        Console.WriteLine();
                    } else {
                        Console.WriteLine("Read Command");

                        // Provide slave with data to transmit when receiving a read request
                        ushort[] txBuf = new ushort[slaveTxSize];
                        for (int i = 0; i < slaveTxSize; i++) {
                            txBuf[i] = (ushort)(0xffff - i);
                        }
                        slaveWriter.WriteSlaveData(txBuf);

                        I2CMasterCommand comParams = new I2CMasterCommand();
                        comParams.type = I2CCommand.Read;
                        comParams.slaveAddress = slaveAddress;
                        comParams.numReadElements = slaveTxSize;
                        // comParams.data - not used for Read command
                        // comParams.numWriteElements - not used for Read command

                        masterWriter.WriteMasterCommand(comParams);

                        Thread.Sleep(1);

                        // Read data returned to master from slave
                        I2CMasterMessage[] masterBuf = masterReader.ReadMaster(rxSize);
                        Console.WriteLine("Read {0} elements from master", masterBuf.Length);
                        for (int i = 0; i < masterBuf.Length; i++) {
                            Console.WriteLine("[{0}]: stopBit={1} Data=0x{2:X}", i, masterBuf[i].stopBit, masterBuf[i].data);
                        }

                        // Read data stored by slave
                        I2CSlaveMessage[] slaveBuf = slaveReader.ReadSlave(rxSize);
                        Console.WriteLine("Read {0} elements from slave", slaveBuf.Length);
                        for (int i = 0; i < slaveBuf.Length; i++) {
                            Console.WriteLine("[{0}]: Type={1} Data=0x{2:X}", i, slaveBuf[i].busCode, slaveBuf[i].data);
                        }
                        Console.WriteLine();
                    }

                    Thread.Sleep(1000);
                    sendCount++;
                }

                mySession.Stop();
            } catch (UeiDaqException exception) {
                Console.WriteLine();
                Console.WriteLine("Error: ({0}) {1}", exception.Error, exception.Message);
            }
        }

        protected static void myHandler(object sender, ConsoleCancelEventArgs args)
        {
            // Set cancel to true to let the Main task clean-up the I/O sessions
            args.Cancel = true;
            stop = true;
        }

        static bool stop = false;
    }
}
