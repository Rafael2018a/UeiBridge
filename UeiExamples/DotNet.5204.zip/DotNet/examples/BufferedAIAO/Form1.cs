using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using UeiDaq;

namespace BufferedAIAO
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.GroupBox AnalogInputbox;
      private System.Windows.Forms.Label label6;
      private System.Windows.Forms.Label NbSc_label;
      private System.Windows.Forms.GroupBox AnalogOutputBox;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.TextBox AIResource;
      private System.Windows.Forms.TextBox AOResource;
      private System.Windows.Forms.TextBox AIRate;
      private System.Windows.Forms.TextBox AINumScans;
      private System.Windows.Forms.TextBox AORate;
      private System.Windows.Forms.TextBox AONumScans;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.Label label7;
      private System.Windows.Forms.TextBox AIAvailableScans;
      private System.Windows.Forms.TextBox AITotalScans;
      private System.Windows.Forms.TextBox AOAvailableUpdates;
      private System.Windows.Forms.TextBox AOTotalUpdates;
      private System.Windows.Forms.Label label8;
      private System.Windows.Forms.Label label9;
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.Label label10;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

      private Session aiSs = null;
      private AnalogScaledReader aiReader;
      private AsyncCallback   aiReaderCallback;
      private IAsyncResult aiReaderIAsyncResult;
      private Session aoSs = null;
      private AnalogScaledWriter aoWriter;
      private AsyncCallback   aoWriterCallback;
      private IAsyncResult aoWriterIAsyncResult;
      private delegate void UpdateUIDelegate(String errorMessage);

      private int aoIteration = 0;


		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.AIResource = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.AOResource = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.AnalogInputbox = new System.Windows.Forms.GroupBox();
         this.AIAvailableScans = new System.Windows.Forms.TextBox();
         this.AITotalScans = new System.Windows.Forms.TextBox();
         this.label5 = new System.Windows.Forms.Label();
         this.label7 = new System.Windows.Forms.Label();
         this.label6 = new System.Windows.Forms.Label();
         this.AIRate = new System.Windows.Forms.TextBox();
         this.AINumScans = new System.Windows.Forms.TextBox();
         this.NbSc_label = new System.Windows.Forms.Label();
         this.AnalogOutputBox = new System.Windows.Forms.GroupBox();
         this.AOAvailableUpdates = new System.Windows.Forms.TextBox();
         this.AOTotalUpdates = new System.Windows.Forms.TextBox();
         this.label8 = new System.Windows.Forms.Label();
         this.label9 = new System.Windows.Forms.Label();
         this.label3 = new System.Windows.Forms.Label();
         this.AORate = new System.Windows.Forms.TextBox();
         this.AONumScans = new System.Windows.Forms.TextBox();
         this.label4 = new System.Windows.Forms.Label();
         this.Stop = new System.Windows.Forms.Button();
         this.Quit = new System.Windows.Forms.Button();
         this.Go = new System.Windows.Forms.Button();
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.label10 = new System.Windows.Forms.Label();
         this.AnalogInputbox.SuspendLayout();
         this.AnalogOutputBox.SuspendLayout();
         this.SuspendLayout();
         // 
         // AIResource
         // 
         this.AIResource.Location = new System.Drawing.Point(16, 40);
         this.AIResource.Name = "AIResource";
         this.AIResource.Size = new System.Drawing.Size(240, 20);
         this.AIResource.TabIndex = 10;
         this.AIResource.Text = "simu://Dev0/Ai0:3";
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(16, 24);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(104, 16);
         this.label2.TabIndex = 11;
         this.label2.Text = "Resource name";
         // 
         // AOResource
         // 
         this.AOResource.Location = new System.Drawing.Point(16, 40);
         this.AOResource.Name = "AOResource";
         this.AOResource.Size = new System.Drawing.Size(240, 20);
         this.AOResource.TabIndex = 12;
         this.AOResource.Text = "simu://Dev0/AO0:1";
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(16, 24);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(120, 16);
         this.label1.TabIndex = 13;
         this.label1.Text = "Resource name";
         // 
         // AnalogInputbox
         // 
         this.AnalogInputbox.Controls.Add(this.AIAvailableScans);
         this.AnalogInputbox.Controls.Add(this.AITotalScans);
         this.AnalogInputbox.Controls.Add(this.label5);
         this.AnalogInputbox.Controls.Add(this.label7);
         this.AnalogInputbox.Controls.Add(this.label6);
         this.AnalogInputbox.Controls.Add(this.AIRate);
         this.AnalogInputbox.Controls.Add(this.AINumScans);
         this.AnalogInputbox.Controls.Add(this.NbSc_label);
         this.AnalogInputbox.Controls.Add(this.label2);
         this.AnalogInputbox.Controls.Add(this.AIResource);
         this.AnalogInputbox.Location = new System.Drawing.Point(8, 8);
         this.AnalogInputbox.Name = "AnalogInputbox";
         this.AnalogInputbox.Size = new System.Drawing.Size(272, 248);
         this.AnalogInputbox.TabIndex = 14;
         this.AnalogInputbox.TabStop = false;
         this.AnalogInputbox.Text = "Analog Input";
         // 
         // AIAvailableScans
         // 
         this.AIAvailableScans.Location = new System.Drawing.Point(16, 216);
         this.AIAvailableScans.Name = "AIAvailableScans";
         this.AIAvailableScans.ReadOnly = true;
         this.AIAvailableScans.Size = new System.Drawing.Size(112, 20);
         this.AIAvailableScans.TabIndex = 27;
         this.AIAvailableScans.Text = "";
         // 
         // AITotalScans
         // 
         this.AITotalScans.Location = new System.Drawing.Point(16, 176);
         this.AITotalScans.Name = "AITotalScans";
         this.AITotalScans.ReadOnly = true;
         this.AITotalScans.Size = new System.Drawing.Size(112, 20);
         this.AITotalScans.TabIndex = 26;
         this.AITotalScans.Text = "";
         // 
         // label5
         // 
         this.label5.Location = new System.Drawing.Point(16, 200);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(96, 16);
         this.label5.TabIndex = 29;
         this.label5.Text = "Available scans";
         // 
         // label7
         // 
         this.label7.Location = new System.Drawing.Point(16, 160);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(88, 16);
         this.label7.TabIndex = 28;
         this.label7.Text = "Total scans";
         // 
         // label6
         // 
         this.label6.Location = new System.Drawing.Point(16, 112);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(128, 16);
         this.label6.TabIndex = 25;
         this.label6.Text = "Scan rate";
         // 
         // AIRate
         // 
         this.AIRate.Location = new System.Drawing.Point(16, 128);
         this.AIRate.Name = "AIRate";
         this.AIRate.Size = new System.Drawing.Size(112, 20);
         this.AIRate.TabIndex = 24;
         this.AIRate.Text = "1000";
         // 
         // AINumScans
         // 
         this.AINumScans.Location = new System.Drawing.Point(16, 88);
         this.AINumScans.Name = "AINumScans";
         this.AINumScans.Size = new System.Drawing.Size(112, 20);
         this.AINumScans.TabIndex = 22;
         this.AINumScans.Text = "1000";
         // 
         // NbSc_label
         // 
         this.NbSc_label.Location = new System.Drawing.Point(16, 72);
         this.NbSc_label.Name = "NbSc_label";
         this.NbSc_label.Size = new System.Drawing.Size(96, 16);
         this.NbSc_label.TabIndex = 23;
         this.NbSc_label.Text = "Number of Scans";
         // 
         // AnalogOutputBox
         // 
         this.AnalogOutputBox.Controls.Add(this.AOAvailableUpdates);
         this.AnalogOutputBox.Controls.Add(this.AOTotalUpdates);
         this.AnalogOutputBox.Controls.Add(this.label8);
         this.AnalogOutputBox.Controls.Add(this.label9);
         this.AnalogOutputBox.Controls.Add(this.label3);
         this.AnalogOutputBox.Controls.Add(this.AORate);
         this.AnalogOutputBox.Controls.Add(this.AONumScans);
         this.AnalogOutputBox.Controls.Add(this.label4);
         this.AnalogOutputBox.Controls.Add(this.AOResource);
         this.AnalogOutputBox.Controls.Add(this.label1);
         this.AnalogOutputBox.Location = new System.Drawing.Point(296, 8);
         this.AnalogOutputBox.Name = "AnalogOutputBox";
         this.AnalogOutputBox.Size = new System.Drawing.Size(272, 248);
         this.AnalogOutputBox.TabIndex = 15;
         this.AnalogOutputBox.TabStop = false;
         this.AnalogOutputBox.Text = "Analog Output";
         // 
         // AOAvailableUpdates
         // 
         this.AOAvailableUpdates.Location = new System.Drawing.Point(16, 216);
         this.AOAvailableUpdates.Name = "AOAvailableUpdates";
         this.AOAvailableUpdates.ReadOnly = true;
         this.AOAvailableUpdates.Size = new System.Drawing.Size(112, 20);
         this.AOAvailableUpdates.TabIndex = 31;
         this.AOAvailableUpdates.Text = "";
         // 
         // AOTotalUpdates
         // 
         this.AOTotalUpdates.Location = new System.Drawing.Point(16, 176);
         this.AOTotalUpdates.Name = "AOTotalUpdates";
         this.AOTotalUpdates.ReadOnly = true;
         this.AOTotalUpdates.Size = new System.Drawing.Size(112, 20);
         this.AOTotalUpdates.TabIndex = 30;
         this.AOTotalUpdates.Text = "";
         // 
         // label8
         // 
         this.label8.Location = new System.Drawing.Point(16, 200);
         this.label8.Name = "label8";
         this.label8.Size = new System.Drawing.Size(96, 16);
         this.label8.TabIndex = 33;
         this.label8.Text = "Available updates";
         // 
         // label9
         // 
         this.label9.Location = new System.Drawing.Point(16, 160);
         this.label9.Name = "label9";
         this.label9.Size = new System.Drawing.Size(88, 16);
         this.label9.TabIndex = 32;
         this.label9.Text = "Total updates";
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(16, 112);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(128, 16);
         this.label3.TabIndex = 25;
         this.label3.Text = "Update rate";
         // 
         // AORate
         // 
         this.AORate.Location = new System.Drawing.Point(16, 128);
         this.AORate.Name = "AORate";
         this.AORate.Size = new System.Drawing.Size(112, 20);
         this.AORate.TabIndex = 24;
         this.AORate.Text = "1000";
         // 
         // AONumScans
         // 
         this.AONumScans.Location = new System.Drawing.Point(16, 88);
         this.AONumScans.Name = "AONumScans";
         this.AONumScans.Size = new System.Drawing.Size(112, 20);
         this.AONumScans.TabIndex = 22;
         this.AONumScans.Text = "1000";
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(16, 72);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(120, 16);
         this.label4.TabIndex = 23;
         this.label4.Text = "Number of Updates";
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(224, 264);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(144, 40);
         this.Stop.TabIndex = 18;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(416, 264);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(144, 40);
         this.Quit.TabIndex = 17;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(16, 264);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(144, 40);
         this.Go.TabIndex = 16;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // ErrorText
         // 
         this.ErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
         this.ErrorText.Location = new System.Drawing.Point(0, 334);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(576, 48);
         this.ErrorText.TabIndex = 19;
         this.ErrorText.Text = "";
         // 
         // label10
         // 
         this.label10.Location = new System.Drawing.Point(0, 312);
         this.label10.Name = "label10";
         this.label10.Size = new System.Drawing.Size(88, 16);
         this.label10.TabIndex = 20;
         this.label10.Text = "Error Messages";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(576, 382);
         this.Controls.Add(this.label10);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Controls.Add(this.AnalogOutputBox);
         this.Controls.Add(this.AnalogInputbox);
         this.Name = "Form1";
         this.Text = "BufferedAIAO";
         this.Load += new System.EventHandler(this.Form1_Load);
         this.AnalogInputbox.ResumeLayout(false);
         this.AnalogOutputBox.ResumeLayout(false);
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private void Form1_Load(object sender, System.EventArgs e)
      {
      
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         UeiDaqStart();
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();
         Application.Exit();
      }

      private void UeiDaqStart()
      {
         aiSs = new Session();
         aoSs = new Session();

         try
         {
            ErrorText.Clear();
            
            aiSs.CreateAIChannel(AIResource.Text, -10.0, 10.0, AIChannelInputMode.Differential);
            aoSs.CreateAOChannel(AOResource.Text, -10.0, 10.0);

            aiSs.ConfigureTimingForBufferedIO(Int32.Parse(AINumScans.Text), 
                                              TimingClockSource.Internal, 
                                              Int32.Parse(AIRate.Text),
                                              DigitalEdge.Rising, 
                                              TimingDuration.Continuous);
            aiSs.GetTiming().SetTimeout(5000);

            aoSs.ConfigureTimingForBufferedIO(Int32.Parse(AONumScans.Text), 
                                              TimingClockSource.Internal, 
                                              Int32.Parse(AORate.Text),
                                              DigitalEdge.Rising, 
                                              TimingDuration.Continuous);
            aoSs.GetTiming().SetTimeout(5000);

            // Create a reader object to read data from the ai session.
            aiReader = new AnalogScaledReader(aiSs.GetDataStream());

            // Create a writer object to write data to the ao session.
            aoWriter = new AnalogScaledWriter(aoSs.GetDataStream());

            // Start the sessions
            aiSs.Start();
            aoSs.Start();

            aiReaderCallback = new AsyncCallback(AIReaderCallbackProc);
            aiReaderIAsyncResult = aiReader.BeginReadMultipleScans(Int32.Parse(AINumScans.Text), aiReaderCallback, Int32.Parse(AINumScans.Text));

            double[,] data = new double[Int32.Parse(AONumScans.Text),aoSs.GetDataStream().GetScanSize()];
            GenerateSinWave(data, aoSs.GetDataStream().GetScanSize(), aoSs.GetDataStream().GetNumberOfScans(), 0);
            
            aoWriterCallback = new AsyncCallback(AOWriterCallbackProc);
            aoWriterIAsyncResult = aoWriter.BeginWriteMultipleScans(aoWriterCallback, Int32.Parse(AONumScans.Text), Int32.Parse(AONumScans.Text), data);
            
            AINumScans.Enabled = false;
            AIRate.Enabled = false;
            AIResource.Enabled = false;

            AONumScans.Enabled = false;
            AORate.Enabled = false;
            AOResource.Enabled = false;
            Go.Enabled = false;
         }
         catch(UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            aiSs.Dispose();
            aiSs = null;

            aoSs.Dispose();
            aoSs = null;
         }
      }

      private void UeiDaqStop()
      {
         if(aiSs != null)
         {
            try
            {
               aiSs.Stop();
               
               // wait for current async call to complete
               // before destroying the session
               aiReaderIAsyncResult.AsyncWaitHandle.WaitOne();
            }
            catch(UeiDaqException exception)
            {
               ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }

            aiSs.Dispose();
            aiSs = null;
         }

         if(aoSs != null)
         {
            try
            {
               aoSs.Stop();
               
               // wait for current async call to complete
               // before destroying the session
               aoWriterIAsyncResult.AsyncWaitHandle.WaitOne();
            }
            catch(UeiDaqException exception)
            {
               ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }

            aoSs.Dispose();
            aoSs = null;
         }

         AINumScans.Enabled = true;
         AIRate.Enabled = true;
         AIResource.Enabled = true;

         AONumScans.Enabled = true;
         AORate.Enabled = true;
         AOResource.Enabled = true;

         Go.Enabled = true;
      }

      private void AIReaderCallbackProc(IAsyncResult ar)
      {
         double[,] data;
         
         try
         {
            int numScans = (int)ar.AsyncState;
            data = aiReader.EndReadMultipleScans(ar);

            UpdateUI("");

            if (aiSs != null && aiSs.IsRunning())
            {
               aiReaderIAsyncResult = aiReader.BeginReadMultipleScans(numScans, aiReaderCallback, numScans);                               
            }
         }
         catch(UeiDaqException exception)
         {   
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            UeiDaqStop();
         }
         catch(Exception e)
         {
            ErrorText.Text = "Unknown Error" + e;
         }
      }

      private void AOWriterCallbackProc(IAsyncResult ar)
      {         
         try
         {
            int numScans = (int)ar.AsyncState;
            aoWriter.EndWriteMultipleScans(ar); 
            
            if(aoSs != null && aoSs.IsRunning())
            {
               double[,] data = new double[numScans,aoSs.GetDataStream().GetScanSize()];
               GenerateSinWave(data, aoSs.GetDataStream().GetScanSize(), numScans, aoIteration++);
               
               aoWriterIAsyncResult = aoWriter.BeginWriteMultipleScans(aoWriterCallback, numScans, numScans, data);                               
            }
         }
         catch(UeiDaqException exception)
         {   
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            UeiDaqStop();
         }
         catch(Exception e)
         {
            ErrorText.Text = "Unknown Error" + e;
         }
      }

      private void UpdateUI(String errorMessage)
      {
         if (this.InvokeRequired)
         {
            UpdateUIDelegate uidlg = new UpdateUIDelegate(UpdateUI);
            Invoke(uidlg, new object[] { errorMessage });
         }
         else
         {
            if (aiSs != null)
            {
               AIAvailableScans.Text = aiSs.GetDataStream().GetAvailableScans().ToString();
               AITotalScans.Text = aiSs.GetDataStream().GetTotalScans().ToString();
            }

            if (aoSs != null)
            { 
               AOAvailableUpdates.Text = aoSs.GetDataStream().GetAvailableScans().ToString();
               AOTotalUpdates.Text = aoSs.GetDataStream().GetTotalScans().ToString();
            }

            if (errorMessage.Length > 0)
            {
               ErrorText.Text = errorMessage;
               UeiDaqStop();
            }
         }
      }
      void GenerateSinWave(double[,] buffer, int nbChannels, int nbSamplePerChannel, int iteration)
      {
         int amplitude = (iteration % 10 + 1);
         
         for(int i=0; i<nbSamplePerChannel; i++)
         {
            for(int j=0; j<nbChannels; j++)
            {
               buffer[i,j] = amplitude * Math.Sin(2*3.1415*(j+1)*i/nbSamplePerChannel);
            }
         }
      }
	}
}
