﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace SerialLoopbackAsync
{
    class Program
    {
        static void Main(string[] args)
        {
            string serialResource = "pdna://192.168.100.4/Dev0/com0,1";

            // if timestamp should be read with data
            bool withTimestamp = true;

            // amount of data needed to trigger event
            int watermark = 5;

            // time without more data to trigger event
            // allows reading data leftover that is less than WATERMARK level
            // set to 0 to disable
            int timeout_us = 1000000;

            // amount of data to send per write
            int sendSize = 9;

            // max amount of data to read
            int recvSize = 4;

            SerialReader[] readers;
            SerialWriter[] writers;
            byte[] sendBuffer = new byte[sendSize];

            // register CTRL + c handler
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

            try {
                // Configure Master session
                Session mySession = new Session();
                SerialPort port = mySession.CreateSerialPort(serialResource,
                    SerialPortMode.RS485FullDuplex,
                    SerialPortSpeed.BitsPerSecond57600,
                    SerialPortDataBits.DataBits8,
                    SerialPortParity.None,
                    SerialPortStopBits.StopBits1,
                    "");

                mySession.ConfigureTimingForAsynchronousIO(watermark, 0, timeout_us, 0);
                mySession.GetTiming().SetTimeout(10);

                // Configure writer and reader for each channel
                writers = new SerialWriter[mySession.GetNumberOfChannels()];
                readers = new SerialReader[mySession.GetNumberOfChannels()];
                for (int i = 0; i < mySession.GetNumberOfChannels(); i++) {
                    int chanNum = mySession.GetChannel(i).GetIndex();

                    writers[i] = new SerialWriter(mySession.GetDataStream(), chanNum);
                    readers[i] = new SerialReader(mySession.GetDataStream(), chanNum);
                }

                mySession.Start();

                int sendCount = 0;
                while (!stop) {
                    // do write for each channel
                    for (int i = 0; i < mySession.GetNumberOfChannels(); i++) {
                        for (int j = 0; j < sendSize; j++) {
                            sendBuffer[j] = (byte)('a' + sendCount);
                            sendCount = (sendCount + 1) % 26;
                        }
                        Console.Write("writer[{0}]: ", i);
                        for (int j = 0; j < sendSize; j++) {
                            Console.Write((char)sendBuffer[j]);
                        }
                        Console.WriteLine();
                        writers[i].Write(sendBuffer);
                    }

                    Console.WriteLine();
                    Thread.Sleep(20);

                    // do read for each channel
                    for (int i = 0; i < mySession.GetNumberOfChannels(); i++) {
                        int chanNum = mySession.GetChannel(i).GetIndex();
                        Console.WriteLine("reader[{0}]: ", i);

                        // "available" is the amount of data remaining from a single event
                        // more data may be in the queue once "available" bytes have been read
                        int available;
                        while ((available = mySession.GetDataStream().GetAvailableMessages(chanNum)) > 0 && recvSize > 0) {
                            Console.Write("  avail: {0}", mySession.GetDataStream().GetAvailableMessages(chanNum));
                            try {
                                readAndPrint(readers[i], recvSize, withTimestamp);
                            } catch (UeiDaqException e) {
                                if (e.Error == Error.Timeout) {
                                    Console.WriteLine("  read timeout");
                                    break;
                                } else {
                                    throw e;
                                }
                            }
                        }
                    }

                    Console.WriteLine();
                    Thread.Sleep(1000);
                }

                mySession.Stop();
            } catch (UeiDaqException exception) {
                Console.WriteLine();
                Console.WriteLine("Error: ({0}) {1}", exception.Error, exception.Message);
            }
        }

        static void readAndPrint(SerialReader reader, int recvSize, bool withTimestamp)
        {
            UInt32 timestamp;
            byte[] recvBuffer;

            int startIdx = 0;
            if (withTimestamp) {
                startIdx = sizeof(UInt32);
                recvBuffer = reader.ReadTimestamped(recvSize);

                // pull out timestamp
                timestamp = BitConverter.ToUInt32(recvBuffer, 0);

                Console.Write("  timestamp: {0}", timestamp);
            } else {
                recvBuffer = reader.Read(recvSize);
            }

            Console.Write("  Data: ");
            for (int j = startIdx; j < recvBuffer.Length; j++) {
                Console.Write((char)recvBuffer[j]);
            }
            Console.WriteLine();
        }

        protected static void myHandler(object sender, ConsoleCancelEventArgs args)
        {
            // Set cancel to true to let the Main task clean-up the I/O sessions
            args.Cancel = true;
            stop = true;
        }

        static bool stop = false;
    }
}
