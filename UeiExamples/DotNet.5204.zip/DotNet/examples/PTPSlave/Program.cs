﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace PTPSlave
{
   class Program
   {
      static void Main(string[] args)
      {
         String[] ptpResources = new String[]{ "pdna://192.168.100.3/dev14/Sync0" };
         Session[] ptpSessions = new Session[ptpResources.Length];
         Sync1PPSController[] ptpControllers = new Sync1PPSController[ptpResources.Length];

         try
         {
            for (int i=0; i<ptpResources.Length; i++)
            {
               ptpSessions[i] = new Session();
               Sync1PPSPort port = ptpSessions[i].CreateSync1PPSPort(ptpResources[i],
                                             Sync1PPSMode.PTP,
                                             Sync1PPSSource.Internal,
                                             100.0);
               // configure port to output 1 PPS signal out of sync connector output 0 (clock out)
               port.SetADPLLOutputSyncLine(SyncLine.Line0);
               port.Set1PPSOutput(Sync1PPSOutput.Output0);
               
               // Configure PTP slave parameters
               port.SetPTPSubdomain(0);
               port.SetPTPPriority1(128 + 3);
               port.SetPTPPriority2(128 + 3);
               port.SetPTPLogSyncInterval(0);
               port.SetPTPLogMinDelayRequestInterval(1);
               port.SetPTPLogAnnounceInterval(4);
               port.SetPTPAnnounceTimeout(3);
               port.SetPTPUTCOffset(37);

               ptpSessions[i].Start();

               // Create a controller object to read PTP status and UTC time
               ptpControllers[i] = new Sync1PPSController(ptpSessions[i].GetDataStream());
            }

            // Establish an event handler to process key press events.
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

            int count = 0;
            stop = false;
            while (!stop)
            {
               for (int i = 0; i < ptpResources.Length; i++)
               {
                  Console.WriteLine("Status for " + ptpResources[i]);
                  Sync1PPSPTPStatus status = ptpControllers[i].ReadPTPStatus();
                  Console.WriteLine("PTP slave state = " + status.State + ", Master clock ID = " + status.MasterClockID + " Mean path delay = " + status.MeanPathDelay);

                  PTPTime ptpTime = ptpControllers[i].ReadPTPUTCTime();
                  Console.WriteLine("PTP UTC Time = " + ptpTime.sec + "s / " + ptpTime.nsec + "ns");

                  bool locked = ptpControllers[i].ReadLockedStatus();
                  Console.WriteLine("ADPLL is " + (locked ? "locked" : "not locked"));
               }

               Thread.Sleep(500);
               count++;
            }

            foreach (Session ptpSession in ptpSessions)
            {
               ptpSession.Stop();
            }
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop= false;
   }
}
