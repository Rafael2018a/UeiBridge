﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace DMM
{
   class Program
   {
      static void Main(string[] args)
      {
         Session dmmSession;
         String dmmResource = "pdna://192.168.100.2/dev0/ai0";

         try
         {

            dmmSession = new Session();
            DMMChannel dmmChan = dmmSession.CreateDMMChannel(dmmResource, 150.0, DMMMeasurementMode.DCVoltage);

            AnalogScaledReader reader = new AnalogScaledReader(dmmSession.GetDataStream());
            dmmSession.ConfigureTimingForSimpleIO();
            dmmSession.Start();

            // Establish an event handler to process key press events.
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

            stop = false;
            while (!stop)
            {
               // Read and display data
               double[] data = reader.ReadSingleScan();

               for (int ch = 0; ch < dmmSession.GetNumberOfChannels(); ch++)
               {
                  Console.WriteLine(data[ch]);
               }
               Console.WriteLine("");
            }

            dmmSession.Stop();
           
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop = false;
   }
}
