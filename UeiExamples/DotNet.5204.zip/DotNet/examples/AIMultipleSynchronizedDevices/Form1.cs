﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using UeiDaq;


namespace AIMultipleSynchronizedDevices
{
    public partial class frmMain : Form
    {
        private delegate void UpdateUIDelegate(int sessionIndex, double[,] analogData);
        private delegate void UpdateErrorDelegate(int sessionIndex, string errorMessage);
        private Session[] mySs;

        private AnalogScaledReader[] analogReader;

        private Thread daqThread;

        
        private bool runFlag = false;

        TextBox[] resourceString = new TextBox[6];
        CheckBox[] enableDev = new CheckBox[6];

        int sessionCount = 0;
        int errorFlag = 0;

        public frmMain()
        {

            InitializeComponent();

            textResourceMasterCube.Text = Properties.Settings.Default["MasterCubeResource"].ToString();

            //initilize resource string text boxes
            resourceString[0] = txtResourceSlave0;
            resourceString[0].Text = Properties.Settings.Default["MasterResource"].ToString();
            resourceString[1] = txtResourceSlave1;
            resourceString[1].Text = Properties.Settings.Default["Slave1Resource"].ToString();
            resourceString[2] = txtResourceSlave2;
            resourceString[2].Text = Properties.Settings.Default["Slave2Resource"].ToString();
            resourceString[3] = txtResourceSlave3;
            resourceString[3].Text = Properties.Settings.Default["Slave3Resource"].ToString();
            resourceString[4] = txtResourceSlave4;
            resourceString[4].Text = Properties.Settings.Default["Slave4Resource"].ToString();
            resourceString[5] = txtResourceSlave5;
            resourceString[5].Text = Properties.Settings.Default["Slave5Resource"].ToString();

            //initialize enable check boxes
            enableDev[0] = chkEnabledSlave0;
            enableDev[1] = chkEnabledSlave1;
            enableDev[2] = chkEnabledSlave2;
            enableDev[3] = chkEnabledSlave3;
            enableDev[4] = chkEnabledSlave4;
            enableDev[5] = chkEnabledSlave5;

            txtSamPerChan.Text = Properties.Settings.Default["ScansPerChannel"].ToString();
            txtSampleRate.Text = Properties.Settings.Default["ScanRate"].ToString();
            txtTimeout.Text = Properties.Settings.Default["Timeout"].ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnStop.Enabled = false;
            chkSyncDev.Checked = true;
        }

        private void Form1_Closing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default["MasterResource"] = resourceString[0].Text;
            Properties.Settings.Default["Slave1Resource"] = resourceString[1].Text;
            Properties.Settings.Default["Slave2Resource"] = resourceString[2].Text;
            Properties.Settings.Default["Slave3Resource"] = resourceString[3].Text;
            Properties.Settings.Default["Slave4Resource"] = resourceString[4].Text;
            Properties.Settings.Default["Slave5Resource"] = resourceString[5].Text;

            Properties.Settings.Default["ScansPerChannel"] = txtSamPerChan.Text;
            Properties.Settings.Default["ScanRate"] = txtSampleRate.Text;
            Properties.Settings.Default["Timeout"] = txtTimeout.Text;

            Properties.Settings.Default["MasterCubeResource"] = textResourceMasterCube.Text;

            Properties.Settings.Default.Save();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            // Clear error from previous run
            txtErrorText.Text = "";

            // Create 3 columns to display device, totalScans, AvailableScans in status list view
            lstStatusList.Columns.Clear();

            //Adding the Text "Device" as a column header
            ColumnHeader colHeader = new ColumnHeader();
            colHeader.Text = "Device";
            colHeader.Width = 200;
            lstStatusList.Columns.Add(colHeader);

            //Adding the text "totalScans" as a column header
            colHeader = new ColumnHeader();
            colHeader.Text = "Total Scans";
            colHeader.Width = 100;
            lstStatusList.Columns.Add(colHeader);

            //Adding the text Available Scans as a column header
            colHeader = new ColumnHeader();
            colHeader.Text = "Available Scans";
            colHeader.Width = 100;
            lstStatusList.Columns.Add(colHeader);

            lstStatusList.View = View.Details;
            lstStatusList.FullRowSelect = true;
            lstStatusList.GridLines = true;


            List<string> resourceStrings = new List<string>();

            //Find out how many sessions we need to create.
            //create one session per layer device

            //Find out how many racks are being used.
            for (int devIndex = 0; devIndex < resourceString.Length; devIndex++)
            {
                if (enableDev[devIndex].Checked == true)
                {
                    string resource = textResourceMasterCube.Text + resourceString[devIndex].Text;
                    resourceStrings.Add(resource);
                }
            }

            sessionCount = resourceStrings.Count;
            mySs = new Session[sessionCount];
            analogReader = new AnalogScaledReader[sessionCount];

            string deviceName = "";

            //Adding initial values into the list view
            lstStatusList.Items.Clear();
            for (int j = 0; j < resourceStrings.Count; j++)
            {
                ListViewItem lvi = new ListViewItem(new[] { resourceStrings[j].ToString(), "0", "0" });
                lstStatusList.Items.Add(lvi);
            }



            //*************************************************
            errorFlag = 0;
            for (int i = 0; i < sessionCount; i++)
            {
                try
                {
                    mySs[i] = new Session();                    
                    mySs[i].CreateAIChannel(resourceStrings[i], -10, 10, AIChannelInputMode.Differential);
                    deviceName = mySs[i].GetDevice().GetDeviceName();

                    // All devices are using their internal clock. They are not synchronized
                    mySs[i].ConfigureTimingForBufferedIO(Convert.ToInt32(txtSamPerChan.Text), TimingClockSource.Internal, Convert.ToInt32(txtSampleRate.Text), DigitalEdge.Rising, TimingDuration.Continuous);

                    if (chkSyncDev.Checked)
                    {
                       //configure the software trigger
                       mySs[i].ConfigureSignalTrigger(TriggerAction.StartSession, "SoftwareTrigger0");  
                    }
                    
                    mySs[i].GetTiming().SetTimeout(Convert.ToInt32(txtTimeout.Text));
                    mySs[i].GetDataStream().SetNumberOfFrames(8);
                    analogReader[i] = new AnalogScaledReader(mySs[i].GetDataStream());
                }
                catch (UeiDaqException exception)
                {
                    txtErrorText.Text = "Error configuring " + deviceName + ": " + exception.Error;
                    errorFlag++;
                    break;
                }
            }
            if (errorFlag > 0)
            {
                return;
            }

            // Start all sessions, master last
            for (int i = sessionCount-1; i >=0; i--)
            {
                try
                {
                    deviceName = mySs[i].GetDevice().GetDeviceName();
                    mySs[i].Start();
                }
                catch (UeiDaqException exception)
                {
                    txtErrorText.Text = "Error starting" + deviceName + ": " + exception.Error;
                    errorFlag++;
                    break;
                }
            }

            try
            {
               // Fire software trigger on first session to start
               // all sessions simultaneously
               mySs[0].GetStartTrigger().Fire();
            }
            catch (UeiDaqException exception)
            {
               txtErrorText.Text = "Error firing trigger: " + exception.Error;
               errorFlag++;
            }

            if (errorFlag > 0)
            {
               // Stop sessions that were already started
               for (int i = 0; i < sessionCount; i++)
               {
                  if (mySs[i].IsRunning())
                  {
                     mySs[i].Stop();
                     mySs[i].Dispose();
                  }
               }
               return;
            }

            // Create and start DAQThread
            runFlag = true;
            daqThread = new Thread(new ThreadStart(DaqThreadProc));
            daqThread.IsBackground = true;
            daqThread.Start();

            
            btnStop.Enabled = true;
            btnStart.Enabled = false;            
        }


        private void UpdateError(int sessionIndex, string errorMessage)
        {
            string deviceName = mySs[sessionIndex].GetDevice().GetDeviceName();
            txtErrorText.Text = "Error while acquiring from " + deviceName + ": " + errorMessage;
            StopSessions();
        }

        private void UpdateUI(int sessionIndex, double[,] analogData)
        {
            if (runFlag == true)
            {
                lstStatusList.Items[sessionIndex].SubItems[1].Text = mySs[sessionIndex].GetDataStream().GetTotalScans().ToString();
                lstStatusList.Items[sessionIndex].SubItems[2].Text = mySs[sessionIndex].GetDataStream().GetAvailableScans().ToString();
            }
        }

        private void DaqThreadProc()
        {
            while (runFlag == true)
            {
                for (int sessionIndex = 0; sessionIndex < sessionCount; sessionIndex++)
                {
                    double[,] analogData = null;

                    if (mySs[sessionIndex].IsRunning() && mySs[sessionIndex].GetType() == SessionType.AI)
                    {
                        try
                        {
                            analogData = analogReader[sessionIndex].ReadMultipleScans(Int32.Parse(txtSamPerChan.Text));
                        }
                        catch (UeiDaqException exception)
                        {
                            BeginInvoke(new UpdateErrorDelegate(UpdateError), new object[] { sessionIndex, exception.Error.ToString() });
                            // Exit thread, the update  error call will clean up the sessions
                            return;
                        }
                            
                    }

                    if (analogData != null)
                    {
                        // Can't update UI in thread, must invoke delegate to update in UI thread.
                        BeginInvoke(new UpdateUIDelegate(UpdateUI), new object[] { sessionIndex, analogData });
                    }
                }
            }

        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            StopSessions();
        }
   
        private void StopSessions()
        {
            if (runFlag)
            {
                runFlag = false;

                // Wait for daqThread to gracefully end        
                daqThread.Join();

                // Clean-up sessions
                for (int i = 0; i < sessionCount; i++)
                {
                    if (mySs != null)
                    {
                        string deviceName="";
                        try
                        {
                            deviceName = mySs[i].GetDevice().GetDeviceName();
                            mySs[i].Stop();
                            mySs[i].Dispose();
                        }
                        catch (UeiDaqException exception)
                        {
                            txtErrorText.Text = "Error stopping" + deviceName + ": " + exception.Error;
                        }
                    }
                }

                mySs = null;
            }

            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnQuit.Enabled = true;
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            StopSessions();
            Application.Exit();
        }

   
    }
}
