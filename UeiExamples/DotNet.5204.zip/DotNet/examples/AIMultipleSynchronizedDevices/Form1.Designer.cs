﻿namespace AIMultipleSynchronizedDevices
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           this.txtResourceSlave0 = new System.Windows.Forms.TextBox();
           this.groupBox1 = new System.Windows.Forms.GroupBox();
           this.label2 = new System.Windows.Forms.Label();
           this.textResourceMasterCube = new System.Windows.Forms.TextBox();
           this.txtResourceSlave3 = new System.Windows.Forms.TextBox();
           this.txtTimeout = new System.Windows.Forms.TextBox();
           this.label22 = new System.Windows.Forms.Label();
           this.label21 = new System.Windows.Forms.Label();
           this.label20 = new System.Windows.Forms.Label();
           this.txtSampleRate = new System.Windows.Forms.TextBox();
           this.chkSyncDev = new System.Windows.Forms.CheckBox();
           this.label18 = new System.Windows.Forms.Label();
           this.label15 = new System.Windows.Forms.Label();
           this.label12 = new System.Windows.Forms.Label();
           this.label7 = new System.Windows.Forms.Label();
           this.label4 = new System.Windows.Forms.Label();
           this.label1 = new System.Windows.Forms.Label();
           this.chkEnabledSlave5 = new System.Windows.Forms.CheckBox();
           this.chkEnabledSlave4 = new System.Windows.Forms.CheckBox();
           this.chkEnabledSlave3 = new System.Windows.Forms.CheckBox();
           this.txtResourceSlave5 = new System.Windows.Forms.TextBox();
           this.txtResourceSlave4 = new System.Windows.Forms.TextBox();
           this.txtSamPerChan = new System.Windows.Forms.TextBox();
           this.chkEnabledSlave2 = new System.Windows.Forms.CheckBox();
           this.chkEnabledSlave1 = new System.Windows.Forms.CheckBox();
           this.chkEnabledSlave0 = new System.Windows.Forms.CheckBox();
           this.txtResourceSlave2 = new System.Windows.Forms.TextBox();
           this.txtResourceSlave1 = new System.Windows.Forms.TextBox();
           this.Status = new System.Windows.Forms.GroupBox();
           this.btnQuit = new System.Windows.Forms.Button();
           this.btnStop = new System.Windows.Forms.Button();
           this.btnStart = new System.Windows.Forms.Button();
           this.lstStatusList = new System.Windows.Forms.ListView();
           this.txtErrorText = new System.Windows.Forms.TextBox();
           this.groupBox1.SuspendLayout();
           this.Status.SuspendLayout();
           this.SuspendLayout();
           // 
           // txtResourceSlave0
           // 
           this.txtResourceSlave0.Location = new System.Drawing.Point(111, 128);
           this.txtResourceSlave0.Name = "txtResourceSlave0";
           this.txtResourceSlave0.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave0.TabIndex = 0;
           this.txtResourceSlave0.Text = "Dev0/Ai0:7";
           // 
           // groupBox1
           // 
           this.groupBox1.Controls.Add(this.label2);
           this.groupBox1.Controls.Add(this.textResourceMasterCube);
           this.groupBox1.Controls.Add(this.txtResourceSlave3);
           this.groupBox1.Controls.Add(this.txtTimeout);
           this.groupBox1.Controls.Add(this.label22);
           this.groupBox1.Controls.Add(this.label21);
           this.groupBox1.Controls.Add(this.label20);
           this.groupBox1.Controls.Add(this.txtSampleRate);
           this.groupBox1.Controls.Add(this.chkSyncDev);
           this.groupBox1.Controls.Add(this.label18);
           this.groupBox1.Controls.Add(this.label15);
           this.groupBox1.Controls.Add(this.label12);
           this.groupBox1.Controls.Add(this.label7);
           this.groupBox1.Controls.Add(this.label4);
           this.groupBox1.Controls.Add(this.label1);
           this.groupBox1.Controls.Add(this.chkEnabledSlave5);
           this.groupBox1.Controls.Add(this.chkEnabledSlave4);
           this.groupBox1.Controls.Add(this.chkEnabledSlave3);
           this.groupBox1.Controls.Add(this.txtResourceSlave5);
           this.groupBox1.Controls.Add(this.txtResourceSlave4);
           this.groupBox1.Controls.Add(this.txtSamPerChan);
           this.groupBox1.Controls.Add(this.chkEnabledSlave2);
           this.groupBox1.Controls.Add(this.chkEnabledSlave1);
           this.groupBox1.Controls.Add(this.chkEnabledSlave0);
           this.groupBox1.Controls.Add(this.txtResourceSlave2);
           this.groupBox1.Controls.Add(this.txtResourceSlave1);
           this.groupBox1.Controls.Add(this.txtResourceSlave0);
           this.groupBox1.ForeColor = System.Drawing.Color.Blue;
           this.groupBox1.Location = new System.Drawing.Point(12, 12);
           this.groupBox1.Name = "groupBox1";
           this.groupBox1.Size = new System.Drawing.Size(499, 484);
           this.groupBox1.TabIndex = 1;
           this.groupBox1.TabStop = false;
           this.groupBox1.Text = "Devices Configuration";
           // 
           // label2
           // 
           this.label2.AutoSize = true;
           this.label2.Location = new System.Drawing.Point(109, 40);
           this.label2.Name = "label2";
           this.label2.Size = new System.Drawing.Size(116, 13);
           this.label2.TabIndex = 55;
           this.label2.Text = "Master Cube Resource";
           // 
           // textResourceMasterCube
           // 
           this.textResourceMasterCube.Location = new System.Drawing.Point(111, 56);
           this.textResourceMasterCube.Name = "textResourceMasterCube";
           this.textResourceMasterCube.Size = new System.Drawing.Size(159, 20);
           this.textResourceMasterCube.TabIndex = 54;
           this.textResourceMasterCube.Text = "pdna://192.168.100.2/";
           // 
           // txtResourceSlave3
           // 
           this.txtResourceSlave3.Location = new System.Drawing.Point(111, 255);
           this.txtResourceSlave3.Name = "txtResourceSlave3";
           this.txtResourceSlave3.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave3.TabIndex = 53;
           this.txtResourceSlave3.Text = "Dev3/Ai0:7";
           // 
           // txtTimeout
           // 
           this.txtTimeout.Location = new System.Drawing.Point(349, 392);
           this.txtTimeout.Name = "txtTimeout";
           this.txtTimeout.Size = new System.Drawing.Size(105, 20);
           this.txtTimeout.TabIndex = 49;
           this.txtTimeout.Text = "5000";
           // 
           // label22
           // 
           this.label22.AutoSize = true;
           this.label22.Location = new System.Drawing.Point(176, 375);
           this.label22.Name = "label22";
           this.label22.Size = new System.Drawing.Size(94, 13);
           this.label22.TabIndex = 48;
           this.label22.Text = "Samples Per Chan";
           // 
           // label21
           // 
           this.label21.AutoSize = true;
           this.label21.Location = new System.Drawing.Point(346, 376);
           this.label21.Name = "label21";
           this.label21.Size = new System.Drawing.Size(45, 13);
           this.label21.TabIndex = 47;
           this.label21.Text = "Timeout";
           // 
           // label20
           // 
           this.label20.AutoSize = true;
           this.label20.Location = new System.Drawing.Point(31, 375);
           this.label20.Name = "label20";
           this.label20.Size = new System.Drawing.Size(68, 13);
           this.label20.TabIndex = 46;
           this.label20.Text = "Sample Rate";
           // 
           // txtSampleRate
           // 
           this.txtSampleRate.Location = new System.Drawing.Point(34, 392);
           this.txtSampleRate.Name = "txtSampleRate";
           this.txtSampleRate.Size = new System.Drawing.Size(105, 20);
           this.txtSampleRate.TabIndex = 45;
           this.txtSampleRate.Text = "1000";
           // 
           // chkSyncDev
           // 
           this.chkSyncDev.AutoSize = true;
           this.chkSyncDev.ForeColor = System.Drawing.Color.Red;
           this.chkSyncDev.Location = new System.Drawing.Point(349, 443);
           this.chkSyncDev.Name = "chkSyncDev";
           this.chkSyncDev.Size = new System.Drawing.Size(137, 17);
           this.chkSyncDev.TabIndex = 42;
           this.chkSyncDev.Text = "Synchronize all devices";
           this.chkSyncDev.UseVisualStyleBackColor = true;
           // 
           // label18
           // 
           this.label18.AutoSize = true;
           this.label18.Location = new System.Drawing.Point(108, 322);
           this.label18.Name = "label18";
           this.label18.Size = new System.Drawing.Size(92, 13);
           this.label18.TabIndex = 39;
           this.label18.Text = "Slave 5 Resource";
           // 
           // label15
           // 
           this.label15.AutoSize = true;
           this.label15.Location = new System.Drawing.Point(108, 281);
           this.label15.Name = "label15";
           this.label15.Size = new System.Drawing.Size(92, 13);
           this.label15.TabIndex = 36;
           this.label15.Text = "Slave 4 Resource";
           // 
           // label12
           // 
           this.label12.AutoSize = true;
           this.label12.Location = new System.Drawing.Point(108, 239);
           this.label12.Name = "label12";
           this.label12.Size = new System.Drawing.Size(92, 13);
           this.label12.TabIndex = 33;
           this.label12.Text = "Slave 3 Resource";
           // 
           // label7
           // 
           this.label7.AutoSize = true;
           this.label7.Location = new System.Drawing.Point(108, 198);
           this.label7.Name = "label7";
           this.label7.Size = new System.Drawing.Size(92, 13);
           this.label7.TabIndex = 30;
           this.label7.Text = "Slave 2 Resource";
           // 
           // label4
           // 
           this.label4.AutoSize = true;
           this.label4.Location = new System.Drawing.Point(108, 157);
           this.label4.Name = "label4";
           this.label4.Size = new System.Drawing.Size(92, 13);
           this.label4.TabIndex = 27;
           this.label4.Text = "Slave 1 Resource";
           // 
           // label1
           // 
           this.label1.AutoSize = true;
           this.label1.Location = new System.Drawing.Point(108, 112);
           this.label1.Name = "label1";
           this.label1.Size = new System.Drawing.Size(91, 13);
           this.label1.TabIndex = 24;
           this.label1.Text = "Master  Resource";
           // 
           // chkEnabledSlave5
           // 
           this.chkEnabledSlave5.AutoSize = true;
           this.chkEnabledSlave5.Location = new System.Drawing.Point(34, 341);
           this.chkEnabledSlave5.Name = "chkEnabledSlave5";
           this.chkEnabledSlave5.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave5.TabIndex = 11;
           this.chkEnabledSlave5.Text = "Enabled";
           this.chkEnabledSlave5.UseVisualStyleBackColor = true;
           // 
           // chkEnabledSlave4
           // 
           this.chkEnabledSlave4.AutoSize = true;
           this.chkEnabledSlave4.Location = new System.Drawing.Point(34, 300);
           this.chkEnabledSlave4.Name = "chkEnabledSlave4";
           this.chkEnabledSlave4.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave4.TabIndex = 10;
           this.chkEnabledSlave4.Text = "Enabled";
           this.chkEnabledSlave4.UseVisualStyleBackColor = true;
           // 
           // chkEnabledSlave3
           // 
           this.chkEnabledSlave3.AutoSize = true;
           this.chkEnabledSlave3.Location = new System.Drawing.Point(34, 258);
           this.chkEnabledSlave3.Name = "chkEnabledSlave3";
           this.chkEnabledSlave3.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave3.TabIndex = 9;
           this.chkEnabledSlave3.Text = "Enabled";
           this.chkEnabledSlave3.UseVisualStyleBackColor = true;
           // 
           // txtResourceSlave5
           // 
           this.txtResourceSlave5.Location = new System.Drawing.Point(111, 338);
           this.txtResourceSlave5.Name = "txtResourceSlave5";
           this.txtResourceSlave5.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave5.TabIndex = 8;
           this.txtResourceSlave5.Text = "Dev5/Ai0:7";
           // 
           // txtResourceSlave4
           // 
           this.txtResourceSlave4.Location = new System.Drawing.Point(111, 297);
           this.txtResourceSlave4.Name = "txtResourceSlave4";
           this.txtResourceSlave4.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave4.TabIndex = 7;
           this.txtResourceSlave4.Text = "Dev4/Ai0:7";
           // 
           // txtSamPerChan
           // 
           this.txtSamPerChan.Location = new System.Drawing.Point(179, 391);
           this.txtSamPerChan.Name = "txtSamPerChan";
           this.txtSamPerChan.Size = new System.Drawing.Size(97, 20);
           this.txtSamPerChan.TabIndex = 6;
           this.txtSamPerChan.Text = "20";
           // 
           // chkEnabledSlave2
           // 
           this.chkEnabledSlave2.AutoSize = true;
           this.chkEnabledSlave2.Location = new System.Drawing.Point(34, 217);
           this.chkEnabledSlave2.Name = "chkEnabledSlave2";
           this.chkEnabledSlave2.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave2.TabIndex = 5;
           this.chkEnabledSlave2.Text = "Enabled";
           this.chkEnabledSlave2.UseVisualStyleBackColor = true;
           // 
           // chkEnabledSlave1
           // 
           this.chkEnabledSlave1.AutoSize = true;
           this.chkEnabledSlave1.Checked = true;
           this.chkEnabledSlave1.CheckState = System.Windows.Forms.CheckState.Checked;
           this.chkEnabledSlave1.Location = new System.Drawing.Point(34, 175);
           this.chkEnabledSlave1.Name = "chkEnabledSlave1";
           this.chkEnabledSlave1.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave1.TabIndex = 4;
           this.chkEnabledSlave1.Text = "Enabled";
           this.chkEnabledSlave1.UseVisualStyleBackColor = true;
           // 
           // chkEnabledSlave0
           // 
           this.chkEnabledSlave0.AutoSize = true;
           this.chkEnabledSlave0.Checked = true;
           this.chkEnabledSlave0.CheckState = System.Windows.Forms.CheckState.Checked;
           this.chkEnabledSlave0.Location = new System.Drawing.Point(34, 131);
           this.chkEnabledSlave0.Name = "chkEnabledSlave0";
           this.chkEnabledSlave0.Size = new System.Drawing.Size(65, 17);
           this.chkEnabledSlave0.TabIndex = 3;
           this.chkEnabledSlave0.Text = "Enabled";
           this.chkEnabledSlave0.UseVisualStyleBackColor = true;
           // 
           // txtResourceSlave2
           // 
           this.txtResourceSlave2.Location = new System.Drawing.Point(111, 214);
           this.txtResourceSlave2.Name = "txtResourceSlave2";
           this.txtResourceSlave2.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave2.TabIndex = 2;
           this.txtResourceSlave2.Text = "Dev2/Ai0:7";
           // 
           // txtResourceSlave1
           // 
           this.txtResourceSlave1.Location = new System.Drawing.Point(111, 172);
           this.txtResourceSlave1.Name = "txtResourceSlave1";
           this.txtResourceSlave1.Size = new System.Drawing.Size(159, 20);
           this.txtResourceSlave1.TabIndex = 1;
           this.txtResourceSlave1.Text = "Dev1/Ai0:7";
           // 
           // Status
           // 
           this.Status.Controls.Add(this.btnQuit);
           this.Status.Controls.Add(this.btnStop);
           this.Status.Controls.Add(this.btnStart);
           this.Status.Controls.Add(this.lstStatusList);
           this.Status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
           this.Status.Location = new System.Drawing.Point(12, 516);
           this.Status.Name = "Status";
           this.Status.Size = new System.Drawing.Size(499, 257);
           this.Status.TabIndex = 2;
           this.Status.TabStop = false;
           this.Status.Text = "Status";
           // 
           // btnQuit
           // 
           this.btnQuit.Location = new System.Drawing.Point(337, 190);
           this.btnQuit.Name = "btnQuit";
           this.btnQuit.Size = new System.Drawing.Size(126, 42);
           this.btnQuit.TabIndex = 8;
           this.btnQuit.Text = "Quit";
           this.btnQuit.UseVisualStyleBackColor = true;
           this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
           // 
           // btnStop
           // 
           this.btnStop.Location = new System.Drawing.Point(196, 189);
           this.btnStop.Name = "btnStop";
           this.btnStop.Size = new System.Drawing.Size(126, 42);
           this.btnStop.TabIndex = 7;
           this.btnStop.Text = "Stop";
           this.btnStop.UseVisualStyleBackColor = true;
           this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
           // 
           // btnStart
           // 
           this.btnStart.Location = new System.Drawing.Point(48, 189);
           this.btnStart.Name = "btnStart";
           this.btnStart.Size = new System.Drawing.Size(126, 42);
           this.btnStart.TabIndex = 6;
           this.btnStart.Text = "Start";
           this.btnStart.UseVisualStyleBackColor = true;
           this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
           // 
           // lstStatusList
           // 
           this.lstStatusList.Location = new System.Drawing.Point(29, 31);
           this.lstStatusList.Name = "lstStatusList";
           this.lstStatusList.Size = new System.Drawing.Size(457, 141);
           this.lstStatusList.TabIndex = 0;
           this.lstStatusList.UseCompatibleStateImageBehavior = false;
           // 
           // txtErrorText
           // 
           this.txtErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
           this.txtErrorText.Location = new System.Drawing.Point(0, 761);
           this.txtErrorText.Multiline = true;
           this.txtErrorText.Name = "txtErrorText";
           this.txtErrorText.ReadOnly = true;
           this.txtErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
           this.txtErrorText.Size = new System.Drawing.Size(550, 48);
           this.txtErrorText.TabIndex = 19;
           // 
           // frmMain
           // 
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.ClientSize = new System.Drawing.Size(550, 809);
           this.Controls.Add(this.txtErrorText);
           this.Controls.Add(this.Status);
           this.Controls.Add(this.groupBox1);
           this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
           this.Name = "frmMain";
           this.Text = "AIMultipleSynchronizedDevices";
           this.Load += new System.EventHandler(this.Form1_Load);
           this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_Closing);
           this.groupBox1.ResumeLayout(false);
           this.groupBox1.PerformLayout();
           this.Status.ResumeLayout(false);
           this.ResumeLayout(false);
           this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtResourceSlave0;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkEnabledSlave5;
        private System.Windows.Forms.CheckBox chkEnabledSlave4;
        private System.Windows.Forms.CheckBox chkEnabledSlave3;
        private System.Windows.Forms.TextBox txtResourceSlave5;
        private System.Windows.Forms.TextBox txtResourceSlave4;
        private System.Windows.Forms.TextBox txtSamPerChan;
        private System.Windows.Forms.CheckBox chkEnabledSlave2;
        private System.Windows.Forms.CheckBox chkEnabledSlave1;
        private System.Windows.Forms.CheckBox chkEnabledSlave0;
        private System.Windows.Forms.TextBox txtResourceSlave2;
        private System.Windows.Forms.TextBox txtResourceSlave1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox chkSyncDev;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtSampleRate;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtTimeout;
        private System.Windows.Forms.TextBox txtResourceSlave3;
        private System.Windows.Forms.GroupBox Status;
        private System.Windows.Forms.ListView lstStatusList;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.TextBox txtErrorText;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textResourceMasterCube;
    }
}

