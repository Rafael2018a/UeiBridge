﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace Protected_DO
{
   class Program
   {
      static void Main(string[] args)
      {
         Session doSession = new Session();
         Session aiSession = new Session();
         int numLines = 1;

         try
         {
            doSession.CreateDOProtectedChannel("pdna://192.168.100.3/dev0/doline0",
                                               -0.02,   // under-current limit
                                               0.02,    // over-current limit
                                               100.0,   // current measurement rate
                                               false,   // circuit breaker reset automatic retry
                                               0.0);    // retry rate
            doSession.ConfigureTimingForSimpleIO();

            // DO lines 0 to 31 are part of channel 0.
            DOProtectedChannel channel = (DOProtectedChannel)doSession.GetChannel(0);

            // Configure individual PWM settings on DO line #0
            channel.SetPWMPeriod(0, 1000); // 1 milli-second period
            channel.SetPWMMode(0, DOPWMMode.SoftStart); // In gated mode PWM is on only when output line is on
            channel.SetPWMDutyCycle(0, 0.1); // 0.1 = 10% duty cycle produces 10ms pulses.

            // AI channels 0 to 31 return the current measured at each closed DO line
            // AI channels 32 to 63 return the voltage measured at each opened DO line 
            aiSession.CreateAIChannel("pdna://192.168.100.3/dev0/ai0:63", -10.0, 10.0, AIChannelInputMode.Differential);
            aiSession.ConfigureTimingForSimpleIO();

            // Create a writer to update the output lines
            DigitalWriter writer = new DigitalWriter(doSession.GetDataStream());
            
            // Create a circuit breaker object to monitor circuit breakers status and eventually reset them
            CircuitBreaker cb = new CircuitBreaker(doSession.GetDataStream(), 0);
            int[] breakCount = new int[32];
                       
            // Create a reader to retrieve diagnostics
            AnalogScaledReader diagReader = new AnalogScaledReader(aiSession.GetDataStream());
            double[] diagData;

            doSession.Start();
            aiSession.Start();

            // Establish an event handler to process key press events.
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

            uint count = 0;
            stop = false;
            while (!stop)
            {
               UInt32[] doData = { 0 };

               // alternate on/off on even/odd output lines 
               for (int line = 0; line < 32; line++)
               {
                  if ((line % 2) > 0)
                  {
                     doData[0] = doData[0] | ((count % 2) << line);
                  }
                  else
                  {
                     doData[0] = doData[0] | (((count+1) % 2) << line);
                  }
               }
               writer.WriteSingleScanUInt32(doData);

               // Read and display diagnostics
               diagData = diagReader.ReadSingleScan();

               for (int line = 0; line < numLines; line++)
               {
                  Console.WriteLine("Output line " + line + " current = " + diagData[line]);
                  Console.WriteLine("Output line " + line + " voltage = " + diagData[line + 32]);
               }
               
               // Monitor CB status
               uint currStatus=0, stickyStatus=0;
               cb.GetStatus(ref currStatus, ref stickyStatus);
               for (int line = 0; line < numLines; line++)
               {
                  if ((currStatus & (1U << line)) > 0)
                  {
                     breakCount[line]++;
                  }

                  Console.WriteLine("CB Status: curr = " + currStatus.ToString("X") + " sticky = " + stickyStatus.ToString("X"));
                  
                  // reset breaker after 5 iterations
                  if (breakCount[line] > 5)
                  {
                     Console.WriteLine("Resetting breaker for line {0}", line);
                     cb.Reset(1U << line);
                     breakCount[line] = 0;
                  }
               }

               Thread.Sleep(500);
               count++;
            }

            doSession.Stop();
            aiSession.Stop();
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop= false;
   }
}
