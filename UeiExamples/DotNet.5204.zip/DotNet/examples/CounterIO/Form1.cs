using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using UeiDaq;

namespace CounterIO
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.TextBox CtrInputResource;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.GroupBox groupBox2;
      private System.Windows.Forms.TextBox CtrOutputResource;
      private System.Windows.Forms.CheckBox CtrInputEnable;
      private System.Windows.Forms.CheckBox CtrOutputEnable;
      private System.Windows.Forms.ComboBox CtrInputMode;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.ComboBox CtrOutputMode;
      private System.Windows.Forms.ComboBox CtrInputSource;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Label label6;
      private System.Windows.Forms.ComboBox CtrInputGate;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.ComboBox CtrOutputGate;
      private System.Windows.Forms.Label label7;
      private System.Windows.Forms.ComboBox CtrOutputSource;
      private System.Windows.Forms.Label Tick1;
      private System.Windows.Forms.Label label8;
      private System.Windows.Forms.NumericUpDown CtrOutputTick2;
      private System.Windows.Forms.PictureBox pictureBox1;
      private System.Windows.Forms.NumericUpDown CtrOutputTick1;
      private CounterMode[] CtrInputModes;
      private CounterMode[] CtrOutputModes;
      private CounterSource[] CtrSources;
      private CounterGate[] CtrGates;
      private Session ciSs;
      private Session coSs;
      private CounterWriter coWriter;
      private CounterReader ciReader;
      private System.Windows.Forms.Timer CITimer;
      private System.Windows.Forms.TextBox CtrInputValues;
      private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

         CtrInputModes = new CounterMode[4];
         CtrInputMode.Items.Add("Count Events");
         CtrInputModes[0] = CounterMode.CountEvents;
         CtrInputMode.Items.Add("Measure Period");
         CtrInputModes[1] = CounterMode.MeasurePeriod;
         CtrInputMode.Items.Add("Measure Pulse Width");
         CtrInputModes[2] = CounterMode.MeasurepulseWidth;
         CtrInputMode.Items.Add("Quadrature Encoder");
         CtrInputModes[3] = CounterMode.QuadratureEncoder;
         CtrInputMode.SelectedIndex = 0;

         CtrOutputModes = new CounterMode[2];
         CtrOutputMode.Items.Add("Generate Single Pulse");
         CtrOutputModes[0] = CounterMode.GeneratePulse;
         CtrOutputMode.Items.Add("Generate Pulse Train");
         CtrOutputModes[1] = CounterMode.GeneratePulseTrain;
         CtrOutputMode.SelectedIndex = 0;

         CtrSources = new CounterSource[3];
         CtrSources[0] = CounterSource.Input;
         CtrInputSource.Items.Add("Input");
         CtrOutputSource.Items.Add("Input");
         CtrSources[1] = CounterSource.Clock;
         CtrInputSource.Items.Add("Clock");
         CtrOutputSource.Items.Add("Clock");
         CtrSources[2] = CounterSource.Counter0Out;
         CtrInputSource.Items.Add("Counter 0 output");
         CtrOutputSource.Items.Add("Counter 0 output");
         CtrInputSource.SelectedIndex = 0;
         CtrOutputSource.SelectedIndex = 0;

         CtrGates = new CounterGate[2];
         CtrGates[0] = CounterGate.Internal;
         CtrInputGate.Items.Add("Internal");
         CtrOutputGate.Items.Add("Internal");
         CtrGates[1] = CounterGate.External;
         CtrInputGate.Items.Add("External");
         CtrOutputGate.Items.Add("External");
         CtrInputGate.SelectedIndex = 0;
         CtrOutputGate.SelectedIndex = 0;

			SetUIState();

         Stop.Enabled = false;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.components = new System.ComponentModel.Container();
         System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
         this.Stop = new System.Windows.Forms.Button();
         this.Quit = new System.Windows.Forms.Button();
         this.Go = new System.Windows.Forms.Button();
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.CtrInputResource = new System.Windows.Forms.TextBox();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.CtrInputValues = new System.Windows.Forms.TextBox();
         this.label6 = new System.Windows.Forms.Label();
         this.CtrInputGate = new System.Windows.Forms.ComboBox();
         this.label2 = new System.Windows.Forms.Label();
         this.CtrInputSource = new System.Windows.Forms.ComboBox();
         this.label5 = new System.Windows.Forms.Label();
         this.CtrInputEnable = new System.Windows.Forms.CheckBox();
         this.CtrInputMode = new System.Windows.Forms.ComboBox();
         this.label3 = new System.Windows.Forms.Label();
         this.groupBox2 = new System.Windows.Forms.GroupBox();
         this.pictureBox1 = new System.Windows.Forms.PictureBox();
         this.label8 = new System.Windows.Forms.Label();
         this.CtrOutputTick2 = new System.Windows.Forms.NumericUpDown();
         this.Tick1 = new System.Windows.Forms.Label();
         this.CtrOutputTick1 = new System.Windows.Forms.NumericUpDown();
         this.label1 = new System.Windows.Forms.Label();
         this.CtrOutputGate = new System.Windows.Forms.ComboBox();
         this.label7 = new System.Windows.Forms.Label();
         this.CtrOutputSource = new System.Windows.Forms.ComboBox();
         this.CtrOutputMode = new System.Windows.Forms.ComboBox();
         this.label4 = new System.Windows.Forms.Label();
         this.CtrOutputResource = new System.Windows.Forms.TextBox();
         this.CtrOutputEnable = new System.Windows.Forms.CheckBox();
         this.CITimer = new System.Windows.Forms.Timer(this.components);
         this.groupBox1.SuspendLayout();
         this.groupBox2.SuspendLayout();
         ((System.ComponentModel.ISupportInitialize)(this.CtrOutputTick2)).BeginInit();
         ((System.ComponentModel.ISupportInitialize)(this.CtrOutputTick1)).BeginInit();
         this.SuspendLayout();
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(216, 224);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(112, 32);
         this.Stop.TabIndex = 24;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(360, 224);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(112, 32);
         this.Quit.TabIndex = 23;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(72, 224);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(112, 32);
         this.Go.TabIndex = 22;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // ErrorText
         // 
         this.ErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
         this.ErrorText.Location = new System.Drawing.Point(0, 262);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(552, 48);
         this.ErrorText.TabIndex = 25;
         this.ErrorText.Text = "";
         // 
         // CtrInputResource
         // 
         this.CtrInputResource.Location = new System.Drawing.Point(16, 32);
         this.CtrInputResource.Name = "CtrInputResource";
         this.CtrInputResource.Size = new System.Drawing.Size(112, 20);
         this.CtrInputResource.TabIndex = 26;
         this.CtrInputResource.Text = "simu://Dev0/Ci0";
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.CtrInputValues);
         this.groupBox1.Controls.Add(this.label6);
         this.groupBox1.Controls.Add(this.CtrInputGate);
         this.groupBox1.Controls.Add(this.label2);
         this.groupBox1.Controls.Add(this.CtrInputSource);
         this.groupBox1.Controls.Add(this.label5);
         this.groupBox1.Controls.Add(this.CtrInputEnable);
         this.groupBox1.Controls.Add(this.CtrInputMode);
         this.groupBox1.Controls.Add(this.label3);
         this.groupBox1.Location = new System.Drawing.Point(8, 8);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(536, 96);
         this.groupBox1.TabIndex = 28;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Counter Input";
         // 
         // CtrInputValues
         // 
         this.CtrInputValues.Location = new System.Drawing.Point(280, 24);
         this.CtrInputValues.Multiline = true;
         this.CtrInputValues.Name = "CtrInputValues";
         this.CtrInputValues.ReadOnly = true;
         this.CtrInputValues.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.CtrInputValues.Size = new System.Drawing.Size(240, 64);
         this.CtrInputValues.TabIndex = 37;
         this.CtrInputValues.Text = "";
         // 
         // label6
         // 
         this.label6.Location = new System.Drawing.Point(144, 48);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(120, 16);
         this.label6.TabIndex = 36;
         this.label6.Text = "Counter Gate";
         // 
         // CtrInputGate
         // 
         this.CtrInputGate.Location = new System.Drawing.Point(144, 64);
         this.CtrInputGate.Name = "CtrInputGate";
         this.CtrInputGate.Size = new System.Drawing.Size(112, 21);
         this.CtrInputGate.TabIndex = 35;
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(144, 8);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(120, 16);
         this.label2.TabIndex = 34;
         this.label2.Text = "Counter Source";
         // 
         // CtrInputSource
         // 
         this.CtrInputSource.Location = new System.Drawing.Point(144, 24);
         this.CtrInputSource.Name = "CtrInputSource";
         this.CtrInputSource.Size = new System.Drawing.Size(112, 21);
         this.CtrInputSource.TabIndex = 33;
         // 
         // label5
         // 
         this.label5.Location = new System.Drawing.Point(280, 8);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(96, 16);
         this.label5.TabIndex = 32;
         this.label5.Text = "Counter Value(s)";
         // 
         // CtrInputEnable
         // 
         this.CtrInputEnable.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
         this.CtrInputEnable.Checked = true;
         this.CtrInputEnable.CheckState = System.Windows.Forms.CheckState.Checked;
         this.CtrInputEnable.Location = new System.Drawing.Point(8, 0);
         this.CtrInputEnable.Name = "CtrInputEnable";
         this.CtrInputEnable.Size = new System.Drawing.Size(96, 16);
         this.CtrInputEnable.TabIndex = 1;
         this.CtrInputEnable.Text = "Counter Input";
         this.CtrInputEnable.CheckedChanged += new System.EventHandler(this.OnUIStateChange);
         // 
         // CtrInputMode
         // 
         this.CtrInputMode.Location = new System.Drawing.Point(8, 64);
         this.CtrInputMode.Name = "CtrInputMode";
         this.CtrInputMode.Size = new System.Drawing.Size(112, 21);
         this.CtrInputMode.TabIndex = 0;
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(8, 48);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(120, 16);
         this.label3.TabIndex = 30;
         this.label3.Text = "Counter Mode";
         // 
         // groupBox2
         // 
         this.groupBox2.Controls.Add(this.pictureBox1);
         this.groupBox2.Controls.Add(this.label8);
         this.groupBox2.Controls.Add(this.CtrOutputTick2);
         this.groupBox2.Controls.Add(this.Tick1);
         this.groupBox2.Controls.Add(this.CtrOutputTick1);
         this.groupBox2.Controls.Add(this.label1);
         this.groupBox2.Controls.Add(this.CtrOutputGate);
         this.groupBox2.Controls.Add(this.label7);
         this.groupBox2.Controls.Add(this.CtrOutputSource);
         this.groupBox2.Controls.Add(this.CtrOutputMode);
         this.groupBox2.Controls.Add(this.label4);
         this.groupBox2.Controls.Add(this.CtrOutputResource);
         this.groupBox2.Controls.Add(this.CtrOutputEnable);
         this.groupBox2.Location = new System.Drawing.Point(8, 112);
         this.groupBox2.Name = "groupBox2";
         this.groupBox2.Size = new System.Drawing.Size(536, 96);
         this.groupBox2.TabIndex = 29;
         this.groupBox2.TabStop = false;
         this.groupBox2.Text = "Counter Output";
         // 
         // pictureBox1
         // 
         this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
         this.pictureBox1.Location = new System.Drawing.Point(408, 16);
         this.pictureBox1.Name = "pictureBox1";
         this.pictureBox1.Size = new System.Drawing.Size(120, 72);
         this.pictureBox1.TabIndex = 45;
         this.pictureBox1.TabStop = false;
         // 
         // label8
         // 
         this.label8.Location = new System.Drawing.Point(280, 48);
         this.label8.Name = "label8";
         this.label8.Size = new System.Drawing.Size(120, 16);
         this.label8.TabIndex = 44;
         this.label8.Text = "Tick2";
         // 
         // CtrOutputTick2
         // 
         this.CtrOutputTick2.Location = new System.Drawing.Point(280, 64);
         this.CtrOutputTick2.Maximum = new System.Decimal(new int[] {
                                                                       1000000,
                                                                       0,
                                                                       0,
                                                                       0});
         this.CtrOutputTick2.Name = "CtrOutputTick2";
         this.CtrOutputTick2.Size = new System.Drawing.Size(112, 20);
         this.CtrOutputTick2.TabIndex = 43;
         this.CtrOutputTick2.Value = new System.Decimal(new int[] {
                                                                     1000,
                                                                     0,
                                                                     0,
                                                                     0});
         // 
         // Tick1
         // 
         this.Tick1.Location = new System.Drawing.Point(280, 8);
         this.Tick1.Name = "Tick1";
         this.Tick1.Size = new System.Drawing.Size(120, 16);
         this.Tick1.TabIndex = 42;
         this.Tick1.Text = "Tick1";
         // 
         // CtrOutputTick1
         // 
         this.CtrOutputTick1.Location = new System.Drawing.Point(280, 24);
         this.CtrOutputTick1.Maximum = new System.Decimal(new int[] {
                                                                       1000000,
                                                                       0,
                                                                       0,
                                                                       0});
         this.CtrOutputTick1.Name = "CtrOutputTick1";
         this.CtrOutputTick1.Size = new System.Drawing.Size(112, 20);
         this.CtrOutputTick1.TabIndex = 41;
         this.CtrOutputTick1.Value = new System.Decimal(new int[] {
                                                                     1000,
                                                                     0,
                                                                     0,
                                                                     0});
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(144, 50);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(120, 16);
         this.label1.TabIndex = 40;
         this.label1.Text = "Counter Gate";
         // 
         // CtrOutputGate
         // 
         this.CtrOutputGate.Location = new System.Drawing.Point(144, 66);
         this.CtrOutputGate.Name = "CtrOutputGate";
         this.CtrOutputGate.Size = new System.Drawing.Size(112, 21);
         this.CtrOutputGate.TabIndex = 39;
         // 
         // label7
         // 
         this.label7.Location = new System.Drawing.Point(144, 10);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(120, 16);
         this.label7.TabIndex = 38;
         this.label7.Text = "Counter Source";
         // 
         // CtrOutputSource
         // 
         this.CtrOutputSource.Location = new System.Drawing.Point(144, 26);
         this.CtrOutputSource.Name = "CtrOutputSource";
         this.CtrOutputSource.Size = new System.Drawing.Size(112, 21);
         this.CtrOutputSource.TabIndex = 37;
         // 
         // CtrOutputMode
         // 
         this.CtrOutputMode.Location = new System.Drawing.Point(8, 64);
         this.CtrOutputMode.Name = "CtrOutputMode";
         this.CtrOutputMode.Size = new System.Drawing.Size(112, 21);
         this.CtrOutputMode.TabIndex = 31;
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(8, 48);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(120, 16);
         this.label4.TabIndex = 32;
         this.label4.Text = "Counter Mode";
         // 
         // CtrOutputResource
         // 
         this.CtrOutputResource.Location = new System.Drawing.Point(8, 24);
         this.CtrOutputResource.Name = "CtrOutputResource";
         this.CtrOutputResource.Size = new System.Drawing.Size(112, 20);
         this.CtrOutputResource.TabIndex = 28;
         this.CtrOutputResource.Text = "simu://Dev0/Co1";
         // 
         // CtrOutputEnable
         // 
         this.CtrOutputEnable.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
         this.CtrOutputEnable.Location = new System.Drawing.Point(8, 0);
         this.CtrOutputEnable.Name = "CtrOutputEnable";
         this.CtrOutputEnable.Size = new System.Drawing.Size(104, 16);
         this.CtrOutputEnable.TabIndex = 2;
         this.CtrOutputEnable.Text = "Counter Output";
         this.CtrOutputEnable.CheckedChanged += new System.EventHandler(this.OnUIStateChange);
         // 
         // CITimer
         // 
         this.CITimer.Tick += new System.EventHandler(this.OnCITimerTick);
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(552, 310);
         this.Controls.Add(this.CtrInputResource);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.groupBox2);
         this.Name = "Form1";
         this.Text = "Form1";
         this.groupBox1.ResumeLayout(false);
         this.groupBox2.ResumeLayout(false);
         ((System.ComponentModel.ISupportInitialize)(this.CtrOutputTick2)).EndInit();
         ((System.ComponentModel.ISupportInitialize)(this.CtrOutputTick1)).EndInit();
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private void Quit_Click(object sender, System.EventArgs e)
      {
         Application.Exit();
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         try
         {
            if(CtrInputEnable.Checked)
            {
               CtrInputResource.Enabled = true;
               CITimer.Stop();
               ciSs.Stop();
            }

            if (CtrOutputEnable.Checked)
            {
               CtrOutputResource.Enabled = true;
               coSs.Stop();
            }

            CtrInputEnable.Enabled = true;
            CtrOutputEnable.Enabled = true;
            Go.Enabled = true;
            Stop.Enabled = false;
         }
         catch(UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
         }

         if(ciSs != null)
         {
            ciSs.Dispose();
            ciSs = null;
         }
         if(coSs != null)
         {
            coSs.Dispose();
            coSs = null;
         }
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         try
         {
            // Configure and start counter input
            if(CtrInputEnable.Checked)
            {
               ciSs = new Session();
               ciSs.CreateCIChannel(CtrInputResource.Text,
                                    CtrSources[CtrInputSource.SelectedIndex],
                                    CtrInputModes[CtrInputMode.SelectedIndex],
                                    CtrGates[CtrInputGate.SelectedIndex],
                                    1,
                                    0);

               ciSs.ConfigureTimingForSimpleIO();

               ciReader = new CounterReader(ciSs.GetDataStream());

               ciSs.Start();

               CITimer.Interval=10;
               CITimer.Start();
            }

            // Configure and start counter output
            if(CtrOutputEnable.Checked)
            {
               coSs = new Session();
               coSs.CreateCOChannel(CtrOutputResource.Text,
                                    CtrSources[CtrOutputSource.SelectedIndex],
                                    CtrOutputModes[CtrOutputMode.SelectedIndex],
                                    CtrGates[CtrOutputGate.SelectedIndex],
                                    (int)CtrOutputTick1.Value,
                                    (int)CtrOutputTick2.Value,
                                    1,
                                    0);

               coSs.ConfigureTimingForSimpleIO();

               coWriter = new CounterWriter(coSs.GetDataStream());

               coSs.Start();
            }

            CtrInputEnable.Enabled = false;
            CtrOutputEnable.Enabled = false;
            Go.Enabled = false;
            Stop.Enabled = true;
            CtrInputResource.Enabled = false;
            CtrOutputResource.Enabled = false;
         }
         catch(UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            if(ciSs != null)
            {
               ciSs.Dispose();
               ciSs = null;
            }
            if(coSs != null)
            {
               coSs.Dispose();
               coSs = null;
            }
         }
      }

      private void SetUIState()
      {
         bool bInputEnable = false;
         bool bOutputEnable = false;

         if(CtrInputEnable.Checked)
            bInputEnable = true;

         if(CtrOutputEnable.Checked)
            bOutputEnable = true;

         // Set state for the input controls
         CtrInputResource.Enabled = bInputEnable;
         CtrInputMode.Enabled = bInputEnable;
         CtrInputSource.Enabled = bInputEnable;
         CtrInputGate.Enabled = bInputEnable;
         CtrInputValues.Enabled = bInputEnable;

         // Set state for the output controls
         CtrOutputResource.Enabled = bOutputEnable;
         CtrOutputMode.Enabled = bOutputEnable;
         CtrOutputSource.Enabled = bOutputEnable;
         CtrOutputGate.Enabled = bOutputEnable;
         CtrOutputTick1.Enabled = bOutputEnable;
         CtrOutputTick2.Enabled = bOutputEnable;
      }

      private void OnUIStateChange(object sender, System.EventArgs e)
      {
         SetUIState();
      }

      private void OnCITimerTick(object sender, System.EventArgs e)
      {
         if(ciSs.GetDataStream().GetSampleSize() == 2)
         {
            UInt16[] val = ciReader.ReadSingleScanUInt16();
            String[] valLines = new String[ciSs.GetNumberOfChannels()];
            for(int ch=0; ch<ciSs.GetNumberOfChannels(); ch++)
            {
               valLines[ch] = String.Format("Ctr{0}: ", ch) + val[ch].ToString();
            }
            CtrInputValues.Lines = valLines;
         }
         else
         {
            UInt32[] val = ciReader.ReadSingleScanUInt32();
            String[] valLines = new String[ciSs.GetNumberOfChannels()];
            for(int ch=0; ch<ciSs.GetNumberOfChannels(); ch++)
            {
               valLines[ch] = String.Format("Ctr{0}: ", ch) + val[ch].ToString();
            }
            CtrInputValues.Lines = valLines;
         }
      }
	}
}
