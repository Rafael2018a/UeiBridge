﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace AIAOLVDT_Coils
{
   class Program
   {
      static void Main(string[] args)
      {
         string aiResource = "pdna://192.168.100.12/dev2/ai1";
         string aoResource = "pdna://192.168.100.12/dev2/ao0";
         bool stop = false;

         try
         {
            // Configure LVDT input session
            Session aiSession = new Session();

            aiSession.CreateLVDTChannel(aiResource, -10, 10, 1000.0, LVDTWiringScheme.FiveWires, 5.0, 400.0, false);
            aiSession.ConfigureTimingForSimpleIO();
            aiSession.Start();

            LVDTReader reader = new LVDTReader(aiSession.GetDataStream());

            // Configure LVDT output session
            Session aoSession = new Session();

            aoSession.CreateSimulatedLVDTChannel(aoResource, 1000.0, LVDTWiringScheme.FiveWires, 5.0, 400.0);
            aoSession.ConfigureTimingForSimpleIO();
            aoSession.Start();

            AnalogScaledWriter writer = new AnalogScaledWriter(aoSession.GetDataStream());

            int count = 0;
            while (!stop)
            {
               double[] aoData = new double[4];

               for (int ch = 0; ch < aoSession.GetNumberOfChannels(); ch++)
               {
                  aoData[ch] = -1.0 + (count % 20) / 10.0;
               }

               writer.WriteSingleScan(aoData);

               Thread.Sleep(500);

               double[] displacement = reader.ReadSingleDisplacement();
               double[] primaryCoils = new double[4];
               double[] secondaryCoils = new double[4];
               reader.ReadCoilAmplitudes(primaryCoils, secondaryCoils);

               for (int ch = 0; ch < aiSession.GetNumberOfChannels(); ch++)
               { 
                  Console.WriteLine("Channel"+aiSession.GetChannel(ch).GetIndex()+ ": displacement="+ displacement[ch].ToString()
                     + " vA=" + primaryCoils[ch].ToString() + " vB=" + secondaryCoils[ch].ToString());
               }

               count++;
            }

            aiSession.Stop();
            aoSession.Stop();
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop= false;
   }
}
