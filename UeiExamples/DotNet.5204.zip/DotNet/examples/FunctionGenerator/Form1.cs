using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Collections.Generic;
using UeiDaq;

namespace FunctionGenerator
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class FunctionGenerator : System.Windows.Forms.Form
	{
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.TextBox MasterResource;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.GroupBox groupBox1;
      private Session mySs;
      private List<AOWaveformWriter> writers;
      private ComboBox ChannelToUpdate;
      private ComboBox WfmShape;
      private Label label3;
      private TextBox SlaveResource;
      private Label label1;
      private Label label4;
      private TextBox RiseTime;
      private Label label9;
      private TextBox DutyCycle;
      private Label label8;
      private TextBox Amplitude;
      private TextBox Frequency;
      private Label label7;
      private Label label6;
      private Label label5;
      private TextBox FallTime;
      private Label label10;
      private Button UpdateChannel;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FunctionGenerator()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

         ChannelToUpdate.SelectedIndex = 0;
         WfmShape.SelectedIndex = 0;
         Stop.Enabled = false;
         UpdateChannel.Enabled = false;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.MasterResource = new System.Windows.Forms.TextBox();
         this.Stop = new System.Windows.Forms.Button();
         this.label2 = new System.Windows.Forms.Label();
         this.Quit = new System.Windows.Forms.Button();
         this.Go = new System.Windows.Forms.Button();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.RiseTime = new System.Windows.Forms.TextBox();
         this.label9 = new System.Windows.Forms.Label();
         this.DutyCycle = new System.Windows.Forms.TextBox();
         this.label8 = new System.Windows.Forms.Label();
         this.Amplitude = new System.Windows.Forms.TextBox();
         this.Frequency = new System.Windows.Forms.TextBox();
         this.ChannelToUpdate = new System.Windows.Forms.ComboBox();
         this.label7 = new System.Windows.Forms.Label();
         this.label6 = new System.Windows.Forms.Label();
         this.label5 = new System.Windows.Forms.Label();
         this.WfmShape = new System.Windows.Forms.ComboBox();
         this.label4 = new System.Windows.Forms.Label();
         this.label3 = new System.Windows.Forms.Label();
         this.SlaveResource = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.FallTime = new System.Windows.Forms.TextBox();
         this.label10 = new System.Windows.Forms.Label();
         this.UpdateChannel = new System.Windows.Forms.Button();
         this.groupBox1.SuspendLayout();
         this.SuspendLayout();
         // 
         // ErrorText
         // 
         this.ErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
         this.ErrorText.Location = new System.Drawing.Point(0, 461);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(400, 48);
         this.ErrorText.TabIndex = 24;
         // 
         // MasterResource
         // 
         this.MasterResource.Location = new System.Drawing.Point(8, 24);
         this.MasterResource.Name = "MasterResource";
         this.MasterResource.Size = new System.Drawing.Size(240, 20);
         this.MasterResource.TabIndex = 21;
         this.MasterResource.Text = "pdna://192.168.100.3/Dev4/Ao0";
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(272, 68);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(112, 32);
         this.Stop.TabIndex = 23;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(8, 8);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(120, 16);
         this.label2.TabIndex = 22;
         this.label2.Text = "Master channel";
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(272, 108);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(112, 32);
         this.Quit.TabIndex = 20;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(272, 28);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(112, 32);
         this.Go.TabIndex = 19;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.UpdateChannel);
         this.groupBox1.Controls.Add(this.RiseTime);
         this.groupBox1.Controls.Add(this.label9);
         this.groupBox1.Controls.Add(this.DutyCycle);
         this.groupBox1.Controls.Add(this.label8);
         this.groupBox1.Controls.Add(this.Amplitude);
         this.groupBox1.Controls.Add(this.Frequency);
         this.groupBox1.Controls.Add(this.ChannelToUpdate);
         this.groupBox1.Controls.Add(this.label7);
         this.groupBox1.Controls.Add(this.label6);
         this.groupBox1.Controls.Add(this.label5);
         this.groupBox1.Controls.Add(this.WfmShape);
         this.groupBox1.Controls.Add(this.label4);
         this.groupBox1.Controls.Add(this.label3);
         this.groupBox1.Location = new System.Drawing.Point(8, 90);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(256, 353);
         this.groupBox1.TabIndex = 27;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Waveform parameters";
         // 
         // RiseTime
         // 
         this.RiseTime.Enabled = false;
         this.RiseTime.Location = new System.Drawing.Point(9, 268);
         this.RiseTime.Name = "RiseTime";
         this.RiseTime.Size = new System.Drawing.Size(100, 20);
         this.RiseTime.TabIndex = 27;
         this.RiseTime.Text = "0.0";
         // 
         // label9
         // 
         this.label9.Location = new System.Drawing.Point(6, 250);
         this.label9.Name = "label9";
         this.label9.Size = new System.Drawing.Size(120, 16);
         this.label9.TabIndex = 26;
         this.label9.Text = "Rise Time";
         // 
         // DutyCycle
         // 
         this.DutyCycle.Enabled = false;
         this.DutyCycle.Location = new System.Drawing.Point(9, 220);
         this.DutyCycle.Name = "DutyCycle";
         this.DutyCycle.Size = new System.Drawing.Size(100, 20);
         this.DutyCycle.TabIndex = 25;
         this.DutyCycle.Text = "0.0";
         // 
         // label8
         // 
         this.label8.Location = new System.Drawing.Point(6, 202);
         this.label8.Name = "label8";
         this.label8.Size = new System.Drawing.Size(120, 16);
         this.label8.TabIndex = 24;
         this.label8.Text = "Duty Cycle";
         // 
         // Amplitude
         // 
         this.Amplitude.Location = new System.Drawing.Point(9, 174);
         this.Amplitude.Name = "Amplitude";
         this.Amplitude.Size = new System.Drawing.Size(100, 20);
         this.Amplitude.TabIndex = 23;
         this.Amplitude.Text = "10.0";
         // 
         // Frequency
         // 
         this.Frequency.Location = new System.Drawing.Point(9, 128);
         this.Frequency.Name = "Frequency";
         this.Frequency.Size = new System.Drawing.Size(100, 20);
         this.Frequency.TabIndex = 23;
         this.Frequency.Text = "100.0";
         // 
         // ChannelToUpdate
         // 
         this.ChannelToUpdate.FormattingEnabled = true;
         this.ChannelToUpdate.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
         this.ChannelToUpdate.Location = new System.Drawing.Point(9, 36);
         this.ChannelToUpdate.Name = "ChannelToUpdate";
         this.ChannelToUpdate.Size = new System.Drawing.Size(73, 21);
         this.ChannelToUpdate.TabIndex = 0;
         // 
         // label7
         // 
         this.label7.Location = new System.Drawing.Point(6, 156);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(120, 16);
         this.label7.TabIndex = 22;
         this.label7.Text = "Amplitude";
         // 
         // label6
         // 
         this.label6.Location = new System.Drawing.Point(6, 110);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(120, 16);
         this.label6.TabIndex = 22;
         this.label6.Text = "Frequency";
         // 
         // label5
         // 
         this.label5.Location = new System.Drawing.Point(6, 62);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(120, 16);
         this.label5.TabIndex = 22;
         this.label5.Text = "Shape";
         // 
         // WfmShape
         // 
         this.WfmShape.FormattingEnabled = true;
         this.WfmShape.Items.AddRange(new object[] {
            "Sine",
            "Pulse",
            "Triangle",
            "Sawtooth"});
         this.WfmShape.Location = new System.Drawing.Point(9, 80);
         this.WfmShape.Name = "WfmShape";
         this.WfmShape.Size = new System.Drawing.Size(73, 21);
         this.WfmShape.TabIndex = 0;
         this.WfmShape.SelectedIndexChanged += new System.EventHandler(this.WfmShape_SelectedIndexChanged);
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(6, 62);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(120, 16);
         this.label4.TabIndex = 22;
         this.label4.Text = "Shape";
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(6, 18);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(120, 16);
         this.label3.TabIndex = 22;
         this.label3.Text = "Channel to update";
         // 
         // SlaveResource
         // 
         this.SlaveResource.Location = new System.Drawing.Point(8, 64);
         this.SlaveResource.Name = "SlaveResource";
         this.SlaveResource.Size = new System.Drawing.Size(240, 20);
         this.SlaveResource.TabIndex = 21;
         this.SlaveResource.Text = "pdna://192.168.100.3/Dev4/Ao1,2,3";
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(8, 48);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(120, 16);
         this.label1.TabIndex = 22;
         this.label1.Text = "Slave channel(s)";
         // 
         // FallTime
         // 
         this.FallTime.Enabled = false;
         this.FallTime.Location = new System.Drawing.Point(17, 402);
         this.FallTime.Name = "FallTime";
         this.FallTime.Size = new System.Drawing.Size(100, 20);
         this.FallTime.TabIndex = 29;
         this.FallTime.Text = "0.0";
         // 
         // label10
         // 
         this.label10.Location = new System.Drawing.Point(14, 384);
         this.label10.Name = "label10";
         this.label10.Size = new System.Drawing.Size(120, 16);
         this.label10.TabIndex = 28;
         this.label10.Text = "Fall Time";
         // 
         // UpdateChannel
         // 
         this.UpdateChannel.Location = new System.Drawing.Point(128, 25);
         this.UpdateChannel.Name = "UpdateChannel";
         this.UpdateChannel.Size = new System.Drawing.Size(112, 32);
         this.UpdateChannel.TabIndex = 28;
         this.UpdateChannel.Text = "Update!";
         this.UpdateChannel.Click += new System.EventHandler(this.UpdateChannel_Click);
         // 
         // FunctionGenerator
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(400, 509);
         this.Controls.Add(this.FallTime);
         this.Controls.Add(this.label10);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.SlaveResource);
         this.Controls.Add(this.MasterResource);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Name = "FunctionGenerator";
         this.Text = "Function Generator";
         this.groupBox1.ResumeLayout(false);
         this.groupBox1.PerformLayout();
         this.ResumeLayout(false);
         this.PerformLayout();

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new FunctionGenerator());
		}

      private void Quit_Click(object sender, System.EventArgs e)
      {
         Application.Exit();
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         ErrorText.Clear();
         ChannelToUpdate.Items.Clear();
                     
         try
         {
            mySs = new Session();
            // Use channel 0 as master clock to synchronize all channels
            mySs.CreateAOWaveformChannel(MasterResource.Text, 
                                         AOWaveformClockSource.Alt0,
                                         AOWaveformOffsetClockSource.SW,
                                         AOWaveformClockSync.PLLToTrgOut);

            // Configure slave channels 1, 2 and 3 to pick-up clock from channel 0
            mySs.CreateAOWaveformChannel(SlaveResource.Text,
                                         AOWaveformClockSource.Alt0,
                                         AOWaveformOffsetClockSource.SW,
                                         AOWaveformClockSync.None);
               
            for(int i=0; i<mySs.GetNumberOfChannels(); i++)
            {
               ChannelToUpdate.Items.Add("channel " + mySs.GetChannel(i).GetIndex().ToString());
            }
            ChannelToUpdate.SelectedIndex = 0;

            mySs.ConfigureTimingForSimpleIO();

            // Function generator channels can generate different waveforms at different rates.
            // We need one writer per channel to configure them independantly
            // Create a writer and configure different waveform shape on each channel
            writers = new List<AOWaveformWriter>();
            foreach (Channel ch in mySs.GetChannels())
            {
               writers.Add(new AOWaveformWriter(mySs.GetDataStream(), ch.GetIndex()));
            }
 
            mySs.Start();

            foreach (AOWaveformWriter writer in writers)
            {
               AOWaveformParameters[] wfmParams = new AOWaveformParameters[1];
               wfmParams[0] = new AOWaveformParameters();
               wfmParams[0].mode = AOWaveformMode.DDS;
               wfmParams[0].type = (AOWaveformType)WfmShape.SelectedIndex;
               wfmParams[0].xform = AOWaveformXform.None;
               wfmParams[0].applyTime = 0.0;
               wfmParams[0].frequency = Convert.ToDouble(Frequency.Text);
               wfmParams[0].span = Convert.ToDouble(Amplitude.Text);
               wfmParams[0].offset = 0.0;
               wfmParams[0].phase = 0.0;
               wfmParams[0].dutyCycle = Convert.ToSingle(DutyCycle.Text);
               wfmParams[0].riseTime = Convert.ToSingle(RiseTime.Text);
               wfmParams[0].fallTime = Convert.ToSingle(FallTime.Text);

               writer.WriteWaveforms(wfmParams);
            }
              
            MasterResource.Enabled = false;
            SlaveResource.Enabled = false;
            Go.Enabled = false;
            Stop.Enabled = true;
            UpdateChannel.Enabled = true;
         }
         catch(UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            mySs.Dispose();
            mySs = null;
         }
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         MasterResource.Enabled = true;
         SlaveResource.Enabled = true;
         Go.Enabled = true;
         Stop.Enabled = false;
         UpdateChannel.Enabled = false;

         if(mySs != null)
         {
            try
            {
               mySs.Stop();
            }
            catch(UeiDaqException exception)
            {
               ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }

            mySs.Dispose();
            mySs = null;
         }
      }

      private void WfmShape_SelectedIndexChanged(object sender, EventArgs e)
      {
         ComboBox comboBox = (ComboBox)sender;

         switch ((AOWaveformType)comboBox.SelectedIndex)
         {
            case AOWaveformType.Sine:
            case AOWaveformType.Triangle:
               DutyCycle.Enabled = false;
               RiseTime.Enabled = false;
               FallTime.Enabled = false;
               break;
            case AOWaveformType.Pulse:
               DutyCycle.Enabled = true;
               RiseTime.Enabled = true;
               FallTime.Enabled = true;
               break;
            case AOWaveformType.SawTooth:
               DutyCycle.Enabled = false;
               RiseTime.Enabled = true;
               FallTime.Enabled = false;
               break;
         }
      }

      private void UpdateChannel_Click(object sender, EventArgs e)
      {
         try
         {
            AOWaveformParameters[] wfmParams = new AOWaveformParameters[1];
            wfmParams[0] = new AOWaveformParameters();
            wfmParams[0].mode = AOWaveformMode.DDS;
            wfmParams[0].type = (AOWaveformType)WfmShape.SelectedIndex;
            wfmParams[0].xform = AOWaveformXform.None;
            wfmParams[0].applyTime = 0.0;
            wfmParams[0].frequency = Convert.ToDouble(Frequency.Text);
            wfmParams[0].span = Convert.ToDouble(Amplitude.Text);
            wfmParams[0].offset = 0.0;
            wfmParams[0].phase = 0.0;
            wfmParams[0].dutyCycle = Convert.ToSingle(DutyCycle.Text);
            wfmParams[0].riseTime = Convert.ToSingle(RiseTime.Text);
            wfmParams[0].fallTime = Convert.ToSingle(FallTime.Text);

            AOWaveformWriter writer = writers[ChannelToUpdate.SelectedIndex];
            writer.WriteWaveforms(wfmParams);
         }
         catch (UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
         }
      } 
	}
}
