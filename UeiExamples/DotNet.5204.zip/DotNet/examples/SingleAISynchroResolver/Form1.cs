using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using UeiDaq;

namespace SingleAISynchroResolver
{
   /// <summary>
   /// Summary description for Form1.
   /// </summary>
   public class Form1 : System.Windows.Forms.Form
   {
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Label label2;
      private Session mySs = null;
      private AnalogScaledReader reader;
      private double[] scan;
      private Timer AITimer;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.ListView Data;
      private System.Windows.Forms.ColumnHeader Channel;
      private System.Windows.Forms.ColumnHeader Value;
      private System.Windows.Forms.Label DataLabel;
      private System.Windows.Forms.ComboBox SRMode;
      private System.Windows.Forms.Label label9;
      private System.Windows.Forms.Label label10;
      private System.Windows.Forms.Label label11;
      private System.Windows.Forms.CheckBox Excitation;
      private System.Windows.Forms.TextBox ExVoltage;
      private System.Windows.Forms.TextBox ExFreq;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public Form1()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         Go.Enabled = true;
         Stop.Enabled = false;
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose(bool disposing)
      {
         if (disposing)
         {
            if (components != null)
            {
               components.Dispose();
            }
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
         this.Go = new System.Windows.Forms.Button();
         this.Quit = new System.Windows.Forms.Button();
         this.Resource = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.Stop = new System.Windows.Forms.Button();
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.Data = new System.Windows.Forms.ListView();
         this.Channel = new System.Windows.Forms.ColumnHeader();
         this.Value = new System.Windows.Forms.ColumnHeader();
         this.DataLabel = new System.Windows.Forms.Label();
         this.SRMode = new System.Windows.Forms.ComboBox();
         this.label9 = new System.Windows.Forms.Label();
         this.label10 = new System.Windows.Forms.Label();
         this.label11 = new System.Windows.Forms.Label();
         this.Excitation = new System.Windows.Forms.CheckBox();
         this.ExVoltage = new System.Windows.Forms.TextBox();
         this.ExFreq = new System.Windows.Forms.TextBox();
         this.SuspendLayout();
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(440, 16);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(144, 40);
         this.Go.TabIndex = 1;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(440, 112);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(144, 40);
         this.Quit.TabIndex = 2;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(8, 24);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(112, 20);
         this.Resource.TabIndex = 3;
         this.Resource.Text = "simu://Dev0/Ai0:7";
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(4, 8);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(120, 16);
         this.label2.TabIndex = 9;
         this.label2.Text = "Resource name";
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(440, 64);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(144, 40);
         this.Stop.TabIndex = 11;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // ErrorText
         // 
         this.ErrorText.Location = new System.Drawing.Point(8, 299);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(576, 48);
         this.ErrorText.TabIndex = 12;
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(8, 280);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(104, 16);
         this.label1.TabIndex = 13;
         this.label1.Text = "Error Message";
         // 
         // Data
         // 
         this.Data.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Channel,
            this.Value});
         this.Data.GridLines = true;
         this.Data.Location = new System.Drawing.Point(181, 24);
         this.Data.Name = "Data";
         this.Data.Size = new System.Drawing.Size(236, 233);
         this.Data.TabIndex = 22;
         this.Data.UseCompatibleStateImageBehavior = false;
         this.Data.View = System.Windows.Forms.View.Details;
         // 
         // Channel
         // 
         this.Channel.Text = "Channel";
         // 
         // Value
         // 
         this.Value.Text = "Value";
         this.Value.Width = 82;
         // 
         // DataLabel
         // 
         this.DataLabel.AutoSize = true;
         this.DataLabel.Location = new System.Drawing.Point(178, 8);
         this.DataLabel.Name = "DataLabel";
         this.DataLabel.Size = new System.Drawing.Size(77, 13);
         this.DataLabel.TabIndex = 23;
         this.DataLabel.Text = "Gathered Data";
         // 
         // SRMode
         // 
         this.SRMode.DisplayMember = "Synchro";
         this.SRMode.Items.AddRange(new object[] {
            UeiDaq.SynchroResolverMode.Synchro,
            UeiDaq.SynchroResolverMode.Resolver});
         this.SRMode.Location = new System.Drawing.Point(8, 165);
         this.SRMode.Name = "SRMode";
         this.SRMode.Size = new System.Drawing.Size(121, 21);
         this.SRMode.TabIndex = 32;
         this.SRMode.Text = "Synchro";
         this.SRMode.ValueMember = "Synchro";
         // 
         // label9
         // 
         this.label9.AutoSize = true;
         this.label9.Location = new System.Drawing.Point(4, 59);
         this.label9.Name = "label9";
         this.label9.Size = new System.Drawing.Size(92, 13);
         this.label9.TabIndex = 34;
         this.label9.Text = "Excitation Voltage";
         // 
         // label10
         // 
         this.label10.AutoSize = true;
         this.label10.Location = new System.Drawing.Point(5, 107);
         this.label10.Name = "label10";
         this.label10.Size = new System.Drawing.Size(106, 13);
         this.label10.TabIndex = 35;
         this.label10.Text = "Excitation Frequency";
         // 
         // label11
         // 
         this.label11.AutoSize = true;
         this.label11.Location = new System.Drawing.Point(5, 149);
         this.label11.Name = "label11";
         this.label11.Size = new System.Drawing.Size(34, 13);
         this.label11.TabIndex = 36;
         this.label11.Text = "Mode";
         // 
         // Excitation
         // 
         this.Excitation.Location = new System.Drawing.Point(7, 203);
         this.Excitation.Name = "Excitation";
         this.Excitation.Size = new System.Drawing.Size(135, 17);
         this.Excitation.TabIndex = 38;
         this.Excitation.Text = "Use External Excitation";
         // 
         // ExVoltage
         // 
         this.ExVoltage.Location = new System.Drawing.Point(8, 75);
         this.ExVoltage.Name = "ExVoltage";
         this.ExVoltage.Size = new System.Drawing.Size(100, 20);
         this.ExVoltage.TabIndex = 39;
         this.ExVoltage.Text = "10";
         // 
         // ExFreq
         // 
         this.ExFreq.Location = new System.Drawing.Point(8, 123);
         this.ExFreq.Name = "ExFreq";
         this.ExFreq.Size = new System.Drawing.Size(100, 20);
         this.ExFreq.TabIndex = 40;
         this.ExFreq.Text = "600";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(592, 360);
         this.Controls.Add(this.ExFreq);
         this.Controls.Add(this.ExVoltage);
         this.Controls.Add(this.Excitation);
         this.Controls.Add(this.label10);
         this.Controls.Add(this.SRMode);
         this.Controls.Add(this.Data);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.Resource);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Controls.Add(this.label9);
         this.Controls.Add(this.DataLabel);
         this.Controls.Add(this.label11);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.Name = "Form1";
         this.Text = "SingleAI Synchro / Resolver";
         this.ResumeLayout(false);
         this.PerformLayout();

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main()
      {
         Application.Run(new Form1());
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();

         Application.Exit();
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         UeiDaqStart();
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();
      }

      public void Timer_Tick(object sender, EventArgs eArgs)
      {
         if (sender == AITimer)
         {
            double[] scan = reader.ReadSingleScan();

            for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
            {
               Data.Items[i].SubItems[1].Text = scan[i].ToString();
            }
         }
      }

      private void UeiDaqStart()
      {
         ErrorText.Clear();
         Data.Items.Clear();

         try
         {
            mySs = new Session();
            
            mySs.CreateSynchroResolverChannel(Resource.Text, (SynchroResolverMode)SRMode.SelectedItem, Double.Parse(ExVoltage.Text), Double.Parse(ExFreq.Text), Excitation.Checked);

            for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
            {
               ListViewItem item = Data.Items.Add(mySs.GetChannel(i).GetIndex().ToString());
               item.SubItems.Add("0.0");
            }

            mySs.ConfigureTimingForSimpleIO();

            // Create a reader object to read data synchronously.
            reader = new AnalogScaledReader(mySs.GetDataStream());

            mySs.Start();

            AITimer = new Timer();
            AITimer.Interval = 100;
            AITimer.Start();
            AITimer.Tick += new EventHandler(Timer_Tick);

            Resource.Enabled = false;
            Go.Enabled = false;
            Stop.Enabled = true;
         }
         catch (UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            mySs.Dispose();
            mySs = null;
         }
      }

      private void UeiDaqStop()
      {
         if (mySs != null)
         {
            AITimer.Stop();

            try
            {
               mySs.Stop();
            }
            catch (UeiDaqException exception)
            {
               ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }

            mySs.Dispose();
            mySs = null;
         }

         Resource.Enabled = true;
         Go.Enabled = true;
         Stop.Enabled = false;
      }
   }
}
