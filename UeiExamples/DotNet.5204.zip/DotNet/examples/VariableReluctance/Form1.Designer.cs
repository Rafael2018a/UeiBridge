﻿namespace VariableReluctance
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtResource = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cboVRMode = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.vrTimer = new System.Windows.Forms.Timer(this.components);
            this.counter = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.velocity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lsvData = new System.Windows.Forms.ListView();
            this.ErrorText = new System.Windows.Forms.TextBox();
            this.position = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.teethcount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // txtResource
            // 
            this.txtResource.Location = new System.Drawing.Point(17, 37);
            this.txtResource.Name = "txtResource";
            this.txtResource.Size = new System.Drawing.Size(192, 20);
            this.txtResource.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Resource String";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "VR Mode";
            // 
            // cboVRMode
            // 
            this.cboVRMode.FormattingEnabled = true;
            this.cboVRMode.Location = new System.Drawing.Point(17, 93);
            this.cboVRMode.Name = "cboVRMode";
            this.cboVRMode.Size = new System.Drawing.Size(192, 21);
            this.cboVRMode.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(229, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Encoder Position";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(17, 289);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(107, 46);
            this.btnStart.TabIndex = 9;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(170, 289);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(107, 46);
            this.btnStop.TabIndex = 10;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(316, 289);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(107, 46);
            this.btnQuit.TabIndex = 11;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // vrTimer
            // 
            this.vrTimer.Tick += new System.EventHandler(this.vrTimer_Tick);
            // 
            // counter
            // 
            this.counter.Text = "Channel";
            this.counter.Width = 92;
            // 
            // velocity
            // 
            this.velocity.Text = "Velocity";
            this.velocity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.velocity.Width = 87;
            // 
            // lsvData
            // 
            this.lsvData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.counter,
            this.velocity,
            this.position,
            this.teethcount});
            this.lsvData.GridLines = true;
            this.lsvData.Location = new System.Drawing.Point(232, 37);
            this.lsvData.Name = "lsvData";
            this.lsvData.Size = new System.Drawing.Size(305, 180);
            this.lsvData.TabIndex = 7;
            this.lsvData.UseCompatibleStateImageBehavior = false;
            this.lsvData.View = System.Windows.Forms.View.Details;
            this.lsvData.SelectedIndexChanged += new System.EventHandler(this.lsvData_SelectedIndexChanged);
            // 
            // ErrorText
            // 
            this.ErrorText.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ErrorText.Location = new System.Drawing.Point(0, 341);
            this.ErrorText.Multiline = true;
            this.ErrorText.Name = "ErrorText";
            this.ErrorText.ReadOnly = true;
            this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ErrorText.Size = new System.Drawing.Size(563, 48);
            this.ErrorText.TabIndex = 26;
            // 
            // position
            // 
            this.position.Text = "Position";
            // 
            // teethcount
            // 
            this.teethcount.Text = "Teeth Count";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 389);
            this.Controls.Add(this.ErrorText);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lsvData);
            this.Controls.Add(this.cboVRMode);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtResource);
            this.Name = "Form1";
            this.Text = "Read Quad Encoder ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtResource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboVRMode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Timer vrTimer;
        private System.Windows.Forms.ColumnHeader counter;
        private System.Windows.Forms.ColumnHeader velocity;
        private System.Windows.Forms.ListView lsvData;
        private System.Windows.Forms.TextBox ErrorText;
        private System.Windows.Forms.ColumnHeader position;
        private System.Windows.Forms.ColumnHeader teethcount;
    }
}

