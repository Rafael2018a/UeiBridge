﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UeiDaq;

namespace VariableReluctance
{
    public partial class Form1 : Form
    {
        private Session mySs;
        private VRReader[] vrReaders;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtResource.Text = "pdna://192.168.100.3/dev3/vr0";
            cboVRMode.Items.Add(VRMode.Decoder.ToString());
            cboVRMode.Items.Add(VRMode.CounterTimed.ToString());
            cboVRMode.Items.Add(VRMode.CounterNPulses.ToString());
            cboVRMode.Items.Add(VRMode.CounterZPulse.ToString());
            cboVRMode.SelectedIndex = 1;
          
            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnQuit.Enabled = true;

        }

        private void vrTimer_Tick(object sender, EventArgs e)
        {
            for (int ch = 0; ch < mySs.GetNumberOfChannels(); ch++)
            {
                VRData[] val = vrReaders[ch].Read(1);
                lsvData.Items[ch].SubItems[1].Text = ((Int32)val[0].velocity).ToString();
                lsvData.Items[ch].SubItems[2].Text = ((Int32)val[0].position).ToString();
                lsvData.Items[ch].SubItems[3].Text = ((Int32)val[0].teethCount).ToString();
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            lsvData.Items.Clear();
            ErrorText.Clear();
            mySs = new Session();
            try
            {
                //The line (VRMode)Enum.Parse(typeof(VRMode),cboVRMode.SelectedItem.ToString() is type casting string to enum
                mySs.CreateVRChannel(txtResource.Text, 
                                     (VRMode)Enum.Parse(typeof(VRMode), cboVRMode.SelectedItem.ToString()));

                vrReaders = new VRReader[mySs.GetNumberOfChannels()];
                for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
                {
                    ListViewItem item = lsvData.Items.Add(mySs.GetChannel(i).GetIndex().ToString());
                    item.SubItems.Add("0");
                    item.SubItems.Add("0");
                    item.SubItems.Add("0");

                    vrReaders[i] = new VRReader(mySs.GetDataStream(), mySs.GetChannel(i).GetIndex());
                }
                mySs.ConfigureTimingForSimpleIO();
                
                mySs.Start();
                vrTimer.Start();

                btnStop.Enabled = true;
                btnStart.Enabled = false;
                btnQuit.Enabled = false;
            }
            catch (UeiDaqException exception)
            {
                ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }            
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnQuit.Enabled = true;
            
            ErrorText.Clear();
            vrTimer.Stop();
            try
            {
                mySs.Stop();

            }
            catch (UeiDaqException exception)
            {
                ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }
            mySs.Dispose();
            mySs = null;
        }

        private void lsvData_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
