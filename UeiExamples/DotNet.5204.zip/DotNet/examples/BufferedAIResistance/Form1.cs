using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using UeiDaq;

namespace BufferedAIResistance
{
   /// <summary>
   /// Summary description for Form1.
   /// </summary>
   public class Form1 : System.Windows.Forms.Form
   {
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Label NbSc_label;
      private System.Windows.Forms.TrackBar Frequency;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.TextBox FrequencyText;
      private Session mySs = null;
      private AnalogScaledReader reader;
      private double[,] scan;
      private AsyncCallback readerCallback;
      private IAsyncResult readerIAsyncResult;
      private delegate void UpdateUIDelegate(String errorMessage);
      private System.Windows.Forms.TextBox NumScans;
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.TextBox TotalScansText;
      private System.Windows.Forms.TextBox AvailableScansText;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.TextBox NumScansReadText;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.Label label6;
      private System.Windows.Forms.TextBox NbFramesText;
      private System.Windows.Forms.ListView Data;
      private System.Windows.Forms.ColumnHeader Channel;
      private System.Windows.Forms.ColumnHeader Value;
      private System.Windows.Forms.Label DataLabel;
      private System.Windows.Forms.TextBox Minimum;
      private System.Windows.Forms.TextBox Maximum;
      private System.Windows.Forms.Label label7;
      private System.Windows.Forms.Label label8;
      private System.Windows.Forms.ComboBox WiringScheme;
      private System.Windows.Forms.Label label9;
      private System.Windows.Forms.Label label10;
      private System.Windows.Forms.TextBox Excitation;
      private System.Windows.Forms.Label label11;
      private System.Windows.Forms.TextBox ReferenceRes;
      private System.Windows.Forms.Label label12;
      private System.Windows.Forms.ComboBox ResistorType;
      private RadioButton Differential;
      private RadioButton SingleEnded;
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public Form1()
      {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         FrequencyText.Text = Frequency.Value.ToString();
         Go.Enabled = true;
         Stop.Enabled = false;
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose(bool disposing)
      {
         if (disposing)
         {
            if (components != null)
            {
               components.Dispose();
            }
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
         this.Go = new System.Windows.Forms.Button();
         this.Quit = new System.Windows.Forms.Button();
         this.Resource = new System.Windows.Forms.TextBox();
         this.NumScans = new System.Windows.Forms.TextBox();
         this.NbSc_label = new System.Windows.Forms.Label();
         this.Frequency = new System.Windows.Forms.TrackBar();
         this.FrequencyText = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.Stop = new System.Windows.Forms.Button();
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.TotalScansText = new System.Windows.Forms.TextBox();
         this.AvailableScansText = new System.Windows.Forms.TextBox();
         this.label3 = new System.Windows.Forms.Label();
         this.label4 = new System.Windows.Forms.Label();
         this.NbFramesText = new System.Windows.Forms.TextBox();
         this.NumScansReadText = new System.Windows.Forms.TextBox();
         this.label5 = new System.Windows.Forms.Label();
         this.label6 = new System.Windows.Forms.Label();
         this.Data = new System.Windows.Forms.ListView();
         this.Channel = new System.Windows.Forms.ColumnHeader();
         this.Value = new System.Windows.Forms.ColumnHeader();
         this.DataLabel = new System.Windows.Forms.Label();
         this.Minimum = new System.Windows.Forms.TextBox();
         this.Maximum = new System.Windows.Forms.TextBox();
         this.label7 = new System.Windows.Forms.Label();
         this.label8 = new System.Windows.Forms.Label();
         this.WiringScheme = new System.Windows.Forms.ComboBox();
         this.label9 = new System.Windows.Forms.Label();
         this.label10 = new System.Windows.Forms.Label();
         this.Excitation = new System.Windows.Forms.TextBox();
         this.label11 = new System.Windows.Forms.Label();
         this.ReferenceRes = new System.Windows.Forms.TextBox();
         this.label12 = new System.Windows.Forms.Label();
         this.ResistorType = new System.Windows.Forms.ComboBox();
         this.Differential = new System.Windows.Forms.RadioButton();
         this.SingleEnded = new System.Windows.Forms.RadioButton();
         ((System.ComponentModel.ISupportInitialize)(this.Frequency)).BeginInit();
         this.SuspendLayout();
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(440, 16);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(144, 40);
         this.Go.TabIndex = 1;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(440, 112);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(144, 40);
         this.Quit.TabIndex = 2;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(8, 24);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(112, 20);
         this.Resource.TabIndex = 3;
         this.Resource.Text = "simu://Dev0/Ai0:3";
         // 
         // NumScans
         // 
         this.NumScans.Location = new System.Drawing.Point(8, 64);
         this.NumScans.Name = "NumScans";
         this.NumScans.Size = new System.Drawing.Size(112, 20);
         this.NumScans.TabIndex = 4;
         this.NumScans.Text = "1000";
         // 
         // NbSc_label
         // 
         this.NbSc_label.Location = new System.Drawing.Point(4, 48);
         this.NbSc_label.Name = "NbSc_label";
         this.NbSc_label.Size = new System.Drawing.Size(96, 16);
         this.NbSc_label.TabIndex = 5;
         this.NbSc_label.Text = "Number of Scans";
         // 
         // Frequency
         // 
         this.Frequency.Location = new System.Drawing.Point(320, 48);
         this.Frequency.Maximum = 100000;
         this.Frequency.Name = "Frequency";
         this.Frequency.Orientation = System.Windows.Forms.Orientation.Vertical;
         this.Frequency.Size = new System.Drawing.Size(42, 78);
         this.Frequency.TabIndex = 6;
         this.Frequency.TickFrequency = 10000;
         this.Frequency.Value = 20000;
         this.Frequency.Scroll += new System.EventHandler(this.Frequency_Scroll);
         // 
         // FrequencyText
         // 
         this.FrequencyText.Location = new System.Drawing.Point(304, 24);
         this.FrequencyText.Name = "FrequencyText";
         this.FrequencyText.Size = new System.Drawing.Size(64, 20);
         this.FrequencyText.TabIndex = 8;
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(4, 8);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(120, 16);
         this.label2.TabIndex = 9;
         this.label2.Text = "Resource name";
         // 
         // groupBox1
         // 
         this.groupBox1.Location = new System.Drawing.Point(296, 8);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(80, 124);
         this.groupBox1.TabIndex = 10;
         this.groupBox1.TabStop = false;
         this.groupBox1.Text = "Frequency";
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(440, 64);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(144, 40);
         this.Stop.TabIndex = 11;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // ErrorText
         // 
         this.ErrorText.Location = new System.Drawing.Point(8, 299);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(576, 48);
         this.ErrorText.TabIndex = 12;
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(8, 280);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(104, 16);
         this.label1.TabIndex = 13;
         this.label1.Text = "Error Message";
         // 
         // TotalScansText
         // 
         this.TotalScansText.Location = new System.Drawing.Point(8, 155);
         this.TotalScansText.Name = "TotalScansText";
         this.TotalScansText.ReadOnly = true;
         this.TotalScansText.Size = new System.Drawing.Size(112, 20);
         this.TotalScansText.TabIndex = 14;
         // 
         // AvailableScansText
         // 
         this.AvailableScansText.Location = new System.Drawing.Point(8, 195);
         this.AvailableScansText.Name = "AvailableScansText";
         this.AvailableScansText.ReadOnly = true;
         this.AvailableScansText.Size = new System.Drawing.Size(112, 20);
         this.AvailableScansText.TabIndex = 15;
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(4, 139);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(88, 16);
         this.label3.TabIndex = 16;
         this.label3.Text = "Total scans";
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(4, 179);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(96, 16);
         this.label4.TabIndex = 17;
         this.label4.Text = "Available scans";
         // 
         // NbFramesText
         // 
         this.NbFramesText.Location = new System.Drawing.Point(134, 24);
         this.NbFramesText.Name = "NbFramesText";
         this.NbFramesText.Size = new System.Drawing.Size(112, 20);
         this.NbFramesText.TabIndex = 18;
         this.NbFramesText.Text = "8";
         // 
         // NumScansReadText
         // 
         this.NumScansReadText.Location = new System.Drawing.Point(8, 112);
         this.NumScansReadText.Name = "NumScansReadText";
         this.NumScansReadText.Size = new System.Drawing.Size(112, 20);
         this.NumScansReadText.TabIndex = 19;
         this.NumScansReadText.Text = "1000";
         // 
         // label5
         // 
         this.label5.Location = new System.Drawing.Point(130, 8);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(104, 16);
         this.label5.TabIndex = 20;
         this.label5.Text = "Number of Frames";
         // 
         // label6
         // 
         this.label6.Location = new System.Drawing.Point(5, 93);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(128, 16);
         this.label6.TabIndex = 21;
         this.label6.Text = "Number of scans to read";
         // 
         // Data
         // 
         this.Data.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Channel,
            this.Value});
         this.Data.GridLines = true;
         this.Data.Location = new System.Drawing.Point(134, 78);
         this.Data.Name = "Data";
         this.Data.Size = new System.Drawing.Size(146, 137);
         this.Data.TabIndex = 22;
         this.Data.View = System.Windows.Forms.View.Details;
         // 
         // Channel
         // 
         this.Channel.Text = "Channel";
         // 
         // Value
         // 
         this.Value.Text = "Value";
         this.Value.Width = 82;
         // 
         // DataLabel
         // 
         this.DataLabel.AutoSize = true;
         this.DataLabel.Location = new System.Drawing.Point(134, 62);
         this.DataLabel.Name = "DataLabel";
         this.DataLabel.Size = new System.Drawing.Size(77, 13);
         this.DataLabel.TabIndex = 23;
         this.DataLabel.Text = "Gathered Data";
         // 
         // Minimum
         // 
         this.Minimum.Location = new System.Drawing.Point(296, 155);
         this.Minimum.Name = "Minimum";
         this.Minimum.Size = new System.Drawing.Size(100, 20);
         this.Minimum.TabIndex = 24;
         this.Minimum.Text = "0.0";
         // 
         // Maximum
         // 
         this.Maximum.Location = new System.Drawing.Point(296, 195);
         this.Maximum.Name = "Maximum";
         this.Maximum.Size = new System.Drawing.Size(100, 20);
         this.Maximum.TabIndex = 25;
         this.Maximum.Text = "1000.0";
         // 
         // label7
         // 
         this.label7.AutoSize = true;
         this.label7.Location = new System.Drawing.Point(293, 139);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(51, 13);
         this.label7.TabIndex = 26;
         this.label7.Text = "Low Limit";
         // 
         // label8
         // 
         this.label8.AutoSize = true;
         this.label8.Location = new System.Drawing.Point(293, 179);
         this.label8.Name = "label8";
         this.label8.Size = new System.Drawing.Size(53, 13);
         this.label8.TabIndex = 27;
         this.label8.Text = "High Limit";
         // 
         // WiringScheme
         // 
         this.WiringScheme.DisplayMember = "FourWires";
         this.WiringScheme.Items.AddRange(new object[] {
            UeiDaq.WiringScheme.FourWires,
            UeiDaq.WiringScheme.SixWires,
            UeiDaq.WiringScheme.TwoWires});
         this.WiringScheme.Location = new System.Drawing.Point(7, 245);
         this.WiringScheme.Name = "WiringScheme";
         this.WiringScheme.Size = new System.Drawing.Size(113, 21);
         this.WiringScheme.TabIndex = 30;
         this.WiringScheme.Text = "FourWires";
         this.WiringScheme.ValueMember = "FourWires";
         // 
         // label9
         // 
         this.label9.AutoSize = true;
         this.label9.Location = new System.Drawing.Point(4, 229);
         this.label9.Name = "label9";
         this.label9.Size = new System.Drawing.Size(79, 13);
         this.label9.TabIndex = 34;
         this.label9.Text = "Wiring Scheme";
         // 
         // label10
         // 
         this.label10.AutoSize = true;
         this.label10.Location = new System.Drawing.Point(130, 229);
         this.label10.Name = "label10";
         this.label10.Size = new System.Drawing.Size(92, 13);
         this.label10.TabIndex = 35;
         this.label10.Text = "Excitation Voltage";
         // 
         // Excitation
         // 
         this.Excitation.Location = new System.Drawing.Point(134, 246);
         this.Excitation.Name = "Excitation";
         this.Excitation.Size = new System.Drawing.Size(100, 20);
         this.Excitation.TabIndex = 37;
         this.Excitation.Text = "0";
         // 
         // label11
         // 
         this.label11.AutoSize = true;
         this.label11.Location = new System.Drawing.Point(243, 229);
         this.label11.Name = "label11";
         this.label11.Size = new System.Drawing.Size(72, 13);
         this.label11.TabIndex = 40;
         this.label11.Text = "Resistor Type";
         // 
         // ReferenceRes
         // 
         this.ReferenceRes.Location = new System.Drawing.Point(398, 245);
         this.ReferenceRes.Name = "ReferenceRes";
         this.ReferenceRes.Size = new System.Drawing.Size(100, 20);
         this.ReferenceRes.TabIndex = 41;
         this.ReferenceRes.Text = "0";
         // 
         // label12
         // 
         this.label12.AutoSize = true;
         this.label12.Location = new System.Drawing.Point(395, 229);
         this.label12.Name = "label12";
         this.label12.Size = new System.Drawing.Size(113, 13);
         this.label12.TabIndex = 42;
         this.label12.Text = "Reference Resistance";
         // 
         // ResistorType
         // 
         this.ResistorType.DisplayMember = "BuiltIn";
         this.ResistorType.Items.AddRange(new object[] {
            UeiDaq.ReferenceResistorType.BuiltIn,
            UeiDaq.ReferenceResistorType.External});
         this.ResistorType.Location = new System.Drawing.Point(246, 245);
         this.ResistorType.Name = "ResistorType";
         this.ResistorType.Size = new System.Drawing.Size(121, 21);
         this.ResistorType.TabIndex = 43;
         this.ResistorType.Text = "BuiltIn";
         this.ResistorType.ValueMember = "BuiltIn";
         // 
         // Differential
         // 
         this.Differential.Checked = true;
         this.Differential.Location = new System.Drawing.Point(431, 173);
         this.Differential.Name = "Differential";
         this.Differential.Size = new System.Drawing.Size(75, 17);
         this.Differential.TabIndex = 44;
         this.Differential.TabStop = true;
         this.Differential.Text = "Differential";
         // 
         // SingleEnded
         // 
         this.SingleEnded.Location = new System.Drawing.Point(431, 198);
         this.SingleEnded.Name = "SingleEnded";
         this.SingleEnded.Size = new System.Drawing.Size(88, 17);
         this.SingleEnded.TabIndex = 45;
         this.SingleEnded.Text = "Single Ended";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(592, 359);
         this.Controls.Add(this.SingleEnded);
         this.Controls.Add(this.Differential);
         this.Controls.Add(this.ResistorType);
         this.Controls.Add(this.label12);
         this.Controls.Add(this.ReferenceRes);
         this.Controls.Add(this.Excitation);
         this.Controls.Add(this.WiringScheme);
         this.Controls.Add(this.Maximum);
         this.Controls.Add(this.Minimum);
         this.Controls.Add(this.Data);
         this.Controls.Add(this.label6);
         this.Controls.Add(this.label5);
         this.Controls.Add(this.NumScansReadText);
         this.Controls.Add(this.NbFramesText);
         this.Controls.Add(this.AvailableScansText);
         this.Controls.Add(this.TotalScansText);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.FrequencyText);
         this.Controls.Add(this.NumScans);
         this.Controls.Add(this.Resource);
         this.Controls.Add(this.label4);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.Frequency);
         this.Controls.Add(this.NbSc_label);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Controls.Add(this.label9);
         this.Controls.Add(this.DataLabel);
         this.Controls.Add(this.label7);
         this.Controls.Add(this.label8);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.label10);
         this.Controls.Add(this.label11);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.Name = "Form1";
         this.Text = "BufferedAI Resistance";
         ((System.ComponentModel.ISupportInitialize)(this.Frequency)).EndInit();
         this.ResumeLayout(false);
         this.PerformLayout();

      }
      #endregion

      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main()
      {
         Application.Run(new Form1());
      }

      private void Frequency_Scroll(object sender, System.EventArgs e)
      {
         FrequencyText.Text = ((TrackBar)(sender)).Value.ToString();
      }

      private void Quit_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();

         Application.Exit();
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         UeiDaqStart();
      }

      private void ReaderCallback(IAsyncResult ar)
      {
         try
         {
            scan = reader.EndReadMultipleScans(ar);

            UpdateUI("");

            if (mySs != null && mySs.IsRunning())
            {
               readerIAsyncResult = reader.BeginReadMultipleScans(Int32.Parse(NumScansReadText.Text), readerCallback, null);
            }
         }
         catch (UeiDaqException exception)
         {
            UpdateUI("Error: (" + exception.Error + ") " + exception.Message);
         }
         catch (Exception e)
         {
            UpdateUI("Unknown Error: " + e);
         }
      }

      private void UpdateUI(String errorMessage)
      {
         if (this.InvokeRequired)
         {
            UpdateUIDelegate uidlg = new UpdateUIDelegate(UpdateUI);
            Invoke(uidlg, new object[] { errorMessage });
         }
         else
         {
            if (mySs != null && mySs.IsRunning())
            {
               AvailableScansText.Text = mySs.GetDataStream().GetAvailableScans().ToString();
               TotalScansText.Text = mySs.GetDataStream().GetTotalScans().ToString();

               for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
               {
                  Data.Items[i].SubItems[1].Text = scan[0, i].ToString();
                  //For demo purposes will only display first value acquired of total scans 
               }
            }

            if (errorMessage.Length > 0)
            {
               ErrorText.Text = errorMessage;
               UeiDaqStop();
            }
         }
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();
      }

      private void UeiDaqStart()
      {
         ErrorText.Clear();
         Data.Items.Clear();

         try
         {

            AIChannelInputMode inputMode;

            if (Differential.Checked)
                inputMode = AIChannelInputMode.Differential;
            else
                inputMode = AIChannelInputMode.SingleEnded;


            mySs = new Session();

            // Create Resistance channels. Voltage measurement devices need a reference resistance to measure resistance.
            // Resistance measurement devices, such as AI-222 do not need a reference resistor, excitation and reference resistor
            // settings are ignored.
            mySs.CreateResistanceChannel(Resource.Text, Double.Parse(Minimum.Text), Double.Parse(Maximum.Text), (WiringScheme)WiringScheme.SelectedItem, 
                                         Double.Parse(ReferenceRes.Text), inputMode);

            for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
            {
               ListViewItem item = Data.Items.Add(mySs.GetChannel(i).GetIndex().ToString());
               item.SubItems.Add("0.0");
            }

            mySs.ConfigureTimingForBufferedIO(Int32.Parse(NumScans.Text),
               TimingClockSource.Internal, Frequency.Value,
               DigitalEdge.Rising, TimingDuration.Continuous);

            mySs.GetTiming().SetTimeout(5000);

            mySs.GetDataStream().SetNumberOfFrames(Int32.Parse(NbFramesText.Text));
            //mySs.GetDataStream().SetOverUnderRun(1);

            // Create a reader object to read data synchronously.
            reader = new AnalogScaledReader(mySs.GetDataStream());

            mySs.Start();

            readerCallback = new AsyncCallback(ReaderCallback);
            readerIAsyncResult = reader.BeginReadMultipleScans(Int32.Parse(NumScansReadText.Text), readerCallback, null);

            NumScans.Enabled = false;
            Frequency.Enabled = false;
            FrequencyText.Enabled = false;
            Resource.Enabled = false;
            Go.Enabled = false;
            Stop.Enabled = true;
         }
         catch (UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            mySs.Dispose();
            mySs = null;
         }
      }

      private void UeiDaqStop()
      {
         if (mySs != null)
         {
            try
            {
               mySs.Stop();
               // wait for current async call to complete
               // before destroying the session
               readerIAsyncResult.AsyncWaitHandle.WaitOne();
            }
            catch (UeiDaqException exception)
            {
               ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }

            mySs.Dispose();
            mySs = null;
         }

         NumScans.Enabled = true;
         Frequency.Enabled = true;
         FrequencyText.Enabled = true;
         Resource.Enabled = true;
         Go.Enabled = true;
         Stop.Enabled = false;
      }
   }
}
