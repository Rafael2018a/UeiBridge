﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UeiDaq;

namespace QuadratureEncoder
{
    public partial class Form1 : Form
    {
        private Session mySs;
        private CounterReader ciReader;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtResource.Text = "pdna://192.168.100.2/dev4/ci0";
            chkEnableZeroIndex.Checked = true;
            cboDecodeType.Items.Add(QuadratureDecodingType.FourX.ToString());
            cboDecodeType.Items.Add(QuadratureDecodingType.OneX.ToString());
            cboDecodeType.Items.Add(QuadratureDecodingType.TwoX.ToString());
            cboDecodeType.SelectedIndex = 1;
        

            cboZeroIndexPhase.Items.Add(QuadratureZeroIndexPhase.AHighBHigh.ToString());
            cboZeroIndexPhase.Items.Add(QuadratureZeroIndexPhase.AHighBLow.ToString());
            cboZeroIndexPhase.Items.Add(QuadratureZeroIndexPhase.ALowBHigh.ToString());
            cboZeroIndexPhase.Items.Add(QuadratureZeroIndexPhase.ALowBLow.ToString());
            cboZeroIndexPhase.Items.Add(QuadratureZeroIndexPhase.ZHigh.ToString());
            cboZeroIndexPhase.SelectedIndex = 4;
            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnQuit.Enabled = true;

        }

        private void ciTimer_Tick(object sender, EventArgs e)
        {
            
            UInt32[] val = ciReader.ReadSingleScanUInt32();

            for (int ch = 0; ch < mySs.GetNumberOfChannels(); ch++)
            {
                lsvData.Items[ch].SubItems[1].Text = ((Int32)val[ch]).ToString();
                                                
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            lsvData.Items.Clear();
            ErrorText.Clear();
            mySs = new Session();
            try
            {
                //The line (QuadratureDecodingType)Enum.Parse(typeof(QuadratureDecodingType),cboDecodeType.SelectedItem.ToString()is type casting string to enum
                mySs.CreateQuadratureEncoderChannel(txtResource.Text, 
                                                    Convert.ToUInt32(txtInitCount.Text), 
                                                    (QuadratureDecodingType)Enum.Parse(typeof(QuadratureDecodingType), cboDecodeType.SelectedItem.ToString()),
                                                    chkEnableZeroIndex.Checked, 
                                                    (QuadratureZeroIndexPhase)Enum.Parse(typeof(QuadratureZeroIndexPhase), cboZeroIndexPhase.SelectedItem.ToString()));

                for (int i = 0; i < mySs.GetNumberOfChannels(); i++)
                {
                    ListViewItem item = lsvData.Items.Add(mySs.GetChannel(i).GetIndex().ToString());
                    item.SubItems.Add("0");
                }
                mySs.ConfigureTimingForSimpleIO();
                ciReader = new CounterReader(mySs.GetDataStream());
                mySs.Start();
                ciTimer.Start();

                btnStop.Enabled = true;
                btnStart.Enabled = false;
                btnQuit.Enabled = false;
            }
            catch (UeiDaqException exception)
            {
                ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }            
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = true;
            btnStop.Enabled = false;
            btnQuit.Enabled = true;
            
            ErrorText.Clear();
            ciTimer.Stop();
            try
            {
                mySs.Stop();

            }
            catch (UeiDaqException exception)
            {
                ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }
            mySs.Dispose();
            mySs = null;
        }

        private void lsvData_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
