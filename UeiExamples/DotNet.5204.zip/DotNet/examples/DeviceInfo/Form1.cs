using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using UeiDaq;

namespace DeviceInfo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.TreeView DeviceTree;
      private System.Windows.Forms.Button EnumDevices;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.Resource = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.DeviceTree = new System.Windows.Forms.TreeView();
         this.EnumDevices = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(8, 24);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(128, 20);
         this.Resource.TabIndex = 0;
         this.Resource.Text = "simu://";
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(8, 8);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(112, 16);
         this.label1.TabIndex = 1;
         this.label1.Text = "Resource";
         // 
         // DeviceTree
         // 
         this.DeviceTree.ImageIndex = -1;
         this.DeviceTree.Location = new System.Drawing.Point(8, 56);
         this.DeviceTree.Name = "DeviceTree";
         this.DeviceTree.SelectedImageIndex = -1;
         this.DeviceTree.Size = new System.Drawing.Size(272, 200);
         this.DeviceTree.TabIndex = 2;
         // 
         // EnumDevices
         // 
         this.EnumDevices.Location = new System.Drawing.Point(144, 24);
         this.EnumDevices.Name = "EnumDevices";
         this.EnumDevices.Size = new System.Drawing.Size(136, 24);
         this.EnumDevices.TabIndex = 3;
         this.EnumDevices.Text = "Enumerate devices";
         this.EnumDevices.Click += new System.EventHandler(this.EnumDevices_Click);
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(292, 266);
         this.Controls.Add(this.EnumDevices);
         this.Controls.Add(this.DeviceTree);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.Resource);
         this.Name = "Form1";
         this.Text = "DeviceInfo";
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private void EnumDevices_Click(object sender, System.EventArgs e)
      {
         try
         {
            DeviceCollection devColl = new DeviceCollection(Resource.Text);

            DeviceTree.Nodes.Clear();
            foreach (Device dev in devColl)
            {
               if(dev != null)
               {
                  TreeNode devNode = new TreeNode(dev.GetDeviceName() + " (Dev" + dev.GetIndex().ToString() + ")");
                  devNode.Nodes.Add(new TreeNode("Serial number = 0x" + dev.GetSerialNumber().ToString()));

                  TreeNode aiNode = new TreeNode("AI subsystem");
                  aiNode.Nodes.Add(new TreeNode("Number of differential channels = " + dev.GetNumberOfAIDifferentialChannels().ToString()));
                  aiNode.Nodes.Add(new TreeNode("Number of single-ended channels = " + dev.GetNumberOfAISingleEndedChannels().ToString()));
                  aiNode.Nodes.Add(new TreeNode("Resolution = " + dev.GetAIResolution().ToString()));
                  devNode.Nodes.Add(aiNode);

                  TreeNode aoNode = new TreeNode("AO subsystem");
                  aoNode.Nodes.Add(new TreeNode("Number of channels = " + dev.GetNumberOfAOChannels().ToString()));
                  aoNode.Nodes.Add(new TreeNode("Resolution = " + dev.GetAOResolution().ToString()));
                  devNode.Nodes.Add(aoNode);

                  TreeNode diNode = new TreeNode("DI subsystem");
                  diNode.Nodes.Add(new TreeNode("Number of channels = " + dev.GetNumberOfDIChannels().ToString()));
                  diNode.Nodes.Add(new TreeNode("Resolution = " + dev.GetDIResolution().ToString()));
                  devNode.Nodes.Add(diNode);

                  TreeNode doNode = new TreeNode("DO subsystem");
                  doNode.Nodes.Add(new TreeNode("Number of channels = " + dev.GetNumberOfDOChannels().ToString()));
                  doNode.Nodes.Add(new TreeNode("Resolution = " + dev.GetDOResolution().ToString()));
                  devNode.Nodes.Add(doNode);

                  TreeNode ciNode = new TreeNode("CI subsystem");
                  ciNode.Nodes.Add(new TreeNode("Number of channels = " + dev.GetNumberOfCIChannels().ToString()));
                  ciNode.Nodes.Add(new TreeNode("Resolution = " + dev.GetCIResolution().ToString()));
                  devNode.Nodes.Add(ciNode);

                  TreeNode coNode = new TreeNode("CO subsystem");
                  coNode.Nodes.Add(new TreeNode("Number of channels = " + dev.GetNumberOfCOChannels().ToString()));
                  coNode.Nodes.Add(new TreeNode("Resolution = " + dev.GetCOResolution().ToString()));
                  devNode.Nodes.Add(coNode);

                  DeviceTree.Nodes.Add(devNode);
               }
            }
         }
         catch(UeiDaqException exception)
         {
            MessageBox.Show("Error: (" + exception.Error + ") " + exception.Message);
         }
      }
	}
}
