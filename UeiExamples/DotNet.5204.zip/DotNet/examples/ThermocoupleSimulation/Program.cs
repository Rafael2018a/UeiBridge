﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace ThermocoupleSimulation
{
   class Program
   {
      static void Main(string[] args)
      {
         Session tcSimSession = new Session();
         Session guardianSession = new Session();

         try
         {
            // Create TC simulation session with 8 channels.
            tcSimSession.CreateSimulatedTCChannel("pdna://192.168.100.2/dev5/ao0:7", 
                                               ThermocoupleType.TypeK, TemperatureScale.Celsius, true);
            tcSimSession.ConfigureTimingForSimpleIO();

            // Create 3 AI channels for each output channel to read diagnostics
            // Each TC output channel is associated with three guardian channels starting at offset tc_chan * 8
            guardianSession.CreateAIChannel("pdna://192.168.100.2/dev5/ai0:2,8:10,16:18,24:26,32:34,40:42,48:50,56:58", -10.0, 10.0, AIChannelInputMode.Differential);
            guardianSession.ConfigureTimingForSimpleIO();

            // Create a writer to update the output channels
            AnalogScaledWriter writer = new AnalogScaledWriter(tcSimSession.GetDataStream());
            double[] aoData = new double[tcSimSession.GetNumberOfChannels()];

            // Create a circuit breaker object per output channel to monitor circuit breaker status and eventually reset them
            CircuitBreaker[] cbs = new CircuitBreaker[tcSimSession.GetNumberOfChannels()];
            int[] breakCount = new int[tcSimSession.GetNumberOfChannels()];
            for (int ch = 0; ch < tcSimSession.GetNumberOfChannels(); ch++)
            {
               cbs[ch] = new CircuitBreaker(tcSimSession.GetDataStream(), tcSimSession.GetChannel(ch).GetIndex());
               breakCount[ch] = 0;
            }
           
            // Create a reader to retrieve diagnostics
            AnalogScaledReader guardianReader = new AnalogScaledReader(guardianSession.GetDataStream());
            double[] diagData;

            tcSimSession.Start();
            guardianSession.Start();

            // Establish an event handler to process key press events.
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

            int count = 0;
            stop = false;
            while (!stop)
            {
               // Update outputs on each channel
               for (int ch = 0; ch < tcSimSession.GetNumberOfChannels(); ch++)
               {
                  // vary temperature from -100 to +100
                  aoData[ch] = -100 + (count % 200);
               }
               writer.WriteSingleScan(aoData);

               // Read and display diagnostics
               diagData = guardianReader.ReadSingleScan();

               for (int ch = 0; ch < tcSimSession.GetNumberOfChannels(); ch++)
               {
                  Console.WriteLine("Output Channel " + tcSimSession.GetChannel(ch).GetIndex() + " diagnostics:");
                  Console.WriteLine("  Current = " + diagData[ch * 3]);
                  Console.WriteLine("  Voltage = " + diagData[ch * 3 + 1]);
                  Console.WriteLine("  ADC internal temperature = " + diagData[ch * 3 + 2]);

                  // Monitor CB status
                  uint currStatus=0, stickyStatus=0;
                  cbs[ch].GetStatus(ref currStatus, ref stickyStatus);

                  if ((currStatus & (1U << tcSimSession.GetChannel(ch).GetIndex())) > 0)
                  {
                     breakCount[ch]++;
                  }

                  Console.WriteLine("  CB Status: curr = " + currStatus.ToString("X") + " sticky = " + stickyStatus.ToString("X"));
                  
                  // reset breaker after 5 iterations
                  if (breakCount[ch] > 5)
                  {
                     Console.WriteLine("Resetting breaker for channel {0}", ch);
                     //cbs[ch].Reset(1U << aoSession.GetChannel(ch).GetIndex());
                     breakCount[ch] = 0;
                  }
               }

               Thread.Sleep(500);
               count++;
            }

            tcSimSession.Stop();
            guardianSession.Stop();
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine("Error: (" + exception.Error + ") " + exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop= false;
   }
}
