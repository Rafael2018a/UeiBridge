using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using UeiDaq;

namespace BufferedAO
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.Windows.Forms.Button Go;
      private System.Windows.Forms.Button Quit;
      private System.Windows.Forms.TextBox Resource;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.TextBox Cycles;
      private Session mySs = null;
      private AnalogScaledWriter writer;
      private AsyncCallback   writerCallback;
      private IAsyncResult writerIAsyncResult;
      private delegate void UpdateUIDelegate(String errorMessage);
      private System.Windows.Forms.Button Stop;
      private System.Windows.Forms.TextBox ErrorText;
      private System.Windows.Forms.Label label1;
      private TextBox Amplitude;
      private TextBox UpdateRate;
      private Label label7;
      private Label label5;
      private Label label6;
      private TextBox FIFOSize;
      private Label label3;
      private TextBox ActualFrequency;
      private Label label4;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
         this.Go = new System.Windows.Forms.Button();
         this.Quit = new System.Windows.Forms.Button();
         this.Resource = new System.Windows.Forms.TextBox();
         this.Cycles = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.Stop = new System.Windows.Forms.Button();
         this.ErrorText = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.Amplitude = new System.Windows.Forms.TextBox();
         this.UpdateRate = new System.Windows.Forms.TextBox();
         this.label7 = new System.Windows.Forms.Label();
         this.label5 = new System.Windows.Forms.Label();
         this.label6 = new System.Windows.Forms.Label();
         this.FIFOSize = new System.Windows.Forms.TextBox();
         this.label3 = new System.Windows.Forms.Label();
         this.ActualFrequency = new System.Windows.Forms.TextBox();
         this.label4 = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // Go
         // 
         this.Go.Location = new System.Drawing.Point(529, 13);
         this.Go.Name = "Go";
         this.Go.Size = new System.Drawing.Size(98, 40);
         this.Go.TabIndex = 1;
         this.Go.Text = "Go";
         this.Go.Click += new System.EventHandler(this.Go_Click);
         // 
         // Quit
         // 
         this.Quit.Location = new System.Drawing.Point(529, 114);
         this.Quit.Name = "Quit";
         this.Quit.Size = new System.Drawing.Size(98, 40);
         this.Quit.TabIndex = 2;
         this.Quit.Text = "Quit";
         this.Quit.Click += new System.EventHandler(this.Quit_Click);
         // 
         // Resource
         // 
         this.Resource.Location = new System.Drawing.Point(8, 24);
         this.Resource.Name = "Resource";
         this.Resource.Size = new System.Drawing.Size(226, 20);
         this.Resource.TabIndex = 3;
         this.Resource.Text = "pdna://192.168.100.2/Dev0/Ao0:1";
         // 
         // Cycles
         // 
         this.Cycles.Location = new System.Drawing.Point(286, 75);
         this.Cycles.Name = "Cycles";
         this.Cycles.Size = new System.Drawing.Size(78, 20);
         this.Cycles.TabIndex = 8;
         this.Cycles.Text = "1";
         // 
         // label2
         // 
         this.label2.Location = new System.Drawing.Point(8, 8);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(120, 16);
         this.label2.TabIndex = 9;
         this.label2.Text = "Resource name";
         // 
         // Stop
         // 
         this.Stop.Location = new System.Drawing.Point(529, 64);
         this.Stop.Name = "Stop";
         this.Stop.Size = new System.Drawing.Size(98, 40);
         this.Stop.TabIndex = 11;
         this.Stop.Text = "Stop";
         this.Stop.Click += new System.EventHandler(this.Stop_Click);
         // 
         // ErrorText
         // 
         this.ErrorText.Location = new System.Drawing.Point(8, 192);
         this.ErrorText.Multiline = true;
         this.ErrorText.Name = "ErrorText";
         this.ErrorText.ReadOnly = true;
         this.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.ErrorText.Size = new System.Drawing.Size(619, 48);
         this.ErrorText.TabIndex = 12;
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(8, 176);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(104, 16);
         this.label1.TabIndex = 13;
         this.label1.Text = "Error Message";
         // 
         // Amplitude
         // 
         this.Amplitude.Location = new System.Drawing.Point(286, 24);
         this.Amplitude.Name = "Amplitude";
         this.Amplitude.Size = new System.Drawing.Size(78, 20);
         this.Amplitude.TabIndex = 23;
         this.Amplitude.Text = "5.0";
         // 
         // UpdateRate
         // 
         this.UpdateRate.Location = new System.Drawing.Point(11, 75);
         this.UpdateRate.Name = "UpdateRate";
         this.UpdateRate.Size = new System.Drawing.Size(112, 20);
         this.UpdateRate.TabIndex = 25;
         this.UpdateRate.Text = "2000";
         // 
         // label7
         // 
         this.label7.Location = new System.Drawing.Point(9, 58);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(119, 14);
         this.label7.TabIndex = 26;
         this.label7.Text = "Update rate (Hz)";
         // 
         // label5
         // 
         this.label5.Location = new System.Drawing.Point(283, 8);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(142, 16);
         this.label5.TabIndex = 27;
         this.label5.Text = "Amplitude (V)";
         // 
         // label6
         // 
         this.label6.Location = new System.Drawing.Point(284, 58);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(163, 14);
         this.label6.TabIndex = 28;
         this.label6.Text = "Number of cycles (per FIFO)";
         // 
         // FIFOSize
         // 
         this.FIFOSize.Location = new System.Drawing.Point(8, 151);
         this.FIFOSize.Name = "FIFOSize";
         this.FIFOSize.ReadOnly = true;
         this.FIFOSize.Size = new System.Drawing.Size(112, 20);
         this.FIFOSize.TabIndex = 14;
         // 
         // label3
         // 
         this.label3.Location = new System.Drawing.Point(8, 135);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(88, 16);
         this.label3.TabIndex = 16;
         this.label3.Text = "Device FIFO size";
         // 
         // ActualFrequency
         // 
         this.ActualFrequency.Location = new System.Drawing.Point(147, 151);
         this.ActualFrequency.Name = "ActualFrequency";
         this.ActualFrequency.ReadOnly = true;
         this.ActualFrequency.Size = new System.Drawing.Size(112, 20);
         this.ActualFrequency.TabIndex = 29;
         // 
         // label4
         // 
         this.label4.Location = new System.Drawing.Point(147, 135);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(217, 16);
         this.label4.TabIndex = 30;
         this.label4.Text = "Actual frequency of signal generated (Hz)";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(639, 246);
         this.Controls.Add(this.ActualFrequency);
         this.Controls.Add(this.label4);
         this.Controls.Add(this.label6);
         this.Controls.Add(this.label5);
         this.Controls.Add(this.UpdateRate);
         this.Controls.Add(this.label7);
         this.Controls.Add(this.Amplitude);
         this.Controls.Add(this.FIFOSize);
         this.Controls.Add(this.ErrorText);
         this.Controls.Add(this.Cycles);
         this.Controls.Add(this.Resource);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.Stop);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.Quit);
         this.Controls.Add(this.Go);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.Name = "Form1";
         this.Text = "BufferedAO_Regeneration";
         this.ResumeLayout(false);
         this.PerformLayout();

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private void Quit_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();

         Application.Exit();
      }

      private void Go_Click(object sender, System.EventArgs e)
      {
         UeiDaqStart();
      }

      private void Stop_Click(object sender, System.EventArgs e)
      {
         UeiDaqStop();
      }

      private void UeiDaqStart()
      {
         mySs = new Session();

         try
         {
            ErrorText.Clear();
            ErrorText.Text = Thread.CurrentThread.Priority.ToString();

            mySs.CreateAOChannel(Resource.Text, -10.0, 10.0);

            // Read FIFO size
            int fifoSize = mySs.GetDevice().GetOutputFIFOSize();
            FIFOSize.Text = fifoSize.ToString();

            // Compute the maximum number of scans that fit in the FIFO
            int numScans = fifoSize / mySs.GetNumberOfChannels();

            mySs.ConfigureTimingForBufferedIO(numScans,
                                             TimingClockSource.Internal, Double.Parse(UpdateRate.Text),
                                             DigitalEdge.Rising, TimingDuration.Continuous);

            // Enable regeneration, this configures the AO device to keep the waveform data indefinitely
            // in its outyput FIFO and output the FIFO content to channels continuously
            mySs.GetDataStream().SetRegenerate(1);

            double[,] data = new double[numScans, mySs.GetNumberOfChannels()];
            GenerateSinWave(data, mySs.GetNumberOfChannels(), numScans, Int32.Parse(Cycles.Text));

            // Display actual frequency of generated sine waveform
            ActualFrequency.Text = (Double.Parse(UpdateRate.Text) * Int32.Parse(Cycles.Text) / numScans).ToString();

            // Create a writer object to write waveform data to FIFO.
            writer = new AnalogScaledWriter(mySs.GetDataStream());
            writer.WriteMultipleScans(numScans, data);

            mySs.Start();

            UpdateRate.Enabled = false;
            Resource.Enabled = false;
            Go.Enabled = false;
         }
         catch(UeiDaqException exception)
         {
            ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            mySs.Dispose();
            mySs = null;
         }
      }

      private void UeiDaqStop()
      {
         if(mySs != null)
         {
            try
            {
               mySs.Stop();
            }
            catch(UeiDaqException exception)
            {
               ErrorText.Text = "Error: (" + exception.Error + ") " + exception.Message;
            }

            mySs.Dispose();
            mySs = null;
         }

         UpdateRate.Enabled = true;
         Resource.Enabled = true;
         Go.Enabled = true;
      }

      void GenerateSinWave(double[,] buffer, int numChannels, int numSamplePerChannel, int numCycles)
      {
         double amplitude = 10.0;
         
         for(int i=0; i<numSamplePerChannel; i++)
         {
            for(int j=0; j<numChannels; j++)
            {
               buffer[i,j] = amplitude * Math.Sin(numCycles*2*3.1415*i/numSamplePerChannel);
            }
         }
      }
	}
}
