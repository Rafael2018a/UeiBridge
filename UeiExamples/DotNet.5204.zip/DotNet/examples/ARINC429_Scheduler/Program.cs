﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UeiDaq;

namespace ARINC429_Scheduler
{
   class Program
   {
      static void Main(string[] args)
      {
         string arincTxResource = "pdna://192.168.100.3/Dev0/atx0:15";
         string arincRxResource = "pdna://192.168.100.3/Dev0/arx1";
         int bufferSize = 256;

         
         ARINCWord[] sendBuffer = new ARINCWord[bufferSize];

         // register CTRL + c handler
         Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);

         try
         {
            // Configure Master session
            Session mySession = new Session();
            ARINCInputPort inPort = mySession.CreateARINCInputPort(arincRxResource,
                ARINCPortSpeed.BitsPerSecond100000,
                ARINCPortParity.None,
                false,
                0);
            int numInputPorts = mySession.GetNumberOfChannels();
            
            ARINCOutputPort outPort = mySession.CreateARINCOutputPort(arincTxResource,
                ARINCPortSpeed.BitsPerSecond100000,
                ARINCPortParity.None);
            int numOutputPorts = mySession.GetNumberOfChannels() - numInputPorts;

            ARINCReader[] readers = new ARINCReader[numInputPorts];
            for(int ch=0; ch<numInputPorts; ch++)
            {
               readers[ch] = new ARINCReader(mySession.GetDataStream(), mySession.GetChannel(ch).GetIndex());
            }

            ARINCWriter[] writers = new ARINCWriter[numOutputPorts];
            for (int ch = 0; ch < numOutputPorts; ch++)
            {
               outPort = (ARINCOutputPort)mySession.GetChannel(ch + numInputPorts);
               writers[ch] = new ARINCWriter(mySession.GetDataStream(), outPort.GetIndex());

               // enable scheduler on TX channel
               outPort.EnableScheduler(true);
               for (int i = 0; i < bufferSize; i++)
               {
                  ARINCSchedulerEntry entry = new ARINCSchedulerEntry();
                  entry.Master = 1;
                  entry.Periodic = 1;
                  entry.Delay = 4000;
                  entry.Word = new ARINCWord { Label = (uint)i + 1, Data = 0x10290 };
                  outPort.AddSchedulerEntry(entry);
               }
            }
            
            mySession.ConfigureTimingForMessagingIO(1, 0.1);
            mySession.GetTiming().SetTimeout(10);

            

            mySession.Start();

            uint sendCount = 0;
            DateTime start_time = DateTime.Now;
            while (!stop)
            {
               // update scheduler table every 100 ms
               Double elapsed_time = ((TimeSpan)(DateTime.Now - start_time)).TotalMilliseconds;
               if (elapsed_time > 10)
               {
                  for (int ch = 0; ch < numOutputPorts; ch++)
                  {
                     // do write for each channel
                     for (int j = 0; j < bufferSize; j++)
                     {
                        sendBuffer[j] = new ARINCWord();
                        sendBuffer[j].Label = (uint)(sendCount % 10);
                        sendBuffer[j].Sdi = 1;
                        sendBuffer[j].Ssm = 0;
                        sendBuffer[j].Data = (uint)((sendCount + j));
                     }

                     writers[ch].WriteScheduler(0, sendBuffer);
                  }
                  start_time = DateTime.Now;
               }

               // Write some out of band words
               for (int ch = 0; ch < numOutputPorts; ch++)
               {
                  ARINCWord[] oobBuffer = new ARINCWord[10];
                  for (uint j = 0; j < 10; j++)
                  {
                     oobBuffer[j] = new ARINCWord();
                     oobBuffer[j].Label = 0xEE +j;
                     oobBuffer[j].Sdi = 0;
                     oobBuffer[j].Ssm = 0;
                     oobBuffer[j].Data = (uint)(0xAAAA);
                  }

                  writers[ch].Write(oobBuffer);
               }

               //Thread.Sleep(20);

               // read from each channel
               for (int ch = 0; ch < numInputPorts; ch++)
               {
                  ARINCWord[] recvBuffer = readers[ch].Read(bufferSize);

                  //Console.WriteLine("reader:  received {0} frames in {1}ms ", recvBuffer.Length, elapsed_time);
                  for (int f = 0; f < recvBuffer.Length; f++)
                  {
                     Console.Write("channel={0} label=0x{1} Data=0x{2}", mySession.GetChannel(ch).GetIndex(), 
                        recvBuffer[f].Label.ToString("X"), recvBuffer[f].Data.ToString("X"));
                     Console.WriteLine("]");
                  }

                  Console.WriteLine();
               }

               sendCount++;
            }

            mySession.Stop();
         }
         catch (UeiDaqException exception)
         {
            Console.WriteLine();
            Console.WriteLine("Error: ({0}) {1}", exception.Error, exception.Message);
         }
      }

      protected static void myHandler(object sender, ConsoleCancelEventArgs args)
      {
         // Set cancel to true to let the Main task clean-up the I/O sessions
         args.Cancel = true;
         stop = true;
      }

      static bool stop = false;
   }
}
