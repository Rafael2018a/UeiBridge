Imports UeiDaq

Module Module1

   Sub Main()
      Dim mySs As New Session

      Try
         mySs.CreateAIChannel("pdna://192.168.0.61/Dev2/Ai0:3", -10.0, 10.0, UeiDaq.AIChannelInputMode.Differential)
         mySs.ConfigureTimingForSimpleIO()

         Dim reader As New AnalogScaledReader(mySs.GetDataStream)
         mySs.Start()

         For i As Integer = 0 To 100
            Dim data(8) As Double
            data = reader.ReadSingleScan()
            Console.WriteLine(i.ToString + " " + data(0).ToString)
         Next
      Catch exception As UeiDaqException
         Console.WriteLine("Error: " + exception.Message)
      End Try

      mySs.Stop()
   End Sub

End Module
