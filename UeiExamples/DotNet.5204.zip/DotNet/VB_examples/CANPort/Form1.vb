' Import the UeiDaq library
Imports UeiDaq

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private writer As CANWriter
    Private reader As CANReader
    Private CANSession As Session

    Private Sub InitUI(ByVal isRunning As Boolean)
      If (isRunning) Then
         btnStart.Enabled = False
         btnStop.Enabled = True
         btnQuit.Enabled = False
         btnSend.Enabled = True
         ReceiveList.Enabled = True
      Else
         btnStart.Enabled = True
         btnStop.Enabled = False
         btnQuit.Enabled = True
         btnSend.Enabled = False
         ReceiveList.Enabled = False
      End If
   End Sub

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents label4 As System.Windows.Forms.Label
   Friend WithEvents Resource As System.Windows.Forms.TextBox
   Friend WithEvents label1 As System.Windows.Forms.Label
   Friend WithEvents Speed As System.Windows.Forms.ComboBox
   Friend WithEvents label3 As System.Windows.Forms.Label
   Friend WithEvents label2 As System.Windows.Forms.Label
   Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
   Friend WithEvents ReceiveList As System.Windows.Forms.ListView
   Friend WithEvents arbitrationIDHeader As System.Windows.Forms.ColumnHeader
   Friend WithEvents remoteHeader As System.Windows.Forms.ColumnHeader
   Friend WithEvents dataSizeHeader As System.Windows.Forms.ColumnHeader
   Friend WithEvents dataHeader As System.Windows.Forms.ColumnHeader
   Friend WithEvents groupBox2 As System.Windows.Forms.GroupBox
   Friend WithEvents groupBox3 As System.Windows.Forms.GroupBox
   Friend WithEvents DataByte0 As System.Windows.Forms.TextBox
   Friend WithEvents DataByte6 As System.Windows.Forms.TextBox
   Friend WithEvents DataByte3 As System.Windows.Forms.TextBox
   Friend WithEvents DataByte2 As System.Windows.Forms.TextBox
   Friend WithEvents DataByte4 As System.Windows.Forms.TextBox
   Friend WithEvents DataByte7 As System.Windows.Forms.TextBox
   Friend WithEvents DataByte5 As System.Windows.Forms.TextBox
   Friend WithEvents DataByte1 As System.Windows.Forms.TextBox
   Friend WithEvents IsRemote As System.Windows.Forms.CheckBox
   Friend WithEvents label5 As System.Windows.Forms.Label
   Friend WithEvents ArbitrationID As System.Windows.Forms.TextBox
   Friend WithEvents btnStart As System.Windows.Forms.Button
   Friend WithEvents btnQuit As System.Windows.Forms.Button
   Friend WithEvents btnStop As System.Windows.Forms.Button
   Friend WithEvents btnSend As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.label4 = New System.Windows.Forms.Label
      Me.Resource = New System.Windows.Forms.TextBox
      Me.label1 = New System.Windows.Forms.Label
      Me.Speed = New System.Windows.Forms.ComboBox
      Me.label3 = New System.Windows.Forms.Label
      Me.label2 = New System.Windows.Forms.Label
      Me.groupBox1 = New System.Windows.Forms.GroupBox
      Me.ReceiveList = New System.Windows.Forms.ListView
      Me.arbitrationIDHeader = New System.Windows.Forms.ColumnHeader
      Me.remoteHeader = New System.Windows.Forms.ColumnHeader
      Me.dataSizeHeader = New System.Windows.Forms.ColumnHeader
      Me.dataHeader = New System.Windows.Forms.ColumnHeader
      Me.groupBox2 = New System.Windows.Forms.GroupBox
      Me.groupBox3 = New System.Windows.Forms.GroupBox
      Me.DataByte0 = New System.Windows.Forms.TextBox
      Me.DataByte6 = New System.Windows.Forms.TextBox
      Me.DataByte3 = New System.Windows.Forms.TextBox
      Me.DataByte2 = New System.Windows.Forms.TextBox
      Me.DataByte4 = New System.Windows.Forms.TextBox
      Me.DataByte7 = New System.Windows.Forms.TextBox
      Me.DataByte5 = New System.Windows.Forms.TextBox
      Me.DataByte1 = New System.Windows.Forms.TextBox
      Me.IsRemote = New System.Windows.Forms.CheckBox
      Me.label5 = New System.Windows.Forms.Label
      Me.ArbitrationID = New System.Windows.Forms.TextBox
      Me.btnSend = New System.Windows.Forms.Button
      Me.btnStart = New System.Windows.Forms.Button
      Me.btnQuit = New System.Windows.Forms.Button
      Me.btnStop = New System.Windows.Forms.Button
      Me.groupBox1.SuspendLayout()
      Me.groupBox2.SuspendLayout()
      Me.groupBox3.SuspendLayout()
      Me.SuspendLayout()
      '
      'label4
      '
      Me.label4.Location = New System.Drawing.Point(4, 8)
      Me.label4.Name = "label4"
      Me.label4.Size = New System.Drawing.Size(488, 16)
      Me.label4.TabIndex = 6
      Me.label4.Text = "This example shows how to send CAN frames out of port 0 and receive CAN frames fr" & _
      "om port 1."
      '
      'Resource
      '
      Me.Resource.Location = New System.Drawing.Point(4, 88)
      Me.Resource.Name = "Resource"
      Me.Resource.Size = New System.Drawing.Size(216, 20)
      Me.Resource.TabIndex = 10
      Me.Resource.Text = "pdna://192.168.100.2/Dev4/CAN0,1"
      '
      'label1
      '
      Me.label1.Location = New System.Drawing.Point(4, 72)
      Me.label1.Name = "label1"
      Me.label1.Size = New System.Drawing.Size(100, 16)
      Me.label1.TabIndex = 7
      Me.label1.Text = "Resource"
      '
      'Speed
      '
      Me.Speed.Items.AddRange(New Object() {"10K", "20K", "50K", "100K", "125K", "250K", "500K", "800K", "1M"})
      Me.Speed.Location = New System.Drawing.Point(236, 88)
      Me.Speed.Name = "Speed"
      Me.Speed.Size = New System.Drawing.Size(121, 21)
      Me.Speed.TabIndex = 9
      '
      'label3
      '
      Me.label3.Location = New System.Drawing.Point(4, 32)
      Me.label3.Name = "label3"
      Me.label3.Size = New System.Drawing.Size(488, 24)
      Me.label3.TabIndex = 8
      Me.label3.Text = "Press the ""Start"" button to start the session. Received CAN frames will appear in" & _
      " the listview. Press the ""Send"" button to send CAN frames."
      '
      'label2
      '
      Me.label2.Location = New System.Drawing.Point(236, 72)
      Me.label2.Name = "label2"
      Me.label2.Size = New System.Drawing.Size(100, 16)
      Me.label2.TabIndex = 11
      Me.label2.Text = "Bus speed"
      '
      'groupBox1
      '
      Me.groupBox1.Controls.Add(Me.ReceiveList)
      Me.groupBox1.Location = New System.Drawing.Point(8, 120)
      Me.groupBox1.Name = "groupBox1"
      Me.groupBox1.Size = New System.Drawing.Size(504, 120)
      Me.groupBox1.TabIndex = 13
      Me.groupBox1.TabStop = False
      Me.groupBox1.Text = "Receive Frames"
      '
      'ReceiveList
      '
      Me.ReceiveList.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.arbitrationIDHeader, Me.remoteHeader, Me.dataSizeHeader, Me.dataHeader})
      Me.ReceiveList.Location = New System.Drawing.Point(8, 16)
      Me.ReceiveList.Name = "ReceiveList"
      Me.ReceiveList.Size = New System.Drawing.Size(488, 96)
      Me.ReceiveList.TabIndex = 0
      Me.ReceiveList.View = System.Windows.Forms.View.Details
      '
      'arbitrationIDHeader
      '
      Me.arbitrationIDHeader.Text = "Arbitration ID"
      Me.arbitrationIDHeader.Width = 77
      '
      'remoteHeader
      '
      Me.remoteHeader.Text = "Is Remote?"
      Me.remoteHeader.Width = 73
      '
      'dataSizeHeader
      '
      Me.dataSizeHeader.Text = "Data Size"
      '
      'dataHeader
      '
      Me.dataHeader.Text = "Data"
      Me.dataHeader.Width = 273
      '
      'groupBox2
      '
      Me.groupBox2.Controls.Add(Me.groupBox3)
      Me.groupBox2.Controls.Add(Me.IsRemote)
      Me.groupBox2.Controls.Add(Me.label5)
      Me.groupBox2.Controls.Add(Me.ArbitrationID)
      Me.groupBox2.Controls.Add(Me.btnSend)
      Me.groupBox2.Location = New System.Drawing.Point(8, 248)
      Me.groupBox2.Name = "groupBox2"
      Me.groupBox2.Size = New System.Drawing.Size(504, 72)
      Me.groupBox2.TabIndex = 12
      Me.groupBox2.TabStop = False
      Me.groupBox2.Text = "Send Frames"
      '
      'groupBox3
      '
      Me.groupBox3.Controls.Add(Me.DataByte0)
      Me.groupBox3.Controls.Add(Me.DataByte6)
      Me.groupBox3.Controls.Add(Me.DataByte3)
      Me.groupBox3.Controls.Add(Me.DataByte2)
      Me.groupBox3.Controls.Add(Me.DataByte4)
      Me.groupBox3.Controls.Add(Me.DataByte7)
      Me.groupBox3.Controls.Add(Me.DataByte5)
      Me.groupBox3.Controls.Add(Me.DataByte1)
      Me.groupBox3.Location = New System.Drawing.Point(280, 24)
      Me.groupBox3.Name = "groupBox3"
      Me.groupBox3.Size = New System.Drawing.Size(208, 40)
      Me.groupBox3.TabIndex = 12
      Me.groupBox3.TabStop = False
      Me.groupBox3.Text = "Data"
      '
      'DataByte0
      '
      Me.DataByte0.Location = New System.Drawing.Point(8, 16)
      Me.DataByte0.Name = "DataByte0"
      Me.DataByte0.Size = New System.Drawing.Size(24, 20)
      Me.DataByte0.TabIndex = 11
      Me.DataByte0.Text = "0"
      '
      'DataByte6
      '
      Me.DataByte6.Location = New System.Drawing.Point(152, 16)
      Me.DataByte6.Name = "DataByte6"
      Me.DataByte6.Size = New System.Drawing.Size(24, 20)
      Me.DataByte6.TabIndex = 9
      Me.DataByte6.Text = "0"
      '
      'DataByte3
      '
      Me.DataByte3.Location = New System.Drawing.Point(80, 16)
      Me.DataByte3.Name = "DataByte3"
      Me.DataByte3.Size = New System.Drawing.Size(24, 20)
      Me.DataByte3.TabIndex = 6
      Me.DataByte3.Text = "0"
      '
      'DataByte2
      '
      Me.DataByte2.Location = New System.Drawing.Point(56, 16)
      Me.DataByte2.Name = "DataByte2"
      Me.DataByte2.Size = New System.Drawing.Size(24, 20)
      Me.DataByte2.TabIndex = 5
      Me.DataByte2.Text = "0"
      '
      'DataByte4
      '
      Me.DataByte4.Location = New System.Drawing.Point(104, 16)
      Me.DataByte4.Name = "DataByte4"
      Me.DataByte4.Size = New System.Drawing.Size(24, 20)
      Me.DataByte4.TabIndex = 7
      Me.DataByte4.Text = "0"
      '
      'DataByte7
      '
      Me.DataByte7.Location = New System.Drawing.Point(176, 16)
      Me.DataByte7.Name = "DataByte7"
      Me.DataByte7.Size = New System.Drawing.Size(24, 20)
      Me.DataByte7.TabIndex = 10
      Me.DataByte7.Text = "0"
      '
      'DataByte5
      '
      Me.DataByte5.Location = New System.Drawing.Point(128, 16)
      Me.DataByte5.Name = "DataByte5"
      Me.DataByte5.Size = New System.Drawing.Size(24, 20)
      Me.DataByte5.TabIndex = 8
      Me.DataByte5.Text = "0"
      '
      'DataByte1
      '
      Me.DataByte1.Location = New System.Drawing.Point(32, 16)
      Me.DataByte1.Name = "DataByte1"
      Me.DataByte1.Size = New System.Drawing.Size(24, 20)
      Me.DataByte1.TabIndex = 4
      Me.DataByte1.Text = "0"
      '
      'IsRemote
      '
      Me.IsRemote.Location = New System.Drawing.Point(192, 40)
      Me.IsRemote.Name = "IsRemote"
      Me.IsRemote.Size = New System.Drawing.Size(80, 16)
      Me.IsRemote.TabIndex = 3
      Me.IsRemote.Text = "Is Remote?"
      '
      'label5
      '
      Me.label5.Location = New System.Drawing.Point(112, 24)
      Me.label5.Name = "label5"
      Me.label5.Size = New System.Drawing.Size(72, 16)
      Me.label5.TabIndex = 2
      Me.label5.Text = "Arbitration ID"
      '
      'ArbitrationID
      '
      Me.ArbitrationID.Location = New System.Drawing.Point(112, 40)
      Me.ArbitrationID.Name = "ArbitrationID"
      Me.ArbitrationID.Size = New System.Drawing.Size(64, 20)
      Me.ArbitrationID.TabIndex = 1
      Me.ArbitrationID.Text = "0x123"
      '
      'btnSend
      '
      Me.btnSend.Location = New System.Drawing.Point(8, 16)
      Me.btnSend.Name = "btnSend"
      Me.btnSend.Size = New System.Drawing.Size(80, 48)
      Me.btnSend.TabIndex = 0
      Me.btnSend.Text = "Send"
      '
      'btnStart
      '
      Me.btnStart.Location = New System.Drawing.Point(16, 328)
      Me.btnStart.Name = "btnStart"
      Me.btnStart.Size = New System.Drawing.Size(88, 32)
      Me.btnStart.TabIndex = 8
      Me.btnStart.Text = "Start"
      '
      'btnQuit
      '
      Me.btnQuit.Location = New System.Drawing.Point(424, 328)
      Me.btnQuit.Name = "btnQuit"
      Me.btnQuit.Size = New System.Drawing.Size(88, 32)
      Me.btnQuit.TabIndex = 14
      Me.btnQuit.Text = "Quit"
      '
      'btnStop
      '
      Me.btnStop.Location = New System.Drawing.Point(216, 328)
      Me.btnStop.Name = "btnStop"
      Me.btnStop.Size = New System.Drawing.Size(88, 32)
      Me.btnStop.TabIndex = 15
      Me.btnStop.Text = "Stop"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(520, 373)
      Me.Controls.Add(Me.btnStop)
      Me.Controls.Add(Me.btnQuit)
      Me.Controls.Add(Me.groupBox1)
      Me.Controls.Add(Me.groupBox2)
      Me.Controls.Add(Me.label4)
      Me.Controls.Add(Me.Resource)
      Me.Controls.Add(Me.label1)
      Me.Controls.Add(Me.Speed)
      Me.Controls.Add(Me.label3)
      Me.Controls.Add(Me.label2)
      Me.Controls.Add(Me.btnStart)
      Me.Name = "Form1"
      Me.Text = "This example shows how to send CAN frames out of port 0 and receive CAN frames on" & _
      " port 1."
      Me.groupBox1.ResumeLayout(False)
      Me.groupBox2.ResumeLayout(False)
      Me.groupBox3.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      Speed.SelectedIndex = 5
      InitUI(False)
   End Sub

   Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
      Try
         CANSession = New Session

         CANSession.CreateCANPort(Resource.Text, _
                                              Speed.SelectedIndex, _
                                              CANFrameFormat.Extended, _
                                              CANPortMode.Normal, _
                                              Convert.ToUInt32(&H7FFFFFFF), _
                                              Convert.ToUInt32(0))
         CANSession.ConfigureTimingForMessagingIO(2, 0)
         CANSession.GetTiming().SetTimeout(500)
         ' Create a CAN reader for port 1
         reader = New CANReader(CANSession.GetDataStream(), 1)

         ' Create a CAN writer for port 0
         writer = New CANWriter(CANSession.GetDataStream(), 0)

         ' Start Session
         CANSession.Start()

         ' Initiate one asychronous read
         reader.BeginRead(1, AddressOf ReaderCallback, Nothing)

         ' Switch UI components to start state
         InitUI(True)

      Catch ex As UeiDaqException
         CANSession.Dispose()
         CANSession = Nothing
         MessageBox.Show(ex.Message, "Error")
         InitUI(False)
      End Try
   End Sub

   Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
      Try
         CANSession.Stop()
      Catch ex As UeiDaqException
         MessageBox.Show(ex.Message, "Error")
      End Try

      CANSession.Dispose()
      CANSession = Nothing
      InitUI(False)
   End Sub

   Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click
      Application.Exit()
   End Sub

   Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
      Try
         ' Build the CANFrame array to send to the CAN port

         Dim frames(0) As CANFrame

         frames(0) = New CANFrame

         frames(0).Id = Convert.ToUInt32(ArbitrationID.Text, 16)
         If (IsRemote.Checked = True) Then
            frames(0).Type = CANFrameType.RemoteFrame
         Else
            frames(0).Type = CANFrameType.DataFrame
         End If

         frames(0).DataSize = Convert.ToUInt32(8)
         frames(0).Data = New Byte() {Convert.ToByte(DataByte0.Text, 16), _
                                     Convert.ToByte(DataByte1.Text, 16), _
                                     Convert.ToByte(DataByte2.Text, 16), _
                                     Convert.ToByte(DataByte3.Text, 16), _
                                     Convert.ToByte(DataByte4.Text, 16), _
                                     Convert.ToByte(DataByte5.Text, 16), _
                                     Convert.ToByte(DataByte6.Text, 16), _
                                     Convert.ToByte(DataByte7.Text, 16) _
                                     }
         writer.Write(frames)
      Catch ex As UeiDaqException
         CANSession.Dispose()
         CANSession = Nothing
         MessageBox.Show(ex.Message, "Error")
         InitUI(False)
      End Try
   End Sub

   Sub ReaderCallback(ByVal ar As IAsyncResult)
      Try
         Dim frames(0) As CANFrame

         frames = reader.EndRead(ar)

         For Each frame As CANFrame In frames
            Dim item As New ListViewItem(New String() {"0x" + frame.Id.ToString("X")}, 0)
            item.SubItems.Add(frame.Type.ToString())
            item.SubItems.Add(frame.DataSize.ToString())
            If (Convert.ToInt32(frame.DataSize) > 0) Then
               Dim Data As String = ""
               For b As Integer = 0 To (Convert.ToInt32(frame.DataSize) - 1) Step 1
                  Data = Data + "0x" + frame.Data(b).ToString("X") + " "
               Next
               item.SubItems.Add(Data)
            End If
            ReceiveList.Items.Add(item)
            item.EnsureVisible()
         Next

         reader.BeginRead(1, AddressOf ReaderCallback, Nothing)

      Catch ex As UeiDaqException
         If CANSession.IsRunning() Then
            If (UeiDaq.Error.Timeout = ex.Error) Then
               ' Timeout error is not fatal, it simply means that no CAN
               ' frame was received. We keep requesting incoming frames
               ' as long as the session is running
               reader.BeginRead(1, AddressOf ReaderCallback, Nothing)
            Else
               CANSession.Dispose()
               CANSession = Nothing
               MessageBox.Show(ex.Message, "Error")
               InitUI(False)
            End If
         End If
      End Try
   End Sub
End Class
