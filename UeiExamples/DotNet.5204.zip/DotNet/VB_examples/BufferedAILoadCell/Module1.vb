Imports UeiDaq

Module Module1

   Sub Main()
      Dim data(,) As Double
      Dim mySs As Session = New Session
      Dim scaleData As Boolean = True
      Dim fsforce As Double = 50   ' Full Scale Force (lbs)
      Dim fsout As Double = 1.861  ' Full Scale output (mV/V)

      Try
         mySs.CreateAIVExChannel("simu://Dev0/ai0:3", -0.05, 0.05, SensorBridgeType.FullBridge, 10, scaleData, AIChannelInputMode.Differential)
         ' mySs.CreateAIVExChannel("simu://Dev0/ai0:3", -10.0, 10.0, SensorBridgeType.FullBridge, 10, False, 0)
         mySs.ConfigureTimingForBufferedIO(1000, TimingClockSource.Internal, 2000.0, DigitalEdge.Rising, TimingDuration.Continuous)

         mySs.GetTiming().SetTimeout(5000)

         ' Create a reader object to read data synchronously.
         Dim reader As AnalogScaledReader = New AnalogScaledReader(mySs.GetDataStream())

         mySs.Start()

         ' Read 20 buffers
         For i As Integer = 0 To 20
            data = reader.ReadMultipleScans(1000)

            Console.Write("BufferedAI:")
            For j As Integer = 0 To mySs.GetNumberOfChannels() - 1
            If scaleData = True Then
               data(0, j) = data(0, j) * (fsforce / fsout)
            End If
               Console.Write(" ch" + j.ToString() + "= " + data(0, j).ToString() + "  ")
            Next
            Console.WriteLine()
         Next

         mySs.Stop()
      Catch e As UeiDaqException
         Console.WriteLine("Error: (" + e.Error.ToString() + ") " + e.Message)
      End Try
   End Sub

End Module
