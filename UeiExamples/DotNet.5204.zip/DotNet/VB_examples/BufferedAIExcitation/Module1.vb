Imports UeiDaq

Module Module1

   Sub Main()
      Dim data(,) As Double
      Dim mySs As Session = New Session

      Try
         mySs.CreateAIVExChannel("simu://Dev0/ai0:3", -10.0, 10.0, SensorBridgeType.FullBridge, 10, False, AIChannelInputMode.Differential)
         ' mySs.CreateAIVExChannel("simu://Dev0/ai0:3", -10.0, 10.0, SensorBridgeType.FullBridge, 10, False, 0)
         mySs.ConfigureTimingForBufferedIO(1000, TimingClockSource.Internal, 2000.0, DigitalEdge.Rising, TimingDuration.Continuous)

         mySs.GetTiming().SetTimeout(5000)

         ' Create a reader object to read data synchronously.
         Dim reader As AnalogScaledReader = New AnalogScaledReader(mySs.GetDataStream())
         
         mySs.Start()

         ' Read 20 buffers
         For i As Integer = 0 To 20
            Data = reader.ReadMultipleScans(1000)

            Console.Write("BufferedAI:")
            For j As Integer = 0 To mySs.GetNumberOfChannels() - 1
               Console.Write(" ch" + j.ToString() + "= " + data(0, j).ToString() + "  ")
            Next
            Console.WriteLine()
         Next

         mySs.Stop()
      Catch e As UeiDaqException
         Console.WriteLine("Error: (" + e.Error.ToString() + ") " + e.Message)
      End Try
   End Sub

End Module
