Imports UeiDaq

Module Module1

   Sub Main()
      Dim mySs As New Session

      Try
         mySs.CreateAOChannel("simu://Dev0/Ao0:1", -10.0, 10.0)
         mySs.ConfigureTimingForSimpleIO()

         Dim writer As New AnalogScaledWriter(mySs.GetDataStream)
         mySs.Start()

         ' generate a ramp from -10V to 10V on channel 0
         ' and +10V to -10V on channel 1
         For i As Double = -10.0 To 10.0 Step 0.1
            Dim data(mySs.GetNumberOfChannels()) As Double
            data(0) = i
            data(1) = -i
            writer.WriteSingleScan(data)
            Console.WriteLine(i.ToString + " " + data(0).ToString)
         Next
      Catch exception As UeiDaqException
         Console.WriteLine("Error: " + exception.Message)
      End Try

      mySs.Stop()
   End Sub

End Module
