Imports UeiDaq

Module Module1

   Sub Main()
      Dim mySs As New Session

      Try
         mySs.CreateTCChannel("pdna://192.168.0.45/Dev0/Ai2", -10.0, 10.0, ThermocoupleType.TypeK, TemperatureScale.Fahrenheit, ColdJunctionCompensationType.BuiltIn, 70, "", AIChannelInputMode.Differential)
         mySs.ConfigureTimingForSimpleIO()

         Dim reader As New AnalogScaledReader(mySs.GetDataStream)
         mySs.Start()

         For i As Integer = 0 To 3200
            Dim data(8) As Double
            data = reader.ReadSingleScan()
            Console.WriteLine(i.ToString + " " + data(0).ToString)
         Next
      Catch exception As UeiDaqException
         Console.WriteLine("Error: " + exception.Message)
      End Try

      mySs.Stop()
   End Sub

End Module
