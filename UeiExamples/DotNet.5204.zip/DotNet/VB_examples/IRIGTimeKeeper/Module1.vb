Imports UeiDaq

Module Module1

   Sub Main()
      Dim mySs As Session = New Session
      Dim irigChan As IRIGTimeKeeperChannel
      Dim enableGPS As Boolean = False


      Try
         If enableGPS Then
            ' Configure IRIG channel time keeper to use GPS as 1PPS source and enable auto-follow
            irigChan = mySs.CreateIRIGTimeKeeperChannel("pdna://192.168.100.3/Dev3/irig0", _
                                                        IRIGTimeKeeper1PPSSource.GPS, _
                                                        True)
            ' Set initial time from GPS
            irigChan.EnableInitialTimeFromGPS(True)
         Else
            ' Configure IRIG channel time keeper to use internal 1PPS and enable auto-follow
            irigChan = mySs.CreateIRIGTimeKeeperChannel("pdna://192.168.100.3/Dev3/irig0", _
                                                        IRIGTimeKeeper1PPSSource.Internal, _
                                                        True)
            ' Set initial time from PC clock
            irigChan.SetInitialTime(DateTime.Now.ToUniversalTime())
         End If

         mySs.ConfigureTimingForSimpleIO()


         ' Create a reader object to read data synchronously.
         Dim reader As IRIGReader = New IRIGReader(mySs.GetDataStream(), 0)

         mySs.Start()

         For i As Integer = 0 To 100
            Dim tkTime As DateTime

            tkTime = reader.Read()

            Console.WriteLine("Current Time keeper time is: " + tkTime.ToString())

            Threading.Thread.Sleep(100)
         Next

         mySs.Stop()
      Catch e As UeiDaqException
         Console.WriteLine("Error: (" + e.Error.ToString() + ") " + e.Message)
      End Try
   End Sub

End Module
