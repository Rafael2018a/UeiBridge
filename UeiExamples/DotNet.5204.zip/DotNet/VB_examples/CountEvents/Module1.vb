Imports UeiDaq

Module Module1

   Sub Main()
      Dim data As UInt16()
      Dim mySs As Session

      mySs = New Session

      Try
         mySs.CreateCIChannel("pwrdaq://Dev0/ci0", CounterSource.Input, CounterMode.CountEvents, CounterGate.Internal, 1, 0)

         mySs.ConfigureTimingForSimpleIO()

         ' Create a reader object to read data synchronously.
         Dim reader As CounterReader = New CounterReader(mySs.GetDataStream())

         ' Read 100 samples
         For i As Integer = 0 To 99

            data = reader.ReadSingleScanUInt16()
            Console.Write("TestCountEvents:")
            Console.WriteLine(" data = " + data(0).ToString() + "  ")
         Next
      Catch e As UeiDaqException
         Console.WriteLine("Error: (" + e.Error.ToString + ") " + e.Message)
      End Try
   End Sub

End Module
