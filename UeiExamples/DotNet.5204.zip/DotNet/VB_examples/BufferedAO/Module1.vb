Imports UeiDaq

Module Module1

   Sub Main()
      Dim data As Double(,)
      Dim mySs As Session = New Session

      Try
         mySs.CreateAOChannel("pwrdaq://Dev0/Ao0:1", -10.0, 10.0)

         mySs.ConfigureTimingForBufferedIO(1000, TimingClockSource.Internal, 60000.0, DigitalEdge.Rising, TimingDuration.Continuous)

         mySs.GetTiming().SetTimeout(5000)

         ' Create a writer object to write data synchronously.
         Dim writer As AnalogScaledWriter = New AnalogScaledWriter(mySs.GetDataStream())
         ReDim data(1000,mySs.GetNumberOfChannels())

         mySs.Start()

         ' Write 100 buffers
         For i As Integer = 0 To 100
            GenerateSinWave(data, mySs.GetNumberOfChannels(), 1000, i)
            writer.WriteMultipleScans(1000, data)
            Console.WriteLine("BufferedAO: " + i.ToString())
         Next

         mySs.Stop()
      Catch e As UeiDaqException
         Console.WriteLine("Error: (" + e.Error.ToString() + ") " + e.Message)
      End Try

      mySs.Dispose()
   End Sub

   Sub GenerateSinWave(ByVal buffer As Double(,), ByVal nbChannels As Integer, ByVal nbSamplePerChannel As Integer, ByVal iteration As Integer)
      Dim amplitude As Integer = (iteration Mod 10 + 1)

      For i As Integer = 0 To nbSamplePerChannel - 1
         For j As Integer = 0 To nbChannels - 1
            buffer(i,j) = amplitude * Math.Sin(2 * 3.1415 * (j + 1) * i / nbSamplePerChannel)
         Next
      Next
   End Sub

End Module
