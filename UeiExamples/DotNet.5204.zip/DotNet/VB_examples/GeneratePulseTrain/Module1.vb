Imports UeiDaq

Module Module1

   Sub Main()
        Dim mySs As Session

      mySs = New Session

      Try
         mySs.CreateCOChannel("pdna://192.168.100.10/Dev5/co0", _
                              CounterSource.Clock, _
                              CounterMode.GeneratePulseTrain, _
                              CounterGate.External, _
                              100000, _
                              200000, _
                              1, _
                              0)

         mySs.ConfigureTimingForSimpleIO()

         mySs.Start()

         For i As Integer = 0 To 19
            Console.WriteLine("Generating pulses")

            System.Threading.Thread.Sleep(500)
         Next
      Catch e As UeiDaqException
         Console.WriteLine("Error: (" + e.Error.ToString + ") " + e.Message)
      End Try
   End Sub

End Module
