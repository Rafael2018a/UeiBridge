Imports System.Threading
Imports UeiDaq

Module Module1
   Dim reader As DigitalReader

   Sub Main()
      Dim mySs As Session = New Session

      Try
         Dim chan As DIChannel = mySs.CreateDIChannel("pwrdaq://Dev0/Di/0")
         chan.SetEdgeMask(&HF, DigitalEdge.Rising)

         mySs.ConfigureTimingForEdgeDetection(DigitalEdge.Rising)
         mySs.GetTiming().SetTimeout(5000)

         ' Create a reader object to read data asynchronously.
         reader = New DigitalReader(mySs.GetDataStream())
         reader.BeginReadSingleScanUInt16(AddressOf ReaderCallback, Nothing)

         Thread.Sleep(4000)
      Catch e As UeiDaqException
         Console.WriteLine("Error: (" + e.Error.ToString() + ") " + e.Message)
      End Try
   End Sub

   Sub ReaderCallback(ByVal ar As IAsyncResult)
      Try
         Dim data As UInt16() = reader.EndReadSingleScanUInt16(ar)

         Console.Write("TestAsyncDIEvent:")
         Console.WriteLine(" data = " + data(0).ToString() + "  ")

         reader.BeginReadSingleScanUInt16(AddressOf ReaderCallback, Nothing)
      Catch e As UeiDaqException  
         Console.WriteLine("Error in callback: (" + e.Error + ") " + e.Message)
      End Try
   End Sub
End Module
