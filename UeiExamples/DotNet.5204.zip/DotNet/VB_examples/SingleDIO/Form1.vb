Imports UeiDaq

Public Class Form1
   Inherits System.Windows.Forms.Form

   Friend diSs As Session
   Friend doSs As Session
   Friend doWriter As DigitalWriter
   Friend diReader As DigitalReader
   Friend diData() As System.UInt16
   Friend doData() As System.UInt16
   Friend diLines() As CheckBox
   Friend doLines() As CheckBox

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      ReDim diLines(16)
      diLines(0) = DI0
      diLines(1) = DI1
      diLines(2) = DI2
      diLines(3) = DI3
      diLines(4) = DI4
      diLines(5) = DI5
      diLines(6) = DI6
      diLines(7) = DI7
      diLines(8) = DI8
      diLines(9) = DI9
      diLines(10) = DI10
      diLines(11) = DI11
      diLines(12) = DI12
      diLines(13) = DI13
      diLines(14) = DI14
      diLines(15) = DI15

      ReDim doLines(16)
      doLines(0) = DO0
      doLines(1) = DO1
      doLines(2) = DO2
      doLines(3) = DO3
      doLines(4) = DO4
      doLines(5) = DO5
      doLines(6) = DO6
      doLines(7) = DO7
      doLines(8) = DO8
      doLines(9) = DO9
      doLines(10) = DO10
      doLines(11) = DO11
      doLines(12) = DO12
      doLines(13) = DO13
      doLines(14) = DO14
      doLines(15) = DO15

      StopSession.Enabled = False

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents groupBox2 As System.Windows.Forms.GroupBox
   Friend WithEvents DigitalInputPort As System.Windows.Forms.ComboBox
   Friend WithEvents DI15 As System.Windows.Forms.CheckBox
   Friend WithEvents DI9 As System.Windows.Forms.CheckBox
   Friend WithEvents DI10 As System.Windows.Forms.CheckBox
   Friend WithEvents DI11 As System.Windows.Forms.CheckBox
   Friend WithEvents DI12 As System.Windows.Forms.CheckBox
   Friend WithEvents DI13 As System.Windows.Forms.CheckBox
   Friend WithEvents DI14 As System.Windows.Forms.CheckBox
   Friend WithEvents DI8 As System.Windows.Forms.CheckBox
   Friend WithEvents DI7 As System.Windows.Forms.CheckBox
   Friend WithEvents DI6 As System.Windows.Forms.CheckBox
   Friend WithEvents DI5 As System.Windows.Forms.CheckBox
   Friend WithEvents DI4 As System.Windows.Forms.CheckBox
   Friend WithEvents DI3 As System.Windows.Forms.CheckBox
   Friend WithEvents DI2 As System.Windows.Forms.CheckBox
   Friend WithEvents DigInputResource As System.Windows.Forms.TextBox
   Friend WithEvents DI1 As System.Windows.Forms.CheckBox
   Friend WithEvents DI0 As System.Windows.Forms.CheckBox
   Friend WithEvents label1 As System.Windows.Forms.Label
   Friend WithEvents DigOutputResource As System.Windows.Forms.TextBox
   Friend WithEvents label2 As System.Windows.Forms.Label
   Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
   Friend WithEvents DigitalOutputPort As System.Windows.Forms.ComboBox
   Friend WithEvents DO15 As System.Windows.Forms.CheckBox
   Friend WithEvents DO9 As System.Windows.Forms.CheckBox
   Friend WithEvents DO10 As System.Windows.Forms.CheckBox
   Friend WithEvents DO11 As System.Windows.Forms.CheckBox
   Friend WithEvents DO12 As System.Windows.Forms.CheckBox
   Friend WithEvents DO13 As System.Windows.Forms.CheckBox
   Friend WithEvents DO14 As System.Windows.Forms.CheckBox
   Friend WithEvents DO8 As System.Windows.Forms.CheckBox
   Friend WithEvents DO7 As System.Windows.Forms.CheckBox
   Friend WithEvents DO6 As System.Windows.Forms.CheckBox
   Friend WithEvents DO5 As System.Windows.Forms.CheckBox
   Friend WithEvents DO4 As System.Windows.Forms.CheckBox
   Friend WithEvents DO3 As System.Windows.Forms.CheckBox
   Friend WithEvents DO2 As System.Windows.Forms.CheckBox
   Friend WithEvents DO1 As System.Windows.Forms.CheckBox
   Friend WithEvents DO0 As System.Windows.Forms.CheckBox
   Friend WithEvents ErrorText As System.Windows.Forms.TextBox
   Friend WithEvents Quit As System.Windows.Forms.Button
   Friend WithEvents Go As System.Windows.Forms.Button
   Friend WithEvents StopSession As System.Windows.Forms.Button
   Friend WithEvents imageList1 As System.Windows.Forms.ImageList
   Friend WithEvents DITimer As System.Windows.Forms.Timer
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
      Me.groupBox2 = New System.Windows.Forms.GroupBox
      Me.DigitalInputPort = New System.Windows.Forms.ComboBox
      Me.DI15 = New System.Windows.Forms.CheckBox
      Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
      Me.DI9 = New System.Windows.Forms.CheckBox
      Me.DI10 = New System.Windows.Forms.CheckBox
      Me.DI11 = New System.Windows.Forms.CheckBox
      Me.DI12 = New System.Windows.Forms.CheckBox
      Me.DI13 = New System.Windows.Forms.CheckBox
      Me.DI14 = New System.Windows.Forms.CheckBox
      Me.DI8 = New System.Windows.Forms.CheckBox
      Me.DI7 = New System.Windows.Forms.CheckBox
      Me.DI6 = New System.Windows.Forms.CheckBox
      Me.DI5 = New System.Windows.Forms.CheckBox
      Me.DI4 = New System.Windows.Forms.CheckBox
      Me.DI3 = New System.Windows.Forms.CheckBox
      Me.DI2 = New System.Windows.Forms.CheckBox
      Me.DigInputResource = New System.Windows.Forms.TextBox
      Me.DI1 = New System.Windows.Forms.CheckBox
      Me.DI0 = New System.Windows.Forms.CheckBox
      Me.label1 = New System.Windows.Forms.Label
      Me.DigOutputResource = New System.Windows.Forms.TextBox
      Me.label2 = New System.Windows.Forms.Label
      Me.groupBox1 = New System.Windows.Forms.GroupBox
      Me.DigitalOutputPort = New System.Windows.Forms.ComboBox
      Me.DO15 = New System.Windows.Forms.CheckBox
      Me.DO9 = New System.Windows.Forms.CheckBox
      Me.DO10 = New System.Windows.Forms.CheckBox
      Me.DO11 = New System.Windows.Forms.CheckBox
      Me.DO12 = New System.Windows.Forms.CheckBox
      Me.DO13 = New System.Windows.Forms.CheckBox
      Me.DO14 = New System.Windows.Forms.CheckBox
      Me.DO8 = New System.Windows.Forms.CheckBox
      Me.DO7 = New System.Windows.Forms.CheckBox
      Me.DO6 = New System.Windows.Forms.CheckBox
      Me.DO5 = New System.Windows.Forms.CheckBox
      Me.DO4 = New System.Windows.Forms.CheckBox
      Me.DO3 = New System.Windows.Forms.CheckBox
      Me.DO2 = New System.Windows.Forms.CheckBox
      Me.DO1 = New System.Windows.Forms.CheckBox
      Me.DO0 = New System.Windows.Forms.CheckBox
      Me.ErrorText = New System.Windows.Forms.TextBox
      Me.Quit = New System.Windows.Forms.Button
      Me.Go = New System.Windows.Forms.Button
      Me.StopSession = New System.Windows.Forms.Button
      Me.DITimer = New System.Windows.Forms.Timer(Me.components)
      Me.groupBox2.SuspendLayout()
      Me.groupBox1.SuspendLayout()
      Me.SuspendLayout()
      '
      'groupBox2
      '
      Me.groupBox2.Controls.Add(Me.DigitalInputPort)
      Me.groupBox2.Controls.Add(Me.DI15)
      Me.groupBox2.Controls.Add(Me.DI9)
      Me.groupBox2.Controls.Add(Me.DI10)
      Me.groupBox2.Controls.Add(Me.DI11)
      Me.groupBox2.Controls.Add(Me.DI12)
      Me.groupBox2.Controls.Add(Me.DI13)
      Me.groupBox2.Controls.Add(Me.DI14)
      Me.groupBox2.Controls.Add(Me.DI8)
      Me.groupBox2.Controls.Add(Me.DI7)
      Me.groupBox2.Controls.Add(Me.DI6)
      Me.groupBox2.Controls.Add(Me.DI5)
      Me.groupBox2.Controls.Add(Me.DI4)
      Me.groupBox2.Controls.Add(Me.DI3)
      Me.groupBox2.Controls.Add(Me.DI2)
      Me.groupBox2.Controls.Add(Me.DigInputResource)
      Me.groupBox2.Controls.Add(Me.DI1)
      Me.groupBox2.Controls.Add(Me.DI0)
      Me.groupBox2.Controls.Add(Me.label1)
      Me.groupBox2.Location = New System.Drawing.Point(8, 136)
      Me.groupBox2.Name = "groupBox2"
      Me.groupBox2.Size = New System.Drawing.Size(528, 112)
      Me.groupBox2.TabIndex = 29
      Me.groupBox2.TabStop = False
      Me.groupBox2.Text = "Digital Input Port"
      '
      'DigitalInputPort
      '
      Me.DigitalInputPort.Location = New System.Drawing.Point(184, 32)
      Me.DigitalInputPort.Name = "DigitalInputPort"
      Me.DigitalInputPort.Size = New System.Drawing.Size(160, 21)
      Me.DigitalInputPort.TabIndex = 35
      '
      'DI15
      '
      Me.DI15.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI15.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI15.ImageIndex = 0
      Me.DI15.ImageList = Me.imageList1
      Me.DI15.Location = New System.Drawing.Point(488, 64)
      Me.DI15.Name = "DI15"
      Me.DI15.Size = New System.Drawing.Size(32, 32)
      Me.DI15.TabIndex = 34
      Me.DI15.Text = "15"
      Me.DI15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'imageList1
      '
      Me.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit
      Me.imageList1.ImageSize = New System.Drawing.Size(24, 24)
      Me.imageList1.ImageStream = CType(resources.GetObject("imageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
      Me.imageList1.TransparentColor = System.Drawing.Color.White
      '
      'DI9
      '
      Me.DI9.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI9.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI9.ImageIndex = 0
      Me.DI9.ImageList = Me.imageList1
      Me.DI9.Location = New System.Drawing.Point(296, 64)
      Me.DI9.Name = "DI9"
      Me.DI9.Size = New System.Drawing.Size(32, 32)
      Me.DI9.TabIndex = 33
      Me.DI9.Text = "9"
      Me.DI9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI10
      '
      Me.DI10.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI10.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI10.ImageIndex = 0
      Me.DI10.ImageList = Me.imageList1
      Me.DI10.Location = New System.Drawing.Point(328, 64)
      Me.DI10.Name = "DI10"
      Me.DI10.Size = New System.Drawing.Size(32, 32)
      Me.DI10.TabIndex = 32
      Me.DI10.Text = "10"
      Me.DI10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI11
      '
      Me.DI11.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI11.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI11.ImageIndex = 0
      Me.DI11.ImageList = Me.imageList1
      Me.DI11.Location = New System.Drawing.Point(360, 64)
      Me.DI11.Name = "DI11"
      Me.DI11.Size = New System.Drawing.Size(32, 32)
      Me.DI11.TabIndex = 31
      Me.DI11.Text = "11"
      Me.DI11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI12
      '
      Me.DI12.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI12.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI12.ImageIndex = 0
      Me.DI12.ImageList = Me.imageList1
      Me.DI12.Location = New System.Drawing.Point(392, 64)
      Me.DI12.Name = "DI12"
      Me.DI12.Size = New System.Drawing.Size(32, 32)
      Me.DI12.TabIndex = 30
      Me.DI12.Text = "12"
      Me.DI12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI13
      '
      Me.DI13.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI13.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI13.ImageIndex = 0
      Me.DI13.ImageList = Me.imageList1
      Me.DI13.Location = New System.Drawing.Point(424, 64)
      Me.DI13.Name = "DI13"
      Me.DI13.Size = New System.Drawing.Size(32, 32)
      Me.DI13.TabIndex = 29
      Me.DI13.Text = "13"
      Me.DI13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI14
      '
      Me.DI14.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI14.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI14.ImageIndex = 0
      Me.DI14.ImageList = Me.imageList1
      Me.DI14.Location = New System.Drawing.Point(456, 64)
      Me.DI14.Name = "DI14"
      Me.DI14.Size = New System.Drawing.Size(32, 32)
      Me.DI14.TabIndex = 28
      Me.DI14.Text = "14"
      Me.DI14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI8
      '
      Me.DI8.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI8.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI8.ImageIndex = 0
      Me.DI8.ImageList = Me.imageList1
      Me.DI8.Location = New System.Drawing.Point(264, 64)
      Me.DI8.Name = "DI8"
      Me.DI8.Size = New System.Drawing.Size(32, 32)
      Me.DI8.TabIndex = 27
      Me.DI8.Text = "8"
      Me.DI8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI7
      '
      Me.DI7.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI7.ImageIndex = 0
      Me.DI7.ImageList = Me.imageList1
      Me.DI7.Location = New System.Drawing.Point(232, 64)
      Me.DI7.Name = "DI7"
      Me.DI7.Size = New System.Drawing.Size(32, 32)
      Me.DI7.TabIndex = 26
      Me.DI7.Text = "7"
      Me.DI7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI6
      '
      Me.DI6.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI6.ImageIndex = 0
      Me.DI6.ImageList = Me.imageList1
      Me.DI6.Location = New System.Drawing.Point(200, 64)
      Me.DI6.Name = "DI6"
      Me.DI6.Size = New System.Drawing.Size(32, 32)
      Me.DI6.TabIndex = 25
      Me.DI6.Text = "6"
      Me.DI6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI5
      '
      Me.DI5.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI5.ImageIndex = 0
      Me.DI5.ImageList = Me.imageList1
      Me.DI5.Location = New System.Drawing.Point(168, 64)
      Me.DI5.Name = "DI5"
      Me.DI5.Size = New System.Drawing.Size(32, 32)
      Me.DI5.TabIndex = 24
      Me.DI5.Text = "5"
      Me.DI5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI4
      '
      Me.DI4.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI4.ImageIndex = 0
      Me.DI4.ImageList = Me.imageList1
      Me.DI4.Location = New System.Drawing.Point(136, 64)
      Me.DI4.Name = "DI4"
      Me.DI4.Size = New System.Drawing.Size(32, 32)
      Me.DI4.TabIndex = 23
      Me.DI4.Text = "4"
      Me.DI4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI3
      '
      Me.DI3.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI3.ImageIndex = 0
      Me.DI3.ImageList = Me.imageList1
      Me.DI3.Location = New System.Drawing.Point(104, 64)
      Me.DI3.Name = "DI3"
      Me.DI3.Size = New System.Drawing.Size(32, 32)
      Me.DI3.TabIndex = 22
      Me.DI3.Text = "3"
      Me.DI3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI2
      '
      Me.DI2.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI2.ImageIndex = 0
      Me.DI2.ImageList = Me.imageList1
      Me.DI2.Location = New System.Drawing.Point(72, 64)
      Me.DI2.Name = "DI2"
      Me.DI2.Size = New System.Drawing.Size(32, 32)
      Me.DI2.TabIndex = 21
      Me.DI2.Text = "2"
      Me.DI2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DigInputResource
      '
      Me.DigInputResource.Location = New System.Drawing.Point(8, 40)
      Me.DigInputResource.Name = "DigInputResource"
      Me.DigInputResource.Size = New System.Drawing.Size(112, 20)
      Me.DigInputResource.TabIndex = 36
      Me.DigInputResource.Text = "simu://Dev0/Di0:3"
      '
      'DI1
      '
      Me.DI1.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI1.ImageIndex = 0
      Me.DI1.ImageList = Me.imageList1
      Me.DI1.Location = New System.Drawing.Point(40, 64)
      Me.DI1.Name = "DI1"
      Me.DI1.Size = New System.Drawing.Size(32, 32)
      Me.DI1.TabIndex = 20
      Me.DI1.Text = "1"
      Me.DI1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DI0
      '
      Me.DI0.Appearance = System.Windows.Forms.Appearance.Button
      Me.DI0.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DI0.ImageIndex = 0
      Me.DI0.ImageList = Me.imageList1
      Me.DI0.Location = New System.Drawing.Point(8, 64)
      Me.DI0.Name = "DI0"
      Me.DI0.Size = New System.Drawing.Size(32, 32)
      Me.DI0.TabIndex = 19
      Me.DI0.Text = "0"
      Me.DI0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'label1
      '
      Me.label1.Location = New System.Drawing.Point(8, 24)
      Me.label1.Name = "label1"
      Me.label1.Size = New System.Drawing.Size(120, 16)
      Me.label1.TabIndex = 37
      Me.label1.Text = "Resource name"
      '
      'DigOutputResource
      '
      Me.DigOutputResource.Location = New System.Drawing.Point(16, 48)
      Me.DigOutputResource.Name = "DigOutputResource"
      Me.DigOutputResource.Size = New System.Drawing.Size(112, 20)
      Me.DigOutputResource.TabIndex = 26
      Me.DigOutputResource.Text = "simu://Dev0/Do0:3"
      '
      'label2
      '
      Me.label2.Location = New System.Drawing.Point(16, 32)
      Me.label2.Name = "label2"
      Me.label2.Size = New System.Drawing.Size(120, 16)
      Me.label2.TabIndex = 27
      Me.label2.Text = "Resource name"
      '
      'groupBox1
      '
      Me.groupBox1.Controls.Add(Me.DigitalOutputPort)
      Me.groupBox1.Controls.Add(Me.DO15)
      Me.groupBox1.Controls.Add(Me.DO9)
      Me.groupBox1.Controls.Add(Me.DO10)
      Me.groupBox1.Controls.Add(Me.DO11)
      Me.groupBox1.Controls.Add(Me.DO12)
      Me.groupBox1.Controls.Add(Me.DO13)
      Me.groupBox1.Controls.Add(Me.DO14)
      Me.groupBox1.Controls.Add(Me.DO8)
      Me.groupBox1.Controls.Add(Me.DO7)
      Me.groupBox1.Controls.Add(Me.DO6)
      Me.groupBox1.Controls.Add(Me.DO5)
      Me.groupBox1.Controls.Add(Me.DO4)
      Me.groupBox1.Controls.Add(Me.DO3)
      Me.groupBox1.Controls.Add(Me.DO2)
      Me.groupBox1.Controls.Add(Me.DO1)
      Me.groupBox1.Controls.Add(Me.DO0)
      Me.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
      Me.groupBox1.Location = New System.Drawing.Point(8, 8)
      Me.groupBox1.Name = "groupBox1"
      Me.groupBox1.Size = New System.Drawing.Size(528, 120)
      Me.groupBox1.TabIndex = 28
      Me.groupBox1.TabStop = False
      Me.groupBox1.Text = "Digital Output Port"
      '
      'DigitalOutputPort
      '
      Me.DigitalOutputPort.Location = New System.Drawing.Point(184, 40)
      Me.DigitalOutputPort.Name = "DigitalOutputPort"
      Me.DigitalOutputPort.Size = New System.Drawing.Size(160, 21)
      Me.DigitalOutputPort.TabIndex = 16
      '
      'DO15
      '
      Me.DO15.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO15.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO15.ImageIndex = 0
      Me.DO15.ImageList = Me.imageList1
      Me.DO15.Location = New System.Drawing.Point(488, 72)
      Me.DO15.Name = "DO15"
      Me.DO15.Size = New System.Drawing.Size(32, 32)
      Me.DO15.TabIndex = 15
      Me.DO15.Text = "15"
      Me.DO15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO9
      '
      Me.DO9.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO9.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO9.ImageIndex = 0
      Me.DO9.ImageList = Me.imageList1
      Me.DO9.Location = New System.Drawing.Point(296, 72)
      Me.DO9.Name = "DO9"
      Me.DO9.Size = New System.Drawing.Size(32, 32)
      Me.DO9.TabIndex = 14
      Me.DO9.Text = "9"
      Me.DO9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO10
      '
      Me.DO10.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO10.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO10.ImageIndex = 0
      Me.DO10.ImageList = Me.imageList1
      Me.DO10.Location = New System.Drawing.Point(328, 72)
      Me.DO10.Name = "DO10"
      Me.DO10.Size = New System.Drawing.Size(32, 32)
      Me.DO10.TabIndex = 13
      Me.DO10.Text = "10"
      Me.DO10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO11
      '
      Me.DO11.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO11.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO11.ImageIndex = 0
      Me.DO11.ImageList = Me.imageList1
      Me.DO11.Location = New System.Drawing.Point(360, 72)
      Me.DO11.Name = "DO11"
      Me.DO11.Size = New System.Drawing.Size(32, 32)
      Me.DO11.TabIndex = 12
      Me.DO11.Text = "11"
      Me.DO11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO12
      '
      Me.DO12.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO12.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO12.ImageIndex = 0
      Me.DO12.ImageList = Me.imageList1
      Me.DO12.Location = New System.Drawing.Point(392, 72)
      Me.DO12.Name = "DO12"
      Me.DO12.Size = New System.Drawing.Size(32, 32)
      Me.DO12.TabIndex = 11
      Me.DO12.Text = "12"
      Me.DO12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO13
      '
      Me.DO13.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO13.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO13.ImageIndex = 0
      Me.DO13.ImageList = Me.imageList1
      Me.DO13.Location = New System.Drawing.Point(424, 72)
      Me.DO13.Name = "DO13"
      Me.DO13.Size = New System.Drawing.Size(32, 32)
      Me.DO13.TabIndex = 10
      Me.DO13.Text = "13"
      Me.DO13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO14
      '
      Me.DO14.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO14.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO14.ImageIndex = 0
      Me.DO14.ImageList = Me.imageList1
      Me.DO14.Location = New System.Drawing.Point(456, 72)
      Me.DO14.Name = "DO14"
      Me.DO14.Size = New System.Drawing.Size(32, 32)
      Me.DO14.TabIndex = 9
      Me.DO14.Text = "14"
      Me.DO14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO8
      '
      Me.DO8.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO8.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO8.ImageIndex = 0
      Me.DO8.ImageList = Me.imageList1
      Me.DO8.Location = New System.Drawing.Point(264, 72)
      Me.DO8.Name = "DO8"
      Me.DO8.Size = New System.Drawing.Size(32, 32)
      Me.DO8.TabIndex = 8
      Me.DO8.Text = "8"
      Me.DO8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO7
      '
      Me.DO7.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO7.ImageIndex = 0
      Me.DO7.ImageList = Me.imageList1
      Me.DO7.Location = New System.Drawing.Point(232, 72)
      Me.DO7.Name = "DO7"
      Me.DO7.Size = New System.Drawing.Size(32, 32)
      Me.DO7.TabIndex = 7
      Me.DO7.Text = "7"
      Me.DO7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO6
      '
      Me.DO6.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO6.ImageIndex = 0
      Me.DO6.ImageList = Me.imageList1
      Me.DO6.Location = New System.Drawing.Point(200, 72)
      Me.DO6.Name = "DO6"
      Me.DO6.Size = New System.Drawing.Size(32, 32)
      Me.DO6.TabIndex = 6
      Me.DO6.Text = "6"
      Me.DO6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO5
      '
      Me.DO5.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO5.ImageIndex = 0
      Me.DO5.ImageList = Me.imageList1
      Me.DO5.Location = New System.Drawing.Point(168, 72)
      Me.DO5.Name = "DO5"
      Me.DO5.Size = New System.Drawing.Size(32, 32)
      Me.DO5.TabIndex = 5
      Me.DO5.Text = "5"
      Me.DO5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO4
      '
      Me.DO4.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO4.ImageIndex = 0
      Me.DO4.ImageList = Me.imageList1
      Me.DO4.Location = New System.Drawing.Point(136, 72)
      Me.DO4.Name = "DO4"
      Me.DO4.Size = New System.Drawing.Size(32, 32)
      Me.DO4.TabIndex = 4
      Me.DO4.Text = "4"
      Me.DO4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO3
      '
      Me.DO3.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO3.ImageIndex = 0
      Me.DO3.ImageList = Me.imageList1
      Me.DO3.Location = New System.Drawing.Point(104, 72)
      Me.DO3.Name = "DO3"
      Me.DO3.Size = New System.Drawing.Size(32, 32)
      Me.DO3.TabIndex = 3
      Me.DO3.Text = "3"
      Me.DO3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO2
      '
      Me.DO2.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO2.ImageIndex = 0
      Me.DO2.ImageList = Me.imageList1
      Me.DO2.Location = New System.Drawing.Point(72, 72)
      Me.DO2.Name = "DO2"
      Me.DO2.Size = New System.Drawing.Size(32, 32)
      Me.DO2.TabIndex = 2
      Me.DO2.Text = "2"
      Me.DO2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO1
      '
      Me.DO1.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO1.ImageIndex = 0
      Me.DO1.ImageList = Me.imageList1
      Me.DO1.Location = New System.Drawing.Point(40, 72)
      Me.DO1.Name = "DO1"
      Me.DO1.Size = New System.Drawing.Size(32, 32)
      Me.DO1.TabIndex = 1
      Me.DO1.Text = "1"
      Me.DO1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'DO0
      '
      Me.DO0.Appearance = System.Windows.Forms.Appearance.Button
      Me.DO0.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
      Me.DO0.ImageIndex = 0
      Me.DO0.ImageList = Me.imageList1
      Me.DO0.Location = New System.Drawing.Point(8, 72)
      Me.DO0.Name = "DO0"
      Me.DO0.Size = New System.Drawing.Size(32, 32)
      Me.DO0.TabIndex = 0
      Me.DO0.Text = "0"
      Me.DO0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'ErrorText
      '
      Me.ErrorText.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.ErrorText.Location = New System.Drawing.Point(0, 310)
      Me.ErrorText.Multiline = True
      Me.ErrorText.Name = "ErrorText"
      Me.ErrorText.ReadOnly = True
      Me.ErrorText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.ErrorText.Size = New System.Drawing.Size(544, 48)
      Me.ErrorText.TabIndex = 22
      Me.ErrorText.Text = ""
      '
      'Quit
      '
      Me.Quit.Location = New System.Drawing.Point(360, 272)
      Me.Quit.Name = "Quit"
      Me.Quit.Size = New System.Drawing.Size(112, 32)
      Me.Quit.TabIndex = 31
      Me.Quit.Text = "Quit"
      '
      'Go
      '
      Me.Go.Location = New System.Drawing.Point(72, 272)
      Me.Go.Name = "Go"
      Me.Go.Size = New System.Drawing.Size(112, 32)
      Me.Go.TabIndex = 30
      Me.Go.Text = "Go"
      '
      'StopSession
      '
      Me.StopSession.Location = New System.Drawing.Point(216, 272)
      Me.StopSession.Name = "StopSession"
      Me.StopSession.Size = New System.Drawing.Size(112, 32)
      Me.StopSession.TabIndex = 32
      Me.StopSession.Text = "Stop"
      '
      'DITimer
      '
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(544, 358)
      Me.Controls.Add(Me.StopSession)
      Me.Controls.Add(Me.Quit)
      Me.Controls.Add(Me.Go)
      Me.Controls.Add(Me.groupBox2)
      Me.Controls.Add(Me.DigOutputResource)
      Me.Controls.Add(Me.label2)
      Me.Controls.Add(Me.groupBox1)
      Me.Controls.Add(Me.ErrorText)
      Me.Name = "Form1"
      Me.Text = "Form1"
      Me.groupBox2.ResumeLayout(False)
      Me.groupBox1.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub Quit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Quit.Click
      Application.Exit()
   End Sub

   Private Sub Go_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Go.Click
      ErrorText.Clear()
      DigitalInputPort.Items.Clear()
      DigitalOutputPort.Items.Clear()

      Try
         ' Initializes Digital input session
         diSs = New Session
         diSs.CreateDIChannel(DigInputResource.Text)

         For i As Integer = 0 To diSs.GetNumberOfChannels() - 1
            DigitalInputPort.Items.Add("Port " + diSs.GetChannel(i).GetIndex().ToString())
         Next

         DigitalInputPort.SelectedIndex = 0

         diSs.ConfigureTimingForSimpleIO()

         ' Create a reader object to read data synchronously.
         diReader = New DigitalReader(diSs.GetDataStream())

         ' Initializes Digital output session
         doSs = New Session
         doSs.CreateDOChannel(DigOutputResource.Text)

         For i As Integer = 0 To doSs.GetNumberOfChannels() - 1
            DigitalOutputPort.Items.Add("Port " + doSs.GetChannel(i).GetIndex().ToString())
         Next

         DigitalOutputPort.SelectedIndex = 0
         ReDim doData(doSs.GetNumberOfChannels())

         doSs.ConfigureTimingForSimpleIO()

         ' Create a reader object to read data synchronously.
         doWriter = New DigitalWriter(doSs.GetDataStream())

         diSs.Start()
         doSs.Start()

         DITimer.Interval = 10
         DITimer.Start()

         DigInputResource.Enabled = False
         DigOutputResource.Enabled = False
         Go.Enabled = False
         StopSession.Enabled = True
      Catch exception As UeiDaqException
         ErrorText.Text = "Error: (" + exception.Error.ToString() + ") " + exception.Message
         If Not diSs Is Nothing Then
            diSs.Dispose()
            diSs = Nothing
         End If
         If Not doSs Is Nothing Then
            doSs.Dispose()
            doSs = Nothing
         End If
      End Try
   End Sub

   Private Sub DITimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DITimer.Tick
      diData = diReader.ReadSingleScanUInt16()
      Dim port As Integer = Convert.ToInt32(diData(DigitalInputPort.SelectedIndex))
      For i As Integer = 0 To 15     
         If (port And (1 << i)) <> 0 Then
            diLines(i).Checked = True
            diLines(i).ImageIndex = 1
         Else
            diLines(i).Checked = False
            diLines(i).ImageIndex = 0
         End If
      Next
   End Sub

   Private Sub StopSession_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopSession.Click
      Try
         DITimer.Stop()
         diSs.Stop()
         doSs.Stop()

         DigInputResource.Enabled = True
         DigOutputResource.Enabled = True
         Go.Enabled = True
         StopSession.Enabled = False

      Catch exception As UeiDaqException
         ErrorText.Text = "Error: (" + exception.Error.ToString() + ") " + exception.Message
      End Try

      diSs.Dispose()
      diSs = Nothing
      doSs.Dispose()
      doSs = Nothing
   End Sub

   Private Sub DO_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DO0.CheckedChanged, DO1.CheckedChanged, DO2.CheckedChanged, DO3.CheckedChanged, DO4.CheckedChanged, DO5.CheckedChanged, DO6.CheckedChanged, DO7.CheckedChanged, DO8.CheckedChanged, DO9.CheckedChanged, DO10.CheckedChanged, DO11.CheckedChanged, DO12.CheckedChanged, DO13.CheckedChanged, DO14.CheckedChanged, DO15.CheckedChanged
      Dim dol As CheckBox = CType(sender, CheckBox)
      If dol.Checked Then
         dol.ImageIndex = 1
      Else
         dol.ImageIndex = 0
      End If

      Dim state As Integer = 0
      For i As Integer = 0 To 15
         If doLines(i).Checked Then
            state = state Or (1 << i)
         End If
      Next

      doData(DigitalOutputPort.SelectedIndex) = Convert.ToUInt16(state)
      doWriter.WriteSingleScanUInt16(doData)
   End Sub
End Class
