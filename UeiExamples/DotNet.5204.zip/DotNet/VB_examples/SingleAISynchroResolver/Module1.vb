Imports UeiDaq

Module Module1

   Sub Main()
      Dim data() As Double
      Dim mySs As Session = New Session

      Try
         mySs.CreateSynchroResolverChannel("simu://Dev0/Ai0:3", SynchroResolverMode.Synchro, 10, 600, False)
         mySs.ConfigureTimingForSimpleIO()

         ' Create a reader object to read data synchronously.
         Dim reader As AnalogScaledReader = New AnalogScaledReader(mySs.GetDataStream())
         
         mySs.Start()

         ' Read 20 buffers
         For i As Integer = 0 To 20
            Data = reader.ReadSingleScan()

            Console.Write("SingleAISynchroResolver:")
            For j As Integer = 0 To mySs.GetNumberOfChannels() - 1
               Console.Write(" ch" + j.ToString() + "= " + data(j).ToString() + "  ")
            Next
            Console.WriteLine()
         Next

         mySs.Stop()
      Catch e As UeiDaqException
         Console.WriteLine("Error: (" + e.Error.ToString() + ") " + e.Message)
      End Try
   End Sub

End Module
