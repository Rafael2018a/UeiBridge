Imports UeiDaq

Module Module1

   Sub Main()
      Dim data(,) As Double
      Dim mySs(2) As Session
      Dim reader(2) As AnalogScaledReader
      Dim devices(2) As String


      Try
         devices(0) = "pdna://192.168.100.2/Dev1/Ai0:1"
         devices(1) = "simu://Dev0/Ai0:2"
         For d As Integer = 0 To 1
         mySs(d) = New Session
         mySs(d).CreateAIChannel(devices(d), -10.0, 10.0, AIChannelInputMode.Differential)
         mySs(d).ConfigureTimingForBufferedIO(1000, TimingClockSource.Internal, 2000.0, DigitalEdge.Rising, TimingDuration.Continuous)

         mySs(d).GetTiming().SetTimeout(5000)

         ' Create a reader object to read data synchronously.
         reader(d) = New AnalogScaledReader(mySs(d).GetDataStream())

         mySs(d).Start()
         Next

         ' Read 20 buffers
         For i As Integer = 1 To 20
            For d As Integer = 0 To 1
               data = reader(d).ReadMultipleScans(1000)

               Console.Write("Device:" + d.ToString())
               For j As Integer = 0 To mySs(d).GetNumberOfChannels() - 1
                  Console.Write(" ch" + j.ToString() + "= " + data(0, j).ToString() + "  ")
               Next
               Console.WriteLine()
            Next
         Next
      For d As Integer = 0 To 1
         mySs(d).Stop()
      Next
      Catch e As UeiDaqException
         Console.WriteLine("Error: (" + e.Error.ToString() + ") " + e.Message)
      End Try
   End Sub

End Module
