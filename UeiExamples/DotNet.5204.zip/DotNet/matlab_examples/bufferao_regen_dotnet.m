
try
    resourceStr = 'pdna://192.168.100.6/dev0/ao0,1';
    updateRate = 1000;
       
    NET.addAssembly('C:\Program Files (x86)\UEI\Framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');
    
    import UeiDaq.*;
    
    %create a session
    aoSs = UeiDaq.Session();
    
    aoSs.CreateAOChannel(resourceStr,-10.0,10.0);
    
    % Get number of channels
    numChannels = aoSs.GetNumberOfChannels();
    
    % Compute the maximum number of scans that fit in the output FIFO
    fifoSize = aoSs.GetDevice().GetOutputFIFOSize();
    numScans = fifoSize / numChannels;
         
    aoSs.ConfigureTimingForBufferedIO(numScans,UeiDaq.TimingClockSource.Internal,updateRate,UeiDaq.DigitalEdge.Rising,UeiDaq.TimingDuration.Continuous);
    aoSs.GetDataStream().SetRegenerate(1);
    
    writer = UeiDaq.AnalogScaledWriter(aoSs.GetDataStream());   
          
    % Prepare some data to generate
    ramp = linspace(0,2*pi,numScans);

    % Each channel will contain a sine wave of 10V amplitude
    data = [];

    for i=1:numChannels 
        data = [data 10*sin(ramp)']
    end

    plot(data);
    
    % convert matlab array to .NET data
    netData = NET.convertArray(data,'System.Double', [numScans, numChannels]);
    writer.WriteMultipleScans(numScans,netData);
    
    aoSs.Start();
    
    % Wait until key pressed
    disp('Press a key to terminate generation')
    pause()
    
    %Clean up the session
    aoSs.Stop();
    aoSs.Dispose();
catch e
  e.message
end