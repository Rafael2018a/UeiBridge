try
    NET.addAssembly('c:\program files (x86)\uei\framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');
    
    %number of samples to acquire
    numIterations = 128;

    session = UeiDaq.Session();

    session.CreateTCChannel('simu://dev0/Ai0:7', -100.0, 100.0,...
                            UeiDaq.ThermocoupleType.TypeK,...
                            UeiDaq.TemperatureScale.Celsius,...
                            UeiDaq.ColdJunctionCompensationType.Constant,...
                            25.0,...
                            '',...
                            UeiDaq.AIChannelInputMode.Differential);
    session.ConfigureTimingForSimpleIO();
    
    % Allocate a buffer to store acquired scans
    buffer = zeros(numIterations, session.GetNumberOfChannels());

    reader = UeiDaq.AnalogScaledReader(session.GetDataStream());

    session.Start();

    for i = 1:numIterations
       netData = reader.ReadSingleScan();
       
       % Convert .NET array to matlab array
       mlData = double(netData);
       % insert scan in plot buffer
       buffer(i,:) = mlData;
    end

    plot(buffer);

    session.Stop();
    session.Dispose();
catch e
    e.message
    session.Dispose()
end