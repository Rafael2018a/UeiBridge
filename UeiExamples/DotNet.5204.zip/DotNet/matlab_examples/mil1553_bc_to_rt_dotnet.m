%Load Ueidaq .NET assembly
NET.addAssembly('c:\program files (x86)\uei\framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');
    
import UeiDaq.*;     
 try
    %Bus Writer resource string
    BWStr = 'pdna://192.168.100.5/dev1/MILB0';   
    bwPort = UeiDaq.MIL1553Port();

    
    %Remote Terminal resource string
    RTStr = 'pdna://192.168.100.5/dev1/MILB1';    
    rtPort = UeiDaq.MIL1553Port();
    rtFilter = UeiDaq.MIL1553FilterEntry();
   

    %Create a session
    MIL1553Session = UeiDaq.Session();
    
    bwPort = MIL1553Session.CreateMIL1553Port(BWStr,MIL1553PortCoupling.Transformer,MIL1553PortOpMode.BusController);
    
    %BW Tx Bus
    bwPort.SetTxBus(MIL1553PortActiveBus.A);
    %Rx Bus
    bwPort.SetRxBus(MIL1553PortActiveBus.A);
    
    rtPort = MIL1553Session.CreateMIL1553Port(RTStr,MIL1553PortCoupling.Transformer,MIL1553PortOpMode.RemoteTerminal);
    
    %RT Tx Bus
    rtPort.SetTxBus(MIL1553PortActiveBus.A);
    %RT Bus
    rtPort.SetRxBus(MIL1553PortActiveBus.A);
    
    MIL1553Session.ConfigureTimingForMessagingIO(1,0.1);
    MIL1553Session.GetTiming().SetTimeout(10);
    MIL1553Session.Start();
    
    bcWriter = MIL1553Writer(MIL1553Session.GetDataStream(),0);
    bcReader = MIL1553Reader(MIL1553Session.GetDataStream(),0);
    
    rtWriter = MIL1553Writer(MIL1553Session.GetDataStream(),1);        
    rtReader = MIL1553Reader(MIL1553Session.GetDataStream(),1);
           
    startRt = NET.createArray('System.Int32',1);
    startSa = NET.createArray('System.Int32',1);
    wordCount = NET.createArray('System.Int32',1);
 
    
    startRt(1) = 1;
    startSa(1) = 2;
    wordCount(1) = 4;
    %------------------------------------------------------------
    % Create MIL-1553 frames used to send commands from BC to RT
    % and receive replies from RT to BC
    rtFrame = UeiDaq.MIL1553RTFrame(startRt(1),startSa(1),0,wordCount(1));    
    
    inRtFrm = NET.createArray('UeiDaq.MIL1553RTFrame',1);
    inRtFrm(1) = rtFrame;
    
    outRtFrm = NET.createArray('UeiDaq.MIL1553RTFrame',1);
    outRtFrm(1) = rtFrame;
    %-----------------------------------------------------------
    
    rtPort.ClearFilterEntries();
    
    rtFilter.Set(MIL1553FilterType.ByRt, startRt(1), startSa(1));
    
    rtFilter.EnableCommands(1, 1, 1);
    rtPort.AddFilterEntry(rtFilter);
    rtPort.EnableFilter(true);
    
    %-----------------------------------------------------------
    % Configure bus controller port
    % we will need three types of frames for BC: 
    %  *BCCB Data 
    %  *BCCB Status 
    %  *BCCB Scheduler (one minor and one major)
    schedMajorFrame = UeiDaq.MIL1553BCSchedFrame(MIL1553BCFrameType.Major);
    major = NET.createArray('UeiDaq.MIL1553BCSchedFrame',1);
    major(1) = schedMajorFrame;
    
    schedMinorFrame = UeiDaq.MIL1553BCSchedFrame(MIL1553BCFrameType.Minor);
    minor = NET.createArray('UeiDaq.MIL1553BCSchedFrame',1);
    minor(1) = schedMinorFrame;
        
    %-----------------------------------------------------------
    fdata = NET.createArray('UeiDaq.MIL1553BCCBDataFrame[]',2);
    fdata(1) =  NET.createArray('UeiDaq.MIL1553BCCBDataFrame',1);  
    fdata(2) = NET.createArray('UeiDaq.MIL1553BCCBDataFrame',1);  
    
    
    fdata(1,1) = UeiDaq.MIL1553BCCBDataFrame(0,0,0);
    fdata(2,1) = UeiDaq.MIL1553BCCBDataFrame(0,1,0);
    
     
    fstatus = NET.createArray('UeiDaq.MIL1553BCCBStatusFrame[]',2);   
    fstatus(1) =  NET.createArray('UeiDaq.MIL1553BCCBStatusFrame',1);  
    fstatus(2) = NET.createArray('UeiDaq.MIL1553BCCBStatusFrame',1);  
    
    fstatus(1,1) = UeiDaq.MIL1553BCCBStatusFrame(0,0,0);
    fstatus(2,1) = UeiDaq.MIL1553BCCBStatusFrame(0,1,0);   

    %-----------------------------------------------------------
    %fill major frame
               
    major(1).AddMajorEntry(0, MIL1553BCMajorFlags.Enable);
    bcWriter.WriteBCSched(major);
    
     % fill minor frame - one for send and one for receive
    
    minor(1).AddMinorEntry(MIL1553BCMinorFlags.Enable);     
    minor(1).AddMinorEntry(MIL1553BCMinorFlags.Enable);     
    bcWriter.WriteBCSched(minor);
    
       % fill BCCB for this minor frame
    fdata(1,1).SetCommand(MIL1553CommandType.BCRT, startRt(1), startSa(1), wordCount(1));
    fdata(1,1).SetCommandBus(MIL1553PortActiveBus.A);  
    fdata(1,1).SetCommandDelay(100);           
    fdata(1,1).SetRetryOptions(3, MIL1553BCRetryType.Reenable);
                        
    data16 = NET.createArray('System.UInt16',wordCount(1));
    sRt = NET.createArray('System.UInt16',1);
    sRt(1) = 1;
        
    for i=1:wordCount(1)
        data16(i) = 4112 + sRt(1) + cast(i,'double');
    end
      
    
    fdata(1,1).CopyRxData(data16);
    
    bcWriter.WriteBCCBData(fdata(1));
     
    fdata(2,1).SetCommand(MIL1553CommandType.BCRT, startRt(1), startSa(1), wordCount(1));
    fdata(2,1).SetCommandBus(MIL1553PortActiveBus.A);  
    fdata(2,1).SetCommandDelay(100);           
    fdata(2,1).SetRetryOptions(3, MIL1553BCRetryType.Reenable);
                                                             
    bcWriter.WriteBCCBData(fdata(2));
     
             
    for i=1:wordCount(1)
        data16(i) = 1 + cast(i,'double');
    end
      
    outRtFrm(1).CopyData(data16);
    rtWriter.WriteRT(outRtFrm);
    
            
    % Start Bus Controller
       
    bcControl = NET.createArray('UeiDaq.MIL1553BCControlFrame',1);
    bcControl(1) = UeiDaq.MIL1553BCControlFrame();
    bcControl(1).Operation = MIL1553BCOps.Enable;
    bcControl(1).MajorClock = 1.0;
    bcControl(1).MinorClock = 10.0;
    bcWriter.WriteBCControl(bcControl);
            

    
    
catch e
    e.message
    %Clean up the session
    MIL1553Session.Stop();     
    MIL1553Session.Dispose();
    return;
 end
 
 
 try
     count = 0;
     numFramesToRead = 10;

    
     frames = NET.createArray('UeiDaq.MIL1553BMFrame',1);        
    
     f = UeiDaq.MIL1553BMFrame();
      
     while (count < 1000)

         % Update Data in RT transmit area. This is the data the RT sends in response
         % to a RT-BC command
         for i=1:wordCount(1)
            data16(i) = count + cast(i,'double');
         end                  
         outRtFrm(1).CopyData(data16);        
         rtWriter.WriteRT(outRtFrm);
         % Read data received by RT during last BC-RT command("receive" area)
         inRtFrm = rtReader.ReadRT(1,startRt(1),startSa(1),0,wordCount(1));
         
         
         inRtStr = sprintf('%d%s%s%s%s', count,': ',char(inRtFrm(1).GetFrameStr()),' Data: ',char(inRtFrm(1).GetDataStr()));                  
         fprintf('\nData Received by RT in last BC-RT command ("receive" area)\n');
         fprintf('%s\n',inRtStr);
         
                    
         % Update Data in BC receive area. This is the data the BC sends along
         % with the BC-RT command
            
         for i=1:wordCount(1)
            data16(i) = 4128 + count + cast(i,'double');
         end
         
         fdata(1,1).CopyRxData(data16);
         bcWriter.WriteBCCBData(fdata(1));
         
         % Read data stored in BC "Transmit" command
          fstatus(2) = bcReader.ReadBCCBStatus(1, 0, 0, 1);
          bccbStatusStr = sprintf('%d%s%s', count,': ',char(fstatus(2,1).GetBcDataStr(wordCount(1))));                  
          fprintf('\nData stored in BC "Transmit" command\n');
          fprintf('%s\n',bccbStatusStr);
         
          % read Bus Monitor messages received on RT port
          frames = rtReader.ReadBM(numFramesToRead);

          for i = 1:frames.Length
              f = frames(i);
              fprintf('\nData Received in Bus Monitor area\n');
              frameStr = sprintf('%s%s',char(f.GetBmMessageStr()),char(f.GetBmDataStrDataOnly()));                                                  
              fprintf('%s\n',frameStr);
          end          
         
          pause(1);
          count = count + 1;
     end
     
     %cleaning up and close the session
     MIL1553Session.Stop();     
     MIL1553Session.Dispose();
 catch e
    e.message
    %Clean up the session
    MIL1553Session.Stop();     
    MIL1553Session.Dispose();
    return;
end