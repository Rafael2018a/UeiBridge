function varargout = singleai_matlab_ui(varargin)
% SINGLEAI_MATLAB_UI MATLAB code for singleai_matlab_ui.fig
%      SINGLEAI_MATLAB_UI, by itself, creates a new SINGLEAI_MATLAB_UI or raises the existing
%      singleton*.
%
%      H = SINGLEAI_MATLAB_UI returns the handle to a new SINGLEAI_MATLAB_UI or the handle to
%      the existing singleton*.
%
%      SINGLEAI_MATLAB_UI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SINGLEAI_MATLAB_UI.M with the given input arguments.
%
%      SINGLEAI_MATLAB_UI('Property','Value',...) creates a new SINGLEAI_MATLAB_UI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before singleai_matlab_ui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to singleai_matlab_ui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help singleai_matlab_ui

% Last Modified by GUIDE v2.5 10-Aug-2016 06:03:29

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @singleai_matlab_ui_OpeningFcn, ...
                   'gui_OutputFcn',  @singleai_matlab_ui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before singleai_matlab_ui is made visible.
function singleai_matlab_ui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to singleai_matlab_ui (see VARARGIN)

% Choose default command line output for singleai_matlab_ui
handles.output = hObject;

% Get location of ueidaq framework .NET assembly
ueidaqroot='';
try
    % this will only work on a 64-bit PC
    ueidaqroot = winqueryreg('HKEY_LOCAL_MACHINE','Software\Wow6432Node\UEI\OOP', 'InstallDir');
    ueidaqroot = [ueidaqroot '\DotNet\DotNet4\x64'];
catch e
    try
        % if 64-bit registry failed it is a 32-bit PC
        ueidaqroot = winqueryreg('HKEY_LOCAL_MACHINE','Software\UEI\OOP','InstallDir');
        ueidaqroot = [ueidaqroot '\DotNet\DotNet4'];
    catch e
        % no ueidaq registry was found, must be a developer PC
        ueidaqroot = 'c:\uei_svn\software\framework\output';
    end
end
NET.addAssembly([ueidaqroot '\UeiDaqDNet.dll']);
    
import UeiDaq.*;

% Create timer to continuaouly acquire data in the background
handles.timer = timer('ExecutionMode', 'fixedRate', 'Period', 0.1, ...
                      'Timerfcn', {@updatePlot_TimerCallback, hObject});
                  
% Update handles structure
guidata(hObject, handles);

set(findall(gcf, 'tag', 'startbutton'), 'enable', 'on');
set(findall(gcf, 'tag', 'stopbutton'), 'enable', 'off');

% This sets up the initial plot - only do when we are invisible
% so window can get raised using singleai_matlab_ui.
if strcmp(get(hObject,'Visible'),'off')
    plot(rand(5));
end

% UIWAIT makes singleai_matlab_ui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = singleai_matlab_ui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function airesourcetext_Callback(hObject, eventdata, handles)
% hObject    handle to airesourcetext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of airesourcetext as text
%        str2double(get(hObject,'String')) returns contents of airesourcetext as a double


% --- Executes during object creation, after setting all properties.
function airesourcetext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to airesourcetext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in startbutton.
function startbutton_Callback(hObject, eventdata, handles)
% hObject    handle to startbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

try
    % allocate session object and store in handles to make it available
    % to all other callbacks
    handles.session = UeiDaq.Session();
    
    resource = get(handles.airesourcetext, 'String');
    handles.session.CreateAIChannel(resource, -10.0, 10.0, UeiDaq.AIChannelInputMode.Differential);
    handles.session.ConfigureTimingForSimpleIO();
    
    % Allocate a buffer to plot acquired scans
    handles.plotBuffer = zeros(100, handles.session.GetNumberOfChannels());
    handles.plotOffset = 1;
    
    handles.reader = UeiDaq.AnalogScaledReader(handles.session.GetDataStream());
    handles.session.Start();
    
    % Save changes to handles structure
    guidata(hObject, handles);
    
    start(handles.timer);
    
    set(findall(gcf, 'tag', 'startbutton'), 'enable', 'off');
    set(findall(gcf, 'tag', 'stopbutton'), 'enable', 'on');
catch e
    msgbox(e.message, 'Error Start', 'error');
    handles.session.Dispose()
end


% --- Executes on button press in stopbutton.
function stopbutton_Callback(hObject, eventdata, handles)
% hObject    handle to stopbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
stop(handles.timer);
handles.session.Stop();
handles.session.Dispose();
set(findall(gcf, 'tag', 'startbutton'), 'enable', 'on');
set(findall(gcf, 'tag', 'stopbutton'), 'enable', 'off');


function updatePlot_TimerCallback(hObject, eventData, hFigure)
try
    handles = guidata(hFigure);
    
    netData = handles.reader.ReadSingleScan();     
    % Convert .NET array to matlab array
    mlData = double(netData);
    
    % insert latest acquired scan in the plot buffer
    handles.plotBuffer(handles.plotOffset,:) = mlData;
    
    plot(handles.axes1, handles.plotBuffer);
    
    if handles.plotOffset >= length(handles.plotBuffer)
        % shift data in plot buffer to simulate a strip chart
        handles.plotBuffer = circshift(handles.plotBuffer, -1, 1);
    else
        handles.plotOffset = handles.plotOffset+1;
    end
    
    % Save changes to handles structure
    guidata(hFigure, handles);
catch e
    stop(handles.timer);
    msgbox(e.message, 'Error', 'error');
    handles.session.Dispose()
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

stop(handles.timer);
if isfield(handles, 'session')
    handles.session.Dispose()
end

delete(handles.figure1)

% Hint: delete(hObject) closes the figure
delete(hObject);
