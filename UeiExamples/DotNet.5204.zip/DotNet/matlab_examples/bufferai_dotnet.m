% Get location of UEIDAQ .NET assembly from registry
ueidaqPath = '';
try
    % this will only work on 64-bit PC
    ueidaqPath = winqueryreg('HKEY_LOCAL_MACHINE','Software\Wow6432Node\UEI\OOP', 'InstallDir');
    ueidaqPath = [ueidaqPath '\DotNet\DotNet4\x64\UeiDaqDNet.dll'];
catch e
    try
        % if not, maybe it is a 32-bit PC
        ueidaqPath = winqueryreg('HKEY_LOCAL_MACHINE','Software\UEI\OOP', 'InstallDir');   
        ueidaqPath = [ueidaqPath '\DotNet\DotNet4\UeiDaqDNet.dll'];
    catch e
        % no registry, must be a UEI developper PC
        ueidaqPath = 'C:\UEI_SVN\Software\Framework\output\Debug\UeiDaqDNet.dll';
    end
end

try
    NET.addAssembly(ueidaqPath); 
    import UeiDaq.*;
    
    scanRate = 1000.0;
    numScans = 200;

    % Create and configure UeiDaq framework session
    aiss = UeiDaq.Session();
    aiss.CreateAIChannel('pdna://192.168.100.3/Dev0/Ai0:3', -10.0, 10.0, UeiDaq.AIChannelInputMode.Differential);
    aiss.ConfigureTimingForBufferedIO(numScans, UeiDaq.TimingClockSource.Internal, ....
                                      scanRate, UeiDaq.DigitalEdge.Rising, ...
                                      UeiDaq.TimingDuration.Continuous);

    % Create a reader object to read data synchronously.
    reader = UeiDaq.AnalogScaledReader(aiss.GetDataStream());

    % Start session and read first buffer
    aiss.Start();
    
    netData = reader.ReadMultipleScans(numScans);
    
    % Convert .NET array to matlab array and plot
    mlData = double(netData);
    plot(mlData);

    aiss.Dispose();
catch e
  error(e.message);
end