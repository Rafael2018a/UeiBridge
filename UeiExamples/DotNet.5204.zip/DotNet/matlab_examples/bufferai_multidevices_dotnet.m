% Get location of UEIDAQ .NET assembly from registry
ueidaqPath = '';
try
    % this will only work on 64-bit PC
    ueidaqPath = winqueryreg('HKEY_LOCAL_MACHINE','Software\Wow6432Node\UEI\OOP', 'InstallDir');
    ueidaqPath = [ueidaqPath '\DotNet\DotNet4\x64\UeiDaqDNet.dll'];
catch e
    try
        % if not, maybe it is a 32-bit PC
        ueidaqPath = winqueryreg('HKEY_LOCAL_MACHINE','Software\UEI\OOP', 'InstallDir');
        ueidaqPath = [ueidaqPath '\DotNet\DotNet4\UeiDaqDNet.dll'];
    catch e
        % no registry, must be a UEI developper PC
        ueidaqPath = 'C:\UEI_SVN\Software\Framework\output\Debug\UeiDaqDNet.dll';
    end
end

try
    NET.addAssembly(ueidaqPath);
    import UeiDaq.*;
    
    
    %Set up resource strings for each device in your cube/RACK
    resourceStr = NET.createArray('System.String',4);
    resourceStr(1) = 'pdna://192.168.100.2/dev0/ai0:3';
    resourceStr(2) = 'pdna://192.168.100.2/dev1/ai0:3';
    resourceStr(3) = 'pdna://192.168.100.4/dev0/ai0:3';
    resourceStr(4) = 'pdna://192.168.100.4/dev1/ai0:3';
    
    
    scanRate = 1000.0;
    numScans = scanRate * 30; % acquring 30 seconds worth of data
    
    
    aiSs = NET.createArray('UeiDaq.Session', resourceStr.Length);
    
    aiReader = NET.createArray('UeiDaq.AnalogScaledReader', resourceStr.Length);
       
    for i=1:resourceStr.Length
        
        aiSs(i) = UeiDaq.Session();
        
        fprintf('Device %d - String: %s\n',i, char(resourceStr(i)));
        
        aiSs(i).CreateAIChannel(resourceStr(i), -10.0, 10.0, UeiDaq.AIChannelInputMode.Differential);
        
        aiSs(i).ConfigureTimingForBufferedIO(numScans, UeiDaq.TimingClockSource.Internal,scanRate, UeiDaq.DigitalEdge.Rising,UeiDaq.TimingDuration.Continuous);
        
        aiSs(i).GetDataStream().SetNumberOfFrames(10);
        
        aiReader(i) = UeiDaq.AnalogScaledReader(aiSs(i).GetDataStream());
        
        aiSs(i).GetTiming().SetTimeout(numScans/scanRate * 10000);
        
        aiSs(i).Start();
        
    end
    
        
    for i=1:resourceStr.Length
               
        fprintf('Acquiring ...');
        data = aiReader(i).ReadMultipleScans(numScans);
        
        for k=1:aiSs(i).GetNumberOfChannels()
            
            for j = 1:numScans
                
                fprintf('Device %d - Channel: %d - Scan Number: %d - Data: %f\n',i,k,j, data(j,k));

            end
            
        end
        
    end    
    
    %clean up all open sessions
    for i=1:resourceStr.Length
        aiSs(i).Stop();
        aiSs(i).Dispose();
    end
catch e
    error(e.message);
    %clean up all open sessions incase the program ended abruptly.
    for i=1:resourceStr.Length
        aiSs(i).Stop();
        aiSs(i).Dispose();
    end
end