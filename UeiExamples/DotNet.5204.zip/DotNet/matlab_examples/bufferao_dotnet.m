
try
    resourceStr = 'pdna://192.168.100.7/dev2/ao0,1';
    frequency = 10000;
    numScansPerChan = 5000;
    numFrames = 8;
       
    NET.addAssembly('C:\Program Files (x86)\UEI\Framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');
    
    import UeiDaq.*;
    
    %create a session
    aoSs = UeiDaq.Session();
    
    aoSs.CreateAOChannel(resourceStr,-10.0,10.0);
         
    aoSs.ConfigureTimingForBufferedIO(numScansPerChan,UeiDaq.TimingClockSource.Internal,Frequency,UeiDaq.DigitalEdge.Rising,UeiDaq.TimingDuration.Continuous);
      
    writer = UeiDaq.AnalogScaledWriter(aoSs.GetDataStream());   
    
    %Get number of channels
    numChannels = aoSs.GetNumberOfChannels();
       
    % Prepare some data to generate
    ramp = linspace(0,2*pi,numScansPerChan);

    % Each channel will contain a sine wave of 10V amplitude
    data = [];

    for i=1:numChannels 
        data = [data 10*sin(ramp)']
    end

    plot(data);
    
    % convert matlab array to .NET data
    netData = NET.convertArray(data,'System.Double', [numScansPerChan, numChannels]);
    writer.WriteMultipleScans(numScansPerChan,netData);
    
    aoSs.Start();
    
    % Wait for 1 period
    pause(0.5+numScansPerChan/frequency)
    
    %Clean up the session
    aoSs.Stop();
    aoSs.Dispose();
catch e
  e.message
end