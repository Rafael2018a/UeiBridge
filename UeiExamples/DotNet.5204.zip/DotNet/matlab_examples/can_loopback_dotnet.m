%Load Ueidaq .NET assembly
NET.addAssembly('c:\program files (x86)\uei\framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');
    
import UeiDaq.*;     
 
numBytesToRead = 10;
%------------------------------------------------------------------
%this block is setting up the Serial Input session
try
    %CAN ports Resource String
    canResourceStr = 'simu://192.168.100.2/dev6/CAN0,1';    
    
    %create a session and attach CAN ports  
    canSs = UeiDaq.Session();        
    canSs.CreateCANPort(canResourceStr,...
                       CANPortSpeed.BitsPerSecond250K,...
                       CANFrameFormat.Extended,...
                       CANPortMode.Normal,...
                       hex2dec('FFFFFFFF'),...
                       0);
        
    canSs.ConfigureTimingForMessagingIO(1, 0.0);
    canSs.GetTiming().SetTimeout(500);
    
    % Cerate reader to read from port 0
    canReader = UeiDaq.CANReader(canSs.GetDataStream(),0);
    % Create writer to write to port 1
    canWriter = UeiDaq.CANWriter(canSs.GetDataStream(),1);
 
    canSs.Start();
catch e
    e.message
    %Clean up the session
    canSs.Dispose();
    return;
end
 

try 
    % Send CAN frame out of first port
    frame = UeiDaq.CANFrame();
    frame.Id = 102;
    frame.Type = CANFrameType.DataFrame;
    frame.DataSize = 8;
    frame.Data = NET.createArray('System.Byte', 8);
    txFrames = NET.createArray('UeiDaq.CANFrame', 1);
    txFrames(1) = frame;
    canWriter.Write(txFrames);
    
    rxFrames = canReader.Read(10);
    
    disp(['Received ', num2str(rxFrames.Length), ' frames']); 
    for i=1:rxFrames.Length 
        fprintf('  Frame %d : ID=%d Data=[', i, rxFrames(i).Id);
        for d=1:rxFrames(i).Data.Length
            fprintf('%d ', rxFrames(i).Data(d));
        end
        fprintf(']\n');
    end
    
    canSs.Dispose();
catch e 
    e.message
    %Clean up the session
    canSs.Dispose();
    return;
end
