try
    %Load UeiDaq .NET assembly
    NET.addAssembly('c:\program files (x86)\uei\framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');

    resourceStr = 'pdna://192.168.100.7/dev2/ao0,1';
    
    import UeiDaq.*;
    
    %create a session
    aoSs = UeiDaq.Session();
    
    aoSs.CreateAOChannel(resourceStr,-10.0,10.0);

    
    writer = UeiDaq.AnalogScaledWriter(aoSs.GetDataStream());
       
    aoSs.ConfigureTimingForSimpleIO();
    
    %Get number of channels
    numChannels = aoSs.GetNumberOfChannels();
   
    aoSs.Start();

    data = zeros(1, numChannels);
    %Output 10V on all selected channels
    for i=1:numChannels,
        data(i) = 10;     
    end
    writer.WriteSingleScan(data);         
    
    pause(0.5)
    
    %Output 0V on all selected channels
    for i=1:chanNum,
        data(i) = 0;           
    end
    writer.WriteSingleScan(data);  

    %Clean up the session
    aoSs.Stop();
    aoSs.Dispose();
    
catch e
  e.message
end