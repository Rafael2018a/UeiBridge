    
%Load UeiDaq .NET assembly
NET.addAssembly('c:\program files (x86)\uei\framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');
    
import UeiDaq.*;            
numIterations = 128;

%------------------------------------------------------------------
%this block is setting up the Digital Output session
try
    %Digital Input Resource String
    diResourceStr = 'pdna://192.168.100.3/dev0/di0';    
    
    %create a session for digital input subsystem  
    diSs = UeiDaq.Session();
    
    %configure digital input session    
    diSs.CreateDIChannel(diResourceStr);    
    diSs.ConfigureTimingForSimpleIO();
    
    diReader = UeiDaq.DigitalReader(diSs.GetDataStream());        
    diSs.Start();
catch e
    e.message
    %Clean up the session
    diSs.Stop();
    diSs.Dispose();
    
    % Exit to prompt
    return;
end

%------------------------------------------------------------------
%this block is setting up the Digital Input session
try
    %Digital Output Resource String
    doResourceStr = 'pdna://192.168.100.3/dev0/do0';
    
    %create a session for digital output subsystem
    doSs = UeiDaq.Session();
    
    %configure digital output session   
    doSs.CreateDOChannel(doResourceStr);
    doSs.ConfigureTimingForSimpleIO();

    doWriter = UeiDaq.DigitalWriter(doSs.GetDataStream());

    doSs.Start(); 
catch e
    e.message
    %Clean up the session
    doSs.Stop();
    doSs.Dispose();  
    
    % Exit to prompt
    return
end

%------------------------------------------------------------------

%Allocate doData buffer

doData = zeros(1,'uint32');

try
    for i=1:numIterations
        %writing to do lines
        doData = i; 
        
        % Write DO channel(s)
        doWriter.WriteSingleScanUInt32(doData);    
        
        pause(0.5);

        %read the DI channel(s)               
        diData= diReader.ReadSingleScanUInt32();    
              
        %convert .NET data to MATLAB double
        mldiData = double(diData);
        
        %convert mlData from double to binary string       
        diStr = dec2bin(mldiData(1,1));
        fprintf('DI Value: %s\n', diStr);
    end
catch e
    e.message  
end

%Clean up the sessions
diSs.Stop();
diSs.Dispose();
doSs.Stop();
doSs.Dispose();
