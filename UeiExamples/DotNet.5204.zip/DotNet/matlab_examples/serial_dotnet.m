%Load Ueidaq .NET assembly
NET.addAssembly('c:\program files (x86)\uei\framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');
    
import UeiDaq.*;     
 
numBytesToRead = 10;
%------------------------------------------------------------------
%this block is setting up the Serial Input session
try
    %Digital Input Resource String
    slResourceStr = 'pdna://192.168.100.2/dev7/COM0,1';    
    
    %create a session for digital input subsystem  
    slSs = UeiDaq.Session();
    %configure digital input session
        
    slSs.CreateSerialPort(slResourceStr,SerialPortMode.RS232,SerialPortSpeed.BitsPerSecond57600,SerialPortDataBits.DataBits8,SerialPortParity.None,SerialPortStopBits.StopBits1,'');
        
    slSs.ConfigureTimingForMessagingIO(100, 100.0);
    slSs.GetTiming().SetTimeout(500);
    
    %port 0 will be configured as serial input
    siReader = UeiDaq.SerialReader(slSs.GetDataStream(),0);
    %port 1 will be configured as serial output
    soWriter = UeiDaq.SerialWriter(slSs.GetDataStream(),1);
 
    slSs.Start();
catch e
    e.message
    %Clean up the session
    slSs.Dispose();
    return;
end
 

try 
    soWriter.Write(uint8('Hello UEI'));
    rxData = siReader.Read(10);
    
    disp(['received data:',uint8(rxData)]); 
    
    slSs.Dispose();
catch e 
    e.message
    %Clean up the session
    slSs.Dispose();
    return;
end
