%Load UeiDaq .NET assembly

NET.addAssembly('c:\program files (x86)\uei\framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');
    
import UeiDaq.*;      
numIterations = 10000;
try
    quadEncoderResourceStr = 'pdna://192.168.100.3/dev1/ci0';


    quadEncoderSs = UeiDaq.Session();

    %-------------------------------------
    % Available encoding types:
    % QuadratureDecodingType.FourX
    % QuadratureDecodingType.TwoX
    % QuadratureDecodingType.OneX
    %-------------------------------------
    % Available ZeroIndex phases:
    % QuadratureZeroIndexPhase.AHighBHigh
    % QuadratureZeroIndexPhase.AHighBLow
    % QuadratureZeroIndexPhase.ALowBHigh
    % QuadratureZeroIndexPhase.ALowBLow
    % QuadratureZeroIndexPhase.ZHigh
    %-------------------------------------
    % For demo purpose, we use QuadratureDecodingType.OneX, and QuadratureZeroIndexPhase.ZHigh
    quadEncoderSs.CreateQuadratureEncoderChannel(quadEncoderResourceStr,0,QuadratureDecodingType.OneX,true,QuadratureZeroIndexPhase.ZHigh);
    quadEncoderSs.ConfigureTimingForSimpleIO();
    quadEncoderReader = UeiDaq.CounterReader(quadEncoderSs.GetDataStream());
    quadEncoderSs.Start()

    for i=1:numIterations %we are only reading 10000 times, change this accordingly.
        ciData = quadEncoderReader.ReadSingleScanUInt32();
           
        %convert .NET data to MATLAB double
        mlciData = double(ciData);
        fprintf('Quad Value: %f\n',mlciData);
        
        %Take the mlciData, insert in equation to translate this number
        %to angular speed, revolutions per minute, etc...
    end
     
    %Clean up the session
    quadEncoderSs.Stop();
    quadEncoderSs.Dispose();
catch e
    e.message
    
    %Clean up the session
    quadEncoderSs.Stop();
    quadEncoderSs.Dispose();
end
