try
    NET.addAssembly('c:\program files (x86)\uei\framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');

    import UeiDaq.*;
    
    scanRate = 10000.0;
    numScans = 1000

    % Create and configure UeiDaq framework session
    aiss = Session();
    aiss.CreateAccelChannel('pdna://192.168.100.2/Dev4/Ai0:3', -10.0, 10.0, 1, 4, UeiDaq.Coupling.AC, true);
    aiss.ConfigureTimingForBufferedIO(numScans, UeiDaq.TimingClockSource.Internal, scanRate, UeiDaq.DigitalEdge.Rising, UeiDaq.TimingDuration.Continuous);

    % Select PLL as clock source
    aiss.GetTiming().SetScanClockSourceSignal('PLL');
    
    % Create a reader object to read data synchronously.
    reader = UeiDaq.AnalogScaledReader(aiss.GetDataStream());

    % Start session and read first buffer
    aiss.Start();
    
    netData = reader.ReadMultipleScans(numScans);
    
    % Convert .NET array to matlab array and plot
    mlData = double(netData);
    subplot(2,1,1), plot(mlData);
    subplot(2,1,2), plot(abs(fft(mlData)));

    aiss.Dispose();
catch e
  e.message
end