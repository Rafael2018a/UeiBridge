%Load Ueidaq .NET assembly
NET.addAssembly('c:\program files (x86)\uei\framework\DotNet\DotNet4\x64\UeiDaqDNet.dll');
    
import UeiDaq.*;     
 try
    %Bus Monitor resource string
    BMStr = 'pdna://192.168.100.6/dev4/MILB0';   
    bmPort = UeiDaq.MIL1553Port();
      

    %Create a session
    MIL1553Session = UeiDaq.Session();
    
    bmPort = MIL1553Session.CreateMIL1553Port(BMStr,MIL1553PortCoupling.Transformer,MIL1553PortOpMode.BusMonitor);
    
    %BM Tx Bus
    bmPort.SetTxBus(MIL1553PortActiveBus.A);
    %Rx Bus
    bmPort.SetRxBus(MIL1553PortActiveBus.A);
        
    MIL1553Session.ConfigureTimingForMessagingIO(1,0.1);
    MIL1553Session.GetTiming().SetTimeout(10);
    MIL1553Session.Start();
    
    bmReader = MIL1553Reader(MIL1553Session.GetDataStream(),0);    
    
catch e
    e.message
    %Clean up the session
    MIL1553Session.Stop();     
    MIL1553Session.Dispose();
    return;
 end
 
 
 try
     count = 0;
     numFramesToRead = 100;
      
     while (count < 100)         
          % read Bus Monitor messages received on port
          bmFrames = bmReader.ReadBM(numFramesToRead);
          
          fprintf("Received %d frames\n", bmFrames.Length);

          for i = 1:bmFrames.Length
              f = bmFrames(i);
              fprintf('\nText Representation:\n');
              frameStr = sprintf('%s%s',char(f.GetBmMessageStr()),char(f.GetBmDataStrDataOnly()));                                                  
              fprintf('%s\n',frameStr);
              
              fprintf('Matlab Representation:\n');
              disp(['Command=' char(f.Command)]);
              disp(['RT=' num2str(f.Rt) ' SA=' num2str(f.Sa)]);
              disp(['WC=' num2str(f.WordCount) ' SZ=' num2str(f.DataSize)]);
              % convert frame data words to a matlab array of uint32
              data = uint32(f.BmData);
              % first word contains the command, RT, SA and word count
              % (already accessible as properties of BmData)
              disp(['Raw command = ' dec2hex(data(1))]);
              % Display data words starting at offset 2 (after command
              % word)
              disp('Data words = ');
              disp(dec2hex(bitand(data(2:f.WordCount+1),hex2dec('FFFF'))));
          end          
         
          %pause(0.1);
          count = count + 1;
     end
     
     %cleaning up and close the session
     MIL1553Session.Stop();     
     MIL1553Session.Dispose();
 catch e
    e.message
    %Clean up the session
    MIL1553Session.Stop();     
    MIL1553Session.Dispose();
    return;
end