#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}

typedef struct _doSessionParams
{
   SessionHandle session;
   int portWidth;
   int numPorts;
   uInt16* datas;   // for devices with 16 or less output lines per port
   uInt32* datal;   // for devices with more than 16 output lines per port
   int iterations;
} tDOSessionParams;

tDOSessionParams G_SessionParams;

void OnEvent(tUeiEvent event, void *param)
{
   int p;

   do
   {
      if(event == UeiEventFrameDone)
      {
         if(G_SessionParams.datas != NULL)
         {
            for(p=0; p<G_SessionParams.numPorts; p++)
            {
               G_SessionParams.datas[p] = 1 << (G_SessionParams.iterations % G_SessionParams.portWidth);
            }
            printf("Digital output 0x%x\n", G_SessionParams.datas[0]);
            UeiDaqErrChk(UeiDaqWriteRawData16Async(G_SessionParams.session, G_SessionParams.numPorts, G_SessionParams.datas, OnEvent)); 
         }
         else
         {  
            for(p=0; p<G_SessionParams.numPorts; p++)
            {
               G_SessionParams.datal[p] = 1 << (G_SessionParams.iterations % G_SessionParams.portWidth);
            }
            printf("Digital output 0x%x\n", G_SessionParams.datal[0]);
            UeiDaqErrChk(UeiDaqWriteRawData32Async(G_SessionParams.session, G_SessionParams.numPorts, G_SessionParams.datal, OnEvent));
         }

         Sleep(100);

         G_SessionParams.iterations++;
      }

      if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)param;
         fprintf(stderr, "Error %d occurred: %s\n", error, UeiDaqTranslateError(error));
      }
   }
   while(0);
}

int main(int argc, char* argv[])
{
   DeviceHandle dev;
   int p;

   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&G_SessionParams.session));

      G_SessionParams.iterations = 0;
      
      // Create 1 digital input channel on a powerdaq board
      // From now on the session is DI only
      UeiDaqErrChk(UeiDaqCreateDOChannel(G_SessionParams.session, "pdna://192.168.15.201/Dev4/do0"));
      
      // Configure timing for simple point by point operations
      UeiDaqErrChk(UeiDaqConfigureTimingForSimpleIO(G_SessionParams.session));

      // Retrive the number of ports psecified in the resource string
      UeiDaqErrChk(UeiDaqGetNumberOfChannels(G_SessionParams.session, &G_SessionParams.numPorts));

      // get the handle on the device to be able to retrieve the
      // port width
      UeiDaqErrChk(UeiDaqGetDeviceHandle(G_SessionParams.session, &dev));

      UeiDaqErrChk(UeiDaqGetDeviceDOResolution(dev, &G_SessionParams.portWidth));

      // Digital data will be stored in a 16 bits or 32 bits integer buffer
      // depending on the width of the port
      // let's allocate a buffer big enough to hold one value for each configured port
      if(G_SessionParams.portWidth <= 16)
      {
         G_SessionParams.datas = (uInt16*)malloc(G_SessionParams.numPorts*sizeof(uInt16));
         G_SessionParams.datal = NULL;
      }
      else
      {
         G_SessionParams.datas = NULL;
         G_SessionParams.datal = (uInt32*)malloc(G_SessionParams.numPorts*sizeof(uInt32));
      }
      
      // Start the session
      UeiDaqErrChk(UeiDaqStartSession(G_SessionParams.session));

      // Begin asynchronous operation
      if(G_SessionParams.datas != NULL)
      {
         for(p=0; p<G_SessionParams.numPorts; p++)
         {
            G_SessionParams.datas[p] = 0;
         }
         UeiDaqErrChk(UeiDaqWriteRawData16Async(G_SessionParams.session, G_SessionParams.numPorts, G_SessionParams.datas, OnEvent)); 
      }
      else
      {  
         for(p=0; p<G_SessionParams.numPorts; p++)
         {
            G_SessionParams.datal[p] = 0;
         }
         UeiDaqErrChk(UeiDaqWriteRawData32Async(G_SessionParams.session, G_SessionParams.numPorts, G_SessionParams.datal, OnEvent));
      }
      
      // Wait until 100 values have been read
      while(G_SessionParams.iterations < 100)
      {
         
      }

      UeiDaqErrChk(UeiDaqStopSession(G_SessionParams.session));
      
      UeiDaqErrChk(UeiDaqCloseSession(G_SessionParams.session));
   }
   while(0);

   if(G_SessionParams.datas != NULL)
   {
      free(G_SessionParams.datas);
   }
   if(G_SessionParams.datal != NULL)
   {
      free(G_SessionParams.datal);
   }

   return 0;
}

