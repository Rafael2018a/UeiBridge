#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}


int main(int argc, char* argv[])
{
   SessionHandle mySs;

   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&mySs));

      // Create one counter output channel on a powerdaq board to generate a pulse train 
      // using the internal clock as a reference. Each pulse will be low for 50000 ticks and
      // high for another 50000 ticks
      // From now on the session is CI only
      UeiDaqErrChk(UeiDaqCreateCOChannel(mySs, "pwrdaq://Dev0/co2", UeiCounterSourceClock, UeiCounterModeGeneratePulseTrain, 
                           UeiCounterGateInternal, 50000, 50000, 1, 0));

      UeiDaqErrChk(UeiDaqConfigureTimingForSimpleIO(mySs));

      // Start generating the pulse train for one second
      UeiDaqErrChk(UeiDaqStartSession(mySs));

      printf("Press 'Enter' to stop generating the pulse train\n");
      getchar();

      UeiDaqErrChk(UeiDaqStopSession(mySs));
      UeiDaqErrChk(UeiDaqCloseSession(mySs));
   } while(0);

   return 0;
}