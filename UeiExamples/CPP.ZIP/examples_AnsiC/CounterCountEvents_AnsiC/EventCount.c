#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}



int main(int argc, char* argv[])
{
   SessionHandle mySs;
   unsigned short countedEvents;
   int i;

   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&mySs));

      // Create one counter input channel on a powerdaq board to count digital 
      // events applied on the input of the counter.
      // From now on the session is CI only
      UeiDaqErrChk(UeiDaqCreateCIChannel(mySs, "pwrdaq://Dev0/ci0", 
                           UeiCounterSourceInput, 
                           UeiCounterModeCountEvents, 
                           UeiCounterGateInternal,
                           1,
                           0));

      UeiDaqErrChk(UeiDaqConfigureTimingForSimpleIO(mySs));

      // Start counting
      UeiDaqErrChk(UeiDaqStartSession(mySs));

      // Read 100 valuies and return
      for(i=0; i<100; i++)
      {
         UeiDaqErrChk(UeiDaqReadRawData16(mySs, 0, 1, &countedEvents));
         printf("Read %d events\n", countedEvents);
      }

      UeiDaqErrChk(UeiDaqStopSession(mySs));
      UeiDaqErrChk(UeiDaqCloseSession(mySs));
   } while(0);

   return 0;
}
