#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}

void GenerateSinWave(double* pBuffer, int nbChannels, int nbSamplePerChannel, int iteration)
{
   int i, j;
   int amplitude = (iteration % 10 + 1);

   for(i=0; i<nbSamplePerChannel; i++)
   {
      for(j=0; j<nbChannels; j++)
      {
         pBuffer[i*nbChannels+j] = amplitude * sin(2*3.1415*(j+1)*i/nbSamplePerChannel);
      }
   }
}

int main(int argc, char* argv[])
{
   int i;
   SessionHandle mySs;
   double data[200];

   // This do/while loop is here to allow us to break out of the normal code flow
   // when an error occurrs 
   do
   {
      UeiDaqErrChk(UeiDaqCreateSession(&mySs));

      // Create 2 analog output channels on a powerdaq board
      // From now on the session is AO only
      UeiDaqErrChk(UeiDaqCreateAOChannel(mySs, "simu://Dev0/ao0:1", -10.0, 10.0));

      UeiDaqErrChk(UeiDaqConfigureTimingForSimpleIO(mySs));

      GenerateSinWave(data, 2, 100, 0);

      // Generates all points in the buffer
      for(i=0; i<100; i++)
      {
         printf("Generating scan %d\n", i);
         UeiDaqErrChk(UeiDaqWriteScaledData(mySs, -1, 1, &data[i*2]));
      }

      UeiDaqErrChk(UeiDaqStopSession(mySs));
      UeiDaqErrChk(UeiDaqCloseSession(mySs));
   }
   while(0);

   return 0;
}