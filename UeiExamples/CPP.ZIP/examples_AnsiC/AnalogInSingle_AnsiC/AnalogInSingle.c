#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}


int main(int argc, char* argv[])
{
   int i, j;
   int numChannels;
   SessionHandle mySs;
   double data[800];

   // This do/while loop is here to allow us to break out of the normal code flow
   // when an error occurrs 
   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&mySs));

      // Create 8 analog input channels on a powerdaq board
      // From now on the session is AI only
      UeiDaqErrChk(UeiDaqCreateAIChannel(mySs, "simu://Dev0/ai0:7", -10.0, 10.0, UeiAIChannelInputModeDifferential));

      // By default the timing object is configured for simple I/O so
      // no need to do anything here.
      UeiDaqErrChk(UeiDaqConfigureTimingForSimpleIO(mySs));

      UeiDaqErrChk(UeiDaqGetNumberOfChannels(mySs, &numChannels));

      UeiDaqErrChk(UeiDaqStartSession(mySs));

      // Read 100 scans
      for(i=0; i<100; i++)
      {
         UeiDaqErrChk(UeiDaqReadScaledData(mySs, -1, 1, &data[i*numChannels]));
         for(j=0; j<numChannels; j++)
         {
            printf("Ch%d=%f  ", j, data[i*numChannels+j]);
         }
         printf("\n");
      }

      UeiDaqErrChk(UeiDaqStopSession(mySs));
      UeiDaqErrChk(UeiDaqCloseSession(mySs));
   }
   while(0);

   return 0;
}