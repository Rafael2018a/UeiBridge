#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}

int main(int argc, char* argv[])
{
   SessionHandle diSs;
   SessionHandle doSs;
   int i;

   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&diSs));
      UeiDaqErrChk(UeiDaqCreateSession(&doSs));

      // Create 1 digital input channel on a powerdaq board
      UeiDaqErrChk(UeiDaqCreateDIChannel(diSs, "pwrdaq://Dev0/di0"));
      UeiDaqErrChk(UeiDaqCreateDOChannel(doSs, "pwrdaq://Dev0/do0"));

      UeiDaqErrChk(UeiDaqConfigureTimingForSimpleIO(diSs));
      UeiDaqErrChk(UeiDaqConfigureTimingForSimpleIO(doSs));
      
      // Start the session
      UeiDaqErrChk(UeiDaqStartSession(diSs));
      UeiDaqErrChk(UeiDaqStartSession(doSs));

      // Read 100 events
      for(i=0; i<100; i++)
      {
         unsigned short data[1];
         UeiDaqErrChk(UeiDaqReadRawData16(diSs, 0, 1, data));
         printf("Digital input 0x%x\n", data[0]);

         data[0] = i;
         UeiDaqErrChk(UeiDaqWriteRawData16(doSs, 0, 1, data));
      }

      UeiDaqErrChk(UeiDaqStopSession(diSs));
      UeiDaqErrChk(UeiDaqStopSession(doSs));

      UeiDaqErrChk(UeiDaqCloseSession(diSs));
      UeiDaqErrChk(UeiDaqCloseSession(doSs));
   }
   while(0);

   return 0;
}

