#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}

SessionHandle mySs;
unsigned short data[1];

void OnEvent(tUeiEvent event, void *param)
{
   do
   {
      if(event == UeiEventDigitalIn)
      {
         printf("Received Digital event 0x%x\n", data[0]);
         UeiDaqErrChk(UeiDaqReadRawData16Async(mySs, 1, data, OnEvent));
      }

      if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)param;
         fprintf(stderr, "Error %d occurred: %s\n", error, UeiDaqTranslateError(error));
      }
   } while(0);
};


int main(int argc, char* argv[])
{
   ChannelHandle ch0;
   TimingHandle timing;

   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&mySs));

      // Create 1 digital input channel on a powerdaq board
      // From now on the session is DI only
      UeiDaqErrChk(UeiDaqCreateDIChannel(mySs, "simu://Dev0/di0"));

      // Get the handle of first channel
      UeiDaqErrChk(UeiDaqGetChannelHandle(mySs, 0, &ch0));
      
      // Set the mask on the channel to respond to events on every digital lines
      UeiDaqErrChk(UeiDaqSetDIChannelEdgeMask(ch0, 0xFFFF, UeiDigitalEdgeRising));

      // Configure the session to detect signal change on line 0 of the first port
      // in the port list, the session will detect edges continuously.
      // The data stream will store 1000 readings at a time
      UeiDaqErrChk(UeiDaqConfigureTimingForEdgeDetection(mySs, UeiDigitalEdgeRising));

      // Get a handle on the timing object
      UeiDaqErrChk(UeiDaqGetTimingHandle(mySs, &timing));
      UeiDaqErrChk(UeiDaqSetTimingTimeout(timing, 5000));
      
      // Start the session
      UeiDaqErrChk(UeiDaqStartSession(mySs));

      UeiDaqErrChk(UeiDaqReadRawData16Async(mySs, 1, data, OnEvent));

      // Keep running until the session is stopped
      printf("Press 'Enter' to stop the program\n");
      getchar();

      UeiDaqErrChk(UeiDaqStopSession(mySs));
      UeiDaqErrChk(UeiDaqCloseSession(mySs));

   } while(0);

   return 0;
}

