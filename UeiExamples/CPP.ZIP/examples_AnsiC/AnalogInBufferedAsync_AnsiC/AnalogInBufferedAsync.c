#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}

double data[8000];
SessionHandle mySs;

void OnEvent(tUeiEvent event, void *param)
{
   int i, numChannels;

   do
   {
      if(event == UeiEventFrameDone)
      {
         UeiDaqErrChk(UeiDaqGetNumberOfChannels(mySs, &numChannels));

         // data contains latest samples, do something with it...
         for(i=0; i<numChannels;i++)
         {
            printf("ch %d = %fV", i, data[i]);
         }
         printf("\n");

         // rearm the session to generate the next asynchronous event
         // when enough new samples will be ready
         UeiDaqErrChk(UeiDaqReadScaledDataAsync(mySs, 1000, data, OnEvent));
      }

      if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)param;
         fprintf(stderr, "Error %d occurred: %s\n", error, UeiDaqTranslateError(error));
      }
   }
   while(0);
}

int main(int argc, char* argv[])
{
   // This do/while loop is here to allow us to break out of the normal code flow
   // when an error occurrs 
   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&mySs));

      // Create 8 analog input channels on a powerdaq board
      // From now on the session is AI only
      UeiDaqErrChk(UeiDaqCreateAIChannel(mySs, "simu://Dev0/ai0:7", -10.0, 10.0, UeiAIChannelInputModeDifferential));

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      UeiDaqErrChk(UeiDaqConfigureTimingForBufferedIO(mySs, 1000, UeiTimingClockSourceInternal, 10000.0, UeiDigitalEdgeRising, UeiTimingDurationContinuous));

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as the reader starts reading data.
      UeiDaqErrChk(UeiDaqStartSession(mySs));
      
      // Arm the reader so that it acquire and store samples in the
      // data array and call our handler once the array is full
      UeiDaqErrChk(UeiDaqReadScaledDataAsync(mySs, 1000, data, OnEvent));
      
      // Wait for the user to press the enter key to end the program
      printf("Press 'Enter' to stop the acquisition\n");
      getchar();

      UeiDaqErrChk(UeiDaqStopSession(mySs));

      UeiDaqErrChk(UeiDaqCloseSession(mySs));
   }
   while(0);

   return 0;
}