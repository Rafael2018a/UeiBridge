#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}


int main(int argc, char* argv[])
{
   DeviceHandle dev;
   char enumFormat[] = "pdna://192.168.15.201/Dev%d";
   char devResource[64]; 
   char devName[64];
   char serial[64];
   int size;
   int data;
   int deviceId = 0;

   // Enumerate through all the devices and list their capabilities
   while(1)
   {
      sprintf(devResource, enumFormat, deviceId);
      UeiDaqErrChk(UeiDaqEnumDevice(devResource, &dev));

      size = 64;
      UeiDaqErrChk(UeiDaqGetDeviceName(dev, devName, &size));
      size = 64;
      UeiDaqErrChk(UeiDaqGetDeviceSerialNumber(dev, serial, &size));

      printf("device %d: %s (#%s)\n", deviceId, devName, serial);

      UeiDaqErrChk(UeiDaqGetDeviceNumberOfAIDifferentialChannels(dev, &data));
      if(data > 0)
      {
         printf("Analog Input Subsystem:\n");
         printf("Number of Analog input channels = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceMaxAIRate(dev, &data));
         printf("Maximum sampling frequency = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceAIResolution(dev, &data));
         printf("Resolution = %d\n", data);
         
         printf("\n"); 
      }

      UeiDaqErrChk(UeiDaqGetDeviceNumberOfAOChannels(dev, &data));
      if(data > 0)
      {
         printf("Analog Output Subsystem:\n");
         printf("Number of Analog output channels = %d\n", data);
         
         UeiDaqErrChk(UeiDaqGetDeviceMaxAORate(dev, &data));
         printf("Maximum generation frequency = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceAOResolution(dev, &data));
         printf("Resolution = %d\n", data);
         
         printf("\n");        
      }

      UeiDaqErrChk(UeiDaqGetDeviceNumberOfDIChannels(dev, &data));
      if(data > 0)
      {
         printf("Digital Input Subsystem:\n");
         printf("Number of digital input ports = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceMaxDIRate(dev, &data));
         printf("Maximum sampling frequency = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceDIResolution(dev, &data));
         printf("Port width = %d\n", data);
         
         printf("\n"); 
      }

      UeiDaqErrChk(UeiDaqGetDeviceNumberOfDOChannels(dev, &data));
      if(data > 0)
      {
         printf("Digital Output Subsystem:\n");
         printf("Number of digital output ports = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceMaxDORate(dev, &data));
         printf("Maximum generation frequency = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceDOResolution(dev, &data));
         printf("Port width = %d\n", data);
         
         printf("\n"); 
      }

      UeiDaqErrChk(UeiDaqGetDeviceNumberOfCIChannels(dev, &data));
      if(data > 0)
      {
         printf("Counter Input Subsystem:\n");
         printf("Number of counters = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceMaxCIRate(dev, &data));
         printf("Counter clock frequency = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceCIResolution(dev, &data));
         printf("Resolution = %d\n", data);
         
         printf("\n"); 
      }

      UeiDaqErrChk(UeiDaqGetDeviceNumberOfCOChannels(dev, &data));
      if(data > 0)
      {
         printf("Timer Output Subsystem:\n");
         printf("Number of timers = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceMaxCORate(dev, &data));
         printf("Timer clock frequency = %d\n", data);

         UeiDaqErrChk(UeiDaqGetDeviceCOResolution(dev, &data));
         printf("Resolution = %d\n", data);
         
         printf("\n"); 
      }

      UeiDaqErrChk(UeiDaqCloseDevice(dev));
      deviceId++;
   };

   return 0;
}