#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}

int main(int argc, char* argv[])
{
   SessionHandle ciSs;
   DeviceHandle dev;
   int counterResolution;
   int numCounters;
   uInt16* datas = NULL;   // for devices with 16 bit or less counter resolution 
   uInt32* datal = NULL;   // for devices with counter resolution greater than 16 bit
   int i;

   do
   {
      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&ciSs));

      // Create one counter input channel 
      UeiDaqErrChk(UeiDaqCreateCIChannel(ciSs, "pdna://192.168.15.200/Dev5/ci0", 
                           UeiCounterSourceInput, 
                           UeiCounterModeMeasurePeriod, 
                           UeiCounterGateInternal,
                           1,
                           0));

      UeiDaqErrChk(UeiDaqConfigureTimingForSimpleIO(ciSs));

      // Retrieve the number of ports psecified in the resource string
      UeiDaqErrChk(UeiDaqGetNumberOfChannels(ciSs, &numCounters));

      // Configure debounce filter for each channel. 
      // This step is optional and is only needed if your signal 
      // is noisy and you want to filter out unwanted spikes
      for(i=0; i<numCounters; i++)
      {
         ChannelHandle ch;

         UeiDaqErrChk(UeiDaqGetChannelHandle(ciSs, i, &ch));

         // filter out pulses shorter than 1ms
         UeiDaqErrChk(UeiDaqSetCIMinimumSourcePulseWidth(ch, 20.0));
      }

      // get the handle on the device to be able to retrieve the
      // port width
      UeiDaqErrChk(UeiDaqGetDeviceHandle(ciSs, &dev));

      UeiDaqErrChk(UeiDaqGetDeviceCIResolution(dev, &counterResolution));

      // Measurement data will be stored in a 16 bits or 32 bits integer buffer
      // depending on the counter resolution
      // let's allocate a buffer big enough to hold one value for each configured port
      if(counterResolution <= 16)
      {
         datas = (uInt16*)malloc(numCounters*sizeof(uInt16));
      }
      else
      {
         datal = (uInt32*)malloc(numCounters*sizeof(uInt32));
      }

      // Start counting
      UeiDaqErrChk(UeiDaqStartSession(ciSs));

      // Read period 100 times
      for(i=0; i<100; i++)
      {
         double period; 

         if(datas != NULL)
         {
            UeiDaqErrChk(UeiDaqReadRawData16(ciSs, 0, numCounters, datas));
            printf("Counter 0: period=%d ticks\n", datas[0]);
         }
         else
         {
            UeiDaqErrChk(UeiDaqReadRawData32(ciSs, 0, numCounters, datal));

            // Use counter base frequency to convert reading to secs.
            // CT-601 base frequency is 66MHz
            period = datal[0]/66000000.0;

            printf("Counter 0: period=%d ticks, %f secs, %f Hz\n", datal[0], period, 1.0/period);
         }
      }

      UeiDaqErrChk(UeiDaqStopSession(ciSs));
      UeiDaqErrChk(UeiDaqCloseSession(ciSs));
   } while(0);

   if(datas != NULL)
   {
      free(datas);
   }
   if(datal != NULL)
   {
      free(datal);
   }

   return 0;
}