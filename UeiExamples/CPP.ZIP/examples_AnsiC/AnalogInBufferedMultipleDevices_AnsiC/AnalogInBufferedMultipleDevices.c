#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "UeiDaq.h"

// Macro used to handle errors
#define UeiDaqErrChk(functionCall) {int error; if((error=functionCall)!=UEIDAQ_SUCCESS) { \
                                    fprintf(stderr, "Error %d occurred at line %d. (%s)\n", error, __LINE__, UeiDaqTranslateError(error)); \
                                    break;}}
//Set for 2 devices
#define SCOUNT 2

int main(int argc, char* argv[])
{
   char clockSync;
   SessionHandle mySs[SCOUNT];
   int i, numChannels;
   double data[SCOUNT][8000];
   char resAddr[SCOUNT][100];
   tUeiTimingClockSource clockSource;

   int deviceNum;
    
   
   clockSync = 0; //sets clock synchronization on (1) or off (0)
   clockSource = UeiTimingClockSourceInternal;


   //Buffer overflow potential, use with caution
   strcpy(resAddr[0],"simu://Dev0/Ai0:6");
   strcpy(resAddr[1],"pdna://192.168.100.2/Dev1/Ai0:1");

   // This do/while loop is here to allow us to break out of the normal code flow
   // when an error occurrs 
   do
   {

            //Set Clock source dependent on synchronization choice
      for (deviceNum=0; deviceNum < SCOUNT; deviceNum++)
      {
         if ( (deviceNum!=0) && (clockSync==1) )
            clockSource = UeiTimingClockSourceExternal;
         else 
            clockSource = UeiTimingClockSourceInternal;

      // Create Session object
      UeiDaqErrChk(UeiDaqCreateSession(&mySs[deviceNum]));

      // Create analog input channels on a powerdaq board
      // From now on the session is AI only
      UeiDaqErrChk(UeiDaqCreateAIChannel(mySs[deviceNum], resAddr[deviceNum], -10.0, 10.0, UeiAIChannelInputModeDifferential));

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      UeiDaqErrChk(UeiDaqConfigureTimingForBufferedIO(mySs[deviceNum], 1000, UeiTimingClockSourceInternal, 2000.0, UeiDigitalEdgeRising, UeiTimingDurationSingleShot));

      // The internal frame size and number of frames is automatically calculated
      // We can override it with the following function calls
      //UeiDaqErrChk(UeiDaqSetDataStreamNumberOfScans(mySs, 500));
      //UeiDaqErrChk(UeiDaqSetDataStreamNumberOfFrames(mySs, 8));
      }


      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as we start reading data.
      //Start slave devices first (reverse order)
      for (deviceNum=(SCOUNT-1); deviceNum >= 0; deviceNum--)
         UeiDaqErrChk(UeiDaqStartSession(mySs[deviceNum]));


      for (deviceNum=0; deviceNum < SCOUNT; deviceNum++)
       {
           UeiDaqErrChk(UeiDaqReadScaledData(mySs[deviceNum], -1, 1000, data[deviceNum]));

           UeiDaqErrChk(UeiDaqGetNumberOfChannels(mySs[deviceNum], &numChannels));
           for(i=0; i<numChannels;i++)
           {
               printf("Dev: %d, ch %d = %fV", deviceNum, i, data[deviceNum][i]);
           }

           printf("\n");

           UeiDaqErrChk(UeiDaqStopSession(mySs[deviceNum]));
           UeiDaqErrChk(UeiDaqCloseSession(mySs[deviceNum]));
      }
   }
   while(0);

   return 0;
}