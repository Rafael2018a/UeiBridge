// DigitalInMFCDlg.h : header file
//

#pragma once

#include "LabGraph.h"
#include "UeiDaq.h"

using namespace UeiDaq;

// CDigitalInMFCDlg dialog
class CDigitalInMFCDlg : public CDialog, IUeiEventListener
{
// Construction
public:
	CDigitalInMFCDlg(CWnd* pParent = NULL);	// standard constructor

   virtual void OnEvent(tUeiEvent event, void *param);

// Dialog Data
	enum { IDD = IDD_DIGITALINMFC_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

   CEdit    m_Resources;
   int      m_NbScans;
   int      m_Frequency;
   CButton  m_Duration;
   CButton  m_Trigger;
   CLabGraph m_Graph;

   CEdit    m_TotalScans;
   CEdit    m_AvailScans;
   CEdit    m_Log;

private:
   CUeiSession m_Session;
   CUeiDigitalReader *m_pReader;
   uInt16 *m_pData;

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
   afx_msg void OnBnClickedGo();
   afx_msg void OnBnClickedStop();
   afx_msg LRESULT OnUpdateStatus(WPARAM wParam, LPARAM lParam);
	afx_msg void OnDestroy();
};
