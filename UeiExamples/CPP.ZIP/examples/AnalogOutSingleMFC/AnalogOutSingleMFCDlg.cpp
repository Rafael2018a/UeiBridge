// AnalogOutSingleMFCDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AnalogOutSingleMFC.h"
#include "AnalogOutSingleMFCDlg.h"
#include ".\analogoutsinglemfcdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CAnalogOutSingleMFCDlg dialog



CAnalogOutSingleMFCDlg::CAnalogOutSingleMFCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAnalogOutSingleMFCDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAnalogOutSingleMFCDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   DDX_Control(pDX, IDC_RESOURCE, m_Resource);
   DDX_Control(pDX, IDC_FREQUENCY, m_Frequency);
   DDX_Control(pDX, IDC_LOG, m_Log);
   DDX_Control(pDX, IDC_VALUE, m_Value);
   DDX_Control(pDX, IDC_VALUE_TEXT, m_ValueText);
   DDX_Control(pDX, IDC_CHANNEL, m_SelChannel);
}

BEGIN_MESSAGE_MAP(CAnalogOutSingleMFCDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
   ON_BN_CLICKED(ID_GO, OnBnClickedGo)
   ON_BN_CLICKED(ID_STOP, OnBnClickedStop)
   ON_WM_TIMER()
   ON_WM_HSCROLL()
END_MESSAGE_MAP()


// CAnalogOutSingleMFCDlg message handlers

BOOL CAnalogOutSingleMFCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_Resource.SetWindowText("simu://Dev0/Ao0:3");
   m_Frequency.SetWindowText("50");
   m_Value.SetRange(-1000, 1000);
   m_Value.SetTicFreq(100);
   m_Value.SetPos(0);
   m_ValueText.SetWindowText("0.0");
   
   GetDlgItem(ID_GO)->EnableWindow(TRUE);
   GetDlgItem(ID_STOP)->EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CAnalogOutSingleMFCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAnalogOutSingleMFCDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAnalogOutSingleMFCDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CAnalogOutSingleMFCDlg::OnBnClickedGo()
{
   try
   {
      CString resstr;
      m_SelChannel.ResetContent();
      m_Resource.GetWindowText(resstr);
      
      m_Session.CreateAOChannel(LPCSTR(resstr), -10.0, 10.0);

      for(int i=0; i<m_Session.GetNumberOfChannels(); i++)
      {
         CString ch;
         ch.Format("Channel %d", m_Session.GetChannel(i)->GetIndex());
         m_SelChannel.AddString(ch);
      }

      m_SelChannel.SetCurSel(0);

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      m_Session.ConfigureTimingForSimpleIO();

      // Create a reader object to read data synchronously.
      m_pWriter = new CUeiAnalogScaledWriter(m_Session.GetDataStream());

      // allocate buffer to receive acquired data
      m_pData = (double*)malloc(m_Session.GetNumberOfChannels() * sizeof(double));
      for(i=0; i<m_Session.GetNumberOfChannels(); i++)
         m_pData[i] = 0.0;

      m_Session.Start();

      CString loopstr;
      m_Frequency.GetWindowText(loopstr);
      m_TimerID = SetTimer(1, 1000/atoi(LPCSTR(loopstr)), NULL);   

      GetDlgItem(ID_GO)->EnableWindow(FALSE);
      GetDlgItem(ID_STOP)->EnableWindow(TRUE);
      m_Log.SetWindowText("");
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("Go Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CAnalogOutSingleMFCDlg::OnTimer(UINT_PTR nIDEvent)
{
   CDialog::OnTimer(nIDEvent);

   try
   {     
      CString newVal;
      m_ValueText.GetWindowText(newVal);
      m_pData[m_SelChannel.GetCurSel()] = atof(LPCSTR(newVal));
      m_pWriter->WriteSingleScan(m_pData);
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("Timer Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CAnalogOutSingleMFCDlg::OnBnClickedStop()
{
   KillTimer(m_TimerID);

   try
   {
      m_Session.Stop();
      m_Session.CleanUp();

      delete m_pWriter;
      free(m_pData);

      GetDlgItem(ID_GO)->EnableWindow(TRUE);
      GetDlgItem(ID_STOP)->EnableWindow(FALSE);
   }
   catch(CUeiException e)
   {
      CString str;
      str.Format("Stop Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CAnalogOutSingleMFCDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
   if(pScrollBar == reinterpret_cast<CScrollBar*>(&m_Value))
   {
      CString str;
      str.Format("%.2f", m_Value.GetPos() / 100.0);
      m_ValueText.SetWindowText(str);
   }
}
