// AnalogOutSingleMFCDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "LabGraph.h"
#include "UeiDaq.h"

using namespace UeiDaq;

// CAnalogOutSingleMFCDlg dialog
class CAnalogOutSingleMFCDlg : public CDialog
{
// Construction
public:
	CAnalogOutSingleMFCDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_ANALOGOUTSINGLEMFC_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
   afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
   CEdit m_Resource;
   CEdit m_Frequency;
   CEdit m_Log;
   CEdit m_ValueText;
   CSliderCtrl m_Value;
   CComboBox m_SelChannel;

   afx_msg void OnBnClickedGo();
   afx_msg void OnBnClickedStop();
   afx_msg void OnTimer(UINT_PTR nIDEvent);

private:
   CUeiSession m_Session;
   CUeiAnalogScaledWriter *m_pWriter;
   double *m_pData;
   UINT_PTR m_TimerID;
};
