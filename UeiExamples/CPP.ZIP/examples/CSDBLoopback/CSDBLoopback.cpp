#include <windows.h>
#include <process.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

CUeiSession mySession;
int numMessagesPerFrame = 7;
int blockSize = 8;

// Read thread reads all messages within the frame
void ReadThread(void* param)
{
   CUeiCSDBReader *pReader = reinterpret_cast<CUeiCSDBReader*>(param);
   while(mySession.IsRunning())
   {
      tUeiCSDBMessage frame[10];
      Int32 numMessagesRead;
      try
      {
         // Read 10 frames at a time
         pReader->ReadFrame(10, frame, &numMessagesRead);

         for(int i=0; i<numMessagesRead; i++)
         {
            std::cout << "Received Message: Address=" << std::hex << (int)frame[i].address;
            std::cout << " data=[ ";
            for (int j=0; j < 8;j++)
            {
               std::cout << (int)frame[i].data[j] << " ";
            }
            std::cout << "]" << std::dec << std::endl;
         }

         Sleep(50);
      }
      catch(CUeiException& e)
      {
         // if error is timeout, notify user and keep listening for new frames
         if(e.GetError() == UEIDAQ_TIMEOUT_ERROR)
         {
            std::cout << "read timeout" << std::endl;
         }
         else
         {
            std::cout << "Error in ReadThread " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
            break;
         }
      }
   }
}

// write thread each updates message block by index one at a time
void WriteThread(void* param)
{
   int count = 0;
   try
   {
      CUeiCSDBWriter *pWriter = reinterpret_cast<CUeiCSDBWriter*>(param);
      while(mySession.IsRunning())
      {
         tUeiCSDBMessage messageBlock;

         messageBlock.address = (count++ % 255);
         messageBlock.status = 0;
         for (int i = 0; i < blockSize-2;; i++)
         {
            messageBlock.data[i] = (uInt8)count+1;
         }
         pWriter->WriteMessageByIndex((count%numMessagesPerFrame), &messageBlock);
         Sleep(10);
      }
   }
   catch(CUeiException& e)
   {
      std::cout << "Error in WriteThread " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }
}


// This example continuously sends CAN frames on port 0 and receives them on port 1
int main(int argc, char* argv[])
{
   try
   {
      mySession.CreateCSDBPort("pdna://192.168.100.3/Dev1/CSDB0,1",
                              50000,
                              1,
                              blockSize,
                              numMessagesPerFrame,
                              10,
                              200,
                              100000); 
      mySession.ConfigureTimingForMessagingIO(1, 0);
      mySession.GetTiming()->SetTimeout(1000);

      // Create a reader to read from port 1
      CUeiCSDBReader reader(mySession.GetDataStream(), 1);
      // Create a writer to write to port 0
      CUeiCSDBWriter writer(mySession.GetDataStream(), 0);

      mySession.Start();

      _beginthread(ReadThread, 0, &reader);
      _beginthread(WriteThread, 0, &writer);

      while(1)
      {
         std::string command;
         
         // Read next command from keyboard
         std::cin >> command;

         // if command is '.' exit program
         if(!command.compare("."))
         {
            break;
         }
      }

      mySession.CleanUp();
   }
   catch(CUeiException& e)
   {
      std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}