#include <windows.h>
#include <process.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

CUeiSession mySession;


// This example continuously sends ARINC-429 words on TX port 0 and receives them on port RX 0 and 1
int main(int argc, char* argv[])
{
    int i, ch, f;
    int numInputPorts;
    int numOutputPorts;
    int numWords = 12;

    try
    {
        mySession.CreateARINCInputPort("pdna://192.168.15.201/dev4/arx0,1", 
                                        UeiARINCBitsPerSecond100000,
                                        UeiARINCParityNone,
                                        false,
                                        0);
        numInputPorts = mySession.GetNumberOfChannels();

        mySession.CreateARINCOutputPort("pdna://192.168.15.201/dev4/atx0", 
                                         UeiARINCBitsPerSecond100000,
                                         UeiARINCParityNone);
        numOutputPorts = mySession.GetNumberOfChannels()-numInputPorts;

        mySession.ConfigureTimingForMessagingIO(1, 0);

        // Set timeout to a very low value to avoid blocking the program
        // if no words are received
        mySession.GetTiming()->SetTimeout(10);

        // Allocate one reader for each configured input port
        CUeiARINCReader** readers = new CUeiARINCReader*[numInputPorts];
        for(ch=0; ch<numInputPorts; ch++)
        {
            readers[ch] = new CUeiARINCReader(mySession.GetDataStream(), mySession.GetChannel(ch)->GetIndex());
        }

        // Allocate one writer for each configured output port
        CUeiARINCWriter** writers = new CUeiARINCWriter*[numOutputPorts];
        for(ch=0; ch<numOutputPorts; ch++)
        {
            writers[ch] = new CUeiARINCWriter(mySession.GetDataStream(), mySession.GetChannel(numInputPorts+ch)->GetIndex());
        }

        // Allocate buffer used to send and receive ARINC words
        tUeiARINCWord* words = new tUeiARINCWord[numWords];

        mySession.Start();

        for(i=0; i<100; i++)
        {
            for(ch=0; ch<numOutputPorts; ch++)
            {
                Int32 numWordsWritten;
                int port = mySession.GetChannel(numInputPorts+ch)->GetIndex();

                for(f=0; f<numWords; f++)
                {
                    words[f].Label = (i % 100) + ch;
                    words[f].Sdi = 1;
                    words[f].Ssm = 2;
                    words[f].Data = f;
                }   
                writers[ch]->Write(numWords, words, &numWordsWritten);

                std::cout << std::dec << " TX Port " << port << ": Wrote " << numWordsWritten << " words" << std::endl;
            }

            for(ch=0; ch<numInputPorts; ch++)
            {
                int port = mySession.GetChannel(ch)->GetIndex();
                Int32 numWordsRead;

                // Wrap Read in its own try/catch block to filter out 
                // timeout error
                try
                {
                    readers[ch]->Read(numWords, words, &numWordsRead);
                }
                catch(CUeiException& e)
                {
                    if(e.GetError() == UEIDAQ_TIMEOUT_ERROR)
                    {
                        continue;
                    }

                    // re-throw any other error, the main exception handler
                    // will process it
                    throw;
                }

                std::cout << std::dec << i << " RX Port " << port << ": Received " << numWordsRead << " words" << std::endl;

                for(f=0; f<numWordsRead; f++)
                {
                    std::cout << std::dec << i << "  RX Port " << port << ": Received word :" << 
                        " Label=" << std::hex << words[f].Label << std::dec << 
                        " Data=" << words[f].Data << 
                        " Sdi=" << words[f].Sdi <<
                        " Ssm=" << words[f].Ssm <<
                        " Parity=" << words[f].Parity << std::endl;
                }
            }
        }

        mySession.Stop();

        for(ch=0; ch<numInputPorts; ch++)
        {
            delete readers[ch];
        }
        delete[] readers;
        
        for(ch=0; ch<numOutputPorts; ch++)
        {
            delete writers[ch];
        }      
        delete[] writers;
        delete[] words;

        mySession.CleanUp();
    }
    catch(CUeiException& e)
    {
        std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
    }

    return 0;
}