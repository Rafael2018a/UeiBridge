#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

class CDigitalInListener : public IUeiEventListener
{
public:
   CDigitalInListener(CUeiSession* pSs):
      m_pSession(pSs),
      m_Datas(NULL),
      m_Datal(NULL),
      m_pReader(NULL),
      m_Iterations(0)
   {
      // Digital data will be stored in a 16 bits or 32 bits integer buffer
      // depending on the width of the port
      // let's allocate a buffer big enough to hold one value for each configured port
      if(m_pSession->GetDevice()->GetDIResolution() <= 16)
      {
         m_Datas = new uInt16[m_pSession->GetNumberOfChannels()];
      }
      else
      {
         m_Datal = new uInt32[m_pSession->GetNumberOfChannels()];
      }

      // Create a reader to read data asynchronously from the digital input ports.
      m_pReader = new CUeiDigitalReader(m_pSession->GetDataStream());
      // Add listener class to reader to get notified when data has been received
      m_pReader->AddEventListener(this);
   }

   ~CDigitalInListener()
   {
      if(m_Datas != NULL)
      {
         delete[] m_Datas;
      }
      if(m_Datal != NULL)
      {
         delete[] m_Datal;
      }

      delete m_pReader;
   }

   void Begin()
   {
      if(m_Datas != NULL)
      {
         m_pReader->ReadSingleScanAsync(m_Datas);
      }
      else
      {
         m_pReader->ReadSingleScanAsync(m_Datal);
      }
   }

   int GetIterations()
   {
      return m_Iterations;
   }

   void OnEvent(tUeiEvent event, void *param)
   {
      if(event == UeiEventFrameDone)
      {
         m_Iterations++;

         // Display data 
         if(m_Datas != NULL)
         {
            std::cout << "Digital input 0x" << std::hex << m_Datas[0] << std::endl;
         }
         else
         {
            std::cout << "Digital input 0x" << std::hex << m_Datal[0] << std::endl;
         }

         // Begin new asynchronous read
         Begin();
      }
      else if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)(uintptr_t)param;
         std::cout << "Error DI: " << CUeiException::TranslateError(error) << std::endl;
      }
   }
private:
   CUeiSession* m_pSession;
   CUeiDigitalReader* m_pReader;
   uInt16* m_Datas;   // for devices with 16 or less input lines per port
   uInt32* m_Datal;   // for devices with more than 16 input lines per port
   int m_Iterations;
};

int main(int argc, char* argv[])
{
   CUeiSession diSs;
   
   try
   {
      // Create 1 digital input channel on a powerdaq board
      // From now on the session is DI only
      diSs.CreateDIChannel("pdna://192.168.15.201/Dev3/di0");
      
      diSs.ConfigureTimingForSimpleIO();      

      // Create the asynchronous listener
      CDigitalInListener listener(&diSs);
      
      // Start the session
      diSs.Start();

      // Start receiving data asynchronously
      listener.Begin();
      
      // Wait until 100 values have been read
      while(listener.GetIterations() < 100)
      {
      }

      diSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}

