#include <windows.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   int ch;
   CUeiSession vrSs;
   CUeiVRReader** readers = NULL;
   
   try
   {
      // Create VR channels on a devcie capable of reading variable reluctance sensors
      // For example a VR-608
      vrSs.CreateVRChannel("pdna://192.168.100.3/Dev3/vr0,1,2,3", 
                           UeiVRModeCounterTimed);     
      vrSs.ConfigureTimingForSimpleIO();

      readers = new CUeiVRReader*[vrSs.GetNumberOfChannels()];

      // We need one reader per channel because they can be configured independantly
      // and return data at a different rate
      for(ch=0; ch<vrSs.GetNumberOfChannels(); ch++)
      {
         int channel = vrSs.GetChannel(ch)->GetIndex();

         readers[ch] = new CUeiVRReader(vrSs.GetDataStream(), channel);
      }

      vrSs.Start();

      // Read 100 values and return
      for (int i = 0; i<100; i++)
      {
          for (ch = 0; ch < vrSs.GetNumberOfChannels(); ch++)
          {
              int channel = vrSs.GetChannel(ch)->GetIndex();
              tUeiVRData vrData;

              readers[ch]->Read(1, &vrData, NULL);

              std::cout << "Ch" << channel << ": velocity= " << vrData.velocity << std::endl;
              std::cout << "Ch" << channel << ": position= " << vrData.position << std::endl;
              std::cout << "Ch" << channel << ": teeth count= " << vrData.teethCount << std::endl;
          }
      }

      vrSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   if(readers)
   {
      for(ch=0; ch<vrSs.GetNumberOfChannels(); ch++)
      {
         delete readers[ch];
      }
      delete[] readers;
   }

   return 0;
}



