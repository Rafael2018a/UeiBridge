#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

unsigned short data[1];

class CDigitalInEvent : public IUeiEventListener
{
public:
   CUeiDigitalReader* m_pReader;

   CDigitalInEvent(CUeiDigitalReader* pReader):m_pReader(pReader){}

   void OnEvent(tUeiEvent event, void *param)
   {
      if(event == UeiEventDigitalIn)
      {
         std::cout << "Received Digital event " << std::hex << data[0] << std::endl;
         m_pReader->ReadSingleScanAsync(data);
      }
      else if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)(uintptr_t)param;
         std::cout << "Error DI: " << CUeiException::TranslateError(error) << std::endl;
      }
   }
};


int main(int argc, char* argv[])
{
   CUeiSession mySs;


   try
   {
      // Create 1 digital input channel on a powerdaq board
      // From now on the session is DI only
      CUeiDIChannel* pChan = mySs.CreateDIChannel("simu://Dev0/di0");

      // Set the mask on the channel to respond to events on every digital lines
      pChan->SetEdgeMask(0xFFFF);

      // Configure the session to detect signal change on line 0 of the first port
      // in the port list, the session will detect edges continuously.
      // The data stream will store 1000 readings at a time
      mySs.ConfigureTimingForEdgeDetection(UeiDigitalEdgeRising);

      mySs.GetTiming()->SetTimeout(5000);

      // Create a reader and a listener object to receive events asynchronously.
      CUeiDigitalReader reader(mySs.GetDataStream());
      CDigitalInEvent eventListener(&reader);
      reader.AddEventListener(&eventListener);

      // Start the session
      mySs.Start();

      reader.ReadSingleScanAsync(data);

      // Keep running until the session is stopped
      std::cout << "Press 'Enter' to stop the program" << std::endl;
      getchar();

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}

