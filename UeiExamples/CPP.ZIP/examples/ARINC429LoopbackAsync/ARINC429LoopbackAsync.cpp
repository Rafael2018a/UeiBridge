#include <windows.h>
#include <process.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

class CARINC429Listener: public IUeiEventListener
{
public:
   CARINC429Listener(int port, CUeiARINCRawReader* reader):
      _enabled(false),
      _port(port),
      _reader(reader),
      _numWords(0),
      _rxWords(NULL)
   {
   }

   ~CARINC429Listener()
   {
      Stop();
      if(_rxWords != NULL)
      {
         delete[] _rxWords;
         _rxWords = NULL;
      }
   }

   void Start(int numWords)
   {
      _numWords = numWords;
      _rxWords = new uInt32[numWords];
      _reader->AddEventListener(this);
      _enabled = true;
      _rxCount = 0;
      _reader->ReadAsync(_numWords, _rxWords);
   }

   void Stop()
   {
      _enabled = false;      
   }

   void OnEvent(tUeiEvent event, void *param)
   {
      if(event == UeiEventFrameDone && _enabled)
      {
         try
         {
            Int32 numWordsRead = (Int32)(uintptr_t)param;
            
            std::cout << std::dec << " RX Port " << _port << ": Received " << numWordsRead << " words" << std::endl;

            for(int f=0; f<numWordsRead; f++)
            {
               // We are receiving raw ARINC words coded as 32-bit words
               // Extract fields here
               tUeiARINCWord arWord;
               arWord.Data = (_rxWords[f] >> 10) & 0x7ffff;
               arWord.Label = (_rxWords[f] & 0xff);
               arWord.Sdi = (_rxWords[f] >> 8) & 0x3;
               arWord.Ssm = (_rxWords[f] >> 29) & 0x3;
               arWord.Parity = (_rxWords[f] >> 31) & 0x1; 

               std::cout << std::dec << _rxCount+f << ":  RX Port " << _port << ": Received word :" << 
                  " Label=" << std::hex << arWord.Label << std::dec << 
                  " Data=" << arWord.Data << 
                  " Sdi=" << arWord.Sdi <<
                  " Ssm=" << arWord.Ssm <<
                  " Parity=" << arWord.Parity << std::endl;
            }

            _rxCount = _rxCount + numWordsRead;
            
            // Read more data
            _reader->ReadAsync(_numWords, _rxWords);
         }
         catch(CUeiException e)
         {
            std::cout << "ARINC429Loopback UeiEventFrameDone: Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
         }
      }

      if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)(uintptr_t)param;
         if(_enabled)
         {
            if(UEIDAQ_TIMEOUT_ERROR == error)
            {
               // Timeout is not a fatal error, it just means that hey was no incoming words received 
               std::cout << std::dec << " RX Port " << _port << ": timeout" << std::endl; 
               _reader->ReadAsync(_numWords, _rxWords);
            }
            else
            {
               std::cout << "ARINC429Loopback UeiEventError: Error " << std::hex << error << ": " << CUeiException::TranslateError(error) << std::endl;
            }
         }
      }
   }
private:
   bool _enabled;
   int _port;
   CUeiARINCRawReader* _reader;
   int _numWords;
   uInt32* _rxWords;
   int _rxCount;
};


// This example continuously sends ARINC-429 words on TX port 0 and receives them on port RX 0 and 1
int main(int argc, char* argv[])
{
    int i, ch, f;
    int numInputPorts;
    int numOutputPorts;
    int numWords = 12;
    CUeiSession mySession;
    
    try
    {
        mySession.CreateARINCInputPort("pdna://192.168.100.2/dev9/arx0,1", 
                                        UeiARINCBitsPerSecond100000,
                                        UeiARINCParityNone,
                                        false,
                                        0);
        numInputPorts = mySession.GetNumberOfChannels();

        mySession.CreateARINCOutputPort("pdna://192.168.100.2/dev9/atx0", 
                                         UeiARINCBitsPerSecond100000,
                                         UeiARINCParityNone);
        numOutputPorts = mySession.GetNumberOfChannels()-numInputPorts;

        mySession.ConfigureTimingForMessagingIO(1, 0);

        // Set timeout to a very low value to avoid blocking the program
        // if no words are received
        mySession.GetTiming()->SetTimeout(10);

        // Allocate one reader for each configured input port
        // Have to use raw reader for now. CUeiARINReader doesn't work in asynchronous mode
        CUeiARINCRawReader** readers = new CUeiARINCRawReader*[numInputPorts];
        CARINC429Listener** listeners = new CARINC429Listener*[numInputPorts];
        for(ch=0; ch<numInputPorts; ch++)
        {
            int rxPort = mySession.GetChannel(ch)->GetIndex();
            readers[ch] = new CUeiARINCRawReader(mySession.GetDataStream(), rxPort);
            listeners[ch] = new CARINC429Listener(rxPort, readers[ch]);
        }

        // Allocate one writer for each configured output port
        CUeiARINCWriter** writers = new CUeiARINCWriter*[numOutputPorts];
        for(ch=0; ch<numOutputPorts; ch++)
        {
            writers[ch] = new CUeiARINCWriter(mySession.GetDataStream(), mySession.GetChannel(numInputPorts+ch)->GetIndex());
        }

        // Allocate buffer used to send ARINC words
        tUeiARINCWord* words = new tUeiARINCWord[numWords];

        mySession.Start();

        // Start listening to all input ports asynchronously
        for(ch=0; ch<numInputPorts; ch++)
        {
           listeners[ch]->Start(numWords);
        }

        for(i=0; i<100; i++)
        {
            for(ch=0; ch<numOutputPorts; ch++)
            {
                Int32 numWordsWritten;
                int port = mySession.GetChannel(numInputPorts+ch)->GetIndex();

                for(f=0; f<numWords; f++)
                {
                    words[f].Label = (i % 100) + ch;
                    words[f].Sdi = 1;
                    words[f].Ssm = 2;
                    words[f].Data = f;
                }   
                writers[ch]->Write(numWords, words, &numWordsWritten);

                std::cout << std::dec << " TX Port " << port << ": Wrote " << numWordsWritten << " words" << std::endl;
            }
        }

        // Stop all listeners
        for(ch=0; ch<numInputPorts; ch++)
        {
            listeners[ch]->Stop();
        }

        // stop session
        mySession.Stop();

        for(ch=0; ch<numInputPorts; ch++)
        {
            delete readers[ch];
            delete listeners[ch];
        }
        delete[] readers;
        delete[] listeners;
        
        for(ch=0; ch<numOutputPorts; ch++)
        {
            delete writers[ch];
        }      
        delete[] writers;
        delete[] words;

        mySession.CleanUp();
    }
    catch(CUeiException& e)
    {
        std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
    }

    return 0;
}