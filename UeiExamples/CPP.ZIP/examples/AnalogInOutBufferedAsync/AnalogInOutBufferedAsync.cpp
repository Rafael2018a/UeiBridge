#include <windows.h>
#include <stdlib.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

CUeiSession aiSs;
CUeiSession aoSs;
double* pAiData = NULL;
double* pAoData = NULL;
CUeiAnalogScaledReader* reader = NULL;
CUeiAnalogScaledWriter* writer = NULL;

class CAnalogInEvent : public IUeiEventListener
{
   void OnEvent(tUeiEvent event, void *param)
   {
      static int count = 0;

      if(event == UeiEventFrameDone)
      {
         try
         {
            std::cout << "AI event #" << count++ << ": ";
            // data contains latest samples, do something with it...
            for(int i=0; i<aiSs.GetNumberOfChannels();i++)
               std::cout << "ch" << i << " = " << pAiData[i] << "V, ";
            std::cout << std::endl;

            // rearm the session to generate the next asynchronous event
            // once enough new samples are ready
            reader->ReadMultipleScansAsync(aiSs.GetDataStream()->GetNumberOfScans(), pAiData);

            // Copy Ai buffer to ao buffer if both sessions use the same number of channels
            if(aiSs.GetDataStream()->GetNumberOfScans() ==
               aoSs.GetDataStream()->GetNumberOfScans())
            {
               memcpy(pAoData, pAiData, aiSs.GetNumberOfChannels()*aiSs.GetDataStream()->GetNumberOfScans()*sizeof(double));
            }
         }
         catch(CUeiException e)
         {
            std::cout << "Error AI: " << e.GetErrorMessage() << std::endl;
         }
      }
      else if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)(uintptr_t)param;
         std::cout << "Error AI: " << CUeiException::TranslateError(error) << std::endl;
      }
   }
};

class CAnalogOutEvent : public IUeiEventListener
{
   void OnEvent(tUeiEvent event, void *param)
   {
      static int count = 0;

      if(event == UeiEventFrameDone)
      {
         try
         {
            std::cout << "AO event #" << count++ << ": " << std::endl;

            // rearm the session to generate the next asynchronous event
            // once enough new samples are ready
            writer->WriteMultipleScansAsync(aoSs.GetDataStream()->GetNumberOfScans(), pAoData);
         }
         catch(CUeiException e)
         {
            std::cout << "Error AO: " << e.GetErrorMessage() << std::endl;
         }
      }
      else if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)(uintptr_t)param;
         std::cout << "Error AO: " << CUeiException::TranslateError(error) << std::endl;
      }
   }
};

int main(int argc, char* argv[])
{
   CAnalogInEvent aiEventListener;
   CAnalogOutEvent aoEventListener;

   try
   {
      // Create analog input channels and add them to the AI session 
      aiSs.CreateAIChannel("pwrdaq://192.168.100.2/Dev1/ai0", -10.0, 10.0, UeiAIChannelInputModeSingleEnded);

      // Create analog output channels and add them to the AO session
      aoSs.CreateAOChannel("pwrdaq://192.168.100.2/Dev0/ao0", -10.0, 10.0);

      // Configure the sessions to acquire/generate 1000 scans timed by the internal clock
      aiSs.ConfigureTimingForBufferedIO(2000, UeiTimingClockSourceInternal, 10000.0, UeiDigitalEdgeRising, UeiTimingDurationContinuous);
      aoSs.ConfigureTimingForBufferedIO(2000, UeiTimingClockSourceInternal, 10000.0, UeiDigitalEdgeRising, UeiTimingDurationContinuous);

      // The internal frame size and number of frames is automatically calculated
      // We can override it with the following function calls
      // aiSs.GetDataStream()->SetFrameSize(500);
      // aiSs.GetDataStream()->SetNumberOfFrames(2);

      // Create a reader object to read data synchronously from the data stream.
      reader = new CUeiAnalogScaledReader(aiSs.GetDataStream());
      reader->AddEventListener(&aiEventListener);

      writer = new CUeiAnalogScaledWriter(aoSs.GetDataStream());
      writer->AddEventListener(&aoEventListener);

      // Allocate buffers to store current frame
      pAiData = new double[aiSs.GetNumberOfChannels()*aiSs.GetDataStream()->GetNumberOfScans()];
      pAoData = new double[aoSs.GetNumberOfChannels()*aoSs.GetDataStream()->GetNumberOfScans()];

      // Start the acquisition and generation sessions.
      aiSs.Start();
      aoSs.Start();

      writer->WriteMultipleScansAsync(aoSs.GetDataStream()->GetNumberOfScans(), pAoData);
      reader->ReadMultipleScansAsync(aiSs.GetDataStream()->GetNumberOfScans(), pAiData);

      // Wait 10 seconds then stop
      Sleep(10000);

      aiSs.Stop();
      aoSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   if(reader != NULL)
   {
      delete reader;
   }

   if(writer != NULL)
   {
      delete writer;
   }

   if(pAiData != NULL)
   {
      delete[] pAiData;
   }

   if(pAoData != NULL)
   {
      delete[] pAoData;
   }

   return 0;
}