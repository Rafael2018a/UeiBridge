// This examples shows how to perform continuous data acquisition and program
// the FIR filters on AI cards that support it: AI-205, AI-211, AI-217, AI-212, AI-218, AI-224
#include <stdlib.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession mySs;
   double* pData = NULL;
   int count = 0;

   try
   {
      // Create analog input channels 
      // From now on the session is AI only
      mySs.CreateAIChannel("pdna://192.168.100.7/Dev2/ai0:3", -10.0, 10.0, UeiAIChannelInputModeDifferential);

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      mySs.ConfigureTimingForBufferedIO(1000, UeiTimingClockSourceInternal, 10000.0, UeiDigitalEdgeRising, UeiTimingDurationContinuous);

      // The internal frame size and number of frames is automatically calculated
      // We can override it with the following function calls
      // mySs.GetDataStream()->SetFrameSize(500);
      // mySs.GetDataStream()->SetNumberOfFrames(2);

      // Create a reader object to read data synchronously from the data stream.
      CUeiAnalogScaledReader reader(mySs.GetDataStream());

      // Allocate buffer to store current frame
      pData = new double[mySs.GetNumberOfChannels()*mySs.GetDataStream()->GetNumberOfScans()*sizeof(double)];

      // Program the first stage of the FIR filter on every channels
      for(int ch=0; ch<mySs.GetNumberOfChannels(); ch++)
      {
         mySs.SetCustomProperty("channel", ch);
         int stage = 0;
         mySs.SetCustomProperty("stage", stage);
         int decimation = 1;
         mySs.SetCustomProperty("decimation", decimation);

         // Program an 8 taps low-pass filter with a cutoff frequency at 1000Hz
         double filter[] = {0.0293891800,0.0993324599,0.1655540998,0.2057242603,
            0.2057242603,0.1655540998,0.0993324599,0.0293891800};
         mySs.SetCustomProperty("tap", 8, filter);                                     
      }

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as the reader starts reading data.
      mySs.Start();

      // Acquire 20 frames then stop
      while(count < 20)
      {
         reader.ReadMultipleScans(mySs.GetDataStream()->GetNumberOfScans(), pData);

         for(int i=0; i<mySs.GetNumberOfChannels();i++)
            std::cout << "ch" << i << " = " << pData[i] << "V, ";

         std::cout << std::endl;
         count++;
      }

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

  if(pData != NULL)
  {
     delete[] pData;
  }

   return 0;
}