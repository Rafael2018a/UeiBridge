#include <windows.h>
#include <process.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;
//#define REPORT_WHAT_BC_WILL_SEND
#define REPORT_BUS_MONITOR_DATA
#define CHANNELS    2
#define SLEEP 300

// This example programs MIL-1553 RT and BM on channel 0 and BC on channel 1
// It continuously update "tranmit" area of RT, Rx data are of BC and read transaction data back
int main(int argc, char* argv[])
{
    std::string status;
    int error = 0;
    CUeiSession session;
    int i, ch;
    int startRt = 3;
    int startSa = 10;
    int numInputPorts = CHANNELS;
    int numOutputPorts = CHANNELS;
    int WordCount = 10;
    uInt32 init_num = 0x300;
    uInt16 data16[32];
    Int32 numFramesWritten, numFramesRead;

    int bc_chan_res = 0;    // select what channel to use for BC, the other channels will become RT and BM
    int rt_chan_res = (bc_chan_res)?0:1;    // set to opposite

    int cycles = 100;
    CUeiDevice* pDevice = NULL;
    try
    {
        char bc_resource[64];
        char rt_resource[64];
        char device_resource[] = "pdna://192.168.100.2/dev0";

        sprintf(bc_resource, "%s/milb%d", device_resource, bc_chan_res);
        sprintf(rt_resource, "%s/milb%d", device_resource, rt_chan_res);

        // port 0 - bus controller
        CUeiMIL1553Port* pPort0 = session.CreateMIL1553Port(
                                        bc_resource,
                                        UeiMIL1553CouplingTransformer,
                                        UeiMIL1553OpModeBusController
                                        );

        // port 1 - remote terminal
        CUeiMIL1553Port* pPort1 = session.CreateMIL1553Port(
                                        rt_resource,
                                        UeiMIL1553CouplingTransformer,
                                        UeiMIL1553OpModeRemoteTerminal
                                        );


        session.ConfigureTimingForMessagingIO(1, 0);
        session.GetTiming()->SetTimeout(1000);

        // Get device status information
        pDevice = session.GetDevice();
        status = pDevice->GetStatus();
        std::cout << "status: " << status << std::endl;
    
        // create one reader and one writer per each port
        CUeiMIL1553Writer** writers = new CUeiMIL1553Writer*[CHANNELS]; 
        CUeiMIL1553Reader** readers = new CUeiMIL1553Reader*[CHANNELS];

        for(ch=0; ch<CHANNELS; ch++)
        {
            readers[ch] = new CUeiMIL1553Reader(session.GetDataStream(), session.GetChannel(ch)->GetIndex());
            writers[ch] = new CUeiMIL1553Writer(session.GetDataStream(), session.GetChannel(ch)->GetIndex());
        }

        // First, configure remote terminal on channel 1
        CUeiMIL1553RTFrame* inFrm;
        CUeiMIL1553RTFrame* outFrm;
		CUeiMIL1553RTStatusFrame* stsFrm;
        CUeiMIL1553BMFrame* bmFrm;
        CUeiMIL1553FilterEntry* filterFrm;
        inFrm = new CUeiMIL1553RTFrame(startRt, startSa, 0, WordCount);
        outFrm = new CUeiMIL1553RTFrame(startRt, startSa, 0, WordCount);
		stsFrm = new CUeiMIL1553RTStatusFrame(startRt);
        bmFrm = new CUeiMIL1553BMFrame;
        filterFrm = new CUeiMIL1553FilterEntry;

        // Set UP RT/SAs we want to operate
        pPort0->ClearFilterEntries();
        filterFrm->Set(UeiMIL1553FilterByRt, startRt, startSa);
        filterFrm->EnableCommands(TRUE, TRUE, TRUE);
        pPort0->AddFilterEntry(*filterFrm);
        pPort0->EnableFilter(TRUE);

        // Then, configure bus controller on channel 1
        // we will need three types of frames for BC: BCCB Data, BCCD Status and BCCB Scheduler (one minor and one major)
        CUeiMIL1553BCSchedFrame* major = new CUeiMIL1553BCSchedFrame(UeiMIL1553BCFrameMajor);
        CUeiMIL1553BCSchedFrame* minor = new CUeiMIL1553BCSchedFrame(UeiMIL1553BCFrameMinor);
        CUeiMIL1553BCCBDataFrame** fdata = new CUeiMIL1553BCCBDataFrame*[2];
        CUeiMIL1553BCCBStatusFrame** fstatus = new CUeiMIL1553BCCBStatusFrame*[2];
       
        fdata[0] = new CUeiMIL1553BCCBDataFrame(0, 0, 0);  // first and
        fdata[1] = new CUeiMIL1553BCCBDataFrame(0, 1, 0);  // second minor frame entries

        fstatus[0] = new CUeiMIL1553BCCBStatusFrame(0, 0, 0);
        fstatus[1] = new CUeiMIL1553BCCBStatusFrame(0, 1, 0);
        
        // This is the frame to control BC
        tUeiMIL1553BCControlFrame* bcControl = new tUeiMIL1553BCControlFrame;
        tUeiMIL1553BCRetryType RetryType = (tUeiMIL1553BCRetryType)(UeiMIL1553BCR_RNR|UeiMIL1553BCR_ESR|UeiMIL1553BCR_RE);

        // fill major frame
        major->AddMajorEntry(0, UeiMIL1553MjEnable);
        writers[0]->Write(1, major, &numFramesWritten);

        // fill minor frame - one for send and one for receive
        minor->AddMinorEntry(UeiMIL1553MnEnable);
        minor->AddMinorEntry(UeiMIL1553MnEnable);
        writers[0]->Write(1, minor, &numFramesWritten);

        // fill BCCB for this minor frame
        fdata[0]->SetCommand(UeiMIL1553CmdBCRT, startRt, startSa, WordCount);
        fdata[0]->SetCommandBus(UeiMIL1553OpModeBusA);    // Test: Both buses is a default setting
        fdata[0]->SetCommandDelay(100);   // Test: default is 0
        fdata[0]->SetRetryOptions(3, RetryType);
        for (i = 0; i < WordCount; i++) data16[i] = 0x1000 + startRt + i;
        fdata[0]->CopyRxData(WordCount, data16);
        writers[0]->Write(1, fdata[0], &numFramesWritten);

        fdata[1]->SetCommand(UeiMIL1553CmdRTBC, startRt, startSa, WordCount);
        fdata[1]->SetCommandBus(UeiMIL1553OpModeBusA);    // Test: Both buses is a default setting
        fdata[1]->SetCommandDelay(100);   // Test: default is 0
        fdata[1]->SetRetryOptions(3, RetryType);
        writers[0]->Write(1, fdata[1], &numFramesWritten);

        // Start operations
        // Start RT
        for (i = 0; i < WordCount; i++) data16[i] = (uInt16)(1 + i);
        outFrm->CopyData(WordCount, data16);
        writers[1]->Write(1, outFrm, &numFramesWritten);

        // start Bus Controller
        bcControl->Operation = UeiMIL1553BcOpEnable;
        bcControl->MajorClock = 1.0;
        bcControl->MinorClock = 10.0;
        writers[0]->Write(1, bcControl, &numFramesWritten);

        // In cycle
        for (Int32 c = 0; (cycles>0)?c < cycles:1; c++)  {
            Sleep(2000);

			// read RT status
			readers[1]->Read(1, stsFrm, &numFramesRead);
			std::cout << "\nRT Rcv Sts= " << stsFrm->DataReady << " RT Snt Sts= " << stsFrm->DataSent << " " << std::hex << stsFrm->Status0 << " " << std::hex << stsFrm->Status1 << std::endl;

            // Change and retreive RT data each iteration
            // Store data to RT "transmit" area
            for (i = 0; i < WordCount; i++) data16[i] = (uInt16)(c + i);
            outFrm->CopyData(WordCount, data16);
            writers[1]->Write(1, outFrm, &numFramesWritten);   

			if ( stsFrm->DataReady )
			{
				// Read data from RT "receive" area
				readers[1]->Read(1, inFrm, &numFramesRead);    
				std::cout << "\nRT= " << inFrm->GetFrameStr() << " Data: " << inFrm->GetDataStr() << std::endl;
			}

            // Change and retrieve BC data each iteration
            // Store data for BC "Receive" command
            for (i = 0; i < WordCount; i++) data16[i] = (uInt16)(0x1000 + c + i);
            fdata[0]->CopyRxData(WordCount, data16);
            writers[0]->Write(1, fdata[0], &numFramesWritten);
            Sleep(SLEEP);


#ifdef REPORT_WHAT_BC_WILL_SEND

            // Read data stored in BC "Transmit" command
            readers[0]->Read(1, fstatus[1], &numFramesRead);
            if (numFramesRead) std::cout << "\nBC Data to Be Transmitted= " << fstatus[1]->GetBcDataStr(WordCount) << std::endl;		
            Sleep(SLEEP);
#endif


#ifdef REPORT_BUS_MONITOR_DATA

			// Read bus monitor and display bus activity

			std::cout << "\nBus Monitor Data :: " << std::endl << std::endl;
            for (i = 0; i < 10; i++) {
                readers[1]->Read(1, bmFrm, &numFramesRead);
                if (numFramesRead) std::cout<< bmFrm->GetBmDataStr() << std::endl;
            };
#endif

            std::cout << "\nIteration (" << c << ")" << std::endl;
            std::cout << "====================================================" << std::endl << std::endl;

        }


        // stop ops
        bcControl->Operation = UeiMIL1553BcOpDisable;
        writers[0]->Write(1, bcControl, &numFramesWritten);

        session.Stop();
        for(ch=0; ch<numInputPorts; ch++)
        {
            delete readers[ch];
        }
        delete[] readers;
        
        for(ch=0; ch<numOutputPorts; ch++)
        {
            delete writers[ch];
        }      
        delete[] writers;
    }
    catch(CUeiException& e)
    {
        std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
    }

    return 0;
}