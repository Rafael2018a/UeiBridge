#include <stdlib.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession mySs;
   double* pData = NULL;
   int count = 0;

   try
   {
      // Create RTD channels to measure temperatures between 0 and 500 deg using Pt100 RTDs connected via four wires. 
      // (Pt100 has resistance of 100 Ohms at 0 deg C and a sensitivity of 0.385 Ohms/deg C)
      mySs.CreateRTDChannel("simu://Dev0/ai0:7", 
                            0.0, 100.0, UeiFourWires, 0, UeiRTDType3850, 
                            100, UeiTemperatureScaleCelsius, UeiAIChannelInputModeDifferential);

      // Configure the session to run in immediate mode (software timing)
      mySs.ConfigureTimingForSimpleIO();
      
      // Set low scan rate for RTD measurement(default is 100Hz)
      mySs.GetTiming()->SetScanClockRate(20.0);

      // Create a reader object to read data synchronously from the data stream.
      CUeiAnalogScaledReader reader(mySs.GetDataStream());

      // Allocate buffer to store current frame
      pData = new double[mySs.GetNumberOfChannels()];

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as the reader starts reading data.
      mySs.Start();

      // Acquire 20 frames then stop
      while(count < 20)
      {
         reader.ReadSingleScan(pData);

         for(int i=0; i<mySs.GetNumberOfChannels();i++)
            std::cout << "ch" << i << " = " << pData[i] << " Ohms, ";

         std::cout << std::endl;
         count++;
      }

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

  if(pData != NULL)
  {
     delete[] pData;
  }

   return 0;
}