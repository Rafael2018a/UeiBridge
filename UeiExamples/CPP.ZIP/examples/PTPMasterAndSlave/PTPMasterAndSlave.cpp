#include <windows.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   char* ptpMasterResource = "pdna://192.168.100.2/dev14/sync0";
   CUeiSession* ptpMasterSession = NULL;
   CUeiSync1PPSController* ptpMasterController = NULL;

   char* ptpSlaveResources[] = { "pdna://192.168.100.3/dev14/Sync0" };
   CUeiSession** ptpSlaveSessions = NULL;
   CUeiSync1PPSController** ptpSlaveControllers = NULL;

   int numSlaves = sizeof(ptpSlaveResources) / sizeof(char*);
   ptpSlaveSessions = new CUeiSession*[numSlaves];   
   ptpSlaveControllers = new CUeiSync1PPSController*[numSlaves];

   try
   {
      // Configure Master session
      ptpMasterSession = new CUeiSession();
      CUeiSync1PPSPort* masterPort = ptpMasterSession->CreateSync1PPSPort(ptpMasterResource,
                                                                        UeiSync1588,
                                                                        UeiSync1PPSInternal,
                                                                        100.0);
      // configure port to output 1 PPS signal out of sync connector output 0 (clock out)
      masterPort->Set1PPSOutput(UeiSync1PPSOutput0);

      // Configure PTP master parameters
      masterPort->SetPTPEthernetPort(0);
      masterPort->SetPTPSubdomain(0);
      masterPort->SetPTPPriority1(128 - 3);
      masterPort->SetPTPPriority2(128 - 3);
      masterPort->SetPTPLogSyncInterval(0);
      masterPort->SetPTPLogMinDelayRequestInterval(1);
      masterPort->SetPTPLogAnnounceInterval(4);
      masterPort->SetPTPAnnounceTimeout(3);
      masterPort->SetPTPUTCOffset(37);

	  // Configure trigger to start session on a 1PPS edge
	  ptpMasterSession->GetStartTrigger()->SetTriggerSource(UeiTriggerSourceNext1PPS);

      ptpMasterSession->Start();

      // Create a controller object to read PTP status and UTC time
      ptpMasterController = new CUeiSync1PPSController(ptpMasterSession->GetDataStream());

      // Configure slave sessions
      for (int i = 0; i<numSlaves; i++)
      {
         ptpSlaveSessions[i] = new CUeiSession();
         
         CUeiSync1PPSPort* slavePort = ptpSlaveSessions[i]->CreateSync1PPSPort(ptpSlaveResources[i],
                                                                              UeiSync1588,
                                                                              UeiSync1PPSInternal,
                                                                              100.0);
         // configure port to output 1 PPS signal out of sync connector output 0 (clock out)
         slavePort->Set1PPSOutput(UeiSync1PPSOutput0);

         // Configure PTP slave parameters
         slavePort->SetPTPEthernetPort(0);
         slavePort->SetPTPSubdomain(0);
         slavePort->SetPTPPriority1(128 + 3);
         slavePort->SetPTPPriority2(128 + 3);
         slavePort->SetPTPLogSyncInterval(0);
         slavePort->SetPTPLogMinDelayRequestInterval(1);
         slavePort->SetPTPLogAnnounceInterval(4);
         slavePort->SetPTPAnnounceTimeout(3);
         slavePort->SetPTPUTCOffset(37);

		 // Configure trigger to start session on a 1PPS edge
		 ptpSlaveSessions[i]->GetStartTrigger()->SetTriggerSource(UeiTriggerSourceNext1PPS);

         ptpSlaveSessions[i]->Start();

         // Create a circuit breaker object per output channel to monitor circuit breaker status and eventually reset them
         ptpSlaveControllers[i] = new CUeiSync1PPSController(ptpSlaveSessions[i]->GetDataStream());
      }

      int count = 0;
      bool stop = false;
      while (!stop)
      {
         // Read PTP master time
         tUeiPTPTime masterTime;
         ptpMasterController->ReadPTPUTCTime(&masterTime);
         std::cout << "PTP Master UTC Time = " << masterTime.sec << "s / " << masterTime.nsec << "ns" << std::endl;
         std::cout << std::endl;

         // Read PTP slave(s) status and time
         for (int i = 0; i < numSlaves; i++)
         {
            std::cout << "Status for " << ptpSlaveResources[i] << std::endl;
            tUeiSync1PPSPTPStatus status;
            ptpSlaveControllers[i]->ReadPTPStatus(&status);
            std::cout << "PTP slave state = " << status.State << ", Master clock ID = " << status.MasterClockID << " Mean path delay = " << status.MeanPathDelay << std::endl;

            tUeiPTPTime slaveTime;
            ptpSlaveControllers[i]->ReadPTPUTCTime(&slaveTime);
            std::cout << "PTP UTC Time = " << slaveTime.sec << "s / " << slaveTime.nsec << "ns" << std::endl;

            // Compute time delay between master and slave
            long long delayNs = (slaveTime.sec * 1000000000L + slaveTime.nsec) - (masterTime.sec * 1000000000L + masterTime.nsec);
            std::cout << "Delay with master = " << delayNs << "ns" << std::endl;

            std::cout << std::endl;
         }

         std::cout << std::endl;

         Sleep(500);
         count++;
      }

      for(int i=0; i<numSlaves; i++)
      {
         ptpSlaveSessions[i]->Stop();
      }
      ptpMasterSession->Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   if(ptpSlaveControllers)
   {
      for(int i=0; i<numSlaves; i++)
      {
         delete ptpSlaveControllers[i];
      }
      delete[] ptpSlaveControllers;
   }
   if (ptpSlaveSessions)
   {
      for (int i = 0; i<numSlaves; i++)
      {
         delete ptpSlaveSessions[i];
      }
      delete[] ptpSlaveSessions;
   }
   if (ptpMasterController)
   {
      delete ptpMasterController;
   }
   if (ptpMasterSession)
   {
      delete ptpMasterSession;
   }

   return 0;
}



