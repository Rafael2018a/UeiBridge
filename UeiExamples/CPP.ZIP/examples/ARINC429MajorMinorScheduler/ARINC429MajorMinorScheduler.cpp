#include <windows.h>
#include <process.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

CUeiSession mySession;


// This example continuously sends scheduled ARINC-429 words on TX port 0 and receives on port RX 0 and 1
int main(int argc, char* argv[])
{
    int i, ch, f;
    int numInputPorts;
    int numOutputPorts;
    int numWords = 12;  // number of words to schedule per output channel
    int numMinorFrames = 4; // number of minor frames per output channel
    double majorFrameRate = 100.0;


    try
    {
        mySession.CreateARINCInputPort("pdna://192.168.1.102/dev7/arx0,1", 
                                        UeiARINCBitsPerSecond100000,
                                        UeiARINCParityNone,
                                        false,
                                        0);
        numInputPorts = mySession.GetNumberOfChannels();

        mySession.CreateARINCOutputPort("pdna://192.168.1.102/dev7/atx0", 
                                         UeiARINCBitsPerSecond100000,
                                         UeiARINCParityNone);
        numOutputPorts = mySession.GetNumberOfChannels()-numInputPorts;

        mySession.ConfigureTimingForMessagingIO(1, 0);

        // Set timeout to a very low value to avoid blocking the program
        // if no words are received
        mySession.GetTiming()->SetTimeout(10);

        // Allocate one reader for each configured input port
        CUeiARINCReader** readers = new CUeiARINCReader*[numInputPorts];
        for(ch=0; ch<numInputPorts; ch++)
        {
            readers[ch] = new CUeiARINCReader(mySession.GetDataStream(), mySession.GetChannel(ch)->GetIndex());
        }

        CUeiARINCWriter** writers = new CUeiARINCWriter*[numOutputPorts];
        for(ch=0; ch<numOutputPorts; ch++)
        {
            writers[ch] = new CUeiARINCWriter(mySession.GetDataStream(), mySession.GetChannel(ch)->GetIndex());
        }
       
        // Configure scheduled words and minor frames
        for(ch=0; ch<numOutputPorts; ch++)
        {
            // Get a pointer to each output port object
            CUeiARINCOutputPort* pOutPort = dynamic_cast<CUeiARINCOutputPort*>(mySession.GetChannel(numInputPorts + ch));

            pOutPort->EnableScheduler(true);
            pOutPort->SetSchedulerType(UeiARINCSchedulerTypeMajorMinorFrame);

            // Configure major frame rate
            pOutPort->SetSchedulerRate(majorFrameRate);

            // Configure minor frames
            tUeiARINCMinorFrameEntry minorFrame;
            for (f = 0; f < numMinorFrames; f++)
            {
               minorFrame.Delay = 0;
               // Set minor frame rates as multiple of major frame rate
               minorFrame.Period = uInt32((1000000.0 / majorFrameRate) / numMinorFrames);
               pOutPort->AddMinorFrameEntry(minorFrame);
            }

            for(f=0; f<numWords; f++)
            {
                tUeiARINCSchedulerEntry schedEntry;

                // Every fourth entry is a master.
                // All slave entries following the master entry (until the next master entry) 
                // are scheduled at the same time
                schedEntry.Master = (0 == (f % 4));

                // Master entry is periodic (this is ignored for slave entries)
                schedEntry.Periodic = 1;

                // Schedule master entry to output word 100ms after trigger
                schedEntry.Delay = 0;

                // Program word to be emitted by this entry
                schedEntry.Word.Label = f + ch;
                schedEntry.Word.Sdi = 1;
                schedEntry.Word.Ssm = 2;
                schedEntry.Word.Data = 2*f;

                // Add word to one of the minor frames
                schedEntry.MinorFrameMask = (1 << (f % numMinorFrames));

                pOutPort->AddSchedulerEntry(schedEntry);
            }
        }

        // Allocate buffer used to receive ARINC words
        tUeiARINCWord* words = new tUeiARINCWord[numWords];

        mySession.Start();

        for(i=0; i<100; i++)
        {
            for(ch=0; ch<numInputPorts; ch++)
            {
                int port = mySession.GetChannel(ch)->GetIndex();
                Int32 numWordsRead;

                // Wrap Read in its own try/catch block to filter out 
                // timeout error
                try
                {
                    readers[ch]->Read(numWords, words, &numWordsRead);
                }
                catch(CUeiException& e)
                {
                    if(e.GetError() == UEIDAQ_TIMEOUT_ERROR)
                    {
                        continue;
                    }

                    // re-throw any other error, the main exception handler
                    // will process it
                    throw;
                }

                std::cout << std::dec << i << " RX Port " << port << ": Received " << numWordsRead << " words" << std::endl;

                for(f=0; f<numWordsRead; f++)
                {
                    std::cout << std::dec << i << "  RX Port " << port << ": Received word :" << 
                        " Label=" << std::hex << words[f].Label << std::dec << 
                        " Data=" << words[f].Data << 
                        " Sdi=" << words[f].Sdi <<
                        " Ssm=" << words[f].Ssm <<
                        " Parity=" << words[f].Parity << std::endl;
                }
            }

            // update scheduled words after 50 iterations
            if(50 == i) 
            {
               for(ch=0; ch<numOutputPorts; ch++)
               {
                  tUeiARINCWord* words = new tUeiARINCWord[numWords];
                  int numWordsWritten;

                  // Set TX page to 0 (default) and write page to 1 immediately
                  writers[ch]->SetTransmitPage(true, 0xffff, 0);

                  for(f=0; f<numWords; f++)
                  {
                     words[f].Label = f;
                     words[f].Ssm = 2;
                     words[f].Sdi = 1;
                     words[f].Data = 102+f;
                  }

                  writers[ch]->WriteScheduler(0, numWords, words, &numWordsWritten);

                  // Swap pages 0 and 1. 0 becomes writing page and 1 becomes transmit page
                  // The swap occurrs at the beginning of the next major frame
                  writers[ch]->SetTransmitPage(false, 0, 0xffff);

                  std::cout << "Updated " << numWordsWritten << " scheduled words" << std::endl;

                  delete[] words;
               }
            }
        }

        mySession.Stop();

        for(ch=0; ch<numInputPorts; ch++)
        {
            delete readers[ch];
        }
        delete[] readers;
        
        delete[] words;

        mySession.CleanUp();
    }
    catch(CUeiException& e)
    {
        std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
    }

    return 0;
}