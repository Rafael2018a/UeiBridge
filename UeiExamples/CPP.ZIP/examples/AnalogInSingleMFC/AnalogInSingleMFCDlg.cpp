// AnalogInSingleMFCDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AnalogInSingleMFC.h"
#include "AnalogInSingleMFCDlg.h"
#include ".\analoginsinglemfcdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CAnalogInSingleMFCDlg dialog



CAnalogInSingleMFCDlg::CAnalogInSingleMFCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAnalogInSingleMFCDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAnalogInSingleMFCDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   DDX_Control(pDX, IDC_RESOURCE, m_Resource);
   DDX_Control(pDX, IDC_FREQUENCY, m_Frequency);
   DDX_Control(pDX, IDC_LOWLIM, m_LowLim);
   DDX_Control(pDX, IDC_HIGHLIM, m_HighLim);
   DDX_Control(pDX, IDC_GRAPH, m_Graph);
   DDX_Control(pDX, IDC_LOG, m_Log);
}

BEGIN_MESSAGE_MAP(CAnalogInSingleMFCDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
   ON_BN_CLICKED(ID_GO, OnBnClickedGo)
   ON_BN_CLICKED(ID_STOP, OnBnClickedStop)
   ON_WM_TIMER()
END_MESSAGE_MAP()


// CAnalogInSingleMFCDlg message handlers

BOOL CAnalogInSingleMFCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_Resource.SetWindowText("simu://Dev0/Ai0:3");
   m_Frequency.SetWindowText("50");
   m_LowLim.SetWindowText("-10");
   m_HighLim.SetWindowText("10");

   m_Graph.yAxis()->setMinimum(-10.0);
   m_Graph.yAxis()->setMaximum(10.0);
   m_Graph.setType(StripChart);
   m_Graph.addPlot(RGB(255,255,0), "");

   GetDlgItem(ID_GO)->EnableWindow(TRUE);
   GetDlgItem(ID_STOP)->EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CAnalogInSingleMFCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAnalogInSingleMFCDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAnalogInSingleMFCDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CAnalogInSingleMFCDlg::OnBnClickedGo()
{
   try
   {
      CString resstr, lowstr, highstr;
      m_Resource.GetWindowText(resstr);
      m_LowLim.GetWindowText(lowstr);
      m_HighLim.GetWindowText(highstr);
      double low = atof(LPCSTR(lowstr));
      double high = atof(LPCSTR(highstr));

      m_Session.CreateAIChannel(LPCSTR(resstr), low, high, UeiAIChannelInputModeDifferential);

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      m_Session.ConfigureTimingForSimpleIO();

      // Create a reader object to read data synchronously.
      m_pReader = new CUeiAnalogScaledReader(m_Session.GetDataStream());

      // allocate buffer to receive acquired data
      m_pData = (double*)malloc(m_Session.GetNumberOfChannels() * sizeof(double));

      // adjust scales of the graph
      m_Graph.xAxis()->setMinimum(0.0);
      m_Graph.xAxis()->setMaximum(100.0);

      m_Graph.yAxis()->setMinimum(low);
      m_Graph.yAxis()->setMaximum(high);

      m_Session.Start();

      CString loopstr;
      m_Frequency.GetWindowText(loopstr);
      m_TimerID = SetTimer(1, 1000/atoi(LPCSTR(loopstr)), NULL);   

      GetDlgItem(ID_GO)->EnableWindow(FALSE);
      GetDlgItem(ID_STOP)->EnableWindow(TRUE);
      m_Log.SetWindowText("");
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("Go Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CAnalogInSingleMFCDlg::OnTimer(UINT_PTR nIDEvent)
{
   CDialog::OnTimer(nIDEvent);

   try
   {
      m_pReader->ReadSingleScan(m_pData);

      m_Graph.plotappend(0, m_pData, m_Session.GetNumberOfChannels(), 0.0, 0.1, true);
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("Timer Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CAnalogInSingleMFCDlg::OnBnClickedStop()
{
   KillTimer(m_TimerID);

   try
   {
      m_Session.Stop();
      m_Session.CleanUp();

      delete m_pReader;
      free(m_pData);

      GetDlgItem(ID_GO)->EnableWindow(TRUE);
      GetDlgItem(ID_STOP)->EnableWindow(FALSE);
   }
   catch(CUeiException e)
   {
      CString str;
      str.Format("Stop Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}
