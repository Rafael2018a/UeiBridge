//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DigitalInOutMFC.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DIGITALINOUTMFC_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDC_COMBO1                      1000
#define IDC_DIGITALPORT                 1000
#define IDC_DIGITALOUTPORT              1000
#define ID_GO                           1001
#define IDC_DOUT0                       1002
#define IDC_DOUT1                       1003
#define IDC_DOUT_RESOURCE               1004
#define IDC_DIN_RESOURCE                1005
#define IDC_DOUT2                       1006
#define IDC_DOUT3                       1007
#define IDC_DOUT4                       1008
#define IDC_DOUT5                       1009
#define ID_STOP                         1010
#define IDC_DOUT6                       1011
#define IDC_DIGITALPORT2                1012
#define IDC_DIGITALINPORT               1012
#define IDC_DOUT7                       1013
#define IDC_DOUT8                       1014
#define IDC_DOUT9                       1015
#define IDC_DOUT10                      1016
#define IDC_DOUT11                      1017
#define IDC_DOUT12                      1018
#define IDC_DOUT13                      1019
#define IDC_DOUT14                      1020
#define IDC_DOUT15                      1021
#define IDC_DIN0                        1022
#define IDC_DIN1                        1023
#define IDC_DIN2                        1024
#define IDC_DIN3                        1025
#define IDC_DIN4                        1026
#define IDC_DIN5                        1027
#define IDC_DIN6                        1028
#define IDC_DIN7                        1029
#define IDC_DIN8                        1030
#define IDC_DIN9                        1031
#define IDC_DIN10                       1032
#define IDC_DIN11                       1033
#define IDC_DIN12                       1034
#define IDC_DIN13                       1035
#define IDC_DIN14                       1036
#define IDC_DIN15                       1037
#define IDC_CHECK2                      1038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
