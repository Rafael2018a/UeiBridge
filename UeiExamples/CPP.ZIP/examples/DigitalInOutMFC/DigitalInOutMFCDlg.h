// DigitalInOutMFCDlg.h : header file
//

#pragma once

#include "UeiDaq.h"
#include "afxwin.h"

using namespace UeiDaq;

// CDigitalInOutMFCDlg dialog
class CDigitalInOutMFCDlg : public CDialog
{
// Construction
public:
	CDigitalInOutMFCDlg(CWnd* pParent = NULL);	// standard constructor
   ~CDigitalInOutMFCDlg();

// Dialog Data
	enum { IDD = IDD_DIGITALINOUTMFC_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

private:
   CUeiSession m_DinSession;
   CUeiSession m_DoutSession;
   CUeiDigitalReader *m_pReader;
   void*  m_pDinData;
   CUeiDigitalWriter *m_pWriter;
   void* m_pDoutData;
   UINT_PTR m_TimerID;

   void DisplayError(CUeiException e);

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
   afx_msg void OnBnClickedGo();
   afx_msg void OnBnClickedStop();
   CEdit m_DinResource;
   CEdit m_DoutResource;
   CComboBox m_DigitalOutPort;
   afx_msg void OnDigLineToggle();
   afx_msg void OnTimer(UINT_PTR nIDEvent);
   CComboBox m_DigitalInPort;
};
