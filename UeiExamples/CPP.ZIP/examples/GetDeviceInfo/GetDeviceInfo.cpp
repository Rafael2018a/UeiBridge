#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   try
   {
      // Create a device enumerator object for the specified family of devices
      CUeiDeviceEnumerator devEnum("pwrdaq://");

      CUeiDevice* pDev;
      int deviceId=0;
      // Enumerate through all the devices and list their capabilities
      while((pDev = devEnum.GetDevice(deviceId++)) != NULL)
      {
         std::string devName;
         std::string serial;

         devName = pDev->GetDeviceName();
         serial = pDev->GetSerialNumber();

         std::cout << "device " << deviceId << " : " << devName << " (#" << serial << ")" << std::endl;

         if(pDev->GetNumberOfAIChannels(UeiAIChannelInputModeSingleEnded) > 0)
         {
            std::cout << "Analog Input Subsystem:" << std::endl;
            std::cout << "Number of Analog input channels = " << pDev->GetNumberOfAIChannels(UeiAIChannelInputModeSingleEnded) << std::endl;
            std::cout << "Maximum sampling frequency = " << pDev->GetMaxAIRate() << std::endl;
            std::cout << "Resolution = " << pDev->GetAIResolution() << std::endl;
            std::cout << "Input gains = ";
            tGains gains;
            pDev->GetAIGains(gains);
            for(size_t i = 0; i< gains.size(); i++)
            {
               std::cout << gains[i] << " ";
            }
            std::cout << std::endl; 
            std::cout << std::endl;
         }

         if(pDev->GetNumberOfAOChannels() > 0)
         {
            std::cout << "Analog Output Subsystem:" << std::endl;
            std::cout << "Number of Analog output channels = " << pDev->GetNumberOfAOChannels() << std::endl;
            std::cout << "Maximum genration frequency = " << pDev->GetMaxAORate() << std::endl;
            std::cout << "Resolution = " << pDev->GetAOResolution() << std::endl;
            
            std::cout << std::endl;        
         }

         if(pDev->GetNumberOfDIChannels() > 0)
         {
            std::cout << "Digital Input Subsystem:" << std::endl;
            std::cout << "Number of Digital input ports = " << pDev->GetNumberOfDIChannels() << std::endl;
            std::cout << "Maximum acquisition frequency = " << pDev->GetMaxDIRate() << std::endl;
            std::cout << "Port width = " << pDev->GetDIResolution() << std::endl;
            
            std::cout << std::endl;        
         }

         if(pDev->GetNumberOfDOChannels() > 0)
         {
            std::cout << "Digital Output Subsystem:" << std::endl;
            std::cout << "Number of Digital output ports = " << pDev->GetNumberOfDOChannels() << std::endl;
            std::cout << "Maximum generation frequency = " << pDev->GetMaxDORate() << std::endl;
            std::cout << "Port width = " << pDev->GetDOResolution() << std::endl;
            
            std::cout << std::endl;        
         }

         if(pDev->GetNumberOfCIChannels() > 0)
         {
            std::cout << "Counter Input Subsystem:" << std::endl;
            std::cout << "Number of counter = " << pDev->GetNumberOfCIChannels() << std::endl;
            std::cout << "Counter clock frequency = " << pDev->GetMaxCIRate() << std::endl;
            std::cout << "Resolution = " << pDev->GetCIResolution() << std::endl;
            
            std::cout << std::endl;        
         }

         if(pDev->GetNumberOfCOChannels() > 0)
         {
            std::cout << "Timer Output Subsystem:" << std::endl;
            std::cout << "Number of timers = " << pDev->GetNumberOfCOChannels() << std::endl;
            std::cout << "Timer clock frequency = " << pDev->GetMaxCORate() << std::endl;
            std::cout << "Resolution = " << pDev->GetCOResolution() << std::endl;
            
            std::cout << std::endl;        
         }

         std::cout << std::endl << std::endl;
      };
   }
   catch(CUeiException& e)
   {
      std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}