#include <windows.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

class CDigitalOutListener : public IUeiEventListener
{
public:
   CDigitalOutListener(CUeiSession* pSs):
      m_pSession(pSs),
      m_Datas(NULL),
      m_Datal(NULL),
      m_pWriter(NULL),
      m_Iterations(0)
   {
      // Digital data will be stored in a 16 bits or 32 bits integer buffer
      // depending on the width of the port
      // let's allocate a buffer big enough to hold one value for each configured port
      if(m_pSession->GetDevice()->GetDOResolution() <= 16)
      {
         m_Datas = new uInt16[m_pSession->GetNumberOfChannels()];
      }
      else
      {
         m_Datal = new uInt32[m_pSession->GetNumberOfChannels()];
      }

      // Create a reader to read data asynchronously from the digital input ports.
      m_pWriter = new CUeiDigitalWriter(m_pSession->GetDataStream());
      // Add listener class to reader to get notified when data has been received
      m_pWriter->AddEventListener(this);
   }

   ~CDigitalOutListener()
   {
      if(m_Datas != NULL)
      {
         delete[] m_Datas;
      }
      if(m_Datal != NULL)
      {
         delete[] m_Datal;
      }

      delete m_pWriter;
   }

   void Begin()
   {
      if(m_Datas != NULL)
      {
         // Create digital patterns to generate
         for(int p=0; p<m_pSession->GetNumberOfChannels(); p++)
         {
            m_Datas[p] = 1 << (m_Iterations % m_pSession->GetDevice()->GetDOResolution());
         }
         m_pWriter->WriteSingleScanAsync(m_Datas);
      }
      else
      {
         // Create digital patterns to generate
         for(int p=0; p<m_pSession->GetNumberOfChannels(); p++)
         {
            m_Datal[p] = 1 << (m_Iterations % m_pSession->GetDevice()->GetDOResolution());
         }
         m_pWriter->WriteSingleScanAsync(m_Datal);
      }
   }

   int GetIterations()
   {
      return m_Iterations;
   }

   void OnEvent(tUeiEvent event, void *param)
   {
      if(event == UeiEventFrameDone)
      {
         m_Iterations++;

         // Begin new asynchronous write
         Begin();

         // Display data gnerated 
         if(m_Datas != NULL)
         {
            std::cout << "Digital output 0x" << std::hex << m_Datas[0] << std::endl;
         }
         else
         {
            std::cout << "Digital output 0x" << std::hex << m_Datal[0] << std::endl;
         }

         Sleep(50);
      }
      else if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)(uintptr_t)param;
         std::cout << "Error DO: " << CUeiException::TranslateError(error) << std::endl;
      }
   }
private:
   CUeiSession* m_pSession;
   CUeiDigitalWriter* m_pWriter;
   uInt16* m_Datas;   // for devices with 16 or less output lines per port
   uInt32* m_Datal;   // for devices with more than 16 output lines per port
   int m_Iterations;
};


int main(int argc, char* argv[])
{
   CUeiSession doSs;
   
   try
   {
      // Create 1 digital input channel on a powerdaq board
      // From now on the session is DI only
      doSs.CreateDOChannel("pdna://192.168.15.201/Dev4/do0");
      
      doSs.ConfigureTimingForSimpleIO();      

      // Create the asynchronous listener
      CDigitalOutListener listener(&doSs);
      
      // Start the session
      doSs.Start();

      // Start receiving data asynchronously
      listener.Begin();
      
      // Wait until 100 values have been written
      while(listener.GetIterations() < 100)
      {
      }

      doSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}

