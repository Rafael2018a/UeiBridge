#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession mySs;
   double data[800];

   try
   {
      // Create 8 analog input channels on a powerdaq board
      // From now on the session is AI only
      mySs.CreateAIChannel("simu://Dev0/ai0:7", -10.0, 10.0, UeiAIChannelInputModeDifferential);

      // By default the timing object is configured for simple I/O so
      // no need to do anything here.
      mySs.ConfigureTimingForSimpleIO();

      // Create a reader object to read data synchronously.
      CUeiAnalogScaledReader reader(mySs.GetDataStream());

      mySs.Start();

      // Read 100 scans
      for(int i=0; i<100; i++)
      {
         reader.ReadSingleScan(&data[i*mySs.GetNumberOfChannels()]);
         std::cout << "Ch0 = " << data[i*mySs.GetNumberOfChannels()] << std::endl;
      }

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}