#include <iostream>
#include <thread>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   try
   {
      CUeiSession diagSession;

      diagSession.CreateDiagnosticChannel("pdna://192.168.100.2/dev12/diag0:12");
      diagSession.ConfigureTimingForSimpleIO();
      diagSession.Start();

      CUeiAnalogScaledReader reader(diagSession.GetDataStream());
      double* data = new double[diagSession.GetNumberOfChannels()];
      for(int i=0; i<10; i++)
      {
         reader.ReadSingleScan(data);
         for(int ch=0; ch<diagSession.GetNumberOfChannels(); ch++)
         {
            std::cout << diagSession.GetChannel(ch)->GetAliasName() << " = " << data[ch] << std::endl;
         }
         std::cout << std::endl;
         std::this_thread::sleep_for(std::chrono::milliseconds(500));
      }
      diagSession.Stop();
   }
   catch(CUeiException& e)
   {
      std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}