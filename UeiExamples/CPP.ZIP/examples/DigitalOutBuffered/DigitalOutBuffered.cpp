#include <iostream>
#include <windows.h>
#include "UeiDaq.h"


using namespace UeiDaq;


int main(int argc, char* argv[])
{
    CUeiSession mySs;
    uInt16* datas=NULL;
    uInt32* datal=NULL;
    int i, j, scanSize, numScans = 400;
    double outputRate = 500.0;

    try
    {
        // Create a digital output session
        mySs.CreateDOChannel("pdna://192.168.100.6/Dev1/DO0");

        // Use the hardware clock on the device and transfer data from the device
        // in blocks
        mySs.ConfigureTimingForBufferedIO(numScans, UeiTimingClockSourceInternal, outputRate, 
            UeiDigitalEdgeRising, UeiTimingDurationContinuous);

        // Create writer to write data to the digital device.
        CUeiDigitalWriter writer(mySs.GetDataStream());

        // Allocate a buffer to hold each generated frame
        scanSize = mySs.GetDataStream()->GetScanSize();

        std::cout << "This is a " << mySs.GetDevice()->GetDOResolution() << " bits DO device" << std::endl;

        // Digital data will be stored in a 16 bits or 32 bits integer buffer
        // depending on the width of the port
        // let's allocate a buffer big enough to hold one value for each configured port
        if(mySs.GetDevice()->GetDOResolution() <= 16)
        {
            datas = new uInt16[scanSize * numScans];
            // Populate data alternating all lines at zero and all lines at one 
            for(i = 0; i < numScans; i++) {
                for(j = 0; j < scanSize; j++) {
                    datas[(i * scanSize) + j] = (i % 2 == 0) ? 0x00 : 0xFF;
                }
            }
        }
        else
        {
            datal = new uInt32[scanSize * numScans];
            // Populate data alternating all lines at zero and all lines at one 
            for(i = 0; i < numScans; i++) {
                for(j = 0; j < scanSize; j++) {
                    datal[(i * scanSize) + j] = (i % 2 == 0) ? 0x00 : 0xFF;
                }
            }
        }


        // Start the generation
        mySs.Start();

        for (i = 0; i < 1; i++) {
            printf("Writing data %d\n", i);

            // Send the buffer to the device
            if(mySs.GetDevice()->GetDIResolution() <= 16)
            {
                writer.WriteMultipleScans(numScans, datas);
            }
            else
            {
                writer.WriteMultipleScans(numScans, datal);
            }

            // writer doesn't block until buffer is actually sent to the outputs
            // wait for the expected duration of a frame
            Sleep((DWORD)(1000.0 * numScans / outputRate));
        }

        mySs.Stop();

        if(datas != NULL) delete[] datas;
        if(datal != NULL) delete[] datal;
    }
    catch(CUeiException e)
    {
        std::cout << "Error: " << e.GetErrorMessage() << std::endl;
    }

    return 0;
}