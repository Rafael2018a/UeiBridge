#include <windows.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession muxSession;

   try
   {
      CUeiMuxPort* pChan = muxSession.CreateMuxPort("pdna://192.168.100.2/dev0/mux0", true);
      

      // optionally configure sync input and output lines
      pChan->EnableSyncInput(false);
      pChan->SetSyncOutputMode(UeiMuxSyncOutputLogic0);
      
      muxSession.ConfigureTimingForSimpleIO();

      int numMuxChannels = muxSession.GetDevice()->GetDOResolution();

      // Create a reader to retrieve diagnostics
      CUeiMuxWriter muxWriter(muxSession.GetDataStream());
      
      muxSession.Start();

      bool stop = false;
      int count = 0;
      while (!stop)
      {
         // This example sets one channel per iteration but it is possible to
         // set an arbitrary number of channels
         int channel = count % numMuxChannels;
         int relay = count % 4;
         muxWriter.WriteMux(1, &channel, &relay);

         Sleep(500);

         double adcBuffer[5];
         muxWriter.ReadADC(5, adcBuffer, NULL);
         for (int j = 0; j<5; j++)
         {
            std::cout << " adc" << j << "= " << adcBuffer[j];
         }
         std::cout << std::endl;

         uInt32 stRelayA, stRelayB, stRelayC, status;
         muxWriter.ReadStatus(&stRelayA, &stRelayB, &stRelayC, &status);
         std::cout << std::hex << " relayA=" << stRelayA <<
            " relayB=" << stRelayB <<
            " relayC=" << stRelayC <<
            " status=" << status << std::dec << std::endl;

         count++;
      }

      muxSession.Stop();
   }
   catch (CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}


