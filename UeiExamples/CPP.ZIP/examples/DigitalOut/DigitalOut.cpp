#include <windows.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession doSs;
   uInt16* datas = NULL;   // for devices with 16 or less output lines per port
   uInt32* datal = NULL;   // for devices with more than 16 output lines per port
   
   try
   {
      // Create 1 digital input channel on a powerdaq board
      // From now on the session is DI only
      doSs.CreateDOChannel("pdna://192.168.15.201/Dev4/do0");
      
      doSs.ConfigureTimingForSimpleIO();

      // Digital data will be stored in a 16 bits or 32 bits integer buffer
      // depending on the width of the port
      // let's allocate a buffer big enough to hold one value for each configured port
      if(doSs.GetDevice()->GetDOResolution() <= 16)
      {
         datas = new uInt16[doSs.GetNumberOfChannels()];
      }
      else
      {
         datal = new uInt32[doSs.GetNumberOfChannels()];
      }
      
      // Create a writer object to receive events asynchronously.
      CUeiDigitalWriter doWriter(doSs.GetDataStream());
      
      // Start the session
      doSs.Start();
      
      // Write 100 values
      for(int i=0; i<100; i++)
      {
         if(datas != NULL)
         {
            // Create digital patterns to generate
            for(int p=0; p<doSs.GetNumberOfChannels(); p++)
            {
               datas[p] = 1 << (i % doSs.GetDevice()->GetDOResolution());
            }
            doWriter.WriteSingleScan(datas);
            std::cout << "Digital output 0x" << std::hex << datas[0] << std::endl;
         }
         else
         {
            for(int p=0; p<doSs.GetNumberOfChannels(); p++)
            {
               datal[p] = 1 << (i % doSs.GetDevice()->GetDOResolution());
            }
            doWriter.WriteSingleScan(datal);
            std::cout << "Digital output 0x" << std::hex << datal[0] << std::endl;
         }

         Sleep(100);
      }

      doSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   if(datas != NULL)
   {
      delete[] datas;
   }
   if(datal != NULL)
   {
      delete[] datal;
   }

   return 0;
}



