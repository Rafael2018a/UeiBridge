#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession diSs;
   uInt16* datas = NULL;   // for devices with 16 or less input lines per port
   uInt32* datal = NULL;   // for devices with more than 16 input lines per port
   
   try
   {
      // Create 1 digital input channel on a powerdaq board
      // From now on the session is DI only
      diSs.CreateDIChannel("pdna://192.168.15.201/Dev3/di0");
      
      diSs.ConfigureTimingForSimpleIO();

      // Digital data will be stored in a 16 bits or 32 bits integer buffer
      // depending on the width of the port
      // let's allocate a buffer big enough to hold one value for each configured port
      if(diSs.GetDevice()->GetDIResolution() <= 16)
      {
         datas = new uInt16[diSs.GetNumberOfChannels()];
      }
      else
      {
         datal = new uInt32[diSs.GetNumberOfChannels()];
      }
      
      // Create a reader to read data from the digital input ports.
      CUeiDigitalReader diReader(diSs.GetDataStream());
      
      // Start the session
      diSs.Start();
      
      // Read 100 values
      for(int i=0; i<100; i++)
      {
         if(datas != NULL)
         {
            diReader.ReadSingleScan(datas);
            std::cout << "Digital input 0x" << std::hex << datas[0] << std::endl;
         }
         else
         {
            diReader.ReadSingleScan(datal);
            std::cout << "Digital input 0x" << std::hex << datal[0] << std::endl;
         }
      }

      diSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   if(datas != NULL)
   {
      delete[] datas;
   }
   if(datal != NULL)
   {
      delete[] datal;
   }

   return 0;
}

