#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession diSs;
   CUeiSession doSs;

   try
   {
      // Create 1 digital input channel on a powerdaq board
      // From now on the session is DI only
      diSs.CreateDIChannel("pwrdaq://Dev0/di0");
      doSs.CreateDOChannel("pwrdaq://Dev0/do0");

      diSs.ConfigureTimingForSimpleIO();
      doSs.ConfigureTimingForSimpleIO();

      // Create a reader and a writer objects to to read and write data from/to the digital ports.
      CUeiDigitalReader diReader(diSs.GetDataStream());
      CUeiDigitalWriter doWriter(doSs.GetDataStream());
      
      // Start the session
      diSs.Start();
      doSs.Start();

      // Read 100 events
      for(int i=0; i<100; i++)
      {
         unsigned short data[1];
         diReader.ReadSingleScan(data);
         std::cout << "Digital input " << std::hex << data[0] << std::endl;

         data[0] = i;
         doWriter.WriteSingleScan(data);
      }

      diSs.Stop();
      doSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}

