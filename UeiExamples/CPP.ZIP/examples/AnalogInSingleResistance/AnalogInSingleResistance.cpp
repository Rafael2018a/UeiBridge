#include <stdlib.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession mySs;
   double* pData = NULL;
   int count = 0;

   try
   {
      // Create Resistance channels to measure resistances between 0 and 1000 Ohms. 
      mySs.CreateResistanceChannel("pdna://192.168.100.2/Dev0/ai0:7", 0.0, 1000.0, UeiTwoWires, 0, UeiAIChannelInputModeDifferential);

      // Configure the session to run in immediate mode (software timing)
      mySs.ConfigureTimingForSimpleIO();
      
      // Set low scan rate for resistance measurement(default is 100Hz)
      mySs.GetTiming()->SetScanClockRate(20.0);

      // Create a reader object to read data synchronously from the data stream.
      CUeiAnalogScaledReader reader(mySs.GetDataStream());

      // Allocate buffer to store current frame
      pData = new double[mySs.GetNumberOfChannels()];

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as the reader starts reading data.
      mySs.Start();

      // Acquire 20 frames then stop
      while(count < 20)
      {
         reader.ReadSingleScan(pData);

         for(int i=0; i<mySs.GetNumberOfChannels();i++)
            std::cout << "ch" << i << " = " << pData[i] << " Ohms, ";

         std::cout << std::endl;
         count++;
      }

      mySs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

  if(pData != NULL)
  {
     delete[] pData;
  }

   return 0;
}