
#include <windows.h>
#include <iostream>
#include <vector>
#include "UeiDaq.h"
#include "UeiSessionGroup.h"
#include "UeiDaqUI.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   // Call the GUI to configure some sessions that will be part of the group "example"
   CUeiDialog::ManageSessions(NULL, "example");

   // vector of sessions used to store "example" group session objects
   std::vector<CUeiSession*>::iterator it;
   std::vector<CUeiSession*> sessions;

   // vector of buffers, we need one for each session
   std::vector<void *> buffers;

   try
   {
      std::string sessionFile;
      int sessionIndex = 0;
      while((sessionFile = CUeiSessionGroup::EnumGroupSessions("example", sessionIndex++)).size() > 0)
      {
         CUeiSession* pSession = new CUeiSession();
         pSession->LoadFromFile(sessionFile);

         sessions.push_back(pSession);

         // allocate session buffer
         void* buffer;
         switch(pSession->GetType())
         {
         case UeiSessionTypeAI:
         case UeiSessionTypeAO:
            buffer = new double[pSession->GetNumberOfChannels()];
            break;
         case UeiSessionTypeDI:
         case UeiSessionTypeDO:
         case UeiSessionTypeCI:
         case UeiSessionTypeCO:
            if(pSession->GetDataStream()->GetSampleSize() == 4)
            {
               buffer = new uInt32[pSession->GetNumberOfChannels()];
            }
            else
            {
               buffer = new uInt16[pSession->GetNumberOfChannels()];
            }
            break;
         default:
            std::cerr << "Session type not supported" << std::endl;
            return -1;
         }

         // Override sessions timing configuration to point by point
         pSession->ConfigureTimingForSimpleIO();

         buffers.push_back(buffer);
      }

      // Read from all input sessions
      for(int i=0; i<(int)sessions.size(); i++)
      {
         CUeiSession* pSession = sessions.at(i);

         switch(pSession->GetType())
         {
         case UeiSessionTypeAI:
            {
               CUeiAnalogScaledReader reader(pSession->GetDataStream());
               reader.ReadSingleScan((f64*)buffers.at(i));
            }
            break;
         case UeiSessionTypeDI:
            {
               CUeiDigitalReader reader(pSession->GetDataStream());
               if(pSession->GetDataStream()->GetSampleSize() == 2)
               {
                  reader.ReadSingleScan((uInt16*)buffers.at(i));
               }
               else
               {
                  reader.ReadSingleScan((uInt32*)buffers.at(i));
               }
            }
            break;
         case UeiSessionTypeCI:
            {
               CUeiCounterReader reader(pSession->GetDataStream());
               if(pSession->GetDataStream()->GetSampleSize() == 2)
               {
                  reader.ReadSingleScan((uInt16*)buffers.at(i));
               }
               else
               {
                  reader.ReadSingleScan((uInt32*)buffers.at(i));
               }
            }
            break;
         }
      }

      // Stop all sessions
      for(it=sessions.begin(); it!= sessions.end(); it++)
      {
         (*it)->Stop();
      }
   }
   catch(CUeiException& e)
   {
      std::cerr << "Error enumerating sessions: " << e.GetErrorMessage() << std::endl;
      return -1;
   }

   // delete sessions and buffers
   for(int i=0; i<(int)sessions.size(); i++)
   {
      delete sessions[i];
      delete buffers[i];
   }

	return 0;
}

