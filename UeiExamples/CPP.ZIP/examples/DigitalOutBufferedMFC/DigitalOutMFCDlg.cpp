// DigitalOutMFCDlg.cpp : implementation file
//

#include "stdafx.h"
#include <math.h>
#include "DigitalOutMFC.h"
#include "DigitalOutMFCDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define WM_UPDATE_STATUS   (WM_USER+1)

void GenerateSinPattern(uInt16* pBuffer, int nbChannels, int nbSamplePerChannel, int iteration);


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CDigitalOutMFCDlg dialog



CDigitalOutMFCDlg::CDigitalOutMFCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDigitalOutMFCDlg::IDD, pParent)
   , m_Amplitude(0)
   , m_NbCycles(0)
   , m_Resource(_T(""))
   , m_NbUpdates(0)
   , m_Frequency(0)
   , m_TotalUpdates(0)
   , m_AvailUpdates(0)
   , m_pWriter(NULL)
   , m_pData(NULL)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDigitalOutMFCDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   DDX_Text(pDX, IDC_AMPLITUDE, m_Amplitude);
   DDV_MinMaxDouble(pDX, m_Amplitude, -10, 10);
   DDX_Text(pDX, IDC_NBCYCLES, m_NbCycles);
   DDV_MinMaxInt(pDX, m_NbCycles, 1, 100000);
   DDX_Text(pDX, IDC_RESOURCE, m_Resource);
   DDX_Text(pDX, IDC_NBUPDATES, m_NbUpdates);
   DDX_Text(pDX, IDC_FREQUENCY, m_Frequency);
   DDV_MinMaxDouble(pDX, m_Frequency, 1, 1000000);
   DDX_Text(pDX, IDC_NBUPDATES_STATUS, m_TotalUpdates);
   DDX_Text(pDX, IDC_NBUPDATEDAVAILABLE, m_AvailUpdates);
   DDX_Control(pDX, IDC_DURATION, m_Duration);
   DDX_Control(pDX, IDC_TRIGGER, m_Trigger);
   DDX_Control(pDX, IDC_REGENERATE, m_Regenerate);
   DDX_Control(pDX, IDC_LOG, m_Log);
   DDX_Control(pDX, IDC_SINUS_WFM, m_SinusWfm);
   DDX_Control(pDX, IDC_TRIANGLE_WFM, m_TriangleWfm);
   DDX_Control(pDX, IDC_SQUARE_WFM, m_SquareWfm);
   DDX_Control(pDX, IDC_SAWTOOTH_WFM, m_SawtoothWfm);
}

BEGIN_MESSAGE_MAP(CDigitalOutMFCDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
   ON_BN_CLICKED(IDC_START, OnBnClickedStart)
   ON_BN_CLICKED(IDC_STOP, OnBnClickedStop)
   ON_WM_DESTROY()
   ON_MESSAGE(WM_UPDATE_STATUS, OnUpdateStatus)
END_MESSAGE_MAP()


// CDigitalOutMFCDlg message handlers

BOOL CDigitalOutMFCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_Resource = "simu://Dev2/Do0:1";
   m_NbUpdates = 1000;
   m_Frequency = 50000;
   m_Duration.SetCheck(1);
   m_Trigger.SetCheck(0);
   m_AvailUpdates = 0;
   m_TotalUpdates = 0;
   m_Amplitude = 10.0;
   m_NbCycles = 1;
   m_wfmType = WaveformSinus;
   m_SinusWfm.SetCheck(1);

   UpdateData(FALSE);

   GetDlgItem(IDC_START)->EnableWindow(TRUE);
   GetDlgItem(IDC_STOP)->EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDigitalOutMFCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDigitalOutMFCDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDigitalOutMFCDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CDigitalOutMFCDlg::OnEvent(tUeiEvent event, void *param)
{
   static count = 0;
   try
   {
      if(event == UeiEventFrameDone)
      {
         GenerateSinPattern(m_pData, m_Session.GetNumberOfChannels(), m_NbUpdates, count);

         int totalUpdates = m_Session.GetDataStream()->GetTotalScans();
         int availUpdates = m_Session.GetDataStream()->GetAvailableScans();
         PostMessage(WM_UPDATE_STATUS, (WPARAM)availUpdates, (LPARAM)totalUpdates); 

         m_pWriter->WriteMultipleScansAsync(m_NbUpdates, m_pData);
      }
      else if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)((INT_PTR)(param));
         throw CUeiException(error);
      }

      count++;
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("OnEvent Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CDigitalOutMFCDlg::OnBnClickedStart()
{
   UpdateData();

   try
   {
      m_Session.CreateDOChannel(LPCSTR(m_Resource));

      tUeiTimingDuration duration;
      if(m_Duration.GetCheck())
         duration = UeiTimingDurationContinuous;
      else
         duration = UeiTimingDurationSingleShot;

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      m_Session.ConfigureTimingForBufferedIO(m_NbUpdates, UeiTimingClockSourceInternal, m_Frequency, UeiDigitalEdgeRising, duration);

      // Create a reader object to read data synchronously.
      m_pWriter = new CUeiDigitalWriter(m_Session.GetDataStream());

      m_pWriter->AddEventListener(this);

      // allocate buffer to receive acquired data
      m_pData = (uInt16*)malloc(m_Session.GetNumberOfChannels() * m_NbUpdates * sizeof(uInt16));

      m_Session.Start();

      //GenerateSinPattern(m_pData, m_Session.GetNumberOfChannels(), m_NbUpdates, 0);
      memset(m_pData, 0xFF, m_Session.GetNumberOfChannels() * m_NbUpdates * sizeof(uInt16));
      m_pWriter->WriteMultipleScansAsync(m_NbUpdates, m_pData);

      GetDlgItem(IDC_START)->EnableWindow(FALSE);
      GetDlgItem(IDC_STOP)->EnableWindow(TRUE);
      m_Log.SetWindowText("");
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("Go Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CDigitalOutMFCDlg::OnBnClickedStop()
{
   try
   {
      if(m_Session.IsRunning())
      {
         m_Session.Stop();
      }
      m_Session.CleanUp();

      if(m_pWriter != NULL)
      {
         delete m_pWriter;
         m_pWriter = NULL;
      }

      if(m_pData != NULL)
      {
         free(m_pData);
         m_pData = NULL;
      }

      GetDlgItem(IDC_START)->EnableWindow(TRUE);
      GetDlgItem(IDC_STOP)->EnableWindow(FALSE);
   }
   catch(CUeiException e)
   {
      CString str;
      str.Format("Stop Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CDigitalOutMFCDlg::OnDestroy()
{
   __super::OnDestroy();

   OnBnClickedStop();
}

LRESULT CDigitalOutMFCDlg::OnUpdateStatus(WPARAM wParam, LPARAM lParam)
{
   m_TotalUpdates = (int)lParam;
   m_AvailUpdates = (int)wParam;

   UpdateData(FALSE);

   return 0;
}

void GenerateSinPattern(uInt16* pBuffer, int nbChannels, int nbSamplePerChannel, int iteration)
{
   int amplitude = (iteration % 10 + 1);

   TRACE("amplitude %d\n", amplitude);

   for(int j=0; j<nbSamplePerChannel; j++)
   {
      for(int k=0; k<nbChannels; k++)
      {
         int outIndex = j * nbChannels;
         int bit_shift = (int)floor((sin(outIndex * 6.28 / nbSamplePerChannel)+1) * amplitude + 0.5);
         pBuffer[outIndex + k] = 1 << bit_shift;
      }
   }
}
