//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DigitalOutMFC.rc
//
#define IDC_STOP                        3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DIGITALOUTMFC_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_START                       1000
#define IDC_SINUS_WFM                   1001
#define IDC_TRIANGLE_WFM                1002
#define IDC_LOG                         1003
#define IDC_RESOURCE                    1004
#define IDC_NBUPDATES                   1005
#define IDC_FREQUENCY                   1006
#define IDC_NBUPDATES_STATUS            1007
#define IDC_NBUPDATEDAVAILABLE          1008
#define IDC_DURATION                    1009
#define IDC_SAWTOOTH_WFM                1010
#define IDC_SQUARE_WFM                  1011
#define IDC_AMPLITUDE                   1012
#define IDC_TRIGGER                     1013
#define IDC_REGENERATE                  1014
#define IDC_AMPLITUDE2                  1015
#define IDC_NBCYCLES                    1015
#define IDC_SPIN1                       1016
#define IDC_SPIN2                       1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
