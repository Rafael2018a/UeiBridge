// DigitalOutMFCDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "UeiDaq.h"

using namespace UeiDaq;

typedef enum _tWaveformType
{
   WaveformMinimum = 0,
   WaveformSinus = WaveformMinimum,
   WaveformTriangle = 1,
   WaveformSawtooth = 2,
   WaveformSquare = 3,
   WaveformDC = 4,
   WaveformMaximum = WaveformDC,
} tWaveformType;

// CDigitalOutMFCDlg dialog
class CDigitalOutMFCDlg : public CDialog, IUeiEventListener
{
// Construction
public:
	CDigitalOutMFCDlg(CWnd* pParent = NULL);	// standard constructor

   void OnEvent(tUeiEvent event, void *param);

// Dialog Data
	enum { IDD = IDD_DIGITALOUTMFC_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
   double m_Amplitude;
   int m_NbCycles;
   CString m_Resource;
   int m_NbUpdates;
   double m_Frequency;
   int m_TotalUpdates;
   int m_AvailUpdates;
   CButton m_Duration;
   CButton m_Trigger;
   CButton m_Regenerate;
   CButton m_SinusWfm;
   CButton m_TriangleWfm;
   CButton m_SquareWfm;
   CButton m_SawtoothWfm;
   tWaveformType m_wfmType;

private:
   CUeiSession m_Session;
   CUeiDigitalWriter *m_pWriter;
   uInt16 *m_pData;
public:
   afx_msg void OnBnClickedStart();
   afx_msg void OnBnClickedStop();
   afx_msg LRESULT OnUpdateStatus(WPARAM wParam, LPARAM lParam);
   afx_msg void OnDestroy();
   CEdit m_Log;
};
