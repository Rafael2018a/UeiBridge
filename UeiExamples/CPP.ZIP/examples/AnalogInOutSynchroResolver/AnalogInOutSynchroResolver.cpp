#include <windows.h>
#include <stdlib.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession aiSs;
   CUeiSession aoSs;
   double* pAiData = NULL;
   double* pAoData = NULL;
   int count = 0;

   try
   {
      // Create Synchro input channel and add it to the AI session 
      // The input channel will provide excitation to the output channel
      aiSs.CreateSynchroResolverChannel("pdna://192.168.1.104/dev0/ai0", 
                              UeiSynchroMode, 
                              7.0, // excitation voltage
                              1400.0, // excitation frequency
                              false); // internal excitation

      // Create simulated Synchro output channel and add it to the AO session
      // The output channel accepts external excitation provided by input channel
      aoSs.CreateSimulatedSynchroResolverChannel("pdna://192.168.1.104/dev0/ao1", 
                                      UeiSynchroMode,
                                      7.0, // excitation voltage
                                      1400.0,// excitation frequency
                                      true); // external excitation

      // Configure the sessions to acquire/generate point by point
      aiSs.ConfigureTimingForSimpleIO();
      aoSs.ConfigureTimingForSimpleIO();

      // Create a reader object to read data synchronously from the data stream.
      CUeiAnalogScaledReader reader(aiSs.GetDataStream());
      CUeiAnalogScaledWriter writer(aoSs.GetDataStream());

      // Allocate buffers to store current frame
      pAiData = new double[aiSs.GetNumberOfChannels()*aiSs.GetDataStream()->GetNumberOfScans()];
      pAoData = new double[aoSs.GetNumberOfChannels()*aoSs.GetDataStream()->GetNumberOfScans()];

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as the reader starts reading data.
      aiSs.Start();
      aoSs.Start();

      while(count < 200)
      {
         int j;
         // generate a ramp from 0 to 2 pi radians
         for(j=0; j<aoSs.GetNumberOfChannels(); j++)
         {
            pAoData[j] = (6.28 * count / 200);
            std::cout << "writing " << "ch" << j << "= " << pAoData[j] << "  ";
         }  
         std::cout << std::endl;

         writer.WriteSingleScan(pAoData);

         Sleep(200);
 
         reader.ReadSingleScan(pAiData);
         for(j=0; j<aiSs.GetNumberOfChannels(); j++)
         {
            std::cout << "reading " << "ch" << j << "= " << pAiData[j] << "  ";
         }
         std::cout << std::endl;

         count++;
      }

      aiSs.Stop();
      aoSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

  if(pAiData != NULL)
  {
     delete[] pAiData;
  }

  if(pAoData != NULL)
  {
     delete[] pAoData;
  }

  return 0;
}