#include <windows.h>
#include <iostream>
#include <math.h>
#include "UeiDaq.h"

using namespace UeiDaq;

CUeiSession mySs;
double* data;
CUeiAnalogScaledWriter* writer;

void GenerateSinWave(double* pBuffer, int nbChannels, int nbSamplePerChannel, int iteration)
{
   int amplitude = (iteration % 10 + 1);

   for(int i=0; i<nbSamplePerChannel; i++)
   {
      for(int j=0; j<nbChannels; j++)
      {
         pBuffer[i*nbChannels+j] = amplitude * sin(2*3.1415*(j+1)*i/nbSamplePerChannel);
      }
   }
}

class CAnalogOutEvent : public IUeiEventListener
{
   void OnEvent(tUeiEvent event, void *param)
   {
      static int count = 0;
      if(event == UeiEventFrameDone)
      {
         try
         {
            std::cout << "event #" << count++ << " received" << std::endl;

            // If regeneration is turned off we can refresh the buffer to generate
            // new data continuously, this call blocks until there is enough
            // room in the buffer to write the required number of samples
            writer->WriteMultipleScansAsync(1000, data);

            // Create a new set of data to be generated next time we get an event
            GenerateSinWave(data, mySs.GetNumberOfChannels(), 1000, 0);         
         }
         catch(CUeiException e)
         {
            std::cout << "Error: " << e.GetErrorMessage() << std::endl;
         }
      }
      else if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)(uintptr_t)param;
         std::cout << "Error: " << CUeiException::TranslateError(error) << std::endl;
      }
   }
};

int main(int argc, char* argv[])
{
   try
   {
      // Create 2 analog output channels on a powerdaq board
      // From now on the session is AO only
      mySs.CreateAOChannel("pwrdaq://Dev0/ao0:7", -10.0, 10.0);

      // Configure the session to generate 1000 scans clocked by internal scan clock
      mySs.ConfigureTimingForBufferedIO(1000, UeiTimingClockSourceInternal, 10000.0, UeiDigitalEdgeRising, UeiTimingDurationContinuous);

      // Allocate a buffer to hold each generated frame
      data = new double[mySs.GetNumberOfChannels()*mySs.GetDataStream()->GetNumberOfScans()];

      // Create a reader object to read data synchronously.
      writer = new CUeiAnalogScaledWriter(mySs.GetDataStream());

      // Configure an asynchronous event handler that will be called
      // by the writer object each time the required number of scans has been generated
      CAnalogOutEvent eventListener;
      writer->AddEventListener(&eventListener);

      // Start the generation
      mySs.Start();

      // Fill the buffer
      GenerateSinWave(data, mySs.GetNumberOfChannels(), 1000, 0);
      writer->WriteMultipleScansAsync(1000, data);

      // Data transfer is done asynchronously
      // Press the Enter key to end the generation
      std::cout << "Press 'Enter' to stop the generation." << std::endl;
      getchar();

      mySs.Stop();

      delete writer;
      delete[] data;
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}