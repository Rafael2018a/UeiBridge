#include <windows.h>
#include <process.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include "UeiDaq.h"
#include "UeiFrameUtils.h"

using namespace UeiDaq;
using namespace std;

int main(int argc, char* argv[])
   {
      int error = 0;
      CUeiSession session;
      int channels = 1;
      int startRt = 1;
      int startSa = 1;
      int messageSize = 32;
      uInt16 data[32];
      uInt32 init_num = 0x300;
      Int32 numFramesWritten;

      int cycles = 10;
      CUeiDevice* pDevice = NULL;
      try
      {
         // port 0 - remote terminal
         CUeiMIL1553Port* pPort0 = session.CreateMIL1553Port(
                                          "pdna://192.168.100.4/Dev7/MILB0",
                                          UeiMIL1553CouplingTransformer,
                                          UeiMIL1553OpModeBusMonitor
                                          );

         session.ConfigureTimingForMessagingIO(1, 0);
         session.GetTiming()->SetTimeout(1);

         pDevice = session.GetDevice();
         pDevice->GetStatus();

         // create one reader and one writer per each port
         CUeiMIL1553Reader* reader = new CUeiMIL1553Reader(session.GetDataStream(), session.GetChannel(0)->GetIndex());
         CUeiMIL1553Writer* writer = new CUeiMIL1553Writer(session.GetDataStream(), session.GetChannel(0)->GetIndex());

         CUeiMIL1553BusWriterFrame* outFrm;
         CUeiMIL1553BMFrame* bmFrm;
         CUeiMIL1553FilterEntry* filterFrm;

         outFrm = new CUeiMIL1553BusWriterFrame;
         bmFrm = new CUeiMIL1553BMFrame;
         filterFrm = new CUeiMIL1553FilterEntry;
 
         // Set UP RT/SAs we want to operate
         pPort0->ClearFilterEntries();
         filterFrm->Set(UeiMIL1553FilterByRt, startRt, startSa);
         filterFrm->EnableCommands(TRUE, TRUE, TRUE);
         pPort0->AddFilterEntry(*filterFrm);
         pPort0->EnableFilter(TRUE);
        
         // Find the DNx-1553-553-Manual.pdf
         string pdna_path = getenv ("PDNAROOT");
         int pos = pdna_path.find("SDK");
         string doc_path = "Documentation\\DNx-1553-553-Manual.pdf";
         pdna_path.replace(pos, sizeof(doc_path), doc_path);
         // Fix the path separator
         pos = pdna_path.find("\\");
         while(pos != std::string::npos){
            pdna_path.replace(pos, sizeof('/'), "/" );
            pos = pdna_path.find("\\");
         }   
         // Copy string path into char
         char * char_pdna_path;
         char_pdna_path = new char[pdna_path.length() + 1];
         strcpy(char_pdna_path, pdna_path.c_str());
         cout << char_pdna_path << endl;
         // Open DNx-1553-553-Manual.pdf and load it into memory
         ifstream::pos_type size;
         unsigned short * memblock;
         ifstream file(char_pdna_path, ios::in|ios::binary|ios::ate);
         if (file.is_open())
         {
             // Read file into a byte array      
             size = file.tellg();
             memblock = new unsigned short [size];
             file.seekg (0, ios::beg);
             file.read ((char*)memblock, size);
             file.close();
             outFrm->SetCommand(startRt, startSa, messageSize, UeiMIL1553CmdBCRT);
             int i = 0;
             fpos_t fsize16 = size.seekpos()/sizeof(unsigned short);
             //pack 2 bytes into each word
             for (Int32 c = 0; c < (int)fsize16; c++) {
                 data[i] = (uInt16)memblock[c];
                 if(i == 31) {
                     //BC-RT 32 words
                     i = 0;
                     outFrm->CopyData(messageSize, data);            
                     writer->Write(1, outFrm, &numFramesWritten);
                     cout << c*2 << " of " << size << '\xd';
                     //do {
                     //    Int32 numFramesRead;
                     //    reader->Read(1, bmFrm, &numFramesRead);
                     //    if (numFramesRead) cout << "BM:" << bmFrm->GetBmMessageStr() << std::endl;
                     //    if (numFramesRead) cout << bmFrm->GetBmDataStr() << std::endl;
                     //} while (numFramesRead);
                 } else {
                     i++;
                 }
             }
         }
         else {
             cout << "Unable to open file";
             std::getchar();
         }



   //dataError:

        session.Stop();
        delete reader;
        delete writer;


      }
      catch(CUeiException& e)
      {
         cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
         error = e.GetError();
      }

      session.CleanUp();

      return 0;
   }