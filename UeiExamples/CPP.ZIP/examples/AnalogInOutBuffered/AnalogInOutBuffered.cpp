#include <windows.h>
#include <stdlib.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession aiSs;
   CUeiSession aoSs;
   double* pAiData = NULL;
   double* pAoData = NULL;
   int count = 0;

   try
   {
      // Create analog input channels and add them to the AI session 
      aiSs.CreateAIChannel("pwrdaq://192.168.100.2/Dev1/ai0:7", -10.0, 10.0, UeiAIChannelInputModeSingleEnded);

      // Create analog output channels and add them to the AO session
      aoSs.CreateAOChannel("pwrdaq://192.168.100.2/Dev0/ao0:7", -10.0, 10.0);

      // Configure the sessions to acquire/generate 1000 scans timed by the internal clock
      aiSs.ConfigureTimingForBufferedIO(6000, UeiTimingClockSourceInternal, 60000.0, UeiDigitalEdgeRising, UeiTimingDurationContinuous);
      aoSs.ConfigureTimingForBufferedIO(6000, UeiTimingClockSourceInternal, 60000.0, UeiDigitalEdgeRising, UeiTimingDurationContinuous);

      // The internal frame size and number of frames is automatically calculated
      // We can override it with the following function calls
      // aiSs.GetDataStream()->SetFrameSize(500);
      // aiSs.GetDataStream()->SetNumberOfFrames(2);

      // Create a reader object to read data synchronously from the data stream.
      CUeiAnalogScaledReader reader(aiSs.GetDataStream());
      CUeiAnalogScaledWriter writer(aoSs.GetDataStream());

      // Allocate buffers to store current frame
      pAiData = new double[aiSs.GetNumberOfChannels()*aiSs.GetDataStream()->GetNumberOfScans()];
      pAoData = new double[aoSs.GetNumberOfChannels()*aoSs.GetDataStream()->GetNumberOfScans()];

      writer.WriteMultipleScans(aoSs.GetDataStream()->GetNumberOfScans(), pAoData);

      // Start the acquisition, this is optional because the acquisition starts
      // automatically as soon as the reader starts reading data.
      aiSs.Start();
      aoSs.Start();

      // Acquire 20 frames then stop
      while(count < 200)
      {
         // Write acquired data back to the analog outputs
         writer.WriteMultipleScans(aoSs.GetDataStream()->GetNumberOfScans(), pAoData);

         reader.ReadMultipleScans(aiSs.GetDataStream()->GetNumberOfScans(), pAiData);

         Sleep(30);

         for(int i=0; i<aiSs.GetNumberOfChannels();i++)
         {
            std::cout << "ch" << i << " = " << pAiData[i] << "V, ";
         }

         // Copy Ai buffer to ao buffer if both sessions use the same number of channels
         if(aiSs.GetDataStream()->GetNumberOfScans() ==
            aoSs.GetDataStream()->GetNumberOfScans())
         {
            memcpy(pAoData, pAiData, aiSs.GetNumberOfChannels()*aiSs.GetDataStream()->GetNumberOfScans()*sizeof(double));
         }

         std::cout << std::endl;
         count++;
      }

      aiSs.Stop();
      aoSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

  if(pAiData != NULL)
  {
     delete[] pAiData;
  }

  if(pAoData != NULL)
  {
     delete[] pAoData;
  }

  return 0;
}