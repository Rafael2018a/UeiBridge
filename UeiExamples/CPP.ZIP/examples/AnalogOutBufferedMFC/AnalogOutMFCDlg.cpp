// AnalogOutMFCDlg.cpp : implementation file
//

#include "stdafx.h"
#include <math.h>
#include "AnalogOutMFC.h"
#include "AnalogOutMFCDlg.h"
#include ".\analogoutmfcdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define WM_UPDATE_STATUS   (WM_USER+1)

void GenerateWaveform(double* pBuffer, int numChannels, int numScans, int numSamplesPerCycle,
                      double amplitude, tWaveformType wfmType, double* phases);

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CAnalogOutMFCDlg dialog



CAnalogOutMFCDlg::CAnalogOutMFCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAnalogOutMFCDlg::IDD, pParent)
   , m_Amplitude(0)
   , m_NbCycles(0)
   , m_Resource(_T(""))
   , m_NbUpdates(0)
   , m_Frequency(0)
   , m_TotalUpdates(0)
   , m_AvailUpdates(0)
   , m_pWriter(NULL)
   , m_pData(NULL)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAnalogOutMFCDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   DDX_Text(pDX, IDC_AMPLITUDE, m_Amplitude);
   DDV_MinMaxDouble(pDX, m_Amplitude, -10, 10);
   DDX_Text(pDX, IDC_NBCYCLES, m_NbCycles);
   DDV_MinMaxInt(pDX, m_NbCycles, 1, 100000);
   DDX_Text(pDX, IDC_RESOURCE, m_Resource);
   DDX_Text(pDX, IDC_NBUPDATES, m_NbUpdates);
   DDX_Text(pDX, IDC_FREQUENCY, m_Frequency);
   DDV_MinMaxDouble(pDX, m_Frequency, 1, 1000000);
   DDX_Text(pDX, IDC_NBUPDATES_STATUS, m_TotalUpdates);
   DDX_Text(pDX, IDC_NBUPDATEDAVAILABLE, m_AvailUpdates);
   DDX_Control(pDX, IDC_DURATION, m_Duration);
   DDX_Control(pDX, IDC_TRIGGER, m_Trigger);
   DDX_Control(pDX, IDC_REGENERATE, m_Regenerate);
   DDX_Control(pDX, IDC_LOG, m_Log);
   DDX_Control(pDX, IDC_SINUS_WFM, m_SinusWfm);
   DDX_Control(pDX, IDC_TRIANGLE_WFM, m_TriangleWfm);
   DDX_Control(pDX, IDC_SQUARE_WFM, m_SquareWfm);
   DDX_Control(pDX, IDC_SAWTOOTH_WFM, m_SawtoothWfm);
}

BEGIN_MESSAGE_MAP(CAnalogOutMFCDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
   ON_BN_CLICKED(IDC_START, OnBnClickedStart)
   ON_BN_CLICKED(IDC_STOP, OnBnClickedStop)
   ON_WM_DESTROY()
   ON_MESSAGE(WM_UPDATE_STATUS, OnUpdateStatus)
END_MESSAGE_MAP()


// CAnalogOutMFCDlg message handlers

BOOL CAnalogOutMFCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_Resource = "simu://Dev0/Ao0:1";
   m_NbUpdates = 1000;
   m_Frequency = 50000;
   m_Duration.SetCheck(1);
   m_Trigger.SetCheck(0);
   m_AvailUpdates = 0;
   m_TotalUpdates = 0;
   m_Amplitude = 10.0;
   m_NbCycles = 1;
   m_wfmType = WaveformSinus;
   m_SinusWfm.SetCheck(1);
   memset(m_Phases, 0, 64*sizeof(double));

   UpdateData(FALSE);

   GetDlgItem(IDC_START)->EnableWindow(TRUE);
   GetDlgItem(IDC_STOP)->EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CAnalogOutMFCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAnalogOutMFCDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAnalogOutMFCDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CAnalogOutMFCDlg::OnEvent(tUeiEvent event, void *param)
{
   static count = 0;
   try
   {
      if(event == UeiEventFrameDone)
      {
         GenerateWaveform(m_pData, m_Session.GetNumberOfChannels(), m_NbUpdates, 100,
                      m_Amplitude, m_wfmType, m_Phases);
         
         int totalUpdates = m_Session.GetDataStream()->GetTotalScans();
         int availUpdates = m_Session.GetDataStream()->GetAvailableScans();
         PostMessage(WM_UPDATE_STATUS, (WPARAM)availUpdates, (LPARAM)totalUpdates); 

         m_pWriter->WriteMultipleScansAsync(m_NbUpdates, m_pData);
      }
      else if(event == UeiEventError)
      {
         tUeiError error = (tUeiError)((INT_PTR)(param));
         throw CUeiException(error);
      }

      count++;
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("OnEvent Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CAnalogOutMFCDlg::OnBnClickedStart()
{
   UpdateData();

   try
   {
      m_Session.CreateAOChannel(LPCSTR(m_Resource), -10.0, 10.0);

      tUeiTimingDuration duration;
      if(m_Duration.GetCheck())
         duration = UeiTimingDurationContinuous;
      else
         duration = UeiTimingDurationSingleShot;

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      m_Session.ConfigureTimingForBufferedIO(m_NbUpdates, UeiTimingClockSourceInternal, m_Frequency, UeiDigitalEdgeRising, duration);

      // Create a reader object to read data synchronously.
      m_pWriter = new CUeiAnalogScaledWriter(m_Session.GetDataStream());

      m_pWriter->AddEventListener(this);

      // allocate buffer to receive acquired data
      m_pData = (double*)malloc(m_Session.GetNumberOfChannels() * m_NbUpdates * sizeof(double));

      m_Session.Start();

      m_pWriter->WriteMultipleScansAsync(m_NbUpdates, m_pData);

      GetDlgItem(IDC_START)->EnableWindow(FALSE);
      GetDlgItem(IDC_STOP)->EnableWindow(TRUE);
      m_Log.SetWindowText("");
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("Go Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CAnalogOutMFCDlg::OnBnClickedStop()
{
   try
   {
      if(m_Session.IsRunning())
      {
         m_Session.Stop();
      }
      m_Session.CleanUp();

      if(m_pWriter != NULL)
      {
         delete m_pWriter;
         m_pWriter = NULL;
      }

      if(m_pData != NULL)
      {
         free(m_pData);
         m_pData = NULL;
      }

      GetDlgItem(IDC_START)->EnableWindow(TRUE);
      GetDlgItem(IDC_STOP)->EnableWindow(FALSE);
   }
   catch(CUeiException e)
   {
      CString str;
      str.Format("Stop Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log.SetWindowText(str);
   }
}

void CAnalogOutMFCDlg::OnDestroy()
{
   __super::OnDestroy();

   OnBnClickedStop();
}

LRESULT CAnalogOutMFCDlg::OnUpdateStatus(WPARAM wParam, LPARAM lParam)
{
   m_TotalUpdates = (int)lParam;
   m_AvailUpdates = (int)wParam;

   m_wfmType = GetWfmType();

   UpdateData(FALSE);

   return 0;
}

tWaveformType CAnalogOutMFCDlg::GetWfmType()
{
   tWaveformType wfmType = WaveformSinus;
   if(m_SinusWfm.GetCheck())
   {
      wfmType = WaveformSinus;
   }
   else if(m_SquareWfm.GetCheck())
   {
      wfmType = WaveformSquare;
   }
   else if(m_TriangleWfm.GetCheck())
   {
      wfmType = WaveformTriangle;
   }
   else if(m_SawtoothWfm.GetCheck())
   {
      wfmType = WaveformSawtooth;
   }

   return wfmType;
}

void GenerateWaveform(double* pBuffer, int numChannels, int numScans, int numSamplesPerCycle,
                      double amplitude, tWaveformType wfmType, double* phases)
{
   double omega[128];
   double value = 0.0;
   
   for(int i=0; i<numScans; i++)
   {
      for(int j=0; j<numChannels; j++)
      {
         if(wfmType == WaveformSinus)
         {
            omega[j] = phases[j] + 2*3.1415*((j+1)*(i+1))/numSamplesPerCycle;
            value = amplitude * sin(omega[j]);
         }
         else if(wfmType == WaveformTriangle)
         {
            omega[j] = fmod(phases[j]+(j+1)*(i+1),(double)numSamplesPerCycle);
            if(omega[j] < numSamplesPerCycle/2)
            {
               value = amplitude * 4.0 * (omega[j] / numSamplesPerCycle) - amplitude;
            }
            else
            {
               value = amplitude * 4.0 * (1.0-(omega[j] / numSamplesPerCycle)) - amplitude;
            }
         }
         else if(wfmType == WaveformSawtooth)
         {
            omega[j] = fmod(phases[j]+(j+1)*(i+1),(double)numSamplesPerCycle);
            value = amplitude * 2.0 * (omega[j] / numSamplesPerCycle) - amplitude;
         }
         else if(wfmType == WaveformSquare)
         {
            omega[j] = fmod(phases[j]+(j+1)*(i+1),(double)numSamplesPerCycle);
            if(omega[j] < numSamplesPerCycle/2)
            {
               value = amplitude;
            }
            else
            {
               value = -amplitude;
            }
         }
         else if(wfmType == WaveformDC)
         {
            value = amplitude;
         }

         pBuffer[i*numChannels+j] = value;
      }
   }

   // Keep latest phases
   for(int j=0; j<numChannels; j++)
   {
      phases[j] = omega[j];
   }
}
