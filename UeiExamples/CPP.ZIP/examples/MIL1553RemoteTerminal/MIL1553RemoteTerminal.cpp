#include <windows.h>
#include <process.h>
#include <iostream>
#include <sstream>
#include "UeiDaq.h"

using namespace UeiDaq;

#define CHANNEL    0    // channel 0 to use
#define CHANNELS   1    // total channels
#define FRAMES     2    // number of CUeiMIL1553RTFrame

// This example programs MIL-1553 RT and BM on channel 0
// It continuously update "transmit" area of RT
// External BC is responsible for sending commands to the programmed RT
int main(int argc, char* argv[])
{
   std::string status;
   int error = 0;
   CUeiSession session;
   int i, j, ch;
   int startRt = 4;
   int startSa = 4;
   int numInputPorts = CHANNELS;
   int numOutputPorts = CHANNELS;
   int WordCount = 10;
   uInt32 init_num = 0x300;
   uInt16 data16[32];
   Int32 numFramesWritten, numFramesRead;
   int rt_chan = 0;

   int cycles = 10;
   CUeiDevice* pDevice = NULL;
   try
   {
      std::ostringstream rt_resource;
      std::string device_resource = "pdna://192.168.100.2/dev0";

      rt_resource << device_resource << "/milb" << rt_chan << std::ends;

      // Configure port as remote terminal
      CUeiMIL1553Port* pPort0 = session.CreateMIL1553Port(rt_resource.str(),
                                                          UeiMIL1553CouplingTransformer,
                                                          UeiMIL1553OpModeRemoteTerminal);

      session.ConfigureTimingForMessagingIO(1, 0);
      session.GetTiming()->SetTimeout(100);

      // Get device status information
      pDevice = session.GetDevice();
      status = pDevice->GetStatus();
      std::cout << "status: " << status << std::endl;

      // create one reader and one writer per each port
      CUeiMIL1553Writer** writers = new CUeiMIL1553Writer*[CHANNELS]; 
      CUeiMIL1553Reader** readers = new CUeiMIL1553Reader*[CHANNELS];

      readers[CHANNEL] = new CUeiMIL1553Reader(session.GetDataStream(), session.GetChannel(CHANNEL)->GetIndex());
      writers[CHANNEL] = new CUeiMIL1553Writer(session.GetDataStream(), session.GetChannel(CHANNEL)->GetIndex());

      // First, configure remote terminal on channel 1
      CUeiMIL1553RTFrame* inFrm[FRAMES];
      CUeiMIL1553RTFrame* outFrm[FRAMES];
      CUeiMIL1553BMFrame* bmFrm;
      for (j = 0; j < FRAMES; j++) 
      {
         inFrm[j] = new CUeiMIL1553RTFrame(startRt+j, startSa, 0, WordCount);
         outFrm[j] = new CUeiMIL1553RTFrame(startRt+j, startSa, 0, WordCount);
      }
      bmFrm = new CUeiMIL1553BMFrame;

      // Start RTs - all SAs will be started at this time
      for (i = 0; i < WordCount; i++) data16[i] = (uInt16)(1 + i);
      for (j = 0; j < FRAMES; j++) 
      {
         outFrm[j]->CopyData(WordCount, data16);
         writers[CHANNEL]->Write(1, outFrm[j], &numFramesWritten);
      }

      // In cycle
      cycles = 10000;
      for (Int32 c = 0; (cycles>0)?c < cycles:1; c++)  
      {
         Sleep(1000);

         // Change and retreive RT data each iteration
         // Store data to RT "transmit" area
         for (j = 0; j < FRAMES; j++) {
            for (i = 0; i < WordCount; i++) data16[i] = (uInt16)(c + i);
            outFrm[j]->CopyData(WordCount, data16);
            writers[CHANNEL]->Write(1, outFrm[j], &numFramesWritten);   

            // Read data from RT "receive" area
            readers[CHANNEL]->Read(1, inFrm[j], &numFramesRead);    
            std::cout << "RT= " << inFrm[j]->GetFrameStr() << " Data: " << inFrm[j]->GetDataStr() << std::endl;
         }
         // Read bus monitor and display bus activity
         for (i = 0; i < 10; i++) {
            std::cout << ".";
            readers[CHANNEL]->Read(1, bmFrm, &numFramesRead);
            if (numFramesRead)  std::cout << bmFrm->GetBmDataStr() << std::endl;
            else break;
         };
         std::cout << "====================================================" << std::endl << std::endl;
         std::cout << "iteration (" << c << ")" << std::endl;
      }

      session.Stop();
      for(ch=0; ch<numInputPorts; ch++)
      {
         delete readers[ch];
      }
      delete[] readers;

      for(ch=0; ch<numOutputPorts; ch++)
      {
         delete writers[ch];
      }      
      delete[] writers;
   }
   catch(CUeiException& e)
   {
      std::cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}