#include <windows.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession tcSimSession;
   CUeiSession guardianSession;

   try
   {
      // Create TC simulation session with 8 channels.
      tcSimSession.CreateSimulatedTCChannel("pdna://192.168.100.2/dev5/ao0:7",
                                             UeiThermocoupleTypeK, UeiTemperatureScaleCelsius, true);
      tcSimSession.ConfigureTimingForSimpleIO();

      // Create 3 AI channels for each output channel to read diagnostics
      // Each TC output channel is associated with three guardian channels starting at offset tc_chan * 8
      guardianSession.CreateAIChannel("pdna://192.168.100.2/dev5/ai0:2,8:10,16:18,24:26,32:34,40:42,48:50,56:58", -10.0, 10.0, UeiAIChannelInputModeDifferential);
      guardianSession.ConfigureTimingForSimpleIO();

      // Create a writer to update the output channels
      CUeiAnalogScaledWriter writer(tcSimSession.GetDataStream());
      
      double* aoData = new double[tcSimSession.GetNumberOfChannels()];

      // Create a circuit breaker object per output channel to monitor circuit breaker status and eventually reset them
      CUeiCircuitBreaker** cbs = new CUeiCircuitBreaker*[tcSimSession.GetNumberOfChannels()];
      int* breakCount = new int[tcSimSession.GetNumberOfChannels()];
      for (int ch = 0; ch < tcSimSession.GetNumberOfChannels(); ch++)
      {
         cbs[ch] = new CUeiCircuitBreaker(tcSimSession.GetDataStream(), tcSimSession.GetChannel(ch)->GetIndex());
         breakCount[ch] = 0;
      }

      // Create a reader to retrieve diagnostics
      CUeiAnalogScaledReader guardianReader(guardianSession.GetDataStream());
      double* diagData = new double[guardianSession.GetNumberOfChannels()];

      tcSimSession.Start();
      guardianSession.Start();

      int count = 0;
      bool stop = false;
      while (!stop)
      {
         // Update outputs on each channel
         for (int ch = 0; ch < tcSimSession.GetNumberOfChannels(); ch++)
         {
            // vary temperature from -100 to +100
            aoData[ch] = -100 + (count % 200);
         }
         writer.WriteSingleScan(aoData);

         // Read and display diagnostics
         guardianReader.ReadSingleScan(diagData);

         for (int ch = 0; ch < tcSimSession.GetNumberOfChannels(); ch++)
         {
            std::cout << "Output Channel " << tcSimSession.GetChannel(ch)->GetIndex() << " diagnostics:" << std::endl;
            std::cout << "  Current = " << diagData[ch * 3] << std::endl;
            std::cout << "  Voltage = " << diagData[ch * 3 + 1] << std::endl;
            std::cout << "  ADC internal temperature = " << diagData[ch * 3 + 2] << std::endl;

            // Monitor CB status
            uInt32 currStatus = 0, stickyStatus = 0;
            cbs[ch]->ReadStatus(&currStatus, &stickyStatus);

            if ((currStatus & (1U << tcSimSession.GetChannel(ch)->GetIndex())) > 0)
            {
               breakCount[ch]++;
            }

            std::cout << "  CB Status: curr = " << std::hex << currStatus << " sticky = " << stickyStatus << std::dec << std::endl;

            // reset breaker after 5 iterations
            if (breakCount[ch] > 5)
            {
               std::cout << "Resetting breaker for channel " << tcSimSession.GetChannel(ch)->GetIndex() << std::endl;
               //cbs[ch]->Reset(1U << aoSession.GetChannel(ch)->GetIndex());
               breakCount[ch] = 0;
            }
         }

         Sleep(500);
         count++;
      }

      tcSimSession.Stop();
      guardianSession.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }



   return 0;
}



