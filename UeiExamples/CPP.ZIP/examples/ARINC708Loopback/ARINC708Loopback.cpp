#include <windows.h>
#include <process.h>
#include <iostream>
#include "UeiDaq.h"
#include "UeiFrameUtils.h"

using namespace UeiDaq;
using namespace std;

#define NUM_FRM         2
#define MESSAGE_SIZE    100


int main(int argc, char* argv[])
{
   int error = 0;
   CUeiSession session;
   int i;
   int channels = 1;
   int messageSize;
   Int32 numFramesWritten, numFramesRead;

   int cycles = 1000;
   CUeiDevice* pDevice = NULL;
   try
   {
      // port 0 - writer
      CUeiMIL1553Port* pPort0 = session.CreateMIL1553Port(
         "pdna://192.168.100.2/dev0/milb0,1",
         UeiMIL1553CouplingTransformer,
         UeiMIL1553OpModeARINC708
         );

      session.ConfigureTimingForMessagingIO(1, 0);
      session.GetTiming()->SetTimeout(2000);

      pDevice = session.GetDevice();
      pDevice->GetStatus();

      for(int ch=0; ch<session.GetNumberOfChannels(); ch++) {
        CUeiMIL1553Port* pPort = dynamic_cast<CUeiMIL1553Port*>(session.GetChannel(ch));
        pPort->SetA708FrameSize(MESSAGE_SIZE);  // 100 uint16s = 1600 bits is default
        messageSize = pPort->GetA708FrameSize();
        pPort->SetRxBus(UeiMIL1553OpModeBusA);
      }


      // create one reader and one writer (on different ports!_
      CUeiMIL1553Writer* writer = new CUeiMIL1553Writer(session.GetDataStream(), session.GetChannel(1)->GetIndex());
      CUeiMIL1553Reader* reader = new CUeiMIL1553Reader(session.GetDataStream(), session.GetChannel(0)->GetIndex());

      CUeiMIL1553A708DataFrame* outFrm;
      CUeiMIL1553A708DataFrame* inFrm;
      CUeiMIL1553A708ControlFrame* ctrlFrame;

      outFrm = new CUeiMIL1553A708DataFrame[6];
      inFrm = new CUeiMIL1553A708DataFrame[6];
      ctrlFrame = new CUeiMIL1553A708ControlFrame;

      // In cycle: we use FIFO mode for both input and output
      for (Int32 c = 0; (cycles>0)?c < cycles:1; c++) {

         // store one frame worth of output data
         for (int idx = 0; idx < NUM_FRM; idx++) {
            for (i = 0; i < messageSize; i++) 
                outFrm[idx].data[i] = (uInt16)((idx<<8) + (i&0xff));
            outFrm[idx].DataSize = messageSize;
         }
         Sleep(100);
         writer->Write(1, outFrm, &numFramesWritten);
         //writer->Write(1, outFrm, &numFramesWritten);

         // Wait and get back received data
         std::cout << "-------" << c << "-------" << std::endl;;
         continue;
         Sleep(10);
         do {
            reader->Read(NUM_FRM, inFrm, &numFramesRead);
            if (numFramesRead) {
                std::cout << "(" << numFramesRead << ") "; 

                for (int idx = 0; idx < numFramesRead; idx++) {
                    for (Int32 ii = 0; ii < messageSize; ii++)
                        std::cout << "+++" << std::hex << inFrm[idx].data[ii] << "}";
                    std::cout << std::dec << std::endl;
                }
            } 
         } while (numFramesRead);

         Sleep(500);
      }

      session.Stop();

      delete reader;
      delete writer;
   }
   catch(CUeiException& e)
   {
      cout << "Error " << std::hex << e.GetError() << ": " << e.GetErrorMessage() << std::endl;
      error = e.GetError();
   }

   session.CleanUp();

   return 0;
}