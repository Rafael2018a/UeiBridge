#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;


int main(int argc, char* argv[])
{
   CUeiSession mySs;
   double* data;

   try
   {
      // Create 2 analog output channels on a powerdaq board
      // From now on the session is AO only
      mySs.CreateAOChannel("simu://Dev0/ao0:1", -10.0, 10.0);

      // Configure the session to generate 1000 scans clocked by internal scan clock
      // The generation will happen only once
      mySs.ConfigureTimingForBufferedIO(1000, UeiTimingClockSourceInternal, 10000.0, UeiDigitalEdgeRising, UeiTimingDurationSingleShot);

      // Allocate a buffer to hold each generated frame
      data = new double[mySs.GetNumberOfChannels()*mySs.GetDataStream()->GetNumberOfScans()];

      // Create a reader object to read data synchronously.
      CUeiAnalogScaledWriter writer(mySs.GetDataStream());

      // Fill the buffer before starting generation
      writer.WriteMultipleScans(1000, data);

      // Start the generation
      mySs.Start();

      // Wait until all scans are generated
      while(mySs.IsRunning())
      {
      };

      mySs.Stop();

      delete[] data;
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}