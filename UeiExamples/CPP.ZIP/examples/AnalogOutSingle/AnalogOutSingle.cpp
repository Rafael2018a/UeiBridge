#include <iostream>
#include <cmath>
#include "UeiDaq.h"

using namespace UeiDaq;

void GenerateSinWave(double* pBuffer, int nbChannels, int nbSamplePerChannel, int iteration)
{
   int amplitude = (iteration % 10 + 1);

   for(int i=0; i<nbSamplePerChannel; i++)
   {
      for(int j=0; j<nbChannels; j++)
      {
         pBuffer[i*nbChannels+j] = amplitude * sin(2*3.1415*(j+1)*i/nbSamplePerChannel);
      }
   }
}

int main(int argc, char* argv[])
{
   CUeiSession mySs;
   double* data;

   try
   {
      // Create 2 analog output channels on a powerdaq board
      // From now on the session is AO only
      mySs.CreateAOChannel("pwrdaq://Dev0/ao0:1", -10.0, 10.0);

      mySs.ConfigureTimingForSimpleIO();

      // Create a reader object to read data synchronously.
      CUeiAnalogScaledWriter writer(mySs.GetDataStream());

      // Allocate a buffer to hold data to generate
      data = new double[mySs.GetNumberOfChannels()*100];
      
      GenerateSinWave(data, mySs.GetNumberOfChannels(), 100, 0);

      // Generates all points in the buffer
      for(int i=0; i<100; i++)
      {
         std::cout << "Generating scan " << i << std::endl;
         writer.WriteSingleScan(&data[i*2]);
      }

      delete[] data;
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   return 0;
}