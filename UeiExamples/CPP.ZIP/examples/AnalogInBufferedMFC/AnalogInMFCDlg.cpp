// AnalogInMFCDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AnalogInMFC.h"
#include "AnalogInMFCDlg.h"
#include ".\analoginmfcdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define WM_UPDATE_STATUS   (WM_USER+1)

#define SW_TRIGGER_LEVEL_MULTIPLIER 10000

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CAnalogInMFCDlg dialog



CAnalogInMFCDlg::CAnalogInMFCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAnalogInMFCDlg::IDD, pParent),
   m_pReader(NULL),
   m_pData(NULL)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

   m_NbScans= 1000;
   m_Frequency = 50000;
}

void CAnalogInMFCDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

   DDX_Control(pDX, IDC_RESOURCE, m_Resources);
   DDX_Text(pDX, IDC_NBSCANS, m_NbScans);
   DDX_Text(pDX, IDC_FREQUENCY, m_Frequency);
   DDX_Control(pDX, IDC_DURATION, m_Duration);
   DDX_Control(pDX, IDC_ENABLE_DIGITAL_TRIGGER, m_DigTrigger);
   DDX_Control(pDX, IDC_ENABLE_SW_TRIGGER, m_SwTrigger);
   DDX_Control(pDX, IDC_GRAPH, m_Graph);
   DDX_Control(pDX, IDC_SW_TRIGGER_LEVEL, m_SwTriggerLevel);
   DDX_Control(pDX, IDC_NBSCANS_STATUS, m_TotalScans);
   DDX_Control(pDX, IDC_NBSCANSAVAILABLE, m_AvailScans);
   DDX_Text(pDX, IDC_LOG, m_Log);
   DDX_Control(pDX, IDC_LOG_TO_FILE, m_LogToFile);
   DDX_Control(pDX, IDC_LOG_FILE_PATH, m_LogFilePath);
}

BEGIN_MESSAGE_MAP(CAnalogInMFCDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
   ON_BN_CLICKED(ID_GO, OnBnClickedGo)
   ON_BN_CLICKED(ID_STOP, OnBnClickedStop)
   ON_WM_DESTROY()
   ON_MESSAGE(WM_UPDATE_STATUS, OnUpdateStatus)
   ON_WM_VSCROLL()
END_MESSAGE_MAP()


// CAnalogInMFCDlg message handlers

BOOL CAnalogInMFCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

   CString str = AfxGetApp()->GetProfileString("parameters", "resource", "simu://Dev0/Ai0:3");
   m_Resources.SetWindowText(str);

   m_NbScans = AfxGetApp()->GetProfileInt("parameters", "numScans", 1000);
   m_Frequency = AfxGetApp()->GetProfileInt("parameters", "frequency", 5000);

   m_Duration.SetCheck(AfxGetApp()->GetProfileInt("parameters", "duration", 1));
   m_DigTrigger.SetCheck(AfxGetApp()->GetProfileInt("parameters", "digTrigger", 0));
   m_SwTrigger.SetCheck(AfxGetApp()->GetProfileInt("parameters", "swTrigger", 0));
   m_AvailScans.SetWindowText("0");
   m_TotalScans.SetWindowText("0");
   m_SwTriggerLevel.SetRange(-10*SW_TRIGGER_LEVEL_MULTIPLIER,10*SW_TRIGGER_LEVEL_MULTIPLIER, 1);
   m_SwTriggerLevel.SetTicFreq(SW_TRIGGER_LEVEL_MULTIPLIER);
   
   m_Graph.yAxis()->setMinimum(-10.0);
   m_Graph.yAxis()->setMaximum(10.0);
   m_Graph.addPlot(RGB(255,255,0), "");

   m_LogToFile.SetCheck(AfxGetApp()->GetProfileInt("parameters", "logToFile", 1));
   m_LogFilePath.SetWindowText(AfxGetApp()->GetProfileString("parameters", "logFilePath", "c:\\data.csv"));
   m_hLogFile = NULL;

   UpdateData(FALSE);

   GetDlgItem(ID_GO)->EnableWindow(TRUE);
   GetDlgItem(ID_STOP)->EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CAnalogInMFCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAnalogInMFCDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAnalogInMFCDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CAnalogInMFCDlg::OnBnClickedGo()
{
   UpdateData();

   if(m_LogToFile.GetCheck())
   {
      CString logFilePath;
      m_LogFilePath.GetWindowText(logFilePath);

      m_hLogFile = fopen(logFilePath, "w");
      if(NULL == m_hLogFile)
      {
         m_Log.Format("Go Error %d: %s", errno, strerror(errno));
         return;
      }
   }

   try
   {
      CString str;
      m_Resources.GetWindowText(str);
      m_Session.CreateAIChannel(LPCSTR(str), -10.0, 10.0, UeiAIChannelInputModeSingleEnded);

      tUeiTimingDuration duration;
      if(m_Duration.GetCheck())
         duration = UeiTimingDurationContinuous;
      else
         duration = UeiTimingDurationSingleShot;

      // Configure the session to acquire 1000 scans clocked by internal scan clock
      m_Session.ConfigureTimingForBufferedIO(m_NbScans, UeiTimingClockSourceInternal, m_Frequency, UeiDigitalEdgeRising, duration);
      m_Session.GetTiming()->SetTimeout(5000);
      m_Session.GetDataStream()->SetNumberOfFrames(16);

      if(m_DigTrigger.GetCheck())
      {
         m_Session.ConfigureStartDigitalTrigger(UeiTriggerSourceExternal, UeiDigitalEdgeRising);
      }
      else if(m_SwTrigger.GetCheck())
      {
         m_Session.ConfigureAnalogSoftwareTrigger(UeiTriggerActionBuffer,
                                                 UeiTriggerConditionRising, 
                                                 0,
                                                 -m_SwTriggerLevel.GetPos()/(double)SW_TRIGGER_LEVEL_MULTIPLIER,
                                                 0.0,
                                                 0);
      }
      else
      {
         m_Session.GetStartTrigger()->SetTriggerSource(UeiTriggerSourceImmediate);
      }

      // Create a reader object to read data synchronously.
      m_pReader = new CUeiAnalogScaledReader(m_Session.GetDataStream());

      m_pReader->AddEventListener(this);

      // allocate buffer to receive acquired data
      m_NbChannels = m_Session.GetNumberOfChannels();
      m_pData = (double*)malloc(m_NbChannels * m_NbScans * sizeof(double));

      // adjust scales of the graph
      m_Graph.xAxis()->setMinimum(0.0);
      m_Graph.xAxis()->setMaximum((double)m_NbScans / (double)m_Frequency);

      m_Session.Start();

      // If acquisition is continuous run asynchronously
      if(duration == UeiTimingDurationContinuous)
      {
         m_pReader->ReadMultipleScansAsync(m_NbScans, m_pData);
         GetDlgItem(ID_GO)->EnableWindow(FALSE);
         GetDlgItem(ID_STOP)->EnableWindow(TRUE);
      }
      else // in one-shot mode, acquire and graph data immediatly
      {
         m_pReader->ReadMultipleScans(m_NbScans, m_pData);
         m_Graph.yplotmultiple(m_NbChannels, m_pData,
                              m_NbScans, 0.0, 1.0/m_Frequency, PlotDataColumn, true); 
         OnBnClickedStop();
      }
      m_Log = "";
   }
   catch(CUeiException e)
   {
      OnBnClickedStop();
      CString str;
      str.Format("Go Error %d: %s", e.GetError(), e.GetErrorMessage());
      m_Log = str;
   }

   UpdateData(FALSE);
}

void CAnalogInMFCDlg::OnEvent(tUeiEvent event, void *param)
{
   try
   {
      if(event == UeiEventFrameDone)
      {
         m_Graph.yplotmultiple(m_NbChannels, m_pData,
                              m_NbScans, 0.0, 1.0/m_Frequency, PlotDataColumn, true); 

         int totalScans = m_Session.GetDataStream()->GetTotalScans();
         int availScans = m_Session.GetDataStream()->GetAvailableScans();
         PostMessage(WM_UPDATE_STATUS, (WPARAM)availScans, (LPARAM)totalScans);

         if(m_hLogFile != NULL)
         {
            for(int scan=0; scan < m_NbScans; scan++)
            {
               for(int ch=0; ch<m_NbChannels; ch++)
               {
                  fprintf(m_hLogFile, "%f,", m_pData[scan*m_NbChannels+ch]);
               }
               fprintf(m_hLogFile, "\n");
            }
         }

         m_pReader->ReadMultipleScansAsync(m_NbScans, m_pData);
      }
      else if(event == UeiEventError)
      {
         // if session is stopping ignore error
         tUeiError error = (tUeiError)((INT_PTR)(param));
         throw CUeiException(error);
      }
   }
   catch(CUeiException e)
   {
      m_Log.Format("OnEvent Error %d: %s", e.GetError(), e.GetErrorMessage());
      PostMessage(WM_COMMAND, ID_STOP, 0);
   }
}


void CAnalogInMFCDlg::OnBnClickedStop()
{
   UpdateData(FALSE);

   try
   {
      if(m_Session.IsRunning())
      {
         m_Session.Stop();
      }
      m_Session.CleanUp();

      if(m_pReader != NULL)
      {
         delete m_pReader;
         m_pReader = NULL;
      }

      if(m_pData != NULL)
      {
         free(m_pData);
         m_pData = NULL;
      }

      if(m_hLogFile != NULL)
      {
         fclose(m_hLogFile);
      }

      GetDlgItem(ID_GO)->EnableWindow(TRUE);
      GetDlgItem(ID_STOP)->EnableWindow(FALSE);
   }
   catch(CUeiException e)
   {
      m_Log.Format("Stop Error %d: %s", e.GetError(), e.GetErrorMessage());
   }
}

void CAnalogInMFCDlg::OnDestroy()
{
   __super::OnDestroy();

   OnBnClickedStop();

   CString str;
   m_Resources.GetWindowText(str);
   AfxGetApp()->WriteProfileString("parameters", "resource", str);
   AfxGetApp()->WriteProfileInt("parameters", "numScans", m_NbScans);
   AfxGetApp()->WriteProfileInt("parameters", "frequency", m_Frequency);
   AfxGetApp()->WriteProfileInt("parameters", "duration", m_Duration.GetCheck());
   AfxGetApp()->WriteProfileInt("parameters", "digTrigger", m_DigTrigger.GetCheck());
   AfxGetApp()->WriteProfileInt("parameters", "swTrigger", m_SwTrigger.GetCheck());
   AfxGetApp()->WriteProfileInt("parameters", "logToFile", m_LogToFile.GetCheck());
   m_LogFilePath.GetWindowText(str);
   AfxGetApp()->WriteProfileString("parameters", "logFilePath", str);
}

LRESULT CAnalogInMFCDlg::OnUpdateStatus(WPARAM wParam, LPARAM lParam)
{
   CString statstr;
   statstr.Format("%d", (int)lParam);
   m_TotalScans.SetWindowText(statstr);
   statstr.Format("%d", (int)wParam);
   m_AvailScans.SetWindowText(statstr);

   return 0;
}

void CAnalogInMFCDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
   if(pScrollBar->IsKindOf(RUNTIME_CLASS(CSliderCtrl)))
   {
      TRACE("%f\n", -m_SwTriggerLevel.GetPos()/(double)SW_TRIGGER_LEVEL_MULTIPLIER);

      m_Session.GetStartTrigger()->SetLevel(-m_SwTriggerLevel.GetPos()/(double)SW_TRIGGER_LEVEL_MULTIPLIER);
   }

   CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

