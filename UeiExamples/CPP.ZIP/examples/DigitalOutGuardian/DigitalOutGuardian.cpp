#include <windows.h>
#include <iostream>
#include "UeiDaq.h"

using namespace UeiDaq;

int main(int argc, char* argv[])
{
   CUeiSession doSs, aiSs;
   CUeiDOProtectedChannel* pDOChannel = NULL;
   uInt32* data = NULL;   // for devices with more than 16 output lines per port
   double* aiData = NULL;
   int* breakCount = NULL;
   
   try
   {
      // Create a digital output protected channel
      // This type of channels gives access to DIO cards with guardian features such
      // as circuit breaker and voltage/current readback
      // 
      // Circuit breaker will trip if current flowing through an output line outside of -1/+1 A
      // Current is sampled at 100Hz
      // Circuit breaker will automatically try to re-arm every 500ms (2.0 Hz) until the over current
      // condition is resolved.
      pDOChannel = doSs.CreateDOProtectedChannel("pdna://192.168.100.3/Dev1/do0", -1.0, 1.0, 100.0, true, 2.0);  
      doSs.ConfigureTimingForSimpleIO();

      // Additionnaly, you can configure some of the output lines to generate a PWM signal
      // for a certain duration during low/high and high/low transitions (soft start and soft stop)
      // It is also possible to continuously generate the PWM
      //
      // All output lines must share the same period (in usecs)
      pDOChannel->SetPWMPeriod(100);
      
      // Program PWM on output line 0 to generate soft start and soft stop PWM for 20ms 
      pDOChannel->SetPWMMode(0, UeiDOPWMSoftBoth);
      pDOChannel->SetPWMLength(0, 20000);

      // Program PWM on output line 1 to generate PWM continuously with 50% duty cycle
      pDOChannel->SetPWMMode(1, UeiDOPWMContinuous);
      pDOChannel->SetPWMDutyCycle(1, 0.5);

      // Digital data will be stored in a 32 bits integer buffer
      data = new uInt32[doSs.GetNumberOfChannels()];
      // Create a writer object to update output port.
      CUeiDigitalWriter doWriter(doSs.GetDataStream());
      
      // Create a circuit breaker object to monitor circuit breakers status and eventually reset them
      CUeiCircuitBreaker cb(doSs.GetDataStream(), 0);
      breakCount = new int[doSs.GetDevice()->GetDOResolution()];
	  for(int i=0; i<doSs.GetDevice()->GetDOResolution(); i++) {
		  breakCount[i]=0; 
	  }

      // Create an analog input session to read back currents and voltages flowing through each of the output lines
      // AI channels 0 to 31 return the current measured at each closed DO line
      // AI channels 32 to 63 return the voltage measured at each opened DO line 
      aiSs.CreateAIChannel("pdna://192.168.100.3/Dev1/ai0:63", -10.0, 10.0, UeiAIChannelInputModeDifferential);
      aiSs.ConfigureTimingForSimpleIO();

      // Allocate AI buffer to hold one value for each ouput line
      aiData = new double[aiSs.GetNumberOfChannels()];
      CUeiAnalogScaledReader aiReader(aiSs.GetDataStream());

      // Start the sessions
      doSs.Start();
      aiSs.Start();
      
      // Write 100 values and measure voltage and current at each output line
      for(int i=0; i<100; i++)
      {
         // Turn on each output line one by one
         data[0] = 1 << (i % doSs.GetDevice()->GetDOResolution());

         doWriter.WriteSingleScan(data);
         std::cout << i << ": Digital output port set to 0x" << std::hex << data[0] << std::endl;

         // Read back voltages and currents
         aiReader.ReadSingleScan(aiData);
         for(int l=0; l<aiSs.GetDevice()->GetDOResolution(); l++)
         {
            std::cout << "  DO line " << l << " current = " << aiData[l] << " A" << std::endl;
            std::cout << "  DO line " << l << " voltage = " << aiData[l+32] << " V" << std::endl;
         }
         
         // Monitor CB status
         unsigned int currStatus=0, stickyStatus=0;
         
         cb.ReadStatus(&currStatus, &stickyStatus);
		 std::cout << std::hex << "CB Status: curr = " << currStatus << " sticky = " << stickyStatus << std::dec << std::endl ;

         for (int l = 0; l < aiSs.GetDevice()->GetDOResolution(); l++)
         {
            if ((currStatus & (1U << l)) > 0)
            {
               breakCount[l]++;
            }

            // reset breaker after 5 iterations
            if (breakCount[l] > 5)
            {
               std::cout << "Resetting breaker for line " << l << std::endl;
               cb.Reset(1U << l);
               breakCount[l] = 0;
            }
         }

         Sleep(100);
      }

      doSs.Stop();
      aiSs.Stop();
   }
   catch(CUeiException e)
   {
      std::cout << "Error: " << e.GetErrorMessage() << std::endl;
   }

   if(data != NULL)
   {
      delete[] data;
   }

   if(aiData != NULL)
   {
      delete[] aiData;
   }

   return 0;
}



