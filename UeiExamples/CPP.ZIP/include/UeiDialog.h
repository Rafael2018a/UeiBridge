#if !defined(__UEIDIALOG_H__)
#define __UEIDIALOG_H__

#ifndef UeiDaqUiAPI
   #define UeiDaqUiAPI __declspec(dllimport)
#endif

namespace UeiDaq
{

/// This class contains static functions to operate various
/// configuration dialog boxes
class CUeiDialog
{
public:
   UeiDaqUiAPI CUeiDialog(void);

   UeiDaqUiAPI virtual ~CUeiDialog(void);

   /// Open the sesion manager dialog box
   ///
   /// Open the sesion manager dialog box and let the user create a new session
   /// and remove or edit an existing session.
   ///
   /// \param hParentWindow The handle of the parent window of the dialog box, if NULL the parent window is the desktop
   /// \param sessionGroup The group of sessions to edit
   /// \return true if the user validated his changes, false if canceled.  
   UeiDaqUiAPI static bool ManageSessions(HWND hParentWindow, std::string sessionGroup);

   /// Open the device browser dialog box
   ///
   /// Open the device browser dialog box and let the user select a device
   /// capable of being used in a session of the specified type
   ///
   /// \param hParentWindow The handle of the parent window of the dialog box, if NULL the parent window is the desktop
   /// \param sessionType The type of session to be used with the selected device
   /// \return A string that contains the resource of the selected device.  
   UeiDaqUiAPI static std::string SelectResource(HWND hParentWindow, tUeiSessionType sessionType);

   /// Open the session configurator dialog box
   ///
   /// Open the session configurator dialog box and let the user configure a session
   ///
   /// \param hParentWindow The handle of the parent window of the dialog box, if NULL the parent window is the desktop
   /// \param bConfigSessionType Allow the user to change the session type (AI, AO...) in the dialog
   /// \param bConfigTiming Allow the user to change timing parameters in the dialog
   /// \param bConfigTriggers Allow the user to change triggers parameters in the dialog
   /// \param xmlSession A string containing an XL representation of the session parameters.  
   /// \return The new configured XML session if the user clicked on "Ok". This string is empty if the user clicked on "Cancel"
   UeiDaqUiAPI static std::string ConfigureSession(HWND hParentWindow, bool bConfigSessionType = true, bool bConfigTiming = true, bool bConfigTriggers = true, std::string xmlSession="");

   /// Open the session configurator dialog box
   ///
   /// Open the session configurator dialog box and let the user configure a session stored in a file
   ///
   /// \param hParentWindow The handle of the parent window of the dialog box, if NULL the parent window is the desktop
   /// \param bConfigSessionType Allow the user to change the session type (AI, AO...) in the dialog
   /// \param bConfigTiming Allow the user to change timing parameters in the dialog
   /// \param bConfigTriggers Allow the user to change triggers parameters in the dialog
   /// \param sessionFile A string containing the name of the session file to configure.  
   /// \return true the user clicked on "Ok". false if the user clicked on "Cancel"
   UeiDaqUiAPI static bool ConfigureSessionFile(HWND hParentWindow, bool bConfigSessionType, bool bConfigTiming, bool bConfigTriggers, std::string sessionFile);
};

}

#endif //__UEIDIALOG_H__
