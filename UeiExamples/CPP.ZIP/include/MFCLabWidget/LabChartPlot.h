#ifndef __CLABCHARTPLOT_H__
#define __CLABCHARTPLOT_H__

#include <math.h>
#include <vector>
#include <iostream>
#include "LabPlot.h"

template<class T>
class CLabChartPlot : public CLabPlot
{
public:
   CLabChartPlot(CLabBase *parent, double x0, double deltaX):
      CLabPlot(parent, x0, deltaX),
      _data(NULL),
      _nbAccumulatedPoints(0)
   {
      _nbPointsPerPlot = 1000;
   };
   virtual ~CLabChartPlot()
   {
      if(_data != NULL)
         free(_data);
   };

   virtual void drawPlot(CDC *pDC)
   {
      int i,j,k;

      if(_data == NULL)
         return;
   
      CRgn rgn;
      CRect rect = bounds();
      rgn.CreateRectRgn(rect.left, rect.top, rect.right, rect.bottom);
      pDC->SelectClipRgn(&rgn);

      COLORREF col = color();
      CPen p(PS_SOLID, 1, color());
      CPen* pOldPen = pDC->SelectObject(&p);

      tGraphType type = ((CLabGraph*)_parent)->getType();

      for(k=0; k<_nbTraces; k++)
      {
         CPen pt(PS_SOLID, 1, col);
         pDC->SelectObject(&pt);
         for(i=0; i<_nbPlots; i++)
         {
            int start, nbPoints;
            if(_nbAccumulatedPoints < _nbPointsPerPlot)
            {
               start = 0;
               nbPoints = _nbAccumulatedPoints;
            }
            else
            {
               start = (_nbAccumulatedPoints % _nbPointsPerPlot);
               nbPoints = _nbPointsPerPlot;
            }

            for(j=0; j<(nbPoints-1); j++)
            {
               T value1, value2;
               T *data = _data + k*(_nbPlots*_nbPointsPerPlot);

               int yindex = start + j;
               if(yindex >= nbPoints)
                   yindex = yindex - nbPoints;
               
               int xindex;
               if(type == ScopeChart)
                  xindex = yindex;
               else
                  xindex = j;
                              
               if(_dir == PlotDataLine)
               {
                  value1 = data[i*_nbPointsPerPlot+yindex];
                  value2 = data[i*_nbPointsPerPlot+yindex+1];
               }
               else
               {
                  value1 = data[yindex*_nbPlots+i];
                  value2 = data[(yindex+1)*_nbPlots+i];
               }
               pDC->MoveTo(xAxis()->translateCoordinate(_x0 + xindex * _deltaX), yAxis()->translateCoordinate(value1));
               pDC->LineTo(xAxis()->translateCoordinate(_x0 + (xindex+1) * _deltaX), yAxis()->translateCoordinate(value2));
            }
         }

         col = DARKER(col);
      }

      pDC->SelectObject(pOldPen);
   }

   void addData(T *data, int nbPlots)
   {     
      _dir = PlotDataColumn;

      if(_nbPlots != nbPlots)
      {
         if(_data != NULL)
            free(_data);

         _data = (T*)malloc(_nbPointsPerPlot*nbPlots*sizeof(T));
         _nbPlots = nbPlots;
      }

      int index = _nbAccumulatedPoints % _nbPointsPerPlot;
      
      for(int i=0; i<nbPlots; i++)
         _data[index*nbPlots+i] = data[i];

      _nbAccumulatedPoints++;
   }

private:
   T *_data;
   int _nbAccumulatedPoints;
};

#endif //__CLABCHARTPLOT_H__

