#ifndef __UEI_SESSION_GROUP_H__
#define __UEI_SESSION_GROUP_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

namespace UeiDaq
{

class CUeiSessionGroup
{
public:
   UeiDaqAPI CUeiSessionGroup(void);
   UeiDaqAPI virtual ~CUeiSessionGroup(void);

   UeiDaqAPI static std::string EnumGroupSessions(std::string sessionGroup, int index);
   UeiDaqAPI static std::string GetSessionByName(std::string sessionGroup, std::string sessionName);
   UeiDaqAPI static void AddSessionToGroup(std::string sessionGroup, std::string sessionFile);
   UeiDaqAPI static void RemoveSessionFromGroup(std::string sessionGroup, std::string sessionFile);

private:
   static int LoadGroupSessions(std::string sessionGroup, std::vector<std::string>& sessions);
   static int SaveGroupSessions(std::string sessionGroup, std::vector<std::string> sessions);
};

}

#endif