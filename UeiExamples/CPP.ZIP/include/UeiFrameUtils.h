#ifndef __UEIFRAMEUTILS_H__
#define __UEIFRAMEUTILS_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

namespace UeiDaq
{

/// \brief Converts non-printable control characters to escape sequence
///
/// Scan source string for non-printable characters and replace with escape sequence
/// For example string 0x41 0x42 0x0d will be printed as "ab\\r"
///   back space (0x08) is printed as \\b
///   tab (0x09) is printed as \\t
///   line feed (0x0A) is printed as \\n
///   form feed (0x0C) is printed as \\f
///   carriage return (0x0D) is printed as \\r
///   All other other control character are printed using their hexadecimal ASCII value  
///
/// \param src string to convert
/// \param dst result of the conversion
UeiDaqAPI void UeiDaqConvertControlCharsToEscapeSequence(std::string src, std::string& dst);

/// \brief Converts string containing escape sequence to control characters
///
/// Scan source string for escape sequence and replace with non-printable equivalent
///   back space \\b is converted to 0x08
///   tab \\t is converted to 0x09
///   line feed \\n is converted to 0x0A
///   form feed \\f is converted to 0x0C
///   carriage return \\r is converted to 0x0D
///
/// \param src string to convert
/// \param dst result of the conversion
UeiDaqAPI void UeiDaqConvertEscapeSequenceToControlChars(std::string src, std::string& dst);

/// \brief converts character to integer value
///
/// For example '1' is converted to 1
///
/// \param c character to convert
/// \return converted value or -1 if non-convertable
UeiDaqAPI int UeiDaqCharToInt(char c);

/// \brief converts integer value to character
///
/// For example 1 is converted to '1'
///
/// \param i integer value to convert
/// \return converted character or -1 if non-convertable
UeiDaqAPI char UeiDaqIntToChar(int i);

// MIL-1553 frames helper classes
#define UeiMil1553_DataSize32     32
#define UeiMil1553_DataSize36     36
#define UeiMil1553_DataSize40     40
#define UeiMil1553_DataSize256    256
#define UeiMil1553_DataSize1024   1024

///< BCB_FLAGS0 This word is used to set execution parameters for the current 1553 command sequence
typedef enum {
    UeiMil1553_BCB_FLAGS0_IRQ   =(1L<<15),  ///< =1 if interrupt should be requested immediately upon completion of the execution of the current entry
    UeiMil1553_BCB_FLAGS0_BEN   =(1L<<14),  ///< =1 - enable communication with RTs on Bus B
    UeiMil1553_BCB_FLAGS0_AEN   =(1L<<13),  ///< =1 - enable communication with RTs on Bus A
    UeiMil1553_BCB_FLAGS0_EXW   =(1L<<12),  ///< =1 - allow extended wait for response from the RT (double maximum response time)
    UeiMil1553_BCB_FLAGS0_RSV11 =(1L<<11),  ///< Reserved
    UeiMil1553_BCB_FLAGS0_RSV10 =(1L<<10),  ///< Reserved
    UeiMil1553_BCB_FLAGS0_RSV9  =(1L<<9),   ///< Reserved
    UeiMil1553_BCB_FLAGS0_SBUS  =(1L<<8),   ///< Select "Start Bus" - bus that will be initially used to communicate with RT (0=Bus A)
    UeiMil1553_BCB_FLAGS0_DTC   =(1L<<7),   ///< =1 - check returned value of the data from RT (compare with MIN and MAX value)
    UeiMil1553_BCB_FLAGS0_MDC   =(1L<<6),   ///< =1 - check returned value of the mode data word (apply AND/OR masks and compare with VAL value
    UeiMil1553_BCB_FLAGS0_STS2  =(1L<<5),   ///< =1 - check returned value of the 2nd status word (apply AND/OR masks and compare with VAL value
    UeiMil1553_BCB_FLAGS0_STS1  =(1L<<4)   ///< =1 - check returned value of the first status word (apply AND/OR masks and compare with VAL value
} tUeiMIL1553_BCB_FLAGS0;

///< Transfer types
typedef enum {
    UeiMil1553_BCB_TT_BCRT_1E  = 1, ///< 1 - BC-RT ("1e" sequence of the BC state machine)
    UeiMil1553_BCB_TT_RTBC_2B  = 2, ///< 2 - RT-BC ("2b" sequence of the BC state machine)
    UeiMil1553_BCB_TT_RTRT_3A  = 3, ///< 3 - RT-RT ("3a" sequence of the BC state machine)
    UeiMil1553_BCB_TT_MD_1A    = 4, ///< 4 - MODE W/O Data (TX) ("1a" sequence of the BC state machine)
    UeiMil1553_BCB_TT_MDTX_2A  = 5, ///< 5 - MODE W Data (TX) ("2a" sequence of the BC state machine)
    UeiMil1553_BCB_TT_MDRX_1C  = 6, ///< 6 - MODE W Data (RX) ("1c" sequence of the BC state machine)
    UeiMil1553_BCB_TT_BBCRT_1F = 7, ///< 7 - Broadcast BC-RT ("1f" sequence of the BC state machine)
    UeiMil1553_BCB_TT_BRTRT_3B = 8, ///< 8 - Broadcast RT-RT ("3b" sequence of the BC state machine)
    UeiMil1553_BCB_TT_BMD_1B   = 9, ///< 9 - Broadcast MODE W/O Data (TX) ("1b" sequence of the BC state machine)
    UeiMil1553_BCB_TT_BMDRX_1D =10 ///< 10 - Broabcast MODE W Data (TX) ("1d" sequence of the BC state machine)  
} tUeiMIL1553TransferTypes;

///< BCB_FLAGS1 Retry on error settings
typedef enum {
    UeiMil1553_BCB_FLAGS1_IRT   =(1L<<14), ///< Retry on incorrect RT# in status 
    UeiMil1553_BCB_FLAGS1_RUS   =(1L<<13), ///< Retry on unexpected status reception
    UeiMil1553_BCB_FLAGS1_RUD   =(1L<<12), ///< Retry on unexpected data reception
    UeiMil1553_BCB_FLAGS1_RWB   =(1L<<11), ///< Retry on wrong bus response
    UeiMil1553_BCB_FLAGS1_RIS   =(1L<<10), ///< Retry on illegal bits set in status
    UeiMil1553_BCB_FLAGS1_RBB   =(1L<<9),  ///< Retry on busy bit in status
    UeiMil1553_BCB_FLAGS1_RTE   =(1L<<8),  ///< Retry on bus timing error
    UeiMil1553_BCB_FLAGS1_RWC   =(1L<<7),  ///< Retry on word count
    UeiMil1553_BCB_FLAGS1_RE    =(1L<<6),  ///< Reenable command transmission on succesfull status reply
    UeiMil1553_BCB_FLAGS1_RNR   =(1L<<5),  ///< Retry on no-response
    UeiMil1553_BCB_FLAGS1_ERE   =(1L<<4),  ///< Enable re-transmit on alternative bus each retry
    UeiMil1553_BCB_FLAGS1_ESR   =(1L<<3)   ///< Enable periodic status request command when retry
} tUeiMIL1553_BCB_FLAGS1;                                         

///< BCB_ERRSTS0 Holds status of the entry processing, written by the BC state machine
typedef enum {
    UeiMil1553_BCB_ERRSTS0_CB    =(1L<<15), ///< Status : Current bus (0 = Bus A)
    UeiMil1553_BCB_ERRSTS0_RSV14 =(1L<<14), ///< Reserved, use as needed
    UeiMil1553_BCB_ERRSTS0_PD    =(1L<<13), ///< Error : descriptor is permanently disabled
    UeiMil1553_BCB_ERRSTS0_S1B   =(1L<<12), ///< Warning : Status 1 RT responded with BUSY
    UeiMil1553_BCB_ERRSTS0_S2B   =(1L<<11), ///< Warning : Status 2 RT responded with BUSY
    UeiMil1553_BCB_ERRSTS0_BNR   =(1L<<10), ///< Error : No response from bus
    UeiMil1553_BCB_ERRSTS0_RCR   =(1L<<9),  ///< Error : Retry count reached (clear to re-start),
    UeiMil1553_BCB_ERRSTS0_WBR   =(1L<<8),  ///< Error : Response received on the wrong bus (also will set WBR bit in PORT_STS)
    UeiMil1553_BCB_ERRSTS0_IRT   =(1L<<7),  ///< Error : Incorrect RT responded (also will set IRT bit in PORT_STS)
    UeiMil1553_BCB_ERRSTS0_LR    =(1L<<6),  ///< Warning : Late response
    UeiMil1553_BCB_ERRSTS0_ER    =(1L<<5),  ///< Error : Early response
    UeiMil1553_BCB_ERRSTS0_S2F   =(1L<<4),  ///< Error : Status 2 compare failed
    UeiMil1553_BCB_ERRSTS0_S1F   =(1L<<3),  ///< Error : Status 1 compare failed
    UeiMil1553_BCB_ERRSTS0_DCF   =(1L<<2),  ///< Error : Data compare failed
    UeiMil1553_BCB_ERRSTS0_TFW   =(1L<<1),  ///< Error : Too few words received (also will set TFW bit in PORT_STS)
    UeiMil1553_BCB_ERRSTS0_TMW   =(1L<<0)  ///< Error : Too many words received (also will set TMW bit in PORT_STS)          
} tUeiMIL1553_BCB_ERRSTS0;

///< BCB_ERRSTS1 Holds Last Error Source code - position in the BC state machine that raises an error
typedef enum {
    UeiMil1553_BCB_ERRSTS1_0000    =0x00, ///< No error
    UeiMil1553_BCB_ERRSTS1_0001    =0x01, ///< Reserved
    UeiMil1553_BCB_ERRSTS1_0002    =0x02, ///< BC_MNR_MEM_WAIT - memory timeout
    UeiMil1553_BCB_ERRSTS1_0003    =0x03, ///< BC_MNR_STS1_CHECK - wrong RT responded
    UeiMil1553_BCB_ERRSTS1_0004    =0x04, ///< BC_MNR_STATE_PROCEED - both buses A/B are enabled or disabled
    UeiMil1553_BCB_ERRSTS1_0005    =0x05, ///< BC_MNR_CMD1_PUT - Illegal value in the BC transfer type field
    UeiMil1553_BCB_ERRSTS1_0006    =0x06, ///< BC_MNR_CMD1_WAIT - Illegal value in the BC transfer type field
    UeiMil1553_BCB_ERRSTS1_0007    =0x07, ///< BC_MNR_CMD2_PUT - Illegal value in the BC transfer type field
    UeiMil1553_BCB_ERRSTS1_0008    =0x08, ///< BC_MNR_CMD2_WAIT - Illegal value in the BC transfer type field
    UeiMil1553_BCB_ERRSTS1_0009    =0x09, ///< BC_MNR_DATA_BCRT_NEXT - Illegal value in the BC transfer type field
    UeiMil1553_BCB_ERRSTS1_000A    =0x0A, ///< BC_MNR_STS1_WAIT - Data received while waiting for the status
    UeiMil1553_BCB_ERRSTS1_000B    =0x0B, ///< BC_MNR_STS1_WAIT - Data/command received on the wrong bus
    UeiMil1553_BCB_ERRSTS1_000C    =0x0C, ///< BC_MNR_STS1_WAIT - Bus timing error
    UeiMil1553_BCB_ERRSTS1_000D    =0x0D, ///< BC_MNR_STS1_VALID - RT in Error State Replied with status
    UeiMil1553_BCB_ERRSTS1_000E    =0x0E, ///< BC_MNR_STS1_VALID - Illegal value in the BC transfer type field
    UeiMil1553_BCB_ERRSTS1_000F    =0x0F, ///< BC_MNR_DATA_RTBC_WAIT - Status received while waiting for the data
    UeiMil1553_BCB_ERRSTS1_0010    =0x10, ///< BC_MNR_DATA_RTBC_WAIT - Data/command received on the wrong bus 
    UeiMil1553_BCB_ERRSTS1_0011    =0x11, ///< BC_MNR_DATA_RTBC_WAIT - Bus timing error
    UeiMil1553_BCB_ERRSTS1_0012    =0x12, ///< BC_MNR_DATA_RTBC_CHECK - For the Mode with data - verification failed against expected value
    UeiMil1553_BCB_ERRSTS1_0013    =0x13, ///< BC_MNR_DATA_RTBC_CHECK - For the MIN/MAX verification - verification failed
    UeiMil1553_BCB_ERRSTS1_0014    =0x14, ///< BC_MNR_DATA_RTBC_CHECK - more then 32 data words received
    UeiMil1553_BCB_ERRSTS1_0015    =0x15, ///< BC_MNR_DATA_RTBC_IDLE - too many data words received
    UeiMil1553_BCB_ERRSTS1_0016    =0x16, ///< BC_MNR_DATA_RTBC_IDLE - too few data words received
    UeiMil1553_BCB_ERRSTS1_0017    =0x17, ///< BC_MNR_DATA_RTBC_VALIDATED - Illegal value in the BC transfer type field
    UeiMil1553_BCB_ERRSTS1_0018    =0x18, ///< BC_MNR_STS2_WAIT - Data received while waiting for the status
    UeiMil1553_BCB_ERRSTS1_0019    =0x19, ///< BC_MNR_STS2_WAIT - Data/command received on the wrong bus
    UeiMil1553_BCB_ERRSTS1_001A    =0x1A, ///< BC_MNR_STS2_WAIT - Bus timing error
    UeiMil1553_BCB_ERRSTS1_001B    =0x1B, ///< BC_MNR_STS2_VALID - Illegal value in the BC transfer type field
    UeiMil1553_BCB_ERRSTS1_001C    =0x1C, ///< BC_MNR_CMD1_PUT - Bus not in idle state
    UeiMil1553_BCB_ERRSTS1_001D    =0x1D, ///< BC_MNR_STS1_IDLE_WAIT - Data/command received on the wrong bus
    UeiMil1553_BCB_ERRSTS1_001E    =0x1E, ///< BC_MNR_MEM_WAIT - Memory timeout detected
    UeiMil1553_BCB_ERRSTS1_001F    =0x1F, ///< BC_MNR_STS1_WAIT - RT did not reply within late response timeout period
    UeiMil1553_BCB_ERRSTS1_0020    =0x20, ///< BC_MNR_STS1_WAIT - RT reply too early
    UeiMil1553_BCB_ERRSTS1_0021    =0x21, ///< BC_MNR_STS1_WAIT - RT reply too late
    UeiMil1553_BCB_ERRSTS1_0022    =0x22, ///< BC_MNR_STS1_INVALID - recovery disabled on invalid bits in status 1
    UeiMil1553_BCB_ERRSTS1_0023    =0x23, ///< BC_MNR_STS1_INVALID - recovery disabled on busy bit in status 1
    UeiMil1553_BCB_ERRSTS1_0024    =0x24, ///< BC_MNR_STS1_INVALID - non-recoverable bits in status 1
    UeiMil1553_BCB_ERRSTS1_0025    =0x25, ///< BC_MNR_STS2_INVALID - recovery disabled on invalid bits in status 2
    UeiMil1553_BCB_ERRSTS1_0026    =0x26, ///< BC_MNR_STS2_INVALID - recovery disabled on busy bit in status 2
    UeiMil1553_BCB_ERRSTS1_0027    =0x27, ///< BC_MNR_STS2_INVALID - non-recoverable bits in status 2
    UeiMil1553_BCB_ERRSTS1_0028    =0x28, ///< BC_MNR_STS2_WAIT - no response
    UeiMil1553_BCB_ERRSTS1_0029    =0x29, ///< BC_MNR_STS2_WAIT - early response
    UeiMil1553_BCB_ERRSTS1_002A    =0x2A, ///< BC_MNR_STS2_CHECK - wrong RT responded
    UeiMil1553_BCB_ERRSTS1_002B    =0x2B, ///< BC_MNR_CMD1_PUT - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_002C    =0x2C, ///< BC_MNR_CMD2_PUT - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_002D    =0x2D, ///< BC_MNR_DATA_BCRT_PUT - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_002E    =0x2E, ///< BC_MNR_STS1_IDLE_WAIT - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_002F    =0x2F, ///< BC_MNR_STS1_WAIT - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_0030    =0x30, ///< BC_MNR_DATA_RTBC_WAIT - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_0031    =0x31, ///< BC_MNR_STS2_WAIT - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_0032    =0x32, ///< BC_MNR_BUS_IDLE_WAIT - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_0033    =0x33, ///< BC_MNR_BUS_IDLE_OK - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_0034    =0x34, ///< BC_MNR_BUS_IDLE_ENC_DONE - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_0035    =0x35, ///< BC_MNR_DESC_START - maximum 1553 access time exceeded
    UeiMil1553_BCB_ERRSTS1_0036    =0x36, ///< BC_MNR_MEM_REQUEST - memory timeout detected
    
    // Bits [11:8] provide additional info and ORed with bits [15:12] and [7:0]
    UeiMil1553_BCB_ERRSTS1_0100    =0x100, ///< BC_MNR_ERR_UNEXP_DATA - Recovery disabled, entry will be disabled permanently
    UeiMil1553_BCB_ERRSTS1_0200    =0x200, ///< BC_MNR_ERR_UNEXP_STS - Recovery disabled, entry will be disabled permanently
    UeiMil1553_BCB_ERRSTS1_0300    =0x300, ///< BC_MNR_ERR_WRONG_BUS - Recovery disabled, entry will be disabled permanently
    UeiMil1553_BCB_ERRSTS1_0400    =0x400, ///< BC_MNR_ERR_MEM_TO - Recovery disabled, entry will be disabled permanently
    UeiMil1553_BCB_ERRSTS1_0500    =0x500, ///< BC_MNR_BUS_ERROR - Recovery disabled, entry will be disabled permanently
    UeiMil1553_BCB_ERRSTS1_0600    =0x600, ///< BC_MNR_ERR_NO_RESPONSE - Recovery disabled, entry will be disabled permanently
    UeiMil1553_BCB_ERRSTS1_0700    =0x700, ///< BC_MNR_ERR_BAD_CMD - Recovery disabled, entry will be disabled permanently
    UeiMil1553_BCB_ERRSTS1_0800    =0x800, ///< BC_MNR_ERR_TOO_MANY - Recovery disabled, entry will be disabled permanently
    UeiMil1553_BCB_ERRSTS1_0900    =0x900, ///< BC_MNR_ERR_TOO_FEW - Recovery disabled, entry will be disabled permanently
    UeiMil1553_BCB_ERRSTS1_0A00    =0xA00, ///< BC_MNR_RECOVERY_CHECK - Recovery disabled, entry will be disabled permanently
    UeiMil1553_BCB_ERRSTS1_0B00    =0xB00, ///< BC_MNR_BUS_IDLE_CHECK - Bus is not in idle state
    UeiMil1553_BCB_ERRSTS1_0C00    =0xC00, ///< BC_MNR_ERR_WRONG_RT - Response received from the incorrect RT
    UeiMil1553_BCB_ERRSTS1_0D00    =0xD00, ///< BC_MNR_TO_ERROR - Maximum 1553 access time exceeded

    // Bits [15:12] provide global error flags and when set - ORed with rest of the error bits
    UeiMil1553_BCB_ERRSTS1_8000   =0x8000, ///< BC_MNR_STATE_DISABLED - entry permanently disabled due to previous error
} tUeiMIL1553_BCB_ERRSTS1;

///<  Report current execution status of the bus controller (0x21A4)
typedef enum {
    UeiMil1553_PORT_BCSTS_BSY    =(1L<<31), ///< =1 if BC not in IDLE or WAIT_CLOCK states
    UeiMil1553_PORT_BCSTS_RSV30  =(1L<<30), ///< Reserved
    UeiMil1553_PORT_BCSTS_RSV29  =(1L<<29), ///< Reserved
    UeiMil1553_PORT_BCSTS_RSV28  =(1L<<28), ///< Reserved
    UeiMil1553_PORT_BCSTS_MRF3   =(1L<<27), ///< Reports ID for the currently processed
    UeiMil1553_PORT_BCSTS_MRF0   =(1L<<24), ///< minor frame 
    UeiMil1553_PORT_BCSTS_DSC7   =(1L<<23), ///< Reports ID for the currently processed
    UeiMil1553_PORT_BCSTS_DSC0   =(1L<<16), ///< descriptor minor frame 
    UeiMil1553_PORT_BCSTS_BIR    =(1L<<12), ///< Response received from incorrect RT
    UeiMil1553_PORT_BCSTS_BTO    =(1L<<11), ///< Maximum 1553 access time exceeded
    UeiMil1553_PORT_BCSTS_BAD    =(1L<<10), ///< Bus activity is detected while in wait for clock (idle), state
    UeiMil1553_PORT_BCSTS_BWB    =(1L<<9),  ///< Response received on the wrong bus
    UeiMil1553_PORT_BCSTS_BCO    =(1L<<8),  ///< BC overrun - major/minor frame clock called in non-idle state
    UeiMil1553_PORT_BCSTS_HBT    =(1L<<7),  ///< Heartbeat - set to one at the beginning of each minor frame
    UeiMil1553_PORT_BCSTS_MTD    =(1L<<6),  ///< Memory access timeout was detected (hardware error)
    UeiMil1553_PORT_BCSTS_RTR    =(1L<<5),  ///< At least one RT in "dead" state replied with valid status
    UeiMil1553_PORT_BCSTS_MF     =(1L<<4),  ///< At least one Mode command w/o data word failed
    UeiMil1553_PORT_BCSTS_MRBF   =(1L<<3),  ///< At least one Mode TX command with data word failed
    UeiMil1553_PORT_BCSTS_MBRF   =(1L<<2),  ///< At least one Mode RX command with data word failed
    UeiMil1553_PORT_BCSTS_RBF    =(1L<<1),  ///< At least one RT->BC transmission failed
    UeiMil1553_PORT_BCSTS_BRF    =(1L<<0),  ///< At least one BC->RT transmission failed              
} tUeiMIL1553_BCB_BCSTS;

///< RT channel status reported (mostly error bits)
typedef enum {
    UeiMil1553_PORT_STS_BSF    =(1L<<31),   ///< RT: Current bus that driving BM FIFO (1=BUS A)
    UeiMil1553_PORT_STS_BSR    =(1L<<30),   ///< RT: Current bus that driving RT (1=BUS A)
    UeiMil1553_PORT_STS_ENB    =(1L<<29),   ///< RT: Bus B Encoder is enabled in RT Engine
    UeiMil1553_PORT_STS_ENA    =(1L<<28),   ///< RT: Bus A Encoder is enabled in RT Engine
    UeiMil1553_PORT_STS_DRB    =(1L<<27),   ///< If set - data is ready at the decoder B
    UeiMil1553_PORT_STS_DRA    =(1L<<26),   ///< If set - data is ready at the decoder A
    UeiMil1553_PORT_STS_WDR    =(1L<<10),   ///< RT : Watchdog request from the RT - indicates no activity from the BC within specified timeframe
    UeiMil1553_PORT_STS_BEB    =(1L<<9),    ///< BUS: Bit timing error on bus B (sticky, auto-cleared after read)
    UeiMil1553_PORT_STS_BEA    =(1L<<8),    ///< BUS: Bit timing error on bus A (sticky, auto-cleared after read)
    UeiMil1553_PORT_STS_PEB    =(1L<<7),    ///< BUS: Parity error on bus B (sticky, auto-cleared after read)
    UeiMil1553_PORT_STS_PEA    =(1L<<6),    ///< BUS: Parity error on bus A (sticky, auto-cleared after read)
    UeiMil1553_PORT_STS_ILC    =(1L<<5),    ///< RT: Illegal command (sticky, auto-cleared after read)
    UeiMil1553_PORT_STS_MER    =(1L<<4),    ///< RT: Message error (sticky, auto-cleared after read)
    UeiMil1553_PORT_STS_TMW    =(1L<<3),    ///< RT: Too many words were detected in RX message (sticky, auto-cleared after read)
    UeiMil1553_PORT_STS_TFW    =(1L<<2),    ///< RT: Too few words were detected inm RX message (sticky, auto-cleared after read)
    UeiMil1553_PORT_STS_ERB    =(1L<<1),    ///< If set - data overflow was detected at the decoder B (sticky, auto-cleared after read)
    UeiMil1553_PORT_STS_ERA    =(1L<<0)     ///< If set - data overfolw was detected at the decoder A (sticky, auto-cleared after read)
} tUeiMIL1553_CH_STS;

/// \brief CUeiMIL1553BCSchedFrame class - program major and minor BC frames.
///
/// This class is used to construct and manipulate tUeiMIL1553BCSchedFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure. 
/// Class can be used with both CUeiMIL1553Reader::read() and CUeiMIL1553Writer::write()
class CUeiMIL1553BCSchedFrame : public tUeiMIL1553BCSchedFrame 
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553BCSchedFrame(tUeiMIL1553BCFrameType);
    /// \brief Constructor with extra initialization
    UeiDaqAPI CUeiMIL1553BCSchedFrame(tUeiMIL1553BCFrameType SetFrameType, int MNIndex, int MNBlock, int MNOffset);
    /// \brief Constructor with extra initialization 2
    UeiDaqAPI CUeiMIL1553BCSchedFrame(tUeiMIL1553BCFrameType SetFrameType, int MNIndex, int MNBlock, int MNOffset, int DataSize);
    UeiDaqAPI CUeiMIL1553BCSchedFrame(tUeiMIL1553BCSchedFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553BCSchedFrame();

    /// \brief Clear structure
    UeiDaqAPI void Clear(void);
    /// \brief Clear and initialze structure with input parameters
    UeiDaqAPI void Set(int MNIndex, int MNBlock, int MNOffset); ///< clear with initialization

    /// \brief Clear and initialze structure with input parameters (for minor frame read only)
    UeiDaqAPI void Set(int MNIndex, int MNBlock, int MNOffset, int DataSize); ///< clear with initialization

    /// \brief Add major entry
    /// Add major entry. User can add enabled/disabled entry, execute-once entry and mark entry as a
    /// swap entry. When entry is marked as swapped every time major frame is started it incert enable
    /// bit for each swap=marked entry. This way a user can create a double-buffering mechanism
    ///
    /// \param MinorId specifies which minor ID is associated with this major entry
    /// \param entryMJ specifies flags - enable, do-once and swap (flags can be added together)
    UeiDaqAPI void AddMajorEntry(int MinorId, tUeiMIL1553BCMajorFlags entryMJ); ///< IRQ?

    /// \brief Add major entry
    /// Add major entry. User can add enabled/disabled entry, execute-once entry and mark entry as a
    /// swap entry. When entry is marked as swapped every time major frame is started it incert enable
    /// bit for each swap=marked entry. This way a user can create a double-buffering mechanism
    ///
    /// \param MinorId specifies which minor ID is associated with this major entry
    /// \param entryMJ specifies flags - enable, do-once and swap (flags can be added together)
    /// \param BCCBSegment - explicitly specify which BCCB segment to use
    UeiDaqAPI void AddMajorEntry(int MinorId, tUeiMIL1553BCMajorFlags entryMJ, int BCCBSegment); ///< IRQ?

    /// \brief Add minor entry
    /// Add minor entry. Minor entry must be enabled to be executed at least once
    /// \param entryMN specifies flags - enable and do-once (flags can be added together)
    UeiDaqAPI void AddMinorEntry(tUeiMIL1553BCMinorFlags entryMN);

    /// \brief Add minor entry
    /// Add minor entry. Minor entry must be enabled to be executed at least once
    /// \param entryMN specifies flags - enable and do-once (flags can be added together)
    /// \param BCCBIndex - explicitly specify which BCCB to use within BCCBSegment
    UeiDaqAPI void AddMinorEntry(tUeiMIL1553BCMinorFlags entryMN, int BCCBIndex);

    UeiDaqAPI tUeiMIL1553BCSchedFrame* GetFrame();
private:


};

/// \brief CUeiMIL1553BCCBDataFrame class - assemble and store data into BC control block
///
/// This class is used to construct and manipulate CUeiMIL1553BCCBDataFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Writer::write()
class CUeiMIL1553BCCBDataFrame : public tUeiMIL1553BCCBDataFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553BCCBDataFrame();
    /// \brief Constructor with initialization
    UeiDaqAPI CUeiMIL1553BCCBDataFrame(int MnFrameNum, int MnIndex, int Block);
    /// \brief Constructor with initialization
    UeiDaqAPI CUeiMIL1553BCCBDataFrame(int BCCBSegment, int BCCBIndex);
    UeiDaqAPI CUeiMIL1553BCCBDataFrame(tUeiMIL1553BCCBDataFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553BCCBDataFrame();
    /// \brief Clear structure
    /// Clear structure, removes all elements of data
    UeiDaqAPI void Clear(void);
    /// \brief Clear and initialze structure with input parameters
    /// \param MnFrameNum minor frame number
    /// \param MnIndex entry in the minor frame 
    /// \param Block upper (0) or lower (1) block if this minor frame entry is involved in double-buffering operation
    UeiDaqAPI void Set(int MnFrameNum, int MnIndex, int Block);
    /// \brief Clear and initialze structure with input parameters
    /// \param BCCBSegment BCCB segment to write BCCB to
    /// \param BCCBIndex BCCB index to write to
    UeiDaqAPI void Set(int BCCBSegment, int BCCBIndex);
    /// \brief Set RT-BC, BC-RT, Mode or Broadcast command
    /// \param cmdType type of the command to transmit or receive
    /// \param Rt remote terminal (31 for broadcast)
    /// \param Sa subaddress (0 for mode command)
    /// \param WordCount number of data words in the command
    UeiDaqAPI void SetCommand(tUeiMIL1553CommandType cmdType, int Rt, int Sa, int WordCount);
    /// \brief Set RT-RT or broadcast RT-RT command
    /// \param cmdType type of the command to transmit or receive
    /// \param Rt remote terminal (31 for broadcast)
    /// \param Sa subaddress (0 for mode command)
    /// \param WordCount number of data words in the command
    /// \param Rt2 remote terminal (31 for broadcast)
    /// \param Sa2 subaddress (0 for mode command)
    UeiDaqAPI void SetCommand(tUeiMIL1553CommandType cmdType, int Rt, int Sa, int WordCount, int Rt2, int Sa2);
    /// \brief Specify retry options
    /// Specify how many retries bus controller should perform until marking the entry as disabled
    /// User can select different types of reties upon encountering different fault conditions and recovery options
    /// \param NumRetries number of retries to try until disabling the entry. Maximum 7 retries, 0 is to retry forever
    /// \param RetryType specify failure conditions and retry options (flags can be added together)
    UeiDaqAPI void SetRetryOptions(int NumRetries, tUeiMIL1553BCRetryType RetryType);
    /// \brief Select which bus the command is transmitted upon
    /// \param Bus Active bus for this command
    UeiDaqAPI void SetCommandBus(tUeiMIL1553PortActiveBus Bus);
    /// \brief Select which bus the command is transmitted upon
    /// \param enabledBus Active bus for this command
    /// \param initialBus Active bus for this command
    UeiDaqAPI void SetCommandBus(tUeiMIL1553PortActiveBus enabledBus, tUeiMIL1553PortActiveBus initialBus);
    /// \brief Set delay in microseconds prior to command execution
    /// \param delay_us delay in microseconds
    UeiDaqAPI void SetCommandDelay(int delay_us);
    /// \brief Enable to compare received data with minimum and maximum programmed in Tmin and Tmax data arrays (one pair per data word)
    UeiDaqAPI void EnableDataCompare(int enable);
    /// \brief Enable to compare expected command status with returned one 
    /// \param number 0 == status1 (main status) 1 == RT-RT command status
    /// \param and_sts word to perform and operation with the status before comparing it to the value
    /// \param or_sts word to perform or operation with the status before comparing it to the value
    /// \param value word to compare returned status with to validata command
    /// \param enable 1 to enable, 0 to disable
    UeiDaqAPI void EnableStatusCompare(int number, unsigned short and_sts, unsigned short or_sts, unsigned short value, int enable);
    /// \brief Copy transmit data into BCCB
    /// \param Size number of words to copy
    /// \param src words array
    UeiDaqAPI void CopyRxData(int Size, unsigned short* src);
    /// \brief Copy minimim value to compare each received word into BCCB
    /// \param Size number of words to copy
    /// \param src words array
    UeiDaqAPI void CopyTminData(int Size, unsigned short* src);
    /// \brief Copy maximum value to compare each received word into BCCB
    /// \param Size number of words to copy
    /// \param src words array
    UeiDaqAPI void CopyTmaxData(int Size, unsigned short* src);

    UeiDaqAPI tUeiMIL1553BCCBDataFrame* GetFrame();
private:

};

/// \brief CUeiMIL1553BCCBStatusFrame class - request and manipulate BC control block status
//  data as well as status and data Rt replied with
///
/// This class is used to construct and manipulate CUeiMIL1553BCCBStatusFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Reader::read()
class CUeiMIL1553BCCBStatusFrame : public tUeiMIL1553BCCBStatusFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553BCCBStatusFrame();
    /// \brief Constructor with initialization
    UeiDaqAPI CUeiMIL1553BCCBStatusFrame(int MnFrameNum, int MnIndex, int Block);
    /// \brief Constructor with initialization
    UeiDaqAPI CUeiMIL1553BCCBStatusFrame(int BCCBSegment, int BCCBIndex);
    UeiDaqAPI CUeiMIL1553BCCBStatusFrame(tUeiMIL1553BCCBStatusFrame*);
    
    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553BCCBStatusFrame();

    /// \brief Clear structure
    UeiDaqAPI void Clear(void);
    /// \brief Clear and initialze structure with input parameters
    /// \param MnFrameNum minor frame number
    /// \param MnIndex entry in the minor frame 
    /// \param Block upper (0) or lower (1) block if this minor frame entry is involved in double-buffering operation
    UeiDaqAPI void Set(int MnFrameNum, int MnIndex, int Block);
    /// \brief Clear and initialze structure with input parameters
    /// \param BCCBSegment BCCB segment to read status from
    /// \param BCCBIndex BCCB index to read status from
    UeiDaqAPI void Set(int BCCBSegment, int BCCBIndex);

    /// \brief Copy received data into user-allocated area
    /// \param Size number of words to copy
    /// \param dst destination array
    UeiDaqAPI void GetTxData(int Size, unsigned short* dst);

    /// \brief Returns transmit command data as a string
    /// \param Size number of words to print
    UeiDaqAPI std::string GetBcDataStr(int Size);

    /// \brief Returns current bus as string
    UeiDaqAPI std::string GetBus();
    
    /// \brief Returns Rt as string
    UeiDaqAPI std::string GetRt();

    /// \brief Returns Rt as string
    UeiDaqAPI std::string GetTimeStamp();

    /// \brief Returns sts1, sts2 as concatenated string
    UeiDaqAPI std::string GetStatusString();

    /// \brief Returns errsts0, errsts1 as concatenated string
    UeiDaqAPI std::string GetErrorStatusString();
    
    UeiDaqAPI tUeiMIL1553BCCBStatusFrame* GetFrame();
private:

};

/// \brief CUeiMIL1553RTFrame class - write or read RT "send" and "transmit" data areas
///
/// This class is used to construct and manipulate CUeiMIL1553RTFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used with both CUeiMIL1553Reader::read() and CUeiMIL1553Writer::write()
class CUeiMIL1553RTFrame : public tUeiMIL1553RTFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553RTFrame();
    /// \brief Constructor with initialization
    UeiDaqAPI CUeiMIL1553RTFrame(int Rt, int Sa, int Block);
    /// \brief Constructor with initialization
    UeiDaqAPI CUeiMIL1553RTFrame(int Rt, int Sa, int Block, int DataSize);
    UeiDaqAPI CUeiMIL1553RTFrame(tUeiMIL1553RTFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553RTFrame();

    /// \brief Clear structure
    UeiDaqAPI void Clear();
    /// \brief Clear and initialze structure with input parameters
    /// \param Rt remote terminal number (0-31)
    /// \param Sa subaddress number (0-31)
    /// \param Block block number (0 or 1)
    UeiDaqAPI void Set(int Rt, int Sa, int Block);
    /// \brief Clear and initialze structure with input parameters
    /// \param Rt remote terminal number (0-31)
    /// \param Sa subaddress number (0-31)
    /// \param Block block number (0 or 1)
    /// \param DataSize number of data words to read
    UeiDaqAPI void Set(int Rt, int Sa, int Block, int DataSize);    
    /// \brief Copy data into RT frame from the user-allocated array
    /// \param Size number of words to copy
    /// \param src source array
    UeiDaqAPI void CopyData(int Size, unsigned short* src);
    /// \brief Copy fata from RT frame into user-allocated array
    /// \param Size number of words to copy
    /// \param dst destination array
    UeiDaqAPI void GetData(int Size, unsigned short* dst);
    /// \brief Return content of the frame in the string representation (1-R-1-4 for example)
    UeiDaqAPI std::string GetFrameStr();
    /// \brief Return data from RT/SA in the string representation (1224-4556 for example)
    UeiDaqAPI std::string GetDataStr();

    UeiDaqAPI tUeiMIL1553RTFrame* GetFrame();
private:

};

/// \brief CUeiMIL1553BMFrame class - read BM messages divided by idle state of the bus
///
/// This class is used to construct and manipulate CUeiMIL1553BMFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Reader::read()
class CUeiMIL1553BMFrame : public tUeiMIL1553BMFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553BMFrame();
    UeiDaqAPI CUeiMIL1553BMFrame(tUeiMIL1553BMFrame* frm);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553BMFrame();

    /// \brief Clear structure
    UeiDaqAPI void Clear();

    /// \brief Return content of the frame in the string representation
    UeiDaqAPI std::string GetBmDataStr();
    /// \brief Return data content of the frame in the string representation - no timestamp
    UeiDaqAPI std::string GetBmDataStrDataOnly();
    /// \brief Return data from bus monitor in the string representation (1224-4556 for example)
    UeiDaqAPI std::string GetBmMessageStr();
    ///\brief Return Bus that this message traveled on
    UeiDaqAPI std::string GetBus();
    ///\brief Return time in us that  the current bus session has been open
    UeiDaqAPI std::string GetAbsoluteTime();
    ///\brief Return Time in us since last message
    UeiDaqAPI std::string GetMessageGap();

    UeiDaqAPI tUeiMIL1553BMFrame* GetFrame();
};

/// \brief CUeiMIL1553BMCmdFrame class - read BM messages divided by 1553 protocol commands
///
/// This class is used to construct and manipulate CUeiMIL1553BMCmdFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Reader::read()
class CUeiMIL1553BMCmdFrame : public tUeiMIL1553BMCmdFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553BMCmdFrame();
    UeiDaqAPI CUeiMIL1553BMCmdFrame(tUeiMIL1553BMCmdFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553BMCmdFrame();

    /// \brief Clear structure
    UeiDaqAPI void Clear();

    /// \brief Return content of the frame in the string representation
    UeiDaqAPI std::string GetBmDataStr();
    /// \brief Return data content of the frame in the string representation - no timestamp
    UeiDaqAPI std::string GetBmDataStrDataOnly();
    /// \brief Return data from bus monitor in the string representation (1224-4556 for example)
    UeiDaqAPI std::string GetBmMessageStr();
    /// \brief Return the timestamp as a string
    UeiDaqAPI std::string GetTimestampStr();
    /// \brief Return the entire message as a fully descriptive multi-line string
    UeiDaqAPI std::string GetFullBmMessageStr();

    UeiDaqAPI tUeiMIL1553BMCmdFrame* GetFrame();
private:
   bool IsRtRtCmd() { return (Command == UeiMIL1553CmdRTRT) || (Command == UeiMIL1553CmdRTRTBroadcast); }
   bool IsModeCodeCmd() { return (Command == UeiMIL1553CmdModeTxNoData) || (Command == UeiMIL1553CmdModeTxWithData) ||
      (Command == UeiMIL1553CmdModeRxWithData) || (Command == UeiMIL1553CmdModeTxNoDataBroadcast) || (Command == UeiMIL1553CmdModeRxWithDataBroadcast); }
};

/// \brief CUeiMIL1553RTStatusFrame class - write or read RT "send" and "transmit" data areas
///
/// This class is used to construct and manipulate CUeiMIL1553RTStatusFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Reader::read()
class CUeiMIL1553RTStatusFrame : public tUeiMIL1553RTStatusFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553RTStatusFrame();
    /// \brief Constructor with initialization
    UeiDaqAPI CUeiMIL1553RTStatusFrame(int Rt);
    UeiDaqAPI CUeiMIL1553RTStatusFrame(tUeiMIL1553RTStatusFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553RTStatusFrame();

    /// \brief Clear structure
    UeiDaqAPI void Clear();
    /// \brief Clear and initialze structure with input parameter
    /// \param Rt specify what RT status to read
    UeiDaqAPI void Set(int Rt);

    UeiDaqAPI tUeiMIL1553RTStatusFrame* GetFrame();
};

/// \brief CUeiMIL1553RTControlFrame class - run-time control of RT
///
/// This class is used to construct and manipulate CUeiMIL1553RTControlFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Writer::write()
class CUeiMIL1553RTControlFrame : public tUeiMIL1553RTControlFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553RTControlFrame();
    UeiDaqAPI CUeiMIL1553RTControlFrame(tUeiMIL1553RTControlFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553RTControlFrame();
    /// \brief Clear structure
    UeiDaqAPI void Clear();
    /// \brief Clear and initialze structure with input parameter
    /// It can be used instead of programming filter
    /// \param enableMask select which RTs are enabled (bitwise)
    UeiDaqAPI void SetEnableMask(int enableMask);
    /// \brief Clear and initialze structure with input parameter
    /// \param Rt select which RT to control
    /// \param enable == TRUE enables RTs, FALSE disables them (filter permitted)
    UeiDaqAPI void SetEnable(int Rt, int enable);
    /// \brief Select active block for RT->BC for each Rt
    /// \param Rt select which RT to control
    /// \param Block select block either zero or one
    UeiDaqAPI void SelectRtBcBlock(int Rt, int Block);
    /// \brief Select active block for BC->RT for each Rt
    /// \param Rt select which RT to control
    /// \param Block select block either zero or one
    UeiDaqAPI void SelectBcRtBlock(int Rt, int Block);
    /// \brief Select active block for each Rt
    /// \param Rt select Rt validation entry to set for
    /// \param Sa select Sa validation entry to set for
    /// \param validationEntry is a validation entry
    UeiDaqAPI void SetValidEntry(int Rt, int Sa, uInt32 validationEntry);

    UeiDaqAPI tUeiMIL1553RTControlFrame* GetFrame();
};


/// \brief CUeiMIL1553FilterEntry class - run-time control of RT
///
/// This class is used to construct and manipulate CUeiMIL1553FilterEntry to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Writer::write()
class CUeiMIL1553FilterEntry : public tUeiMIL1553FilterEntry
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553FilterEntry();
    /// \brief Constructor with initialization
    UeiDaqAPI CUeiMIL1553FilterEntry(tUeiMIL1553FilterType FilterType, int Rt, int Sa);
    
    UeiDaqAPI CUeiMIL1553FilterEntry(tUeiMIL1553FilterEntry* entry);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553FilterEntry();

    

    /// \brief Clear structure
    UeiDaqAPI void Clear();
    /// \brief Clear and initialze structure with input parameter
    /// \param FilterType select type of filtering to apply
    /// \param Rt select which RT to enable
    /// \param Sa select which SA to enable
    UeiDaqAPI void Set(tUeiMIL1553FilterType FilterType, int Rt, int Sa);

    /// \brief Set minimum and maximum data sizes to accept by RT
    /// Set minimum and maximum data sizes to accept by RT
    /// This method requires that FilterType is set to UeiMIL1553FilterByRtSaSize
    /// If filter is not set all RTs are enabled
    /// If filter is set to UeiMIL1553FilterByRt all SAs of selected RTs are enabled
    /// If filter is set to UeiMIL1553FilterByRtSa all command and sizes of selected RT/SA are enabled
    /// \param MinRxLength minimum lenght for BC->RT command
    /// \param MaxRxLength maximum lenght for BC->RT command
    /// \param MinTxLength minimum lenght for RT->BC command
    /// \param MaxTxLength maximum lenght for RT->BC command
    UeiDaqAPI void SetSizes(int MinRxLength, int MaxRxLength, int MinTxLength, int MaxTxLength);
    
    /// \brief Enable different types of commands
    /// This method requires that FilterType is set to UeiMIL1553FilterByRtSaSize
    /// \param EnableRxRequests set to TRUE to enable Rx (BC->RT) requests
    /// \param EnableTxRequests set to TRUE to enable Tx (RT->BC) requests
    /// \param EnableModeCommands set to TRUE to enable receiving of mode commands
    UeiDaqAPI void EnableCommands(int EnableRxRequests, int EnableTxRequests, int EnableModeCommands);

    UeiDaqAPI tUeiMIL1553FilterEntry* GetEntry();
};


/// \brief CUeiMIL1553RTParametersFrame class - specify RT parameters during initialization
///
/// This class is used to construct and manipulate CUeiMIL1553RTParametersFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Writer::write()
class CUeiMIL1553RTParametersFrame : public tUeiMIL1553RTParametersFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553RTParametersFrame();
    /// \brief Constructor with initialization
    UeiDaqAPI CUeiMIL1553RTParametersFrame(int Rt);
    UeiDaqAPI CUeiMIL1553RTParametersFrame(tUeiMIL1553RTParametersFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553RTParametersFrame();

    /// \brief Clear structure
    UeiDaqAPI void Clear();
    /// \brief Clear and initialze structure with input parameter
    /// \param Rt select which RT to set parameters for
    UeiDaqAPI void Set(int Rt);

    UeiDaqAPI tUeiMIL1553RTParametersFrame* GetFrame();
};

/// \brief CUeiMIL1553BusWriterFrame class - write data to the bus
///
/// This class is used to construct and manipulate CUeiMIL1553BusWriterFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Writer::write()
class CUeiMIL1553BusWriterFrame : public tUeiMIL1553BusWriterFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553BusWriterFrame();
    UeiDaqAPI CUeiMIL1553BusWriterFrame(tUeiMIL1553BusWriterFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553BusWriterFrame();

    /// \brief Clear structure
    UeiDaqAPI void Clear();
    /// \brief  Add command to Tx Frame (BC-RT or RT-BC or mode or broadcast)
    UeiDaqAPI void SetCommand(int Rt, int Sa, int WordCount, tUeiMIL1553CommandType Command);
    /// \brief Add RT-RT command to Tx Frame
    UeiDaqAPI void SetCommand(int Rt, int Sa, int Rt2, int Sa2, int WordCount, tUeiMIL1553CommandType Command);
    /// \brief Add pre-command delay
    UeiDaqAPI void SetDelay(int Delay);
    /// \brief Add data from the user-allocated array
    /// \param Size number of words to copy
    /// \param src source array
    UeiDaqAPI void CopyData(int Size, unsigned short* src);

    UeiDaqAPI tUeiMIL1553BusWriterFrame* GetFrame();
};

/// \brief CUeiMIL1553BCStatusFrame class - receive BC status information
///
/// This class is used to construct and manipulate CUeiMIL1553BCStatusFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Writer::read()
class CUeiMIL1553BCStatusFrame : public tUeiMIL1553BCStatusFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553BCStatusFrame();
    UeiDaqAPI CUeiMIL1553BCStatusFrame(tUeiMIL1553BCStatusFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553BCStatusFrame();

    UeiDaqAPI tUeiMIL1553BCStatusFrame* GetFrame();
};


/// \brief CUeiMIL1553BCControlFrame class - control BC execution process
///
/// This class is used to construct and manipulate CUeiMIL1553BCStatusFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Writer::write()
class CUeiMIL1553BCControlFrame : public tUeiMIL1553BCControlFrame
{
public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553BCControlFrame();
    UeiDaqAPI CUeiMIL1553BCControlFrame(tUeiMIL1553BCControlFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553BCControlFrame();
    /// \brief disable operation
    UeiDaqAPI void SetDisable();
    /// \brief prepare frame to perform continues operation
    UeiDaqAPI void SetEnableContinous(double Minor, double Major);
    /// \brief prepare frame to perform one major step
    UeiDaqAPI void SetOneMajorStep();
    /// \brief prepare frame to perform one minor step
    UeiDaqAPI void SetOneMinorStep();
    /// \brief prepare frame to perform goto command
    UeiDaqAPI void SetGoto(tUeiMIL1553BCGotoOps command, int major, int minor);
    /// \brief prepare frame to select minor frame block
    UeiDaqAPI void SelectMnBlock(unsigned int block);
    /// \brief enable disabled and disable enabled NJ entries with "swap" flag set
    UeiDaqAPI void SwapMjEntries();

    UeiDaqAPI tUeiMIL1553BCControlFrame* GetFrame();
};

/// \brief CUeiMIL1553A708DataFrame class - exchange data with ARINC-708
///
/// This class is used to construct and manipulate CUeiMIL1553A708DataFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Writer::write()
class CUeiMIL1553A708DataFrame : public tUeiMIL1553A708DataFrame
{
    public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553A708DataFrame();
    UeiDaqAPI CUeiMIL1553A708DataFrame(tUeiMIL1553A708DataFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553A708DataFrame();

    UeiDaqAPI tUeiMIL1553A708DataFrame* GetFrame();
};

/// \brief CUeiMIL1553A708ControlFrame class - control ARINC-708 operations
///
/// This class is used to construct and manipulate CUeiMIL1553A708ControlFrame to simplify its use
/// You can use a pointer to this class instead of its parent structure
/// Class can be used only with CUeiMIL1553Writer::write()
class CUeiMIL1553A708ControlFrame : public tUeiMIL1553A708ControlFrame
{
    public:
    /// \brief Constructor
    UeiDaqAPI CUeiMIL1553A708ControlFrame();
    UeiDaqAPI CUeiMIL1553A708ControlFrame(tUeiMIL1553A708ControlFrame*);

    /// \brief Destructor
    UeiDaqAPI ~CUeiMIL1553A708ControlFrame();

    UeiDaqAPI tUeiMIL1553A708ControlFrame* GetFrame();
};



}

#endif // __UEIFRAMEUTILS_H__
