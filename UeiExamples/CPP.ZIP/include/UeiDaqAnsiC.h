///
/// \file
/// The UeiDaq Framework ANSI-C programming interface allows you to program
/// the framework using the ANSI-C language. It is very close to the UeiDaq C++ class
/// library model.
/// Each framework C++ class is represented in ANSI-C by a handle datatype and
/// there is an ANSI-C funtion corresponding to each C++ class method.
///

#ifndef __UEIDAQANSIC_H__
#define __UEIDAQANSIC_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

#ifdef __cplusplus
   using namespace UeiDaq;

   extern "C" {
#endif

/// \brief The SessionHandle type represents a session object.
///
/// Represents a session object created with UeiDaqCreateSession and destroyed with
/// UeiDaqCloseSession.
typedef void*      SessionHandle;
/// \brief The DeviceHandle type represents a device object.
///
/// Call UeiDaqGetDeviceHandle to get the handle of the
/// device associated with a session.
typedef void*      DeviceHandle;
/// \brief The TimingHandle type represents a timing object.
///
/// Call UeiDaqGetTimingHandle to get the handle of the
/// timing object associated with a session.
typedef void*      TimingHandle;
/// \brief The TriggerHandle type represents a trigger object.
///
/// Call UeiDaqGet**TriggerHandle to get the handle of one of the
/// trigger objects associated with a session.
typedef void*      TriggerHandle;
/// \brief The ChannelHandle type represents a channel object.
///
/// Call UeiDaqGetChannelHandle to get the handle of one of the channel
/// objects associated with a session.
typedef void*      ChannelHandle;
/// \brief The DataStreamHandle type represents a DataStream object.
///
/// Call UeiDaqGetDataStreamHandle to get the handle of the
/// DataStream object associated with a session.
typedef void*      DataStreamHandle;

/// \brief Asynchronous callback function prototype.
///
/// The prototype of the callback function called when reading/writing
/// asynchronously. You can initiate an asynchronous operation using
/// one of the UeiDaqRead**Async or UeiDaqWrite***Async function calls.
typedef void (*tUeiEventCallback)(tUeiEvent event, void* param);

/// \brief Create a session
///
/// Allocates and initializes resources for a new session.
///
/// \param sessionHandle The handle to the new session
/// \return The status code
UeiDaqAPI int UeiDaqCreateSession(SessionHandle* sessionHandle);

/// \brief Close a session
///
/// Releases resources for the specified session.
///
/// \param sessionHandle The handle to the session
/// \return The status code
UeiDaqAPI int UeiDaqCloseSession(SessionHandle sessionHandle);

/// \brief Close a device
///
/// Releases resources for the specified device.
/// Call this function to release handles obtained with UeiDaqEnumDevice
///
/// \param deviceHandle The handle to close
/// \return The status code
UeiDaqAPI int UeiDaqCloseDevice(DeviceHandle deviceHandle);

/// \brief Create Diagnostic input channel list
///
/// Create and add one or more channel to the diagnostic channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \return The status code
UeiDaqAPI int UeiDaqCreateDiagnosticChannel(SessionHandle sessionHandle, char* resource);

/// \brief Create Analog voltage input channel list
///
/// Create and add one or more channel to the AI channel list associated with the session.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
/// UeiDaqCreateAIChannel(mySession, "pwrdaq://Dev1/Ai0", -10.0, 10.0, UeiAIChannelInputModeDifferential );
/// \endcode
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param min The minimum value you expect to measure.
/// \param max The maximum value you expect to measure
/// \param mode The input mode of the Analog input(s)
/// \return The status code
UeiDaqAPI int UeiDaqCreateAIChannel(SessionHandle sessionHandle, char* resource, f64 min, f64 max, tUeiAIChannelInputMode mode);

/// \brief Create Analog current input channel list
///
/// Create and add one or more channel to the AI channel list associated with the session.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
/// UeiDaqCreateAIChannel(mySession, "pwrdaq://Dev1/Ai0", -10.0, 10.0, UeiAIChannelInputModeDifferential );
/// \endcode
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param min The minimum value you expect to measure.
/// \param max The maximum value you expect to measure
/// \param enableCB The circuit breaker configuration
/// \param mode The input mode of the Analog input(s)
/// \return The status code
UeiDaqAPI int UeiDaqCreateAICurrentChannel(SessionHandle sessionHandle, char* resource, f64 min, f64 max, tUeiFeatureEnable enableCB, tUeiAIChannelInputMode mode);

/// \brief Create Analog output channel list
///
/// Create and add one or more channel to the AO channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param min The minimum value you expect to generate.
/// \param max The maximum value you expect to generate
/// \param resource The device and channel(s) to add to the list.
/// \return The status code
UeiDaqAPI int UeiDaqCreateAOChannel(SessionHandle sessionHandle, char* resource, f64 min, f64 max);

/// \brief Create Analog output current channel list
///
/// Create and add one or more current channel to the AO current channel list associated with the session.
/// Current channels are only available on AO devices capable of outputing current
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param min The minimum value you expect to generate.
/// \param max The maximum value you expect to generate
/// \return The status code
UeiDaqAPI int UeiDaqCreateAOCurrentChannel(SessionHandle sessionHandle, char* resource, f64 min, f64 max);

/// \brief Create Analog output waveform channel list
///
/// Create and add one or more waveform channel to the channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param dacClockSource the main DAC clock source
/// \param offsetDACClockSource the offset DAC clock source
/// \param clockSync channel0 clock routing
/// \return The status code
UeiDaqAPI int UeiDaqCreateAOWaveformChannel(SessionHandle sessionHandle, 
                                            char* resource, 
                                            tUeiAOWaveformClockSource dacClockSource,
                                            tUeiAOWaveformOffsetClockSource offsetDACClockSource,
                                            tUeiAOWaveformClockSync clockSync);

/// \brief Create Protected analog output channel list
///
/// Create and add one or more channel to the channel list associated with the session.
/// Protected AO channels are available on certain devices such as the DNA-AO-318 and DNA-AO-316.
/// The amount of current flowing through each output is monitored at the given rate
/// and must stay within the specified range, otherwise the device will automatically open
/// the circuit acting as a breaker.
/// You can specify whether the device should attempt to reestablish the circuit and how
/// often it should try to do so.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param mode Selects which DAC is conencted to the output
/// \param measurementRate The monitoring rate. Determines how fast the breaker react after an over or under-limit condition.
/// \param autoRetry Specifies whether the device will attempt to reestablish the circuit after an over or under-limit condition
/// \param retryRate The number of retries per second.
/// \return A pointer to the first channel created.
/// \return The status code
UeiDaqAPI int UeiDaqCreateAOProtectedChannel(SessionHandle sessionHandle, 
                                             char* resource,
                                             tUeiAODACMode mode,
                                             double measurementRate,
                                             int autoRetry,
                                             double retryRate);

/// \brief Create Protected analog output current channel list
///
/// Create and add one or more channel to the channel list associated with the session.
/// Protected AO current channels are available on certain devices such as the DNA-AO-318-020
/// The amount of current flowing through each output is monitored at the given rate
/// and must stay within the specified range, otherwise the device will automatically open
/// the circuit acting as a breaker.
/// You can specify whether the device should attempt to reestablish the circuit and how
/// often it should try to do so.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param mode Selects which DAC is connected to the output
/// \param measurementRate The monitoring rate. Determines how fast the breaker react after an over or under-limit condition.
/// \param autoRetry Specifies whether the device will attempt to reestablish the circuit after an over or under-limit condition
/// \param retryRate The number of retries per second.
/// \return The status code
UeiDaqAPI int UeiDaqCreateAOProtectedCurrentChannel(SessionHandle sessionHandle, 
                                                    char* resource,
                                                    tUeiAODACMode mode,
                                                    double measurementRate,
                                                    int autoRetry,
                                                    double retryRate);

/// \brief Create Simulated Thermocouple output channel list
///
/// Create and add one or more simulated thermocouple channel to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param tcType The type of thermocouple to simulate.
/// \param tempScale The temperature unit used to convert temperature to volts.
/// \param enableCjc The cold junction compensation state.
/// \return The status code
UeiDaqAPI int UeiDaqCreateSimulatedTCChannel(SessionHandle sessionHandle,
                                             char* resource,
                                             tUeiThermocoupleType tcType,
                                             tUeiTemperatureScale tempScale,
                                             int enableCjc);

/// \brief Create simulated RTD output channel list
///
/// Create and add one or more simulated RTD channel to the channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param rtdType The type of RTD connected on the Analog input(s).
/// \param rtdNominalResistance The nominal resistance of the RTD at ice point (0 deg Celsius).
/// \param tempScale The temperature unit used to convert resistance to temperature.
/// \return The status code.
UeiDaqAPI int UeiDaqCreateSimulatedRTDChannel(SessionHandle sessionHandle,
                                              char* resource,
                                              tUeiRTDType rtdType,
                                              double rtdNominalResistance,
                                              tUeiTemperatureScale tempScale);

/// \brief Create Digital input channel list
///
/// Create and add one or more channel to the DI channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \return The status code
UeiDaqAPI int UeiDaqCreateDIChannel(SessionHandle sessionHandle, char* resource);

/// \brief Create Digital input channel list
///
/// Create and add one or more channel to the DO channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \return The status code
UeiDaqAPI int UeiDaqCreateDOChannel(SessionHandle sessionHandle, char* resource);

/// \brief Create Counter input channel list
///
/// Create and add one or more channel to the CI channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param source The source of the signal counted or used as a timebase
/// \param mode The mode that specify whether the session counts events, measures a pulse width or measures a period on the signal configured as the source
/// \param gate The signal that specify whether the counter/timer is on or off
/// \param divider The divider used to scale the timebase speed
/// \param inverted Specifies whether the signal at the source is inverted before performing the counting operation
/// \return The status code
UeiDaqAPI int UeiDaqCreateCIChannel(SessionHandle sessionHandle,
                                    char* resource,
                                    tUeiCounterSource source,
                                    tUeiCounterMode mode,
                                    tUeiCounterGate gate,
                                    Int32 divider,
                                    Int32 inverted);

/// \brief Create Variable Reluctance input channel list
///
/// Create and add one or more channel to the VR channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param mode The mode used to decode/count the VR sensor signal
/// \return The status code
UeiDaqAPI int UeiDaqCreateVRChannel(SessionHandle sessionHandle,
                                    char* resource,
                                    tUeiVRMode mode);


/// \brief Create quadrature encoder input channel list
///
/// Create and add one or more channel to the CI channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param initialPosition The initial number of pulses when the session starts
/// \param decodingType The decoding type 1x, 2x or 4x
/// \param enableZeroIndexing Enable or disable restting the measurement when a zero index event is detected
/// \param zeroIndexPhase Specifies the states of A, B and Z inputs that will generate a zero index event
/// \return The status code
UeiDaqAPI int UeiDaqCreateQuadratureEncoderChannel(SessionHandle sessionHandle,
                                          char* resource,
                                          uInt32 initialPosition,
                                          tUeiQuadratureDecodingType decodingType,
                                          Int32 enableZeroIndexing,
                                          tUeiQuadratureZeroIndexPhase zeroIndexPhase);


/// \brief Create Counter output channel list
///
/// Create and add one or more channel to the CO channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param source The timebase used to determine the shape of the signal generated on the counter output
/// \param mode The mode that specify whether the session generate a pulse or a pulse train on the counter output
/// \param gate The signal that specify whether the counter/timer is on or off
/// \param tick1 Specifies how long the output stays low, number of ticks of the signal connected at the source.
/// \param tick2 Specifies how long the output stays high, number of ticks of the signal connected at the source.
/// \param divider The divider used to scale the timebase speed
/// \param inverted Specifies whether the signal at the source is inverted before performing the operation
/// \return The status code
UeiDaqAPI int UeiDaqCreateCOChannel(SessionHandle sessionHandle,
                                    char* resource,
                                    tUeiCounterSource source,
                                    tUeiCounterMode mode,
                                    tUeiCounterGate gate,
                                    uInt32 tick1,
                                    uInt32 tick2,
                                    Int32 divider,
                                    Int32 inverted);

/// \brief Create Thermocouple input channel list
///
/// Create and add one or more thermocouple channel to the thermocouple channel list associated with the session.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
/// UeiDaqCreateTCChannel(mySession, "pwrdaq://Dev1/Ai0", -100.0, 100.0, UeiThermocoupleTypeJ,
///                           UeiTemperatureScaleCelsius, UeiCJCTypeConstant, 25.0, "",
///                           UeiAIChannelInputModeDifferential);
/// \endcode
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param min The minimum value you expect to measure.
/// \param max The maximum value you expect to measure.
/// \param tcType The type of thermocouple connected on the Analog input(s).
/// \param tempScale The temperature unit used to convert volts to temperature.
/// \param cjcType The cold junction compensation type.
/// \param cjcConstant The cold junction compensation constant, this parameter is only used if cjcType is set to UeiCJCTypeConstant.
/// \param cjcResource The resource string of the channel on which the cold junction compensation sensor is connected, this parameter is only used if cjcType is set to UeiCJCTypeResource.
/// \param mode The input mode used to measure voltage from the thermocouple
/// \return The status code.
/// \sa UeiDaqCreateAIChannel
UeiDaqAPI int UeiDaqCreateTCChannel(SessionHandle sessionHandle,
                                    char* resource,
                                    f64 min,
                                    f64 max,
                                    tUeiThermocoupleType tcType,
                                    tUeiTemperatureScale tempScale,
                                    tUeiColdJunctionCompensationType cjcType,
                                    f64 cjcConstant,
                                    char* cjcResource,
                                    tUeiAIChannelInputMode mode);

/// \brief Create Resistance input channel list
///
/// Create and add one or more resistance channel to the channel list associated with the session.
/// In two wires mode, only one analog input channel per resistance is required.
/// In four wires mode, two analog input channels per resistance are required effectively
/// dividing the number of available channels on your device by two.
/// Channels are paired consecutively: (0,1), (2,3), (4,5).... You only need to specify the first channel in the channel list.
/// Read the DNA-STP-AIU manual to learn how to connect your resistance.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
/// UeiDaqCreateResistanceChannel(mySession, "pdna://192.168.100.2/Dev1/Ai0", 0.0, 1000.0,
///                               UeiFourWires, 0.0);
/// \endcode
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param min The minimum value you expect to measure.
/// \param max The maximum value you expect to measure.
/// \param wiring The wiring scheme used to connect the resistive sensor to the acquisition device.
/// \param twoWiresLeadResistance The leads resistance in two wires mode.
/// \param mode The input mode used to measure voltage from the sensor
/// \return The status code.
/// \sa UeiDaqCreateAIChannel
UeiDaqAPI int UeiDaqCreateResistanceChannel(SessionHandle sessionHandle,
                                            char* resource,
                                            f64 min,
                                            f64 max,
                                            tUeiWiringScheme wiring,
                                            double twoWiresLeadResistance,
                                            tUeiAIChannelInputMode mode);

/// \brief Create RTD input channel list
///
/// Create and add one or more RTD channel to the channel list associated with the session.
/// In two wires mode, only one analog input channel per RTD is required.
/// In four wires mode, two analog input channels per RTD are required effectively
/// dividing the number of available channels on your device by two.
/// Channels are paired consecutively: (0,1), (2,3), (3,4).... You only need to specify the first channel in the channel list.
/// Read the DNA-STP-AIU manual to learn how to connect your RTD.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
/// UeiDaqCreateRTDChannel(mySession, "pdna://192.168.100.2/Dev1/Ai0", -100.0, 100.0, UeiFourWires, 0.0,
///                        UeiRTDType3850, 100.0, UeiTemperatureScaleCelsius,
///                        UeiAIChannelInputModeDifferential);
/// \endcode
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param min The minimum value you expect to measure.
/// \param max The maximum value you expect to measure.
/// \param wiring The wiring scheme used to connect the RTD to the acquisition device.
/// \param twoWiresLeadResistance The leads resistance in two wires mdoe.
/// \param rtdType The type of RTD connected on the Analog input(s).
/// \param rtdNominalResistance The nominal resistance of the RTD at ice point (0 deg Celsius).
/// \param tempScale The temperature unit used to convert resistance to temperature.
/// \param mode The input mode used to measure voltage from the sensor
/// \return The status code.
/// \sa UeiDaqCreateAIChannel
UeiDaqAPI int UeiDaqCreateRTDChannel(SessionHandle sessionHandle,
                                     char* resource,
                                     f64 min,
                                     f64 max,
                                     tUeiWiringScheme wiring,
                                     double twoWiresLeadResistance,
                                     tUeiRTDType rtdType,
                                     double rtdNominalResistance,
                                     tUeiTemperatureScale tempScale,
                                     tUeiAIChannelInputMode mode);

/// \brief Create Analog input with excitation channel list
///
/// Create and add one or more analog input channel to the channel list associated with the session.
/// This will only work with devices that can provide excitation voltage.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
/// UeiDaqCreateAIVExChannel(mySession, "pdna://Dev1/Ai0", -100.0, 100.0, UeiSensorFullBridge,
///                         10.0, true);
/// \endcode
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param min The minimum value you expect to measure.
/// \param max The maximum value you expect to measure.
/// \param sensorBridgeType The type of the wheatstone bridge built-in the sensor
/// \param excitationVoltage The excitation voltage to output to the sensor
/// \param useExcitationForScaling Specifies whether the acquired data is divided by the excitation voltage
/// \param mode The input mode used to measure voltage from the sensor
/// \return The status code.
/// \sa UeiDaqCreateAIChannel
UeiDaqAPI int UeiDaqCreateAIVExChannel(SessionHandle sessionHandle,
                                       char* resource,
                                       f64 min,
                                       f64 max,
                                       tUeiSensorBridgeType sensorBridgeType,
                                       double excitationVoltage,
                                       int useExcitationForScaling,
                                       tUeiAIChannelInputMode mode);

/// \brief Create Accelerometer channel list
///
/// Create and add one or more accelerometer channel to the channel list associated with the session.
/// This will only work with devices that can provide excitation current for
/// ICP and IEPE sensors.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
///
/// // Configure channel 0 on device 1 to acquire acceleration measured
/// // by a sensor with a sensitivity of 24 mV/g, powered by a current
/// // of 5mA. the gain of the device is adjusted to measure accelerations
/// // between -10.0g and + 10.0g
/// UeiDaqCreateAccelChannel(mySession, "pwrdaq://Dev1/Ai0", -10.0, 10.0, 24,
///                          5.0, UeiCouplingAC);
/// \endcode
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param min The minimum value you expect to measure. The unit depends on the unit of the accelerometer sensitivity. (mV/g will provide measurements in g).
/// \param max The maximum value you expect to measure. The unit depends on the unit of the accelerometer sensitivity. (mV/g will provide measurements in g).
/// \param sensorSensitivity The sensitivity of the accelerometer. The unit of this parameter specifies the unit of the measurements.
/// \param excitationCurrent The excitation current to output to the sensor
/// \param coupling The coupling type. AC coupling turns on a 0.1Hz high pass filter.
/// \param enableLowPassFilter Turn on or off the low-pass anti-aliasing filter
/// \return The status code.
/// \sa UeiDaqCreateAIChannel
UeiDaqAPI int UeiDaqCreateAccelChannel(SessionHandle sessionHandle,
                                       char* resource,
                                       f64 min,
                                       f64 max,
                                       double sensorSensitivity,
                                       double excitationCurrent,
                                       tUeiCoupling coupling,
                                       int enableLowPassFilter);

/// \brief Create digital multi-meter channel
///
/// Create and add one or more analog input channel to the channel list associated with the session.
/// This will only work with DMM devices.
///
/// \par Example:
/// \code 
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
///
/// UeiDaqCreateDMMChannel(mySession, "pdna://192.168.100.2/Dev1/Ai0", 10, UeiDMMModeDCVoltage);
/// \endcode
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param range The input range. Input signals will need to be within -range/+range interval.
/// \param measurementMode The measurement mode configuration
/// \return The status code.
/// \sa UeiDaqCreateAIChannel
UeiDaqAPI int UeiDaqCreateDMMChannel(SessionHandle sessionHandle,
                                     char* resource,
                                     f64 range,
                                     tUeiDMMMeasurementMode measurementMode);

/// \brief Create LVDT/RVDT input channel list
///
/// Create and add one or more LVDT or RVDT input channel to the channel list associated with the session.
/// This will only work with devices that can provide excitation waveform
/// to the LVDT or RVDT sensor.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
///
/// // Configure channel 0 on device 1 to acquire position measured
/// // by a LVDT with a sensitivity of 24 mV/V/mm, powered by a 600Hz
/// // sine waveform with amplitude of 10.0V RMS .
/// // The gain of the device is adjusted to measure positions
/// // between -10.0mm and + 10.0mm
/// UeiDaqCreateLVDTChannel(mySession, "pwrdaq://Dev1/Ai0", -10.0, 10.0, 24,
///                         UeiLVDTFiveWires, 10.0, 600.0, 0);
/// \endcode
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param min The minimum value you expect to measure. The unit depends on the unit of the LVDT/RVDT sensitivity. (mV/V/mm will provide measurements in mm).
/// \param max The maximum value you expect to measure. The unit depends on the unit of the LVDT/RVDT sensitivity. (mV/V/mm will provide measurements in mm).
/// \param sensorSensitivity The sensitivity of the LVDT or RVDT. The unit of this parameter specifies the unit of the measurements.
/// \param wiringScheme Specifies whether the LVDT/RVDT is tied to the device using 4 or 5 wires
/// \param excitationVoltage The amplitude RMS of the excitation sine waveform to output to the sensor
/// \param excitationFrequency The frequency of the excitation sine waveform to output to the sensor
/// \param externalExcitation Specifies whther the LVDT is powered by the device or by an external source.
/// \return The status code.
/// \sa UeiDaqCreateAIChannel
UeiDaqAPI int UeiDaqCreateLVDTChannel(SessionHandle sessionHandle,
                                      char* resource,
                                      f64 min,
                                      f64 max,
                                      double sensorSensitivity,
                                      tUeiLVDTWiringScheme wiringScheme,
                                      double excitationVoltage,
                                      double excitationFrequency,
                                      int externalExcitation);

/// \brief Create simulated LVDT/RVDT output channel list
///
/// Create and add one or more simulated LVDT or RVDT output channel to the channel list associated with the session.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
///
/// // Configure channel 0 on device 1 to simulate position measured
/// // by a LVDT with a sensitivity of 24 mV/V/mm, powered by a 600Hz
/// // sine waveform with amplitude of 10.0V RMS.
/// UeiDaqCreateSimulatedLVDTChannel(mySession, "pwrdaq://Dev1/Ai0", 24,
///                                  UeiLVDTFiveWires, 10.0, 600.0);
/// \endcode
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param sensorSensitivity The sensitivity of the LVDT or RVDT. The unit of this parameter specifies the unit of the measurements.
/// \param wiringScheme Specifies whether the LVDT/RVDT is tied to the device using 4 or 5 wires
/// \param excitationVoltage The amplitude RMS of the excitation sine waveform to output to the sensor
/// \param excitationFrequency The frequency of the excitation sine waveform to output to the sensor
/// \return The status code.
/// \sa UeiDaqCreateAOChannel
UeiDaqAPI int UeiDaqCreateSimulatedLVDTChannel(SessionHandle sessionHandle,
                                      char* resource,
                                      double sensorSensitivity,
                                      tUeiLVDTWiringScheme wiringScheme,
                                      double excitationVoltage,
                                      double excitationFrequency);

/// \brief Create Synchro/Resolver analog input channel list
///
/// Create and add one or more Synchro or Resolver channel to the channel list associated with the session.
/// This will only work with devices that can provide excitation waveform
/// to the Synchro or Resolver sensor.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
///
/// // Configure channel 0 on device 1 to acquire position measured
/// // by a synchro powered by a 600Hz sine waveform with
/// // amplitude of 10.0 VRMS.
/// UeiDaqCreateSynchroResolverChannel(mySession, "pwrdaq://Dev1/Ai0",
///                                    UeiSynchroMode, 10.0, 600.0, false);
/// \endcode
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param mode Specifies whether the input sensor is a synchro or a resolver
/// \param excitationVoltage The amplitude RMS of the excitation sine waveform to output to the sensor
/// \param excitationFrequency The frequency of the excitation sine waveform to output to the sensor
/// \param externalExcitation Specifies whther the sensor is powered by the device or by an external source.
/// \return The status code.
/// \sa CreateAIChannel
UeiDaqAPI int UeiDaqCreateSynchroResolverChannel(SessionHandle sessionHandle,
                                                 char* resource,
                                                 tUeiSynchroResolverMode mode,
                                                 double excitationVoltage,
                                                 double excitationFrequency,
                                                 int externalExcitation);

/// \brief Create simulated Synchro/Resolver analog output channel list
///
/// Create and add one or more simulated synchro or simulated resolver
/// channel to the channel list associated with the session.
///
/// \par Example:
/// \code
/// SessionHandle mySession;
/// UeiDaqCreateSession(&mySession);
///
/// // Configure channel 0 on device 1 to simulate position measurement
/// // returned by a synchro powered by a 600Hz sine waveform with
/// // amplitude of 10.0 VRMS.
/// UeiDaqCreateSimulatedSynchroResolverChannel(mySession, "pwrdaq://Dev1/Ai0",
///                                             UeiSynchroMode, 10.0, 600.0, false);
/// \endcode
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param mode Specifies whether the sensor simulated is a synchro or a resolver
/// \param excitationVoltage The amplitude RMS of the excitation sine waveform to output to the sensor
/// \param excitationFrequency The frequency of the excitation sine waveform to output to the sensor
/// \param externalExcitation Specifies whther the sensor is powered by the device or by an external source.
/// \return The status code.
/// \sa CreateAIChannel
UeiDaqAPI int UeiDaqCreateSimulatedSynchroResolverChannel(SessionHandle sessionHandle,
                                                          char* resource,
                                                          tUeiSynchroResolverMode mode,
                                                          double excitationVoltage,
                                                          double excitationFrequency,
                                                          int externalExcitation);

/// \brief Create serial port
///
/// Create and add one or more serial ports to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param mode The serial port mode: RS-232, RS-485 half ans full duplex
/// \param bitsPerSecond The number of bits transmitted per second over the serial link
/// \param dataBits The number of data bits describing each character
/// \param parity The parity scheme used for transmission error detection
/// \param stopBits The number of stop bits used to indicate the end of a data message
/// \param termination The read operation terminates when the termination string is read from the serial device
/// \return the status code.
UeiDaqAPI int UeiDaqCreateSerialPort(SessionHandle sessionHandle,
                                     char* resource,
                                     tUeiSerialPortMode mode,
                                     tUeiSerialPortSpeed bitsPerSecond,
                                     tUeiSerialPortDataBits dataBits,
                                     tUeiSerialPortParity parity,
                                     tUeiSerialPortStopBits stopBits,
                                     char* termination);

/// \brief Create HDLC port
///
/// Create and add one or more HDLC ports to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param physInterface The physical interface: RS-232, RS-485 or RS-422
/// \param bitsPerSecond The number of bits transmitted per second 
/// \param encoding The method used to encode bits on the physical interface
/// \param crcMode The method used to calculate each frame CRC
/// \param txClockSource The source of the transmitter clock
/// \param rxClockSource The source of the receiver clock
/// \return the status code.
UeiDaqAPI int UeiDaqCreateHDLCPort(SessionHandle sessionHandle,
                                   char* resource,
                                   tUeiHDLCPortPhysical physInterface,
                                   uInt32 bitsPerSecond,
                                   tUeiHDLCPortEncoding encoding,
                                   tUeiHDLCPortCRCMode crcMode,
                                   tUeiHDLCPortClockSource txClockSource,
                                   tUeiHDLCPortClockSource rxClockSource);

/// \brief Create CAN port
///
/// Create and add one or more CAN ports to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param bitsPerSecond The number of bits transmitted per second over the CAN port
/// \param frameFormat Specifies the format of frames sent, basic (11 bits ID) or extended (29 bits ID)
/// \param mode The operation mode, normal or passive to only listen
/// \param acceptanceMask The acceptance mask is used to filter incoming frames. The mask selects
///                       which bits within arbitration ID will be used for filtering.
/// \param acceptanceCode The acceptance code is used to filter incoming frames. The arbitration ID bits selected
///                       by the mask are compared to the code and the frame is rejected if there is any difference.
///                       If (mask XOR id) AND code == 0 the frame is accepted.
/// \return the status code.
/// \sa UeiDaqCreateSerialPort
UeiDaqAPI int UeiDaqCreateCANPort(SessionHandle sessionHandle,
                                  char* resource,
                                  tUeiCANPortSpeed bitsPerSecond,
                                  tUeiCANFrameFormat frameFormat,
                                  tUeiCANPortMode mode,
                                  uInt32 acceptanceMask,
                                  uInt32 acceptanceCode);

/// \brief Create Industrial digital output channel list
///
/// Create and add one or more channel to the channel list associated with the session.
/// Each channel is associated with a digital output port that groups a predefined number of output lines.
/// Industrial DO channels are available on certain devices such as the DNx-MF-101 and DNx-DIO-43x.
/// low-to high and high to low transitions can be replaced by pwm providing soft start and soft stop.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param pwmMode The PWM mode used to soft start and/or stop.
/// \param pwmLengthUs The soft start/stop pulse train length in micro-seconds.
/// \param pwmPeriodUs The soft start/stop or continuous pulse train period in micro-seconds.
/// \param pwmDutyCycle The continuous pulse train duty cycle
/// \return The status code.
/// \sa UeiDaqCreateDOChannel
UeiDaqAPI int UeiDaqCreateDOIndustrialChannel(SessionHandle sessionHandle,
                                              char* resource, 
                                              tUeiDOPWMMode pwmMode, 
                                              uInt32 pwmLengthUs,
                                              uInt32 pwmPeriodUs,
                                              double pwmDutyCycle);

/// \brief Create Protected digital output channel list
///
/// Create and add one or more channel to the channel list associated with the session.
/// Protected channels are available on certain devices such as the PowerDNA DIO-416.
/// The amount of current flowing through each digital line is monitored at the given rate
/// and must stay within the specified range, otherwise the device will automatically open
/// the circuit acting as a breaker.
/// You can specify whether the device should attempt to reestablish the circuit and how
/// often it should try to do so.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param underCurrentLimit The minimum amount of current allowed in Amps.
/// \param overCurrentLimit The maximum amount of current allowed in Amps.
/// \param currentSampleRate The current sampling rate. Determines how fast the breaker react after an over or under-current condition.
/// \param autoRetry Specifies whether the device will attempt to reestablish the circuit after an over or under-current condition
/// \param retryRate The number of retries per second.
/// \return the status code.
/// \sa UeiDaqCreateAIChannel, UeiDaqCreateAOChannel, UeiDaqCreateDIChannel, UeiDaqCreateDOChannel, UeiDaqCreateCIChannel, UeiDaqCreateCOChannel
UeiDaqAPI int UeiDaqCreateDOProtectedChannel(SessionHandle sessionHandle,
                                             char* resource,
                                             double underCurrentLimit,
                                             double overCurrentLimit,
                                             double currentSampleRate,
                                             int autoRetry,
                                             double retryRate);

/// \brief Create industrial digital input channel list
///
/// Create and add one or more channel to the channel list associated with the session.
/// Each channel is associated with a digital input port that groups a predefined number of input lines.
/// Industrial channels are only available on certain DIO devices such as the DNA-DIO-448.
/// You can program program the levels at which the input line state change as well as configure
/// a digital filter to eliminate glitches and spikes
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param lowThreshold the low hysteresis threshold
/// \param highThreshold the high hysteresis threshold
/// \param minPulseWidth the digital filter minimum pulse width in ms. Use 0.0 to disable digital input filter.
/// \return the status code.
/// \sa UeiDaqCreateAIChannel, UeiDaqCreateAOChannel, UeiDaqCreateDIChannel, UeiDaqCreateDOChannel, UeiDaqCreateCIChannel, UeiDaqCreateCOChannel
UeiDaqAPI int UeiDaqCreateDIIndustrialChannel(SessionHandle sessionHandle,
                                              char* resource,
                                              double lowThreshold,
                                              double highThreshold,
                                              double minPulseWidth);

/// \brief Create ARINC input port
///
/// Create and add one or more ARINC input ports to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param bitsPerSecond The number of bits transmitted per second over the ARINC port
/// \param parity The parity used to detect transmission errors.
/// \param enableSDIFilter Set to true to enable frame filtering based on their SDI bits.
/// \param SDIMask The mask used to match incoming frame SDI bits (only bits 0 and 1 are significant).
/// \return the status code.
/// \sa UeiDaqCreateARINCOutputPort
UeiDaqAPI int UeiDaqCreateARINCInputPort(SessionHandle sessionHandle,
                                      char* resource,
                                      tUeiARINCPortSpeed bitsPerSecond,
                                      tUeiARINCPortParity parity,
                                      int enableSDIFilter,
                                      uInt32 SDIMask);

/// \brief Create ARINC output port
///
/// Create and add one or more ARINC output ports to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param bitsPerSecond The number of bits transmitted per second over the ARINC port
/// \param parity The parity used to detect transmission errors.
/// \return the status code.
/// \sa UeiDaqCreateARINCInputPort
UeiDaqAPI int UeiDaqCreateARINCOutputPort(SessionHandle sessionHandle,
                                          char* resource,
                                          tUeiARINCPortSpeed bitsPerSecond,
                                          tUeiARINCPortParity parity);

/// \brief Create MIL-1553 port
///
/// Create and add one or more MIL-1553 ports to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param coupling The way how the port is connected to MIL-1553 bus (tranformer, direct, etc.)
/// \param portMode The mode of operation (bus monitor, remote terminal, bus controller)
/// \return the status code.
UeiDaqAPI int UeiDaqCreateMIL1553Port(SessionHandle sessionHandle,
                                      char* resource,
                                      tUeiMIL1553PortCoupling coupling,
                                      tUeiMIL1553PortOpMode portMode);

/// \brief Create IRIG time keeper channel
///
/// Create and add one or more IRIG time keeper channels to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param source The 1 PPS signal source
/// \param autoFollow Enable or disable auto follow
/// \return the status code.
UeiDaqAPI int UeiDaqCreateIRIGTimeKeeperChannel(SessionHandle sessionHandle,
                                                char* resource, 
                                                tUeiIRIGTimeKeeper1PPSSource source,
                                                int autoFollow);

/// \brief Create IRIG input channel
///
/// Create and add one or more IRIG input channels to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param inputType The input where the timecode signal is connected
/// \param timeCodeFormat The time code format used by the input signal
/// \return the status code.
UeiDaqAPI int UeiDaqCreateIRIGInputChannel(SessionHandle sessionHandle,
                                           char* resource, 
                                           tUeiIRIGDecoderInputType inputType,
                                           tUeiIRIGTimeCodeFormat timeCodeFormat);

/// \brief Create IRIG output channel
///
/// Create and add one or more IRIG output channels to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param timeCodeFormat The time code format used for the generated signal
/// \return the status code.
UeiDaqAPI int UeiDaqCreateIRIGOutputChannel(SessionHandle sessionHandle,
                                            char* resource, 
                                            tUeiIRIGTimeCodeFormat timeCodeFormat);

/// \brief Create IRIG DO TTL channel
///
/// Create and add one or more IRIG DO TTL channels to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param source0 The source used to generate TTL pulses on output 0
/// \param source1 The source used to generate TTL pulses on output 1
/// \param source2 The source used to generate TTL pulses on output 2
/// \param source3 The source used to generate TTL pulses on output 3
/// \return the status code.
UeiDaqAPI int UeiDaqCreateIRIGDOTTLChannel(SessionHandle sessionHandle,
                                           char* resource, 
                                           tUeiIRIGDOTTLSource source0,
                                           tUeiIRIGDOTTLSource source1,
                                           tUeiIRIGDOTTLSource source2,
                                           tUeiIRIGDOTTLSource source3);

/// \brief Create 1PPS synchronization port
///
/// The 1PPS synchronization port uses an ADPLL and an event module to produce a clock at an arbitrary rate
/// Multiple racks can easily be synchronized when they use the same 1PPS synchronization clock
/// The ADPLL+event module on each rack will produce synchronized scan clocks
///
/// The source of the 1PPS sync clock can be internal, external or generated from NTP
/// The 1PPS clock is routed via one of the four internal sync lines to the ADPLL (adaptive digital PLL)
/// The ADPLL locks on the 1PPS and outputs its own 1PPS that is an average of the original 1PPS clock
/// The ADPLL can maintain its 1PPS output even if the original 1PPS clock gets disconnected
/// The ADPLL 1PPS output is routed via one of the four sync lines to the event module
/// The ADPLL 1PPS output can also be routed to the sync connector for sharing with other racks/cubes
/// The event module produces a user selectable number of pulses upon every 1PPS pulse coming from the ADPLL.
/// The event module clock output is routed to the Input layers via one of the remaining sync lines 
///
/// \param sessionHandle The handle to an existing session
/// \param resource The IO module IP address.
/// \param mode The mode used to obtain the reference 1PPS (existing 1PPS clock, NTP or 1588)
/// \param source The source of the 1PPS refenrece clock
/// \param EMOutputRate The rate of the resulting clock (synchronized with the 1PPS reference)
/// \return the status code.
UeiDaqAPI int UeiDaqCreateSync1PPSPort(SessionHandle sessionHandle, 
                                       char* resource,
                                       tUeiSync1PPSMode mode,
                                       tUeiSync1PPSSource source,
                                       double EMOutputRate);

/// \brief Create CSDB port
///
/// Create and add one or more CSDB ports to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port(s) to add to the session.
/// \param bps The CSDB port speed in bits per second (12500 or 50000)
/// \param parity The parity (0 for even >0 for odd)
/// \param blockSize The number of bytes per block (including address and status bytes)
/// \param numberOfMessages The number of message blocks per frame
/// \param interByteDelayUs The delay between bytes within a block
/// \param interBlockDelayUs The delay between blocks within a frame
/// \param framePeriodUs The period at which cyclic frames are emitted
/// \return the status code.
UeiDaqAPI int UeiDaqCreateCSDBPort(SessionHandle sessionHandle, 
                                    char* resource,
                                    int bps,
                                    int parity,
                                    int blockSize,
                                    int numberOfMessages,
                                    int interByteDelayUs,
                                    int interBlockDelayUs,
                                    int framePeriodUs);

/// \brief Create SSI master port list
///
/// Create and add one or more port to the SSI channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param bps The speed of the clock
/// \param wordSize The number of bits per word (3 to 32)
/// \param enableClock Enable or disable clock output
/// \param enableTermination Enable or disable termination resistor
/// \param pauseTime Specifies the time delay between two consecutive clock sequences from the master
/// \param transferTimeout Specifies the minimum time required by the slave to realise that the data transmission is complete
/// \param bitUpdateTime Specifies the maximum bit update time
/// \return the status code.
UeiDaqAPI int UeiDaqCreateSSIMasterPort(SessionHandle sessionHandle,
                                       char* resource,
                                       unsigned int bps,
                                       unsigned int wordSize,
                                       int enableClock,
                                       int enableTermination,
                                       double pauseTime,
                                       double transferTimeout,
                                       double bitUpdateTime);

/// \brief Create SSI slave port list
///
/// Create and add one or more port to the SSI channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list.
/// \param bps The speed of the clock
/// \param wordSize The number of bits per word (3 to 32)
/// \param enableTransmit Enable or disable data output
/// \param enableTermination Enable or disable termination resistor
/// \param pauseTime Specifies the time delay between two consecutive clock sequences from the master
/// \param transferTimeout Specifies the minimum time required by the slave to realise that the data transmission is complete
/// \param bitUpdateTime Specifies the maximum bit update time
/// \return the status code.
UeiDaqAPI int UeiDaqCreateSSISlavePort(SessionHandle sessionHandle, 
                                       char* resource,
                                       unsigned int bps,
                                       unsigned int wordSize,
                                       int enableTransmit,
                                       int enableTermination,
                                       double pauseTime,
                                       double transferTimeout,
                                       double bitUpdateTime);

/// \brief Create Mux port
///
/// Create and add a MUX port to the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and port to add to the session.
/// \param breakBeforeMake 1 to enable break before make, 0 otherwise
/// \return the status code.
UeiDaqAPI int UeiDaqCreateMuxPort(SessionHandle sessionHandle, char* resource, int breakBeforeMake);

/// \brief Create I2C slave port
///
/// Create and add one or more port to the I2C slave channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list
/// \param ttlLevel The line voltage level
/// \param addressWidth The addressing mode used by the slave
/// \param address The I2C address of the slave
UeiDaqAPI int UeiDaqCreateI2CSlavePort(SessionHandle sessionHandle,
                                       char* resource,
                                       tUeiI2CTTLLevel ttlLevel,
                                       tUeiI2CSlaveAddressWidth addressWidth,
                                       int address);

/// \brief Create I2C master port
///
/// Create and add one or more port to the I2C master channel list associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param resource The device and channel(s) to add to the list
/// \param bitRate The number of bits transmitted per second
/// \param ttlLevel The line voltage level
/// \param enableSecureShell Enable or disable use of secure shell functions for reading and writing
UeiDaqAPI int UeiDaqCreateI2CMasterPort(SessionHandle sessionHandle,
                                        char* resource,
                                        tUeiI2CPortSpeed bitRate,
                                        tUeiI2CTTLLevel ttlLevel,
                                        int enableSecureShell);

/// \brief Configure the timing object for simple IO
///
/// Configure the timing object for simple IO. In this mode scans are acquired/generated
/// one at a time. The pace of the acquisition/generation is entirely determined by the
/// speed at which your software is calling the read/write functions.
///
/// \param sessionHandle The handle to an existing session
/// \return The status code
/// \sa UeiDaqConfigureTimingForBufferedIO, UeiDaqConfigureTimingForEdgeDetection, UeiDaqConfigureTimingForTimeSequencing
UeiDaqAPI int UeiDaqConfigureTimingForSimpleIO(SessionHandle sessionHandle);

/// \brief Configure the timing object for buffered mode
///
/// Configure the timing object for buffered mode using hardware timing
///
/// \param sessionHandle The handle to an existing session
/// \param samplePerChannel The size of the buffer used to transfer sample from/to the device.
/// \param clkSource The source of the clock.
/// \param rate  The frequency of the hardware clock pacing the acquisition/generation of each scan in Hz.
/// \param edge The edge of the clock that triggers the scan acquisition/generation: rising or falling.
/// \param duration The duration of the acquisition/generation, continuous or single-shot.
/// \return The status code
/// \sa UeiDaqConfigureTimingForSimpleIO, UeiDaqConfigureTimingForEdgeDetection, UeiDaqConfigureTimingForTimeSequencing
UeiDaqAPI int UeiDaqConfigureTimingForBufferedIO(SessionHandle sessionHandle,
                                                int samplePerChannel,
                                                tUeiTimingClockSource clkSource,
                                                double rate,
                                                tUeiDigitalEdge edge,
                                                tUeiTimingDuration duration);

/// \brief Configure the timing object for digital line state change detection
///
/// Configure the timing object for digital line state change detection
/// The line on which the state change is sensed is specified by calling
/// UeiDaqSetDIChannelEdgeMask().
///
/// \param sessionHandle The handle to an existing session
/// \param edge The edge of the signal that triggers the state change detection event.
/// \return The status code
/// \sa UeiDaqSetDIChannelEdgeMask, UeiDaqConfigureTimingForSimpleIO, UeiDaqConfigureTimingForBufferedIO, UeiDaqConfigureTimingForTimeSequencing
UeiDaqAPI int UeiDaqConfigureTimingForEdgeDetection(SessionHandle sessionHandle, tUeiDigitalEdge edge);

/// \brief Configure the timing object for asynchronous FIFO based I/O
///
/// Configure the timing object for asynchronous FIFO based I/O
/// Data is read/written when the input/output FIFO reaches the specified watermark level,
/// when the periodic timer expires or when the no activity timeout expires (whichever happens first)
/// Set watermark to -1 to disable watermark events
/// Set period to -1 to disable periodic timer events
/// Set no activity timeout to -1 to disable no activity events
///
/// \param sessionHandle The handle to an existing session
/// \param watermark The watermark level used to configure FIFO asynchronous event. (-1) to disable
/// \param periodUs The period at which an event is fired when the FIFO level stays below watermark for too long (-1) to disable) 
/// \param noActivityTimeoutUs The maximum time to wait for any activity (-1) disable
/// \param maxDataSize The maximum number of values returned along with an event
/// \return The status code
UeiDaqAPI int UeiDaqConfigureTimingForAsynchronousIO(SessionHandle sessionHandle, int watermark, int periodUs, int noActivityTimeoutUs, int maxDataSize);

/// \brief Configure the timing object for time sequencing
///
/// In Time sequencing mode, the timing information is built-in the data buffer
/// written to the board
///
/// \param sessionHandle The handle to an existing session
/// \param samplePerChannel The number of samples to acquire if duration is one-shot.
/// \param duration The duration of the acquisition/generation, continuous or single-shot.
/// \return The status code
/// \sa UeiDaqConfigureTimingForSimpleIO, UeiDaqConfigureTimingForEdgeDetection, UeiDaqConfigureTimingForBufferedIO
UeiDaqAPI int UeiDaqConfigureTimingForTimeSequencing(SessionHandle sessionHandle,
                                                     int samplePerChannel,
                                                     tUeiTimingDuration duration);

/// \brief Configure the timing object for data map mode
///
/// Configure the timing object for direct data mapping mode using hardware timing
///
/// \param sessionHandle The handle to an existing session
/// \param clkSource The source of the clock.
/// \param rate The refresh rate of the data map.
/// \sa UeiDaqConfigureTimingForSimpleIO, UeiDaqConfigureTimingForEdgeDetection, UeiDaqConfigureTimingForTimeSequencing
UeiDaqAPI int UeiDaqConfigureTimingForDataMappingIO(SessionHandle sessionHandle,
                                                    tUeiTimingClockSource clkSource,
                                                    double rate);

/// \brief Configure the timing object for messaging IO
///
/// Configure the session to do messaging IOs. This timing mode is only available
/// for Serial and CAN bus sessions.
///
/// The serial and CAN bus devices can be programmed to wait for a certain
/// number of messages to be received before notifying the session.
/// It is also possible to program the maximum amount of time to wait for the
/// specified number of messages before notifying the session.
///
/// For serial sessions a message is simply a byte, for CAN sessions a message
/// is a CAN frame represented with the data structure tUeiCANFrame.
///
/// \param sessionHandle The handle to an existing session
/// \param bufferSize The miminum number of messages to buffer before notifying the session
/// \param refreshRate The rate at which the device notifies the session that messages have been received. Set the rate to 0 to be notified immediately when a message is received.
/// \sa UeiDaqConfigureTimingForBufferedIO, UeiDaqConfigureTimingForEdgeDetection, UeiDaqConfigureTimingForTimeSequencing
UeiDaqAPI int UeiDaqConfigureTimingForMessagingIO(SessionHandle sessionHandle,
                                                  int bufferSize,
                                                  double refreshRate);

/// \brief Configure the timing object for variable map mode
///
/// Configure the timing object forVMAP mode
/// VMap mode provides access to a device's FIFO without any buffering
///
/// \param sessionHandle The handle to an existing session
/// \param rate The rate at which data is clocked in or out of the FIFO (relevant only for clocked I/Os such as AI, AO, DI and DO).
/// \sa ConfigureTimingForSimpleIO, ConfigureTimingForEdgeDetection, ConfigureTimingForTimeSequencing
UeiDaqAPI int UeiDaqConfigureTimingForVMapIO(SessionHandle sessionHandle, double rate);

/// \brief Configure the digital trigger condition that will start the session
///
/// Configure the digital trigger condition that will start the session
///
/// \param sessionHandle The handle to an existing session
/// \param source	The trigger source descriptor
/// \param edge The edge of the trigger signal that starts the session.
/// \return The status code
UeiDaqAPI int UeiDaqConfigureStartDigitalTrigger(SessionHandle sessionHandle,
                                                 tUeiTriggerSource source,
                                                 tUeiDigitalEdge edge);

/// \brief Configure the digital trigger condition that will stop the session
///
/// Configure the digital trigger condition that will stop the session
///
/// \param sessionHandle The handle to an existing session
/// \param source	The trigger source descriptor
/// \param edge The edge of the trigger signal that stops the session.
/// \return The status code
UeiDaqAPI int UeiDaqConfigureStopDigitalTrigger(SessionHandle sessionHandle,
                                                 tUeiTriggerSource source,
                                                 tUeiDigitalEdge edge);

/// \brief Configure the analog software trigger
///
/// The analog software trigger looks at every sample acquired on the
/// specified channel until the trigger condition is met.
/// Once the trigger condition is met the application can read the acquired
/// scans in a buffer.
/// The trigger level and hysteresis are specified in the same unit as the
/// measurements.
///
/// \param sessionHandle The handle to an existing session
/// \param action The action to execute when the trigger condition is met
/// \param condition	The condition for the trigger to occur.
/// \param triggerChannel The analog input channel to monitor for the trigger condition.
/// \param level The scaled value that defines the trigger threshold.
/// \param hysteresis The scaled size of the hysteresis window.
/// \param preTriggerScans The number of scans to save before the trigger occurrence.
/// \return The status code
UeiDaqAPI int UeiDaqConfigureAnalogSoftwareTrigger(SessionHandle sessionHandle,
                                                   tUeiTriggerAction action,
                                                   tUeiTriggerCondition condition,
                                                   Int32 triggerChannel,
                                                   f64 level,
                                                   f64 hysteresis,
                                                   Int32 preTriggerScans);

/// \brief Configure the trigger signal that will start or stop the session
///
/// Configure the trigger signal that will start or stop the session
/// The trigger signal is device dependent, it can be a physical line
/// on a backplane (such as a PXI trigger) or a software signal used
/// to synchronize multiple devices (for example starting all layers
/// in a PowerDNA cube simultaneously).
///
/// \param sessionHandle The handle to an existing session
/// \param action The action to execute when the signal occurs.
/// \param signal The signal that will transmit the trigger
/// \return The status code
UeiDaqAPI int UeiDaqConfigureSignalTrigger(SessionHandle sessionHandle,
                                           tUeiTriggerAction action,
                                           char* signal);

/// \brief Start the session.
///
/// Start the session immediately of after the trigger condition occurred.
///
/// \param sessionHandle The handle to an existing session
/// \return The status code
/// \sa UeiDaqStopSession UeiDaqCleanUpSession UeiDaqIsSessionRunning UeiDaqWaitUntilSessionIsDone
UeiDaqAPI int UeiDaqStartSession(SessionHandle sessionHandle);

/// \brief Check session status.
///
/// Check whether the session is in the running state.
///
/// \param sessionHandle The handle to an existing session
/// \param done true if the session is still running and false otherwise
/// \return The status code
/// \sa UeiDaqStartSession UeiDaqStopSession UeiDaqCleanUp UeiDaqWaitUntilSessionIsDone
UeiDaqAPI int UeiDaqIsSessionRunning(SessionHandle sessionHandle, int *done);

/// \brief Wait for the specified time until the session is stopped.
///
/// Wait for the specified time until the session is stopped.
///
/// \param sessionHandle The handle to an existing session
/// \param timeout Maximum amount of time in ms this call will wait.
/// \param done True if the session is finished, false otherwise
/// \return The status code
/// \sa UeiDaqStartSession UeiDaqStopSession UeiDaqCleanUpSession UeiDaqIsSessionRunning
UeiDaqAPI int UeiDaqWaitUntilSessionIsDone(SessionHandle sessionHandle,
                                           int timeout,
                                           int *done);

/// \brief Stop the session.
///
/// Stop the session immediately and wait for the session to be in
/// the stopped state before returning, once it returned you can restart
/// the session immediately with UeiDaqStartSession() without having to
/// reconfigure channels. timing or triggers.
///
/// \param sessionHandle The handle to an existing session
/// \return The status code
/// \sa UeiDaqStartSession UeiDaqCleanUpSession UeiDaqIsSessionRunning UeiDaqWaitUntilSessionIsDone
UeiDaqAPI int UeiDaqStopSession(SessionHandle sessionHandle);

/// \brief Pause one port in the session.
///
/// Pause the specified messaging port.
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to pause 
/// \param numValuesPending The number of values pending at the time of the pause. On some device, those values will need to be resent
/// \return The status code
UeiDaqAPI int UeiDaqPauseSession(SessionHandle sessionHandle, int port, uInt32* numValuesPending);

/// \brief Pause one port in the session.
///
/// Pause the specified messaging port.
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to resume 
/// \return The status code
UeiDaqAPI int UeiDaqResumeSession(SessionHandle sessionHandle, int port);

/// \brief Clean-up the session object.
///
/// Stop and Clean-up the session. All session parameters are lost and
/// you need to reconfigure channels, timing or triggers if you want to reuse
/// the same session object.
///
/// \param sessionHandle The handle to an existing session
/// \return The status code
/// \sa UeiDaqStopSession UeiDaqStartSession UeiDaqIsSessionRunning UeiDaqWaitUntilSessionIsDone
UeiDaqAPI int UeiDaqCleanUpSession(SessionHandle sessionHandle);

/// \brief Enable/Disable session auto-restart
///
/// Enabling auto-restart will automatically stop/start a running session
/// once it is detected that the device was reset (uually because of a power-cycle).
///
/// \param sessionHandle The handle to an existing session
/// \param enable true to auto-restart, false otherwise
/// \return The status code
UeiDaqAPI int UeiDaqEnableSessionAutoReStart(SessionHandle sessionHandle, int enable);

/// \brief Get a handle to the device object.
///
/// Get a handle to the device object associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param device A handle to the Device object that can be later used to retrieve information about the device associated to the session.
/// \return The status code
UeiDaqAPI int UeiDaqGetDeviceHandle(SessionHandle sessionHandle, DeviceHandle *device);

/// \brief Get a handle to the timing object.
///
/// Get a handle to the timing object associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param timing A handle to the Timing object that is used to configure timing informations.
/// \return The status code
UeiDaqAPI int UeiDaqGetTimingHandle(SessionHandle sessionHandle, TimingHandle* timing);

/// \brief Get a handle to the stream object.
///
/// Get a handle to the stream object associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param stream A handle to the DataStream object that is used to access data.
/// \return The status code
UeiDaqAPI int UeiDaqGetDataStreamHandle(SessionHandle sessionHandle, DataStreamHandle* stream);

/// \brief Get a handle to the start trigger object.
///
/// Get a handle to the start trigger object associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param trigger A handle to the Trigger object that is used to access triggers data.
/// \return The status code
UeiDaqAPI int UeiDaqGetStartTriggerHandle(SessionHandle sessionHandle, TriggerHandle* trigger);

/// \brief Get a handle to the stop trigger object.
///
/// Get a handle to the stop trigger object associated with the session.
///
/// \param sessionHandle The handle to an existing session
/// \param trigger A handle to the Trigger object that is used to access triggers data.
/// \return The status code
UeiDaqAPI int UeiDaqGetStopTriggerHandle(SessionHandle sessionHandle, TriggerHandle* trigger);

/// \brief Get the number of channels.
///
/// Get the number of channels in the channel list.
///
/// \param sessionHandle The handle to an existing session
/// \param numChannels The number of channels.
/// \return The status code
UeiDaqAPI int UeiDaqGetNumberOfChannels(SessionHandle sessionHandle, int* numChannels);

/// \brief Get the handle on a channel object.
///
/// Get the handle on the channel object specified by its index in the channel list.
///
/// \param sessionHandle The handle to an existing session
/// \param index index of the channel object in the channel list
/// \param channel A handle to the channel object.
/// \return The status code
UeiDaqAPI int UeiDaqGetChannelHandle(SessionHandle sessionHandle, int index, ChannelHandle *channel);

/// \brief Get the handle on a channel object by physical channel id.
///
/// Get thehandle on a channel object specified by its physical channel id.
///
/// \param sessionHandle The handle to an existing session
/// \param id physical id of the channel object
/// \param channel A handle to the channel object.
/// \return The status code
UeiDaqAPI int UeiDaqGetChannelHandlelById(SessionHandle sessionHandle, int id, ChannelHandle *channel);

/// \brief Read 16 bits wide raw scans from the stream
///
/// Read 16 bits wide raw scans from the stream.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the required number of scans
///
/// \param sessionHandle The handle to an existing session
/// \param timeout The timeout determines the amount of time in ms allowed to read the specified number of scans
/// \param numScans Number of scans to read
/// \param pBuffer Destination buffer for the scans
/// \return The status code
UeiDaqAPI int UeiDaqReadRawData16(SessionHandle sessionHandle, Int32 timeout, Int32 numScans, uInt16 *pBuffer);

/// \brief Read 16 bits wide raw scans asynchronously from the stream
///
/// Read 16 bits wide raw scans asynchronously from the stream.
/// This function returns immediately, the specified callback function is called
/// once the buffer is ready.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the required number of scans
///
/// \param sessionHandle The handle to an existing session
/// \param numScans Number of scans to read
/// \param pBuffer Destination buffer for the scans
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqReadRawData16Async(SessionHandle sessionHandle, Int32 numScans, uInt16 *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Read 32 bits wide raw scans from the stream
///
/// Read 32 bits wide raw scans from the stream.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the required number of scans
///
/// \param sessionHandle The handle to an existing session
/// \param timeout The timeout determines the amount of time in ms allowed to read the specified number of scans
/// \param numScans Number of scans to read
/// \param pBuffer Destination buffer for the scans
/// \return The status code
UeiDaqAPI int UeiDaqReadRawData32(SessionHandle sessionHandle, Int32 timeout, Int32 numScans, uInt32 *pBuffer);

/// \brief Read 32 bits wide raw scans asynchronously from the stream
///
/// Read 32 bits wide raw scans asynchronously from the stream.
/// This function returns immediately, the specified callback function is called
/// once the buffer is ready.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the required number of scans
///
/// \param sessionHandle The handle to an existing session
/// \param numScans Number of scans to read
/// \param pBuffer Destination buffer for the scans
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqReadRawData32Async(SessionHandle sessionHandle, Int32 numScans, uInt32 *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Read scaled scans from the stream
///
/// Read scaled scans from the stream.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the required number of scans
///
/// \param sessionHandle The handle to an existing session
/// \param timeout The timeout determines the amount of time in ms allowed to read the specified number of scans
/// \param numScans Number of scans to read
/// \param pBuffer Destination buffer for the scans
/// \return The status code
UeiDaqAPI int UeiDaqReadScaledData(SessionHandle sessionHandle, Int32 timeout, Int32 numScans, f64 *pBuffer);

/// \brief Read scaled scans asynchronously from the stream
///
/// Read scaled scans asynchronously from the stream.
/// This function returns immediately, the specified callback function is called
/// once the buffer is ready.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the required number of scans
///
/// \param sessionHandle The handle to an existing session
/// \param numScans Number of scans to read
/// \param pBuffer Destination buffer for the scans
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqReadScaledDataAsync(SessionHandle sessionHandle, Int32 numScans, f64 *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Read message from the stream
///
/// Read message from the stream.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the message
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numBytes Number of bytes to read
/// \param pBuffer Destination buffer for the messages
/// \param numBytesRead Number of bytes actually read from the port
/// \return The status code
UeiDaqAPI int UeiDaqReadMessage(SessionHandle sessionHandle, Int32 port, Int32 numBytes, void *pBuffer, Int32* numBytesRead);

/// \brief Read messages asynchronously from the stream
///
/// Read messages asynchronously from the stream.
/// This function returns immediately, the specified callback function is called
/// once the buffer is ready. The callback function parameter contains the number of bytes
/// actually read.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the message
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numBytes Number of bytes to read
/// \param pBuffer Destination buffer for the messages
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqReadMessageAsync(SessionHandle sessionHandle, Int32 port, Int32 numBytes, void *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Read serial message from the stream with timestamp
///
/// Read message from the stream including a timestamp as the first values
/// in the buffer.
/// It is the caller's responsability to allocate enough memory in the buffer
/// to store the message
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numBytes Number of bytes to read
/// \param pBuffer Destination buffer for the messages
/// \param numBytesRead Number of bytes actually read from the port
/// \return The status code
UeiDaqAPI int UeiDaqReadSerialMessageTimestamped(SessionHandle sessionHandle, Int32 port, Int32 numBytes, void *pBuffer, Int32* numBytesRead);

/// \brief Read serial messages asynchronously from the stream with timestamp
///
/// Read messages asynchronously from the stream including a timestamp as the first
/// values in the buffer.
/// This function returns immediately, the specified callback function is called
/// once the buffer is ready. The callback function parameter contains the number of bytes
/// actually read.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the message
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numBytes Number of bytes to read
/// \param pBuffer Destination buffer for the messages
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqReadSerialMessageTimestampedAsync(SessionHandle sessionHandle, Int32 port, Int32 numBytes, void *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Read CAN frames from the stream
///
/// Read CAN frames from the stream.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numFrames Number of frames to read
/// \param pBuffer Destination buffer for the frames
/// \param numFramesRead Number of frames actually read from the port
/// \return The status code
UeiDaqAPI int UeiDaqReadCANFrame(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiCANFrame *pBuffer, Int32* numFramesRead);

/// \brief Read CAN frames asynchronously from the stream
///
/// Read CAN frames asynchronously from the stream.
/// This function returns immediately, the specified callback function is called
/// once the buffer is ready. The callback function parameter contains the number of frames
/// actually read.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numFrames Number of frames to read
/// \param pBuffer Destination buffer for the frames
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqReadCANFrameAsync(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiCANFrame *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Read ARINC words from the stream
///
/// Read ARINC words from the stream.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the words
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numWords Number of words to read
/// \param pBuffer Destination buffer for the words
/// \param numWordsRead Number of words actually read from the port
/// \return The status code
UeiDaqAPI int UeiDaqReadARINCWords(SessionHandle sessionHandle, Int32 port, Int32 numWords, tUeiARINCWord *pBuffer, Int32* numWordsRead);

/// \brief Read ARINC raw words from the stream
///
/// Read ARINC raw words from the stream.
/// Raw ARINC word is a 32 bits value encoding
/// the ARINC word fields: SSM, SDI, Label, Data and Parity
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the words
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numWords Number of words to read
/// \param pBuffer Destination buffer for the words
/// \param numWordsRead Number of words actually read from the port
/// \return The status code
UeiDaqAPI int UeiDaqReadARINCRawWords(SessionHandle sessionHandle, Int32 port, Int32 numWords, uInt32 *pBuffer, Int32* numWordsRead);

/// \brief Read ARINC words asynchronously from the stream
///
/// Read ARINC words asynchronously from the stream.
/// This function returns immediately, the specified callback function is called
/// once the buffer is ready. The callback function parameter contains the number of words
/// actually read.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the words
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numWords Number of words to read
/// \param pBuffer Destination buffer for the words
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqReadARINCWordsAsync(SessionHandle sessionHandle, Int32 port, Int32 numWords, tUeiARINCWord *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Read MIL-1553 frames from the stream
///
/// Read MIL-1553 frames from the stream.
/// The device associated with this data stream
/// must support MIL-1553
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Destination buffer for the frames
/// \param numFramesRead The actual number of frames read
/// \return The status code
UeiDaqAPI int UeiDaqReadMIL1553Frames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553Frame *pBuffer, Int32* numFramesRead);

/// \brief Read MIL-1553 bus monitor frames from the stream
///
/// Read MIL-1553 bus monitor frames from the stream.
/// The device associated with this data stream
/// must support MIL-1553
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Destination buffer for the frames
/// \param numFramesRead The actual number of frames read
/// \return The status code
UeiDaqAPI int UeiDaqReadMIL1553BMFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553BMFrame *pBuffer, Int32* numFramesRead);

/// \brief Read MIL-1553 RT status frames from the stream
///
/// Read MIL-1553 Bus Monitor protocol-parsed data
/// The device associated with this data stream
/// must support MIL-1553
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Destination buffer for the frames
/// \param numFramesRead The actual number of frames read
/// \return The status code
UeiDaqAPI int UeiDaqReadMIL1553BMCmdFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553BMCmdFrame *pBuffer, Int32* numFramesRead);

/// \brief Read MIL-1553 RT data area frames from the stream
///
/// Read MIL-1553 RT data area from the stream.
/// The device associated with this data stream
/// must support MIL-1553
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Destination buffer for the frames
/// \param numFramesRead The actual number of frames read
/// \return The status code
UeiDaqAPI int UeiDaqReadMIL1553RTDataFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553RTFrame *pBuffer, Int32* numFramesRead);

/// \brief Read MIL-1553 RT status frames from the stream
///
/// Read MIL-1553 RT status from the stream.
/// The device associated with this data stream
/// must support MIL-1553
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Destination buffer for the frames
/// \param numFramesRead The actual number of frames read
/// \return The status code
UeiDaqAPI int UeiDaqReadMIL1553RTStatusFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553RTStatusFrame *pBuffer, Int32* numFramesRead);

/// \brief Read MIL-1553 BCCB status frames (result of entry and data for Tx command)
///
/// Read MIL-1553 RT status from the stream.
/// The device associated with this data stream
/// must support MIL-1553
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Destination buffer for the frames
/// \param numFramesRead The actual number of frames read
/// \return The status code
UeiDaqAPI int UeiDaqReadMIL1553BCCBStatusFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553BCCBStatusFrame *pBuffer, Int32* numFramesRead);

/// \brief Read MIL-1553 BCCB status frames (result of entry and data for Tx command)
///
/// Read MIL-1553 BC Scheduler frame - i.e. major or minor entry
/// The device associated with this data stream
/// must support MIL-1553
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Destination buffer for the frames
/// \param numFramesRead The actual number of frames read
/// \return The status code
UeiDaqAPI int UeiDaqReadMIL1553BCSchedFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553BCSchedFrame *pBuffer, Int32* numFramesRead);

/// \brief Read MIL-1553 bus controller status (result of entry and data for Tx command)
///
/// Read MIL-1553 RT status from the stream.
/// The device associated with this data stream
/// must support MIL-1553
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param pBuffer Destination buffer for the frames
/// \return The status code
UeiDaqAPI int UeiDaqReadMIL1553BCStatus(SessionHandle sessionHandle, Int32 port, tUeiMIL1553BCStatusFrame *pBuffer);

/// \brief Read MIL-1553 frames from the stream
///
/// Read MIL-1553 words from the stream.
/// The device associated with this data stream
/// must support MIL-1553
/// This function returns immediately, the specified callback function is called
/// once the buffer is ready. The callback function parameter contains the number of frames
/// actually read.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param bufferSize Maximum number of frames that can be stored in the buffer
/// \param pBuffer Destination buffer for the frames
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqReadMIL1553FramesAsync(SessionHandle sessionHandle, Int32 port, Int32 bufferSize, tUeiMIL1553Frame *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Read ARINC 708 data frames from the stream
///
/// Read ARINC 708 data frames from the stream.
/// The device assiociated with this data stream
/// must support ARINC 708
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the frames
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Destination buffer for the frames
/// \param numFramesRead The actual number of frames read
/// \return The status code
UeiDaqAPI int UeiDaqReadMIL1553A708DataFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553A708DataFrame *pBuffer, Int32* numFramesRead);

/// \brief Read current time in BCD format
///
/// Read current time in Binary Coded Decimal format from IRIG layer
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param pBuffer Destination buffer for the time
/// \param status The time keeper status
/// \return The status code
UeiDaqAPI int UeiDaqReadIRIGTimeKeeperBCDTime(SessionHandle sessionHandle, Int32 port, tUeiBCDTime *pBuffer, Int32* status);

/// \brief Read current time in SBS format
///
/// Read current time in Straight Binary Seconds format from IRIG layer
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param pBuffer Destination buffer for the time
/// \param status The time keeper status
/// \return The status code
UeiDaqAPI int UeiDaqReadIRIGTimeKeeperSBSTime(SessionHandle sessionHandle, Int32 port, tUeiSBSTime *pBuffer, Int32* status);

/// \brief Read current time in C-ANSI format
///
/// Read current time in C-ANSI format from IRIG layer
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param pBuffer Destination buffer for the time
/// \param status The time keeper status
/// \return The status code
UeiDaqAPI int UeiDaqReadIRIGTimeKeeperCANSITime(SessionHandle sessionHandle, Int32 port, tUeiANSITime *pBuffer, Int32* status);

/// \brief Read NMEA data from GPS
///
/// Read NMEA data from GPS associated with specified port
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numBytes maximum number of bytes to read
/// \param pBuffer destination buffer
/// \param numBytesRead Number of bytes read from GPS receiver
/// \return The status code
UeiDaqAPI int UeiDaqReadIRIGGPS(SessionHandle sessionHandle, Int32 port, Int32 numBytes, char *pBuffer, Int32* numBytesRead);

/// \brief Read time registers
///
/// For internal use only
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numRegisters  number of registers to read
/// \param pBuffer destination buffer
/// \param numRegistersRead Number of registers actually read 
/// \return The status code
UeiDaqAPI int UeiDaqReadIRIGTReg(SessionHandle sessionHandle, Int32 port, Int32 numRegisters, uInt32 *pBuffer, Int32* numRegistersRead);

/// \brief Read raw input time code
///
/// Read raw input time code (for internal use only)
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to read from
/// \param numTimeCodeChars number of time code characters to read
/// \param pBuffer destination buffer
/// \param numTimeCodeCharsRead Number of time code characters actually read
/// \return The status code
UeiDaqAPI int UeiDaqReadIRIGRawTimeCode(SessionHandle sessionHandle, Int32 port, Int32 numTimeCodeChars, uInt32 *pBuffer, Int32* numTimeCodeCharsRead);

/// \brief Read HDLC frame from the stream
///
/// Read HDLC frame from the stream.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the message
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numBytes Number of bytes to read
/// \param pBuffer Destination buffer for the messages
/// \param numBytesRead Number of bytes actually read from the port
/// \return The status code
UeiDaqAPI int UeiDaqReadHDLCFrame(SessionHandle sessionHandle, Int32 port, Int32 numBytes, void *pBuffer, Int32* numBytesRead);

/// \brief Read variable reluctance data
///
/// Read variable reluctance data. Each value comes as a structure that includes the
/// VR sensor velocity (teeth/sec), position, teeth count and timestamp
///
/// \param sessionHandle The handle to an existing session
/// \param channel The channel to read from
/// \param numValues number of values to read
/// \param pBuffer destination buffer
/// \param numValuesRead Number of values actually read
/// \return The status code
UeiDaqAPI int UeiDaqReadVRData(SessionHandle sessionHandle, Int32 channel, Int32 numValues, tUeiVRData *pBuffer, Int32* numValuesRead);

/// \brief Read variable reluctance FIFO data
///
/// Variable reluctance FIFO data can be used to calculate a map of the inter-tooth delays 
/// around the encoder wheel. this is useful to calculate acceleration.
///
/// \param sessionHandle The handle to an existing session
/// \param channel The channel to read from
/// \param numValues number of values to read
/// \param pBuffer destination buffer
/// \param numValuesRead Number of values actually read
/// \return The status code
UeiDaqAPI int UeiDaqReadVRFifoData(SessionHandle sessionHandle, Int32 channel, Int32 numValues, uInt32 *pBuffer, Int32* numValuesRead);

/// \brief Read variable reluctance ADC data
///
/// Read ADC FIFO data, this is used as a diagnostic to visualize the shape of the signal
/// as it is acquired on the VR input device.
/// There is one FIFO for each pair of channel. this function reads the ADC data
/// for both even and odd channels
///
/// \param sessionHandle The handle to an existing session
/// \param channel The channel to read from
/// \param numValues number of values to read
/// \param pBuffer destination buffer for even and odd channel ADC data
/// \param numValuesRead Number of values actually read
/// \return The status code
UeiDaqAPI int UeiDaqReadVRADCData(SessionHandle sessionHandle, Int32 channel, Int32 numValues, double *pBuffer, Int32* numValuesRead);

/// \brief Read variable reluctance ADC status
///
/// Read ADC status data, this is used as a diagnostic to troubleshoot VR input
///
/// \param sessionHandle The handle to an existing session
/// \param channel The channel to read from
/// \param pStatus destination buffer for even and odd channel ADC data
/// \return The status code
UeiDaqAPI int UeiDaqReadVRADCStatus(SessionHandle sessionHandle, Int32 channel, uInt32* pStatus);

/// \brief Read CSDB message blocks from the stream
///
/// Read CSDB message blocks from the stream.
/// It is the caller's responsability to allocate enough memory in the buffer.
/// to store the messages
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to read the message from
/// \param numMessages Number of message blocks to read
/// \param pBuffer Destination buffer for the messages
/// \param numMessagesRead Number of message blocks actually read from the port
/// \return The status code
UeiDaqAPI int UeiDaqReadCSDBFrame(SessionHandle sessionHandle, Int32 port, Int32 numMessages, tUeiCSDBMessage *pBuffer, Int32* numMessagesRead);

/// \brief Read 1PPS synchronization status from the stream
///
/// Read 1PPS synchronization status from the stream.
///
/// \param sessionHandle The handle to an existing session
/// \param pBuffer Destination buffer for the messages
/// \return The status code
UeiDaqAPI int UeiDaqReadSync1PPSStatus(SessionHandle sessionHandle, tUeiSync1PPSStatus *pBuffer);

/// \brief Read 1PPS synchronization locked status from the stream
///
/// Read 1PPS synchronization locked status from the stream.

///
/// \param sessionHandle The handle to an existing session
/// \param isLocked Destination buffer for the status
/// \return The status code
UeiDaqAPI int UeiDaqReadSync1PPSLockedStatus(SessionHandle sessionHandle, int *isLocked);

/// \brief Read PTP status from the stream
///
/// Read PTP status from the stream.
///
/// \param sessionHandle The handle to an existing session
/// \param pBuffer Destination buffer for the status
/// \return The status code
UeiDaqAPI int UeiDaqReadSync1PPSPTPStatus(SessionHandle sessionHandle, tUeiSync1PPSPTPStatus *pBuffer);

/// \brief Read PTP UTC time from the stream
///
/// Read PTP UTC time from the stream.
///
/// \param sessionHandle The handle to an existing session
/// \param pBuffer Destination buffer for the UTC time
/// \return The status code
UeiDaqAPI int UeiDaqReadSync1PPSPTPUTCTime(SessionHandle sessionHandle, tUeiPTPTime *pBuffer);

/// \brief Read word(s) from the SSI master port
/// 
/// Read 32-bit data words from the input stream
///
/// \param sessionHandle The handle to an existing session
/// \param port The SSI master port to read from
/// \param grayDecoding true to convert gray encoded values to binary
/// \param numWords the number of words that can be stored in the destination buffer
/// \param pBuffer destination buffer
/// \param numWordsRead the actual number of frames read from the SSI port
/// \return The status code
UeiDaqAPI int UeiDaqReadSSIMasterWords(SessionHandle sessionHandle, int port, int grayDecoding, Int32 numWords, uInt32* pBuffer, Int32* numWordsRead);

/// \brief Get Mux status
/// 
/// Get status of each relay on the MUX device
///
/// \param sessionHandle The handle to an existing session
/// \param relayA status of "A" relays
/// \param relayB status of "B" relays
/// \param relayC status of "C" relays
/// \param status mux status word
/// \return The status code
UeiDaqAPI int UeiDaqReadMuxStatus(SessionHandle sessionHandle, uInt32* relayA, uInt32* relayB, uInt32* relayC, uInt32* status);

/// \brief Read ADC
///
/// Read diagnostic ADC values
///
/// \param sessionHandle The handle to an existing session
/// \param numVals Number of ADC values to read
/// \param pBuffer destination buffer
/// \return The status code
UeiDaqAPI int UeiDaqReadMuxADC(SessionHandle sessionHandle, Int32 numVals, double* pBuffer);

/// \brief Read current count of times each relay has been energized
///
/// Read current count of times each relay has been energized
///
/// \param sessionHandle The handle to an existing session
/// \param countsBufferSize Number of relay counts to read and store in countsBuffer
/// \param pCountsBuffer Data buffer to store relay counts
/// \param numCountsRead Number of relay counts read and stored in countsBuffer
/// \return The status code
UeiDaqAPI int UeiDaqReadMuxReadRelayCounts(SessionHandle sessionHandle, Int32 countsBufferSize, Int32* pCountsBuffer, Int32* numCountsRead);

/// \brief Read primary and secondary coils RMS voltages
///
/// Read RMS amplitudes for the primary and secondary coils of each configured
/// channel
///
/// \param sessionHandle The handle to an existing session
/// \param channel The channel to read from
/// \param pPrimaryCoilsBuffer destination buffer for primary coils amplitudes
/// \param pSecondaryCoilsBuffer destination buffer for secondary coils amplitudes
/// \return The status code
UeiDaqAPI int UeiDaqReadLVDTCoilAmplitudes(SessionHandle sessionHandle, f64* pPrimaryCoilsBuffer, f64* pSecondaryCoilsBuffer);

/// \brief Read messages received by slave
///
/// Read messages received by slave.
///
/// \param sessionHandle The handle to an existing session
/// \param port The I2C slave port to read from
/// \param numMessages The number of messages to read
/// \param pBuffer Destination buffer
/// \param numMessagesRead The number of messages received
/// \return The status code
UeiDaqAPI int UeiDaqReadI2CSlave(SessionHandle sessionHandle, Int32 port, Int32 numMessages, tUeiI2CSlaveMessage* pBuffer, Int32* numMessagesRead);

/// \brief Read messages received by master
///
/// Read messages received by master.
///
/// \param sessionHandle The handle to an existing session
/// \param port The I2C master port to read from
/// \param numMessages The number of messages to read
/// \param pBuffer Destination buffer
/// \param numMessagesRead The number of messages recevied
/// \return The status code
UeiDaqAPI int UeiDaqReadI2CMaster(SessionHandle sessionHandle, Int32 port, Int32 numMessages, tUeiI2CMasterMessage* pBuffer, Int32* numMessagesRead);

/// \brief Read DMM status returned with last read data
///
/// Read DMM status returned with last read data. Status
/// is only updated when channel data is read.
/// \param sessionHandle The handle to an existing session
/// \param pStatus destination for status
/// \return The status code
UeiDaqAPI int UeiDaqReadDMMStatus(SessionHandle sessionHandle, uInt32* pStatus);

/// \brief Read DMM protection tripped status
///
/// Read DMM status returned with last read data and return
/// if protection was tripped when data was read.
/// \param sessionHandle The handle to an existing session
/// \param isTripped protection tripped status
/// return The status code
UeiDaqAPI int UeiDaqIsDMMProtectionTripped(SessionHandle sessionHandle, int* isTripped);

/// \brief Read DMM protection tripped in max range status
///
/// Read DMM status returned with last read data and return
/// if protection was tripped in max range when data was read.
/// \param sessionHandle The handle to an existing session
/// \param isTrippedMax protection tripped in max range status
/// return The status code
UeiDaqAPI int UeiDaqIsDMMProtectionTrippedMaxRange(SessionHandle sessionHandle, int* isTrippedMax);

/// \brief Read DMM protection reconfigured to safe range status
///
/// Read DMM status returned with last read data and return
/// if protection reconfigured to safe range when data was read.
/// \param sessionHandle The handle to an existing session
/// \param isReconfigured protection reconfigured to safe range status
/// return The status code
UeiDaqAPI int UeiDaqIsDMMProtectionReconfiguredSafeRange(SessionHandle sessionHandle, int* isReconfigured);

/// \brief Write 16-bit wide raw scans to the stream
///
/// Write the specified number of 16-bit raw scans to the stream.
///
/// \param sessionHandle The handle to an existing session
/// \param timeout The timeout determines the amount of time in ms allowed to read the specified number of scans
/// \param numScans Number of scans to write
/// \param pBuffer Source buffer for the scans
/// \return The status code
UeiDaqAPI int UeiDaqWriteRawData16(SessionHandle sessionHandle, Int32 timeout, Int32 numScans, uInt16 *pBuffer);

/// \brief Write 16 bits wide raw scans asynchronously to the stream
///
/// Write 16 bits wide raw scans asynchronously to the stream.
/// This function returns immediately, the specified callback function is called
/// once the buffer has been consumed.
///
/// \param sessionHandle The handle to an existing session
/// \param numScans Number of scans to write
/// \param pBuffer Source buffer for the scans
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqWriteRawData16Async(SessionHandle sessionHandle, Int32 numScans, uInt16 *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Write 32-bit wide raw scans to the stream
///
/// Write the specified number of 32-bit raw scans to the stream.
///
/// \param sessionHandle The handle to an existing session
/// \param timeout The timeout determines the amount of time in ms allowed to read the specified number of scans
/// \param numScans Number of scans to write
/// \param pBuffer Source buffer for the scans
/// \return The status code
UeiDaqAPI int UeiDaqWriteRawData32(SessionHandle sessionHandle, Int32 timeout, Int32 numScans, uInt32 *pBuffer);

/// \brief Write 32 bits wide raw scans asynchronously to the stream
///
/// Write 32 bits wide raw scans asynchronously to the stream.
/// This function returns immediately, the specified callback function is called
/// once the buffer has been consumed.
///
/// \param sessionHandle The handle to an existing session
/// \param numScans Number of scans to write
/// \param pBuffer Source buffer for the scans
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqWriteRawData32Async(SessionHandle sessionHandle, Int32 numScans, uInt32 *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Write scaled scans to the stream
///
/// Write the specified number of scaled scans to the stream.
///
/// \param sessionHandle The handle to an existing session
/// \param timeout The timeout determines the amount of time in ms allowed to read the specified number of scans
/// \param numScans Number of scans to write
/// \param pBuffer Source buffer for the scans
/// \return The status code
UeiDaqAPI int UeiDaqWriteScaledData(SessionHandle sessionHandle, Int32 timeout, Int32 numScans, f64 *pBuffer);

/// \brief Write scaled scans asynchronously to the stream
///
/// Write scaled scans asynchronously to the stream.
/// This function returns immediately, the specified callback function is called
/// once the buffer has been consumed.
///
/// \param sessionHandle The handle to an existing session
/// \param numScans Number of scans to write
/// \param pBuffer Source buffer for the scans
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqWriteScaledDataAsync(SessionHandle sessionHandle, Int32 numScans, f64 *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Write messages to the stream
///
/// Write the requested number of bytes to the port
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param numBytes Number of bytes to write
/// \param pBuffer Source buffer for the message
/// \param numBytesWritten Number of bytes actually written to the port
/// \return The status code
UeiDaqAPI int UeiDaqWriteMessage(SessionHandle sessionHandle, Int32 port, Int32 numBytes, void *pBuffer, Int32* numBytesWritten);

/// \brief Write messages asynchronously to the stream
///
/// Write the requested number of bytes asynchronously to the port
/// This function returns immediately, the specified callback function is called
/// once the buffer has been consumed. The callback function parameter contains
/// the number of bytes actually written.
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param numBytes Number of bytes to write
/// \param pBuffer Source buffer for the message
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqWriteMessageAsync(SessionHandle sessionHandle, Int32 port, Int32 numBytes, void *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Write 16-bit word messages to the stream
///
/// Write the requested number of int16s to the port
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param numWords Number of words to write
/// \param pBuffer Source buffer for the message
/// \param numWordsWritten Number of bytes actually written to the port
/// \return The status code
UeiDaqAPI int UeiDaqWriteMessageInt16(SessionHandle sessionHandle, Int32 port, Int32 numWords, Int16 *pBuffer, Int32* numWordsWritten);

/// \brief send serial break
///
/// Send serial break
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param durationMs The duration of the break in milliseconds
/// \return The status code
UeiDaqAPI int UeiDaqSendSerialBreak(SessionHandle sessionHandle, Int32 port, uInt32 durationMs);

/// \brief Write CAN frames to the stream
///
/// Write the requested number of CAN frames to the port
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param numFrames Number of frames to write
/// \param pBuffer Source buffer for the frames
/// \param numFramesWritten Number of frames actually written to the port
/// \return The status code
UeiDaqAPI int UeiDaqWriteCANFrame(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiCANFrame *pBuffer, Int32* numFramesWritten);

/// \brief Write CAN frames asynchronously to the stream
///
/// Write the requested number of CAN frames asynchronously to the port
/// This function returns immediately, the specified callback function is called
/// once the buffer has been consumed. The callback function parameter contains
/// the number of frames actually written.
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param numFrames Number of frames to write
/// \param pBuffer Source buffer for the frames
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqWriteCANFrameAsync(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiCANFrame *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Write ARINC words to the stream
///
/// Write the requested number of ARINC words to the port
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param numWords Number of words to write
/// \param pBuffer Source buffer for the words
/// \param numWordsWritten Number of words actually written to the port
/// \return The status code
UeiDaqAPI int UeiDaqWriteARINCWords(SessionHandle sessionHandle, Int32 port, Int32 numWords, tUeiARINCWord *pBuffer, Int32* numWordsWritten);

/// \brief Write RAW ARINC words to the stream
///
/// Write the requested number of raw ARINC words to the port.
/// Raw ARINC word is a 32 bits value encoding
/// the ARINC word fields: SSM, SDI, Label, Data and Parity
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param numWords Number of words to write
/// \param pBuffer Source buffer for the words
/// \param numWordsWritten Number of words actually written to the port
/// \return The status code
UeiDaqAPI int UeiDaqWriteARINCRawWords(SessionHandle sessionHandle, Int32 port, Int32 numWords, uInt32 *pBuffer, Int32* numWordsWritten);

/// \brief Update scheduled ARINC words 
///
/// Update scheduler entry with new raw word(s)
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param firstWord Index of the first word to modify in the scheduler table
/// \param numWords Number of words to write in scheduler table
/// \param pBuffer Source buffer for the words
/// \param numWordsWritten Number of words actually sent to the scheduler
/// \return The status code
UeiDaqAPI int UeiDaqWriteScheduledARINCWords(SessionHandle sessionHandle, Int32 port, Int32 firstWord, Int32 numWords, tUeiARINCWord *pBuffer, Int32* numWordsWritten);

/// \brief Update scheduled ARINC words 
///
/// Update scheduler entry with new ARNIC word(s)
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param firstWord Index of the first word to modify in the scheduler table
/// \param numWords Number of words to write in scheduler table
/// \param pBuffer Source buffer for the words
/// \param numWordsWritten Number of words actually sent to the scheduler
/// \return The status code
UeiDaqAPI int UeiDaqWriteScheduledARINCRawWords(SessionHandle sessionHandle, Int32 port, Int32 firstWord, Int32 numWords, uInt32 *pBuffer, Int32* numWordsWritten);

/// \brief Write ARINC words asynchronously to the stream
///
/// Write the requested number of ARINC words asynchronously to the port
/// This function returns immediately, the specified callback function is called
/// once the buffer has been consumed. The callback function parameter contains
/// the number of words actually written.
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param numWords Number of words to write
/// \param pBuffer Source buffer for the words
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqWriteARINCWordsAsync(SessionHandle sessionHandle, Int32 port, Int32 numWords, tUeiARINCWord *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Enable scheduler
///
/// Enable or disable scheduler
/// \param sessionHandle The handle to an existing session
/// \param port the port to enable/disable
/// \param enable true to enable, false to disable scheduler
/// \return The status code
UeiDaqAPI int UeiDaqEnableARINCScheduler(SessionHandle sessionHandle, Int32 port, int enable);

/// \brief Set the writing page/transmit page for all channels at once
///
/// Major/Minor scheduler features two copies of the scheduler entries. Page 0 and page 1.
/// This call specifies which channel should be written to and which channel should be transmitting.
/// This is designed to configure or update a page while the other is being transmitted.
/// But it is still possible to both write and transmit a channel at the same time.
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param immediate Specifies when the page configuration will be updated (true to update immediately, false to wait for the next major frame clock) 
/// \param writeMask Bit mask specifying the writing page for each channel (bit set to 0 for page 0 or 1 for page 1)
/// \param txMask Bit mask specifying the transmitting page for each channel (bit set to 0 for page 0 or 1 for page 1)
/// \return The status code
UeiDaqAPI int UeiDaqSetARINCTransmitPage(SessionHandle sessionHandle, Int32 port, int immediate, uInt32 writeMask, uInt32 txMask);

/// \brief Write MIL-1553 frames to the stream
///
/// Write MIL-1553 frames to the stream.
/// The device associated with this data stream
/// must support MIL-1553
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param numFramesWritten The number of actual frames written
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553Frames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553Frame *pBuffer, Int32* numFramesWritten);

/// \brief Write MIL-1553 frames to the bus
///
/// Write MIL-1553 bus writer frames to the stream.
/// The device associated with this data stream
/// must support MIL-1553
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param numFramesWritten The number of actual frames written
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553BusWriterFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553BusWriterFrame *pBuffer, Int32* numFramesWritten);

/// \brief Write MIL-1553 RT data area frames to the stream
///
/// Write MIL-1553 RT data area frames to the stream.
/// The device associated with this data stream
/// must support MIL-1553
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param numFramesWritten The number of actual frames written
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553RTDataFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553RTFrame *pBuffer, Int32* numFramesWritten);

/// \brief Write MIL-1553 RT Control information frames to the stream
///
/// Write MIL-1553 RT Control information frames to the stream.
/// The device associated with this data stream
/// must support MIL-1553
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param numFramesWritten The number of actual frames written
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553RTControlFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553RTControlFrame *pBuffer, Int32* numFramesWritten);

/// \brief Write MIL-1553 RT set parameters frames to the stream
///
/// Write MIL-1553 RT set parameters frames to the stream.
/// The device associated with this data stream
/// must support MIL-1553
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param numFramesWritten The number of actual frames written
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553RTParametersFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553RTParametersFrame *pBuffer, Int32* numFramesWritten);

/// \brief Write MIL-1553 BC control block data
///
/// Write MIL-1553 RT set parameters frames to the stream.
/// The device associated with this data stream
/// must support MIL-1553
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param numFramesWritten The number of actual frames written
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553BCCBDataFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553BCCBDataFrame *pBuffer, Int32* numFramesWritten);

/// \brief Write MIL-1553 BC scheduler frames
///
/// Write MIL-1553 RT set parameters frames to the stream.
/// The device associated with this data stream
/// must support MIL-1553
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param numFramesWritten The number of actual frames written
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553BCSchedFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553BCSchedFrame *pBuffer, Int32* numFramesWritten);


/// \brief Write MIL-1553 BC control frames
///
/// Write MIL-1553 RT set parameters frames to the stream.
/// The device associated with this data stream
/// must support MIL-1553
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param numFramesWritten The number of actual frames written
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553BCControlFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553BCControlFrame *pBuffer, Int32* numFramesWritten);

/// \brief Write MIL-1553 frames asynchronously to the stream
///
/// Write MIL-1553 frames to the stream.
/// This function returns immediately, the specified callback function is called
/// once the buffer has been consumed. The callback function parameter contains
/// the number of frames actually written.
/// The device associated with this data stream
/// must support MIL-1553
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param bufferSize Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param pEventCallback The callback function pointer
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553FramesAsync(SessionHandle sessionHandle, Int32 port, Int32 bufferSize, tUeiMIL1553Frame *pBuffer, tUeiEventCallback pEventCallback);

/// \brief Write ARINC 708 data frames
///
/// Write ARINC 708 data frames to the stream.
/// The device associated with this data stream
/// must support ARINC-708
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param numFramesWritten The number of actual frames written
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553A708DataFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553A708DataFrame *pBuffer, Int32* numFramesWritten);

/// \brief Write ARINC 708 control frames
///
/// Write ARINC 708 control frames to the stream.
/// The device associated with this data stream
/// must support ARINC-708
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write to
/// \param numFrames Maximum number of frames that can be stored in the buffer
/// \param pBuffer Source buffer of the frames
/// \param numFramesWritten The number of actual frames written
/// \return The status code
UeiDaqAPI int UeiDaqWriteMIL1553A708ControlFrames(SessionHandle sessionHandle, Int32 port, Int32 numFrames, tUeiMIL1553A708ControlFrame *pBuffer, Int32* numFramesWritten);

/// \brief Write HDLC frames to the stream
///
/// Write the requested number of bytes to the port
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param numBytes Number of bytes to write
/// \param pBuffer Source buffer for the message
/// \param numBytesWritten Number of bytes actually written to the port
/// \return The status code
UeiDaqAPI int UeiDaqWriteHDLCFrame(SessionHandle sessionHandle, Int32 port, Int32 numBytes, void *pBuffer, Int32* numBytesWritten);

/// \brief Write waveform to the AO device
/// 
/// Format and send one or more tUeiAOWaveformParameters(s) to the AO device.
///
/// \param sessionHandle The handle to an existing session
/// \param channel the channel to write the waveform to
/// \param numWfms the number of waveforms to send
/// \param pBuffer source buffer
/// \param numWfmsWritten the actual number of waveforms sent 
/// \return The status code
UeiDaqAPI int UeiDaqWriteAOWaveform(SessionHandle sessionHandle, Int32 channel, Int32 numWfms, tUeiAOWaveformParameters* pBuffer, Int32* numWfmsWritten);

/// \brief Write sweep command to the AO device
/// 
/// Format and send one or more tUeiAOWaveformSweepParameter(s) to the AO device.
///
/// \param sessionHandle The handle to an existing session
/// \param channel the channel to sweep
/// \param numSwps the number of sweep commands to send
/// \param pBuffer source buffer
/// \param numSwpsWritten the actual number of sweep commands sent 
/// \return The status code
UeiDaqAPI int UeiDaqWriteAOWaveformSweep(SessionHandle sessionHandle, Int32 channel, Int32 numSwps, tUeiAOWaveformSweepParameters* pBuffer, Int32* numSwpsWritten);

/// \brief Write arbitrary waveform data to the AO device
/// 
/// Send arbitrary waveform data to the AO device.
///
/// \param sessionHandle The handle to an existing session
/// \param channel the channel to write the waveform to
/// \param numValues the number of values to send
/// \param pBuffer source buffer
/// \param numValsWritten the actual number of values sent 
/// \return The status code
UeiDaqAPI int UeiDaqWriteAOWaveformArbitraryData(SessionHandle sessionHandle, Int32 channel, Int32 numValues, double* pBuffer, Int32* numValsWritten);

/// \brief Write word(s) to the SSI slave port
/// 
/// Write 32-bit data words to the output stream
///
/// \param sessionHandle The handle to an existing session
/// \param port The SSI slave port to write to
/// \param grayEncoding true to convert binary values to gray
/// \param numWords the number of words to write
/// \param pBuffer source buffer
/// \param numWordsWritten the actual number of frames sent to the SSI port
/// \return The status code
UeiDaqAPI int UeiDaqWriteSSISlaveWords(SessionHandle sessionHandle, int port, int grayEncoding, Int32 numWords, uInt32* pBuffer, Int32* numWordsWritten);

/// \brief Resets circuit breaker
/// 
/// Reset a circuit breaker, in case it was tripped.
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to set breaker on
/// \param mask the mask specifying which circuit breaker to reset (1 to reset, 0 to leave alone) 
/// \return The status code
UeiDaqAPI int UeiDaqResetCircuitBreaker(SessionHandle sessionHandle, Int32 port, uInt32 mask);

/// \brief Get current circuit breaker status
/// 
/// Get  circuit breaker status masks. 
/// Each bit in the current status mask correspond to a circuit breaker. 1 if CB is currently tripped, 0 otherwise
/// Each bit in the sticky status mask correspond to a circuit breaker. 1 if CB was tripped at least once since last time status was read, 0 otherwise
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to get breaker status from
/// \param currentStatus the current circuit breaker status bits (1 if tripped, 0 otherwise)
/// \param stickyStatus the sticky circuit breaker status bits (1 if tripped, 0 otherwise) 
/// \return The status code
UeiDaqAPI int UeiDaqGetCircuitBreakerStatus(SessionHandle sessionHandle, Int32 port, uInt32* currentStatus, uInt32* stickyStatus);

/// \brief Get detailed status about each circuit breaker
///
/// Read detailed status about each cicuit breaker. The meaning of each status bits
/// depends on the type of the I/O device. Refer to the device's user manual for 
/// detailed description of each status bit
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to get breaker status from
/// \param numStatus the number of status to read 
/// \param pBuffer destination buffer for the channel(s) status
/// \param numStatusRead the actual number of status retrieved
/// \return The status code
UeiDaqAPI int UeiDaqGetAllCircuitBreakerStatus(SessionHandle sessionHandle, Int32 port, Int32 numStatus, uInt32* pBuffer, Int32* numStatusRead);

/// \brief Configure short/open circuit simulation
///
/// Configure short/open circuit simulation using bit masks
/// Set bit to 1 to sohrt or open the corresponding channel
/// If a channel is commanded to be both open and shorted it
/// will be shorted.
///
/// \param sessionHandle The handle to an existing session
/// \param openBitmask the bitmask controlling which channel should be open 
/// \param shortBitmask the bitmask controlling which channel should be shorted 
/// \param shortDurationUs the maximum of time that shorted channels will stay shorted
/// \return The status code
UeiDaqAPI int UeiDaqSetAOShortOpenCircuit(SessionHandle sessionHandle, uInt32 openBitmask, uInt32 shortBitmask, uInt32 shortDurationUs);

/// \brief Write CSDB messages to the stream
///
/// Write the requested number of CSDB message block to the port
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to write the message to
/// \param numMessages Number of message blocks to write
/// \param pBuffer Source buffer for the frames
/// \param numMessagesWritten Number of message blocks actually written to the port
/// \return The status code
UeiDaqAPI int UeiDaqWriteCSDBFrame(SessionHandle sessionHandle, Int32 port, Int32 numMessages, tUeiCSDBMessage *pBuffer, Int32* numMessagesWritten);

/// \brief send trigger signal to slave devices
///
/// Set and send the trigger signal that will start
/// all slave deivces
///
/// \param sessionHandle The handle to an existing session
/// \param trigOp The trigger operation
/// \param resetTimestamp true to reset timestamp counter on all slave devices
/// \return The status code
UeiDaqAPI int UeiDaqTriggerSync1PPSDevices(SessionHandle sessionHandle, tUeiSync1PPSTriggerOperation trigOp, int resetTimestamp);

/// \brief Set relays individually
///
/// Set relays individually (use with care to avoid short circuits and damaging your equipment)
/// One bit per relay [channel 0 relay A, channel 0 relay B, channel 0 relay C, channel 1 relay A, channel 1 relay B, etc...]
///
/// \param sessionHandle The handle to an existing session
/// \param numValues Number of values to write
/// \param relayBuffer Data buffer to write
/// \return The status code
UeiDaqAPI int UeiDaqWriteMuxRelays(SessionHandle sessionHandle, int numValues, uInt32* relayBuffer);

/// \brief Write multiple synchro/resolver angles to be generated with fixed delay to device FIFO
///
/// Write multiple angles to simulate velocity/acceleration on simulated synchro/resolver
/// Each angle is associated with a delay (in microseconds)
/// The angles are staged to be sent to the device. Actual send happens upon calling UeiDaqSynchroResolverUpdate()
/// \param sessionHandle The handle to an existing session
/// \param channel the channel to update
/// \param numberOfValues numberOfValues in the buffer
/// \param pDelayBuffer destination buffer for delays
/// \param pAngleBuffer destination buffer for angles
/// \return The status code
UeiDaqAPI int UeiDaqWriteSynchroResolverAngles(SessionHandle sessionHandle, int channel, int numberOfValues, uInt32* pDelayBuffer, f64* pAngleBuffer);

/// \brief Update all simulated synchro/resolver channels with staged angles and delays
///
/// Update all channels with staged angles and delays
/// \param sessionHandle The handle to an existing session
/// \param written array containing the number of values actually written for each channel
/// \param available array containing the space available in FIFO for each channel
/// \return The status code
UeiDaqAPI int UeiDaqUpdateSynchroResolverAngles(SessionHandle sessionHandle, Int32* written, Int32* available);

/// \brief Set mux
///
/// Set mux on a set of channels
///
/// \param sessionHandle The handle to an existing session
/// \param numChannels The number of channels to set mux on
/// \param channels The list of channels to set mux on
/// \param relayIndices The index of the relay to close for each channel in the channel list (0 for relay A, 1 for relay B etc...)
/// \return The status code
UeiDaqAPI int UeiDaqWriteMux(SessionHandle sessionHandle, int numChannels, int* channels, int* relayIndices);

/// \brief Set low-level format mux values
///
/// Set mux on each channel using the same representation than the low-level API
/// Two bits per channels: 00 relays off, 01 relay A ON, 10 relay B on, 11 relay C on
/// [ channel 0 mux, channel 1 mux, channel 2 mux, etc...]
///
/// \param sessionHandle The handle to an existing session
/// \param numValues Number of values to write
/// \param muxBuffer Data buffer to write
/// \return The status code
UeiDaqAPI int UeiDaqWriteMuxRaw(SessionHandle sessionHandle, int numValues, uInt32* muxBuffer);

/// \brief Set single channel on MUX for use with DMM
///
/// Set mux on a single channel and select output to DMM
///
/// \param sessionHandle The handle to an existing session
/// \param channelNum Channel to set
/// \param relaySelect Relay to enable. 0 for disable, 1 for relay A, 2 for relay B. Ignored if using UeiMuxDmmMeasRes4 dmmMode
/// \param dmmMode Select output to DMM
/// \return The status code
UeiDaqAPI int UeiDaqWriteMuxDmm(SessionHandle sessionHandle, Int32 channelNum, Int32 relaySelect, tUeiMuxDmmMode dmmMode);

/// \brief Writes data to slave
///
/// Writes data to slave FIFO that is transmitted when a
/// master requests data using a read command.
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to write the data to
/// \param numElements Number of data elements in the buffer
/// \param pBuffer Data buffer
/// \param numElementsWritten Number of elements actually written to the slave
/// \return The status code
UeiDaqAPI int UeiDaqWriteI2CSlaveData(SessionHandle sessionHandle, Int32 port, Int32 numElements, uInt16* pBuffer, Int32* numElementsWritten);

/// \brief Write command for master to transmit
///
/// Write command for master to transmit.
///
/// \param sessionHandle The handle to an existing session
/// \param port The port to write the command to
/// \param command The command to write to the master
/// \return The status code
UeiDaqAPI int UeiDaqWriteI2CMasterCommand(SessionHandle sessionHandle, Int32 port, tUeiI2CMasterCommand* command);

/// \brief Flush I/O buffers associated with the specifed port
///
/// Flush transmit and or receive buffer(s) associated with the specified port
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to flush
/// \param action the action to be taken while flushing the buffer(s)
/// \return The status code
UeiDaqAPI int UeiDaqFlushMessages(SessionHandle sessionHandle, Int32 port, tUeiFlushAction action);

/// \brief Get the number of available input messages
///
/// Get the number of messages ready to be read from the specified port
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to query
/// \param pAvailableInputMessages the number of available messages.
/// \return The status code
UeiDaqAPI Int32 UeiDaqGetAvailableInputMessages(SessionHandle sessionHandle, Int32 port, Int32* pAvailableInputMessages);

/// \brief Get the number of available output slots
///
/// Get the number of message slots ready to accept new output messages on the specified port
///
/// \param sessionHandle The handle to an existing session
/// \param port the port to query
/// \param pAvailableOutputSlots the number of available messages.
/// \return The status code
UeiDaqAPI Int32 UeiDaqGetAvailableOutputSlots(SessionHandle sessionHandle, Int32 port, Int32* pAvailableOutputSlots);

/// \brief Get a channel resource name
///
/// Get the channel URL.
///
/// \param channelHandle The handle to an existing channel
/// \param resourceName A string to contain the returned resource name.
/// \param resourceNameLength The length of the string, on function return contains the number of characters copied. If resourceName is NULL, resourceNameLength contains the required length for resourceName
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetChannelResourceName(ChannelHandle channelHandle, char* resourceName, int* resourceNameLength);

/// \brief Set resource name
///
/// Set the channel URL. Ex: pwrdaq://Dev1/ai0..
///
/// \param channelHandle The handle to an existing channel
/// \param resName A string that contains the resource name.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetChannelResourceName(ChannelHandle channelHandle, char* resName);

/// \brief Get alias name
///
/// Get the alias name of the channel
///
/// \param channelHandle The handle to an existing channel
/// \param aliasName A string to contain the returned alias name.
/// \param aliasNameLength The length of the string, on function return contains the number of characters copied. If aliasName is NULL, aliasNameLength contains the required length for aliasName
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetChannelAliasName(ChannelHandle channelHandle, char* aliasName, int* aliasNameLength);

/// \brief Set alias name
///
/// Set the alias name of the channel
///
/// \param channelHandle The handle to an existing channel
/// \param aliasName A string that contains the new alias name.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetChannelAliasName(ChannelHandle channelHandle, char* aliasName);

/// \brief Get the index
///
/// Get the index of the channel in the session's channel list
///
/// \param channelHandle The handle to an existing channel
/// \param index The returned channel index.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetChannelIndex(ChannelHandle channelHandle, int* index);

/// \brief Set the index
///
/// Set the index of the channel in the session's channel list
///
/// \param channelHandle The handle to an existing channel
/// \param index The channel index.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetChannelIndex(ChannelHandle channelHandle, int index);

/// \brief Get the minimum range value
///
/// Get the minimum expected value for the signal connected to the channel.
///
/// \param channelHandle The handle to an existing channel
/// \param minimum The returned minimum value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetAIChannelMinimum(ChannelHandle channelHandle, f64* minimum);

/// \brief Set the minimum range value
///
/// Set the minimum expected value for the signal connected to the channel.
///
/// \param channelHandle The handle to an existing channel
/// \param minimum The minimum value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetAIChannelMinimum(ChannelHandle channelHandle, f64 minimum);

/// \brief Get the maximum range value
///
/// Get the maximum expected value for the signal connected to the channel.
///
/// \param channelHandle The handle to an existing channel
/// \param maximum The returned maximum value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetAIChannelMaximum(ChannelHandle channelHandle, f64* maximum);

/// \brief Set the maximum range value
///
/// Set the maximum expected value for the signal connected to the channel.
///
/// \param channelHandle The handle to an existing channel
/// \param maximum The maximum value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetAIChannelMaximum(ChannelHandle channelHandle, f64 maximum);

/// \brief Get the input mode
///
/// Get the input mode of the channel, possible values are "differential" or "single-ended".
///
/// \param channelHandle The handle to an existing channel
/// \param mode The returned input mode.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetAIChannelInputMode(ChannelHandle channelHandle, tUeiAIChannelInputMode *mode);

/// \brief Get mux position mode
///
/// Get the mux position mode for devices with self-test capability
///
/// \param channelHandle The handle to an existing channel
/// \param muxPos The returned mux position mode
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetAIChannelMuxPos(ChannelHandle channelHandle, tUeiAIChannelMuxPos *muxPos);

/// \brief Set mux position mode
///
/// Set the mux position mode for devices with self-test capability
///
/// \param channelHandle The handle to an existing channel
/// \param muxPos The new mux position mode
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetAIChannelMuxPos(ChannelHandle channelHandle, tUeiAIChannelMuxPos muxPos);

/// \brief Get the gain
///
/// Get the gain that best fits the requested input range
///
/// \param channelHandle The handle to an existing channel
/// \param gain The current gain
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetAIChannelGain(ChannelHandle channelHandle, f64* gain);

/// \brief Set the gain
///
/// Overrides gain calcualted from input range
///
/// \param channelHandle The handle to an existing channel
/// \param gain the new gain
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetAIChannelGain(ChannelHandle channelHandle, f64 gain);

/// \brief Set the input mode
///
/// Set the input mode of the channel, possible values are "differential" or "single-ended".
///
/// \param channelHandle The handle to an existing channel
/// \param mode The input mode.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetAIChannelInputMode(ChannelHandle channelHandle, tUeiAIChannelInputMode mode);

/// \brief Get open circuit detection status
///
/// Get status of open circuit detection
/// \param channelHandle The handle to an existing channel
/// \param enabled true if open circuit detection is enabled, false otherwise
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqIsAIChannelOpenCircuitTestEnabled(ChannelHandle channelHandle, int *enabled);

/// \brief Enable or disable open cicuit detection
///
/// Enable or disable open circuit detection
/// \param channelHandle The handle to an existing channel
/// \param enable true to enable open circuit detection
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqEnableAIChannelOpenCircuitTest(ChannelHandle channelHandle, int enable);

/// \brief Get open circuit detection result
///
/// Get result of open circuit detection
/// \param channelHandle The handle to an existing channel
/// \param open true if circuit is open, false otherwise
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqIsAIChannelCircuitOpen(ChannelHandle channelHandle, int* open);

/// \brief Get bias resistor state
///
/// Bias resistors connects the negative input to ground and positive input to
/// a voltage source. This is useful to measure temperature from un-grounded
/// thremocouple. Disable bias to measure from grounded thermocouples
/// 
/// \param channelHandle The handle to an existing channel
/// \param enabled true if bias is enabled, false otherwise
/// \return The status code
UeiDaqAPI int UeiDaqIsAIChannelBiasEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Set bias resistor state
///
/// Bias resistors connects the negative input to ground and positive input to
/// a voltage source. This is useful to measure temperature from un-grounded
/// thremocouple. Disable bias to measure from grounded thermocouples
/// 
/// \param channelHandle The handle to an existing channel
/// \param enable the bias resistor state
/// \return The status code
UeiDaqAPI int UeiDaqEnableAIChannelBias(ChannelHandle channelHandle, int enable);

/// \brief Get auto-zero state
///
/// Some analog input devices come with a special channel to measure
/// ground offset. auto-zero substract the ground voltage measurement
/// from the input voltage measurement.
///
/// \param channelHandle The handle to an existing channel
/// \param enabled the auto-zero state
/// \return The status code
UeiDaqAPI int UeiDaqIsAIChannelAutoZeroEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Set auto zero state
///
/// Some analog input devices come with a special channel to measure
/// ground offset. auto-zero substract the ground voltage measurement
/// from the input voltage measurement.
///
/// \param channelHandle The handle to an existing channel
/// \param enable the new auto-zero state
/// \return The status code
UeiDaqAPI int UeiDaqEnableAIChannelAutoZero(ChannelHandle channelHandle, int enable);

/// \brief Get the minimum value
///
/// Get the minimum value for the generated signal.
///
/// \param channelHandle The handle to an existing channel
/// \param minimum The returned minimum value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetAOChannelMinimum(ChannelHandle channelHandle, f64* minimum);

/// \brief Set the minimum value
///
/// Set the minimum value for the generated signal.
///
/// \param channelHandle The handle to an existing channel
/// \param minimum The minimum value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetAOChannelMinimum(ChannelHandle channelHandle, f64 minimum);

/// \brief Get the maximum value
///
/// Get the maximum value for the generated signal.
///
/// \param channelHandle The handle to an existing channel
/// \param maximum The returned maximum value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetAOChannelMaximum(ChannelHandle channelHandle, f64* maximum);

/// \brief Set the maximum value
///
/// Set the maximum value for the generated signal.
///
/// \param channelHandle The handle to an existing channel
/// \param maximum The maximum value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetAOChannelMaximum(ChannelHandle channelHandle, f64 maximum);

/// \brief Get the default value state
///
/// Determines whether output will be set to a default value when session stops.
///
/// \param channelHandle The handle to an existing channel
/// \param pDefaultValueEnabled The default value state.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqIsAOChannelDefaultValueEnabled(ChannelHandle channelHandle, int* pDefaultValueEnabled);

/// \brief Set the default value state
///
/// Enables default value. The output will be set to a default value when session stops.
///
/// \param channelHandle The handle to an existing channel
/// \param enableDefaultValue true to turn stop value on, false otherwise
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqEnableAOChannelDefaultValue(ChannelHandle channelHandle, int enableDefaultValue);

/// \brief Get the default value
///
/// Get the default value.
///
/// \param channelHandle The handle to an existing channel
/// \param pDefaultVal the default value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetAOChannelDefaultValue(ChannelHandle channelHandle, f64* pDefaultVal);

/// \brief Set the default value
///
/// Set the default value.
///
/// \param channelHandle The handle to an existing channel
/// \param defaultVal the default value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetAOChannelDefaultValue(ChannelHandle channelHandle, f64 defaultVal);

/// \brief Get the main DAC clock source
///
/// Get the source of the clock used by the main DAC.
///
/// \param channelHandle The handle to an existing channel
/// \param pSource the main DAC clock source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle  
UeiDaqAPI int UeiDaqGetAOWaveformMainDACClockSource(ChannelHandle channelHandle, tUeiAOWaveformClockSource* pSource);

/// \brief Set the main DAC clock source
///
/// Set the source of the clock used by the main DAC.
///
/// \param channelHandle The handle to an existing channel
/// \param source the new main DAC clock source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle  
UeiDaqAPI int UeiDaqSetAOWaveformMainDACClockSource(ChannelHandle channelHandle, tUeiAOWaveformClockSource source);

/// \brief Get the offset DAC clock source
///
/// Get the source of the clock used by the offset DAC.
///
/// \param channelHandle The handle to an existing channel
/// \param pSource the offset DAC clock source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle  
UeiDaqAPI int UeiDaqGetAOWaveformOffsetDACClockSource(ChannelHandle channelHandle, tUeiAOWaveformOffsetClockSource* pSource);

/// \brief Set the offset DAC clock source
///
/// Set the source of the clock used by the offset DAC.
///
/// \param channelHandle The handle to an existing channel
/// \param source the new offset DAC clock source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle  
UeiDaqAPI int UeiDaqSetAOWaveformOffsetDACClockSource(ChannelHandle channelHandle, tUeiAOWaveformOffsetClockSource source);

/// \brief Get the main DAC clock synchronization
///
/// Get the output where the clock used by the main DAC is routed.
///
/// \param channelHandle The handle to an existing channel
/// \param pSync the main DAC clock synchronization.
/// \return The status code
/// \sa UeiDaqGetChannelHandle  
UeiDaqAPI int UeiDaqGetAOWaveformMainDACClockSync(ChannelHandle channelHandle, tUeiAOWaveformClockSync* pSync);

/// \brief Route the main DAC synchronization
///
/// Set the output where the clock used by the main DAC will be routed.
///
/// \param channelHandle The handle to an existing channel
/// \param sync the new main DAC clock synchronization.
/// \return The status code
/// \sa UeiDaqGetChannelHandle  
UeiDaqAPI int UeiDaqSetAOWaveformMainDACClockSync(ChannelHandle channelHandle, tUeiAOWaveformClockSync sync);

/// \brief Get the main DAC trigger source
///
/// Get the source of the trigger used by the main DAC.
///
/// \param channelHandle The handle to an existing channel
/// \param pSource the main DAC trigger source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle  
UeiDaqAPI int UeiDaqGetAOWaveformMainDACTriggerSource(ChannelHandle channelHandle, tUeiAOWaveformTriggerSource* pSource);

/// \brief Set the main DAC trigger source
///
/// Set the source of the trigger used by the main DAC.
///
/// \param channelHandle The handle to an existing channel
/// \param source the new main DAC trigger source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle  
UeiDaqAPI int UeiDaqSetAOWaveformMainDACTriggerSource(ChannelHandle channelHandle, tUeiAOWaveformTriggerSource source);

/// \brief Get the offset DAC trigger source
///
/// Get the source of the trigger used by the offset DAC.
///
/// \param channelHandle The handle to an existing channel
/// \param pSource the offset DAC trigger source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle  
UeiDaqAPI int UeiDaqGetAOWaveformOffsetDACTriggerSource(ChannelHandle channelHandle, tUeiAOWaveformOffsetTriggerSource* pSource);

/// \brief Set the offset DAC trigger source
///
/// Set the source of the trigger used by the offset DAC.
///
/// \param channelHandle The handle to an existing channel
/// \param source the new offset DAC trigger source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle  
UeiDaqAPI int UeiDaqSetAOWaveformOffsetDACTriggerSource(ChannelHandle channelHandle, tUeiAOWaveformOffsetTriggerSource source);

/// \brief Get the DAC mode
///
/// Each channel uses two DACs that can be enabled independantly. 
///
/// \param channelHandle The handle to an existing channel
/// \param pMode The current DAC mode.
/// \return The status code
UeiDaqAPI int UeiDaqGetAOProtectedDACMode(ChannelHandle channelHandle, tUeiAODACMode* pMode);

/// \brief Set the DAC mode
///
/// Each channel uses two DACs that can be enabled independantly. 
///
/// \param channelHandle The handle to an existing channel
/// \param mode The new DAC mode.
/// \return The status code
UeiDaqAPI int UeiDaqSetAOProtectedDACMode(ChannelHandle channelHandle, tUeiAODACMode mode);

/// \brief Gets diagnostic channels
///
/// Each AO channel comes with up to five diagnostic channels.
/// Select which diagnostic to monitor at specified index.
///
/// \param channelHandle The handle to an existing channel
/// \param index The 0 based index of the diagnostic channel
/// \param pAdcChannel The current diagnostic source.
/// \return The status code
UeiDaqAPI int UeiDaqGetAOProtectedADCChannel(ChannelHandle channelHandle, int index, tUeiAODiagChannel* pAdcChannel);

/// \brief Sets diagnostic channel
///
/// Each AO channel comes with up to five diagnostic channels.
/// Set the diagnostic channel associated with the specified index.
///
/// \param channelHandle The handle to an existing channel
/// \param index The 0 based index of the diagnostic channel
/// \param adcChannel The new diagnostic channel at specified index
/// \return The status code
UeiDaqAPI int UeiDaqSetAOProtectedADCChannel(ChannelHandle channelHandle, int index, tUeiAODiagChannel adcChannel);

/// \brief Get the minimum circuit breaker limits
///
/// Each circuit-breaker can monitor one diagnostic channel.
/// Get the minimum current/volt/temperature allowed on the specified channel.
/// The circuit will open if less than the minimum value is monitored.
///
/// \param channelHandle The handle to an existing channel
/// \param index The 0 based index of the circuit breaker
/// \param pLowLimit The current low limit.
/// \return The status code
UeiDaqAPI int UeiDaqGetAOProtectedCircuitBreakerLowLimit(ChannelHandle channelHandle, int index, double* pLowLimit);

/// \brief Set the minimum circuit breaker limits
///
/// Each circuit-breaker can monitor one diagnostic channel.
/// Set the minimum current/volt/temperature allowed on the specified channel.
/// The circuit will open if less than the minimum value is monitored.
///
/// \param channelHandle The handle to an existing channel
/// \param index The 0 based index of the circuit breaker
/// \param lowLimit The new low limit.
/// \return The status code
UeiDaqAPI int UeiDaqSetAOProtectedCircuitBreakerLowLimit(ChannelHandle channelHandle, int index, double lowLimit);

/// \brief Get the maximum circuit breaker limits
///
/// Each circuit-breaker can monitor one diagnostic channel.
/// Get the maximum current/volt/temperature allowed on the specified channel.
/// The circuit will open if more than the maximum value is monitored.
///
/// \param channelHandle The handle to an existing channel
/// \param index The 0 based index of the circuit breaker
/// \param pHighLimit The current high limit.
/// \return The status code
UeiDaqAPI int UeiDaqGetAOProtectedCircuitBreakerHighLimit(ChannelHandle channelHandle, int index, double* pHighLimit);

/// \brief Set the maximum circuit breaker limits
///
/// Each circuit-breaker can monitor one diagnostic channel.
/// Set the maximum current/volt/temperature allowed on the specified channel.
/// The circuit will open if more than the minimum value is monitored.
///
/// \param channelHandle The handle to an existing channel
/// \param index The 0 based index of the circuit breaker
/// \param highLimit The new high limit.
/// \return The status code
UeiDaqAPI int UeiDaqSetAOProtectedCircuitBreakerHighLimit(ChannelHandle channelHandle, int index, double highLimit);

/// \brief Get the diagnostic measurement rate 
///
/// Get the rate at which the diagnostic channels are monitored.
/// This rate determines how fast the device react when an under or over limit
/// condition occurs.
///
/// \param channelHandle The handle to an existing channel
/// \param pMeasurementRate The current circuit breaker measurement rate.
/// \return The status code
UeiDaqAPI int UeiDaqGetAOProtectedMeasurementRate(ChannelHandle channelHandle, double* pMeasurementRate);

/// \brief Set the diagnostic measurement rate 
///
/// Set the rate at which the diagnostic channels are monitored.
/// This rate determines how fast the device react when an under or over limit
/// condition occurs.
///
/// \param channelHandle The handle to an existing channel
/// \param measurementRate The new circuit breaker measurement rate.
/// \return The status code
UeiDaqAPI int UeiDaqSetAOProtectedMeasurementRate(ChannelHandle channelHandle, double measurementRate);

/// \brief Determines whether the CB is currently protecting the channel
/// 
/// Return true is circuit breaker for this channels is enabled and
/// false otherwise
///
/// \param channelHandle The handle to an existing channel
/// \param index The 0 based index of the circuit breaker
/// \param pEnabled The current circuit breaker state
/// \return The status code
UeiDaqAPI int UeiDaqIsAOProtectedCircuitBreakerEnabled(ChannelHandle channelHandle, int index, int* pEnabled);

/// \brief Enable or Disable channel protection 
/// 
/// Enable or disable circuit breaker on this channel. when enabled a circuit
/// breaker monitors up to two measurement channels and opens the circuit
/// if any of the measurements goes out of pre-set limits.
///
/// \param channelHandle The handle to an existing channel
/// \param index The 0 based index of the circuit breaker
/// \param enable 1 to turn-on protection, 0 to turn it off
/// \return The status code
UeiDaqAPI int UeiDaqEnableAOProtectedCircuitBreaker(ChannelHandle channelHandle, int index, int enable);

/// \brief Get the auto retry setting. 
///
/// The auto retry setting specifies wheter the device should attempt
/// to close the circuit after it was opened because of an over or
/// under limit condition.
/// If it is set to true the device will try to close the circuit at a rate
/// set by the autoRetryRate setting.
///
/// \param channelHandle The handle to an existing channel
/// \param pAutoRetry true if auto-retry is on, false otherwise.
/// \return The status code
UeiDaqAPI int UeiDaqGetAOProtectedAutoRetry(ChannelHandle channelHandle, int* pAutoRetry);

/// \brief Set the auto retry setting. 
///
/// The auto retry setting specifies wheter the device should attempt
/// to close the circuit after it was opened because of an over or
/// under limit condition.
/// If it is set to true the device will try to close the circuit at a rate
/// set by the autoRetryRate setting.
///
/// \param channelHandle The handle to an existing channel
/// \param autoRetry true to turn auto-retry on, false to turn it off.
/// \return The status code
UeiDaqAPI int UeiDaqSetAOProtectedAutoRetry(ChannelHandle channelHandle, int autoRetry);

/// \brief Get the auto retry rate. 
///
/// Specifies how often the device will attemp to close a circuit that
/// was opened because of an over or under limit condition.
///
/// \param channelHandle The handle to an existing channel
/// \param pAutoRetryRate The number of retries per second.
/// \return The status code
UeiDaqAPI int UeiDaqGetAOProtectedAutoRetryRate(ChannelHandle channelHandle, double* pAutoRetryRate);

/// \brief Set the auto retry rate. 
///
/// Specifies how often the device will attemp to close a circuit that
/// was opened because of an over or under limit condition.
///
/// \param channelHandle The handle to an existing channel
/// \param autoRetryRate The new number of retries per second.
/// \return The status code
UeiDaqAPI int UeiDaqSetAOProtectedAutoRetryRate(ChannelHandle channelHandle, double autoRetryRate);

/// \brief Get the over/under count. 
///
/// Specifies number of consecutive over/under limit diagnostic readings that must 
/// occur in order to trip breaker. 
///
/// \param channelHandle The handle to an existing channel
/// \param pOverUnderCount The maximum number of over/under readings.
/// \return The status code
UeiDaqAPI int UeiDaqGetAOProtectedOverUnderCount(ChannelHandle channelHandle, uInt32* pOverUnderCount);

/// \brief Set the over/under count. 
///
/// Specifies number of consecutive over/under limit diagnostic readings that must 
/// occur in order to trip breaker. 
///
/// \param channelHandle The handle to an existing channel
/// \param overUnderCount The new maximum number of over/under readings.
/// \return The status code
UeiDaqAPI int UeiDaqSetAOProtectedOverUnderCount(ChannelHandle channelHandle, uInt32 overUnderCount);

/// \brief Get the edge detection mask
///
/// Get the mask used to select wich digital line will be used to sense edges.
/// When bit x is set to 1, line x is used.
///
/// \param channelHandle The handle to an existing channel
/// \param mask The returned edge detection mask.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetDIChannelEdgeMask(ChannelHandle channelHandle, uInt32* mask);

/// \brief Set the edge detection mask
///
/// Set the mask used to select wich digital line will be used to sense edges.
/// When bit x is set to 1, line x is used.
///
/// \param channelHandle The handle to an existing channel
/// \param mask The edge detection mask.
/// \param edgeType The edge of the signal that triggers the state change detection event.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetDIChannelEdgeMask(ChannelHandle channelHandle, uInt32 mask, tUeiDigitalEdge edgeType);

/// \brief Get the default value state
///
/// Determines whether output will be set to a default value when session stops.
///
/// \param channelHandle The handle to an existing channel
/// \param pDefaultValueEnabled The default value state.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqIsDOChannelDefaultValueEnabled(ChannelHandle channelHandle, int* pDefaultValueEnabled);

/// \brief Set the default value state
///
/// Enables default value. The output will be set to a default value when session stops.
///
/// \param channelHandle The handle to an existing channel
/// \param enableDefaultValue true to turn stop value on, false otherwise
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqEnableDOChannelDefaultValue(ChannelHandle channelHandle, int enableDefaultValue);

/// \brief Get the default value
///
/// Get the default value.
///
/// \param channelHandle The handle to an existing channel
/// \param pDefaultVal the default value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetDOChannelDefaultValue(ChannelHandle channelHandle, uInt32* pDefaultVal);

/// \brief Set the default value
///
/// Set the default value.
///
/// \param channelHandle The handle to an existing channel
/// \param defaultVal the default value.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetDOChannelDefaultValue(ChannelHandle channelHandle, uInt32 defaultVal);

/// \brief Get the counter source
///
/// Get the source of the signal counted or used as a timebase
///
/// \param channelHandle The handle to an existing channel
/// \param source The returned source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetCIChannelCounterSource(ChannelHandle channelHandle, tUeiCounterSource* source);

/// \brief Set the counter source
///
/// Set the source of the signal counted or used as a timebase
///
/// \param channelHandle The handle to an existing channel
/// \param source The source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetCIChannelCounterSource(ChannelHandle channelHandle, tUeiCounterSource source);

/// \brief Get the counter mode
///
/// Get the mode that specify whether the session counts events, measures a pulse width or measures a period on the signal configured as the source
///
/// \param channelHandle The handle to an existing channel
/// \param mode The returned mode.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetCIChannelCounterMode(ChannelHandle channelHandle, tUeiCounterMode* mode);

/// \brief Set the counter mode
///
/// Set the mode that specify whether the session counts events, measures a pulse width or measures a period on the signal configured as the source
///
/// \param channelHandle The handle to an existing channel
/// \param mode The new mode.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetCIChannelCounterMode(ChannelHandle channelHandle, tUeiCounterMode mode);

/// \brief Get the counter gate
///
/// Get the signal that specify whether the counter/timer is on or off
///
/// \param channelHandle The handle to an existing channel
/// \param gate The returned gate.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetCIChannelCounterGate(ChannelHandle channelHandle, tUeiCounterGate* gate);

/// \brief Set the counter gate
///
/// Set the signal that specify whether the counter/timer is on or off
///
/// \param channelHandle The handle to an existing channel
/// \param gate The gate.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetCIChannelCounterGate(ChannelHandle channelHandle, tUeiCounterGate gate);

/// \brief Get the inverted setting
///
/// Checks whether the signal at the source is inverted before performing the counting operation
///
/// \param channelHandle The handle to an existing channel
/// \param inverted The returned inverted setting.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetCIChannelInverted(ChannelHandle channelHandle, Int32* inverted);

/// \brief Set the inverted setting
///
/// Specifies whether the signal at the source is inverted before performing the counting operation
///
/// \param channelHandle The handle to an existing channel
/// \param inverted The inverted setting.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetCIChannelInverted(ChannelHandle channelHandle, Int32 inverted);

/// \brief Get the timebase divider
///
/// Get the divider used to scale the timebase speed.
///
/// \param channelHandle The handle to an existing channel
/// \param divider the current divider.
/// \return The status code
/// \sa UeiDaqSetCITimebaseDivider
UeiDaqAPI int UeiDaqGetCITimebaseDivider(ChannelHandle channelHandle, Int32* divider);

/// \brief Set the timebase divider
///
/// Set the divider used to scale the timebase speed.
///
/// \param channelHandle The handle to an existing channel
/// \param divider the new divider value.
/// \return The status code
/// \sa UeiDaqGetCITimebaseDivider
UeiDaqAPI int UeiDaqSetCITimebaseDivider(ChannelHandle channelHandle, Int32 divider);

/// \brief Get the minimum pulse width at the counter source
///
/// Get the minimum pulse width in ms the counter recognizes at its source.
/// Any pulse whose width is smaller will be ignored.
/// \param channelHandle The handle to an existing channel
/// \param minWidth the current minimum pulse width
/// \sa UeiDaqSetCIMinimumSourcePulseWidth
UeiDaqAPI int UeiDaqGetCIMinimumSourcePulseWidth(ChannelHandle channelHandle, double* minWidth);

/// \brief Set the minimum pulse width at the counter source
///
/// Set the minimum pulse width in ms the counter recognizes at its source.
/// Any pulse whose width is smaller will be ignored.
/// \param channelHandle The handle to an existing channel
/// \param minWidth the minimum pulse width
/// \return The status code
/// \sa UeiDaqGetCIMinimumSourcePulseWidth
UeiDaqAPI int UeiDaqSetCIMinimumSourcePulseWidth(ChannelHandle channelHandle, double minWidth);

/// \brief Get the minimum pulse width at the counter gate
///
/// Get the minimum pulse width in ms the counter recognizes at its gate.
/// Any pulse whose width is smaller will be ignored.
/// \param channelHandle The handle to an existing channel
/// \param minWidth the current minimum pulse width
/// \return The status code
/// \sa UeiDaqSetCIMinimumGatePulseWidth
UeiDaqAPI int UeiDaqGetCIMinimumGatePulseWidth(ChannelHandle channelHandle, double* minWidth);

/// \brief Set the minimum pulse width at the counter gate
///
/// Set the minimum pulse width in ms the counter recognizes at its gate.
/// Any pulse whose width is smaller will be ignored.
/// \param channelHandle The handle to an existing channel
/// \param minWidth the minimum pulse width
/// \return The status code
/// \sa UeiDaqGetCIMinimumGatePulseWidth
UeiDaqAPI int UeiDaqSetCIMinimumGatePulseWidth(ChannelHandle channelHandle, double minWidth);

/// \brief Get the gate mode
///
/// Get the gate mode which determines whether the counter/timer will
/// run continuously once the gate is asserted
/// \param channelHandle The handle to an existing channel
/// \param gateMode the current gate mode.
/// \return The status code
/// \sa UeiDaqSetCIGateMode
UeiDaqAPI int UeiDaqGetCIGateMode(ChannelHandle channelHandle, tUeiCounterGateMode* gateMode);

/// \brief Set the gate mode
///
/// Set the gate mode which determines whether the counter/timer will
/// run continuously once the gate is asserted
/// \param channelHandle The handle to an existing channel
/// \param gateMode the new gate mode.
/// \return The status code
/// \sa UeiDaqGetCIGateMode
UeiDaqAPI int UeiDaqSetCIGateMode(ChannelHandle channelHandle, tUeiCounterGateMode gateMode);

/// \brief Get the period count
///
/// Get the number of periods used to average a period measurement
/// \param channelHandle The handle to an existing channel
/// \param periodCount the current period count.
/// \return The status code
/// \sa UeiDaqSetCIPeriodCount
UeiDaqAPI int UeiDaqGetCIPeriodCount(ChannelHandle channelHandle, Int32* periodCount);

/// \brief Set the period count
///
/// Set the number of period(s) to measure. An average measurement is returned.
/// \param channelHandle The handle to an existing channel
/// \param periodCount the new period count.
/// \return The status code
/// \sa UeiDaqGetCIPeriodCount
UeiDaqAPI int UeiDaqSetCIPeriodCount(ChannelHandle channelHandle, Int32 periodCount);

/// \brief Get the counter source
///
/// Get the source of the signal used as a timebase
///
/// \param channelHandle The handle to an existing channel
/// \param source The returned source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetCOChannelCounterSource(ChannelHandle channelHandle, tUeiCounterSource* source);

/// \brief Set the counter source
///
/// Set the source of the signal used as a timebase
///
/// \param channelHandle The handle to an existing channel
/// \param source The source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetCOChannelCounterSource(ChannelHandle channelHandle, tUeiCounterSource source);

/// \brief Get the counter mode
///
/// Get the mode that specify whether the session generates a single pulse or a pulse train on the counter output
///
/// \param channelHandle The handle to an existing channel
/// \param mode The returned mode.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetCOChannelCounterMode(ChannelHandle channelHandle, tUeiCounterMode* mode);

/// \brief Set the counter mode
///
/// Set the mode that specify whether the session generates a single pulse or a pulse train on the counter output
///
/// \param channelHandle The handle to an existing channel
/// \param mode The new mode.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetCOChannelCounterMode(ChannelHandle channelHandle, tUeiCounterMode mode);

/// \brief Get the counter gate
///
/// Get the signal that specify whether the counter/timer is on or off
///
/// \param channelHandle The handle to an existing channel
/// \param gate The returned gate.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetCOChannelCounterGate(ChannelHandle channelHandle, tUeiCounterGate* gate);

/// \brief Set the counter gate
///
/// Set the signal that specify whether the counter/timer is on or off
///
/// \param channelHandle The handle to an existing channel
/// \param gate The gate.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetCOChannelCounterGate(ChannelHandle channelHandle, tUeiCounterGate gate);

/// \brief Get the inverted setting
///
/// Checks whether the signal at the source is inverted before performing the timing operation
///
/// \param channelHandle The handle to an existing channel
/// \param inverted The returned inverted setting.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetCOChannelInverted(ChannelHandle channelHandle, Int32* inverted);

/// \brief Set the inverted setting
///
/// Specifies whether the signal at the source is inverted before performing the timing operation
///
/// \param channelHandle The handle to an existing channel
/// \param inverted The inverted setting.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetCOChannelInverted(ChannelHandle channelHandle, Int32 inverted);

/// \brief Get the number of low ticks
///
/// Specifies how long the output stays low.
///
/// \param channelHandle The handle to an existing channel
/// \param tick1 The returned number of ticks of the signal connected at the source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetCOChannelTick1(ChannelHandle channelHandle, Int32* tick1);

/// \brief Set the number of low ticks
///
/// Specifies how long the output stays low.
///
/// \param channelHandle The handle to an existing channel
/// \param tick1 The number of ticks of the signal connected at the source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetCOChannelTick1(ChannelHandle channelHandle, Int32 tick1);

/// \brief Get the number of high ticks
///
/// Specifies how long the output stays high.
///
/// \param channelHandle The handle to an existing channel
/// \param tick2 The returned number of ticks of the signal connected at the source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqGetCOChannelTick2(ChannelHandle channelHandle, Int32* tick2);

/// \brief Set the number of high ticks
///
/// Specifies how long the output stays high.
///
/// \param channelHandle The handle to an existing channel
/// \param tick2 The number of ticks of the signal connected at the source.
/// \return The status code
/// \sa UeiDaqGetChannelHandle
UeiDaqAPI int UeiDaqSetCOChannelTick2(ChannelHandle channelHandle, Int32 tick2);

/// \brief Get the timebase divider
///
/// Get the divider used to scale the timebase speed.
///
/// \param channelHandle The handle to an existing channel
/// \param divider the current divider.
/// \return The status code
/// \sa UeiDaqSetCOTimebaseDivider
UeiDaqAPI int UeiDaqGetCOTimebaseDivider(ChannelHandle channelHandle, Int32* divider);

/// \brief Set the timebase divider
///
/// Set the divider used to scale the timebase speed.
///
/// \param channelHandle The handle to an existing channel
/// \param divider the new divider value.
/// \return The status code
/// \sa UeiDaqGetCOTimebaseDivider
UeiDaqAPI int UeiDaqSetCOTimebaseDivider(ChannelHandle channelHandle, Int32 divider);

/// \brief Get the minimum pulse width at the counter source
///
/// Get the minimum pulse width in ms the counter recognizes at its source.
/// Any pulse whose width is smaller will be ignored.
/// \param channelHandle The handle to an existing channel
/// \param minWidth the current minimum pulse width
/// \sa UeiDaqSetCOMinimumSourcePulseWidth
UeiDaqAPI int UeiDaqGetCOMinimumSourcePulseWidth(ChannelHandle channelHandle, double* minWidth);

/// \brief Set the minimum pulse width at the counter source
///
/// Set the minimum pulse width in ms the counter recognizes at its source.
/// Any pulse whose width is smaller will be ignored.
/// \param channelHandle The handle to an existing channel
/// \param minWidth the minimum pulse width
/// \return The status code
/// \sa UeiDaqGetCOMinimumSourcePulseWidth
UeiDaqAPI int UeiDaqSetCOMinimumSourcePulseWidth(ChannelHandle channelHandle, double minWidth);

/// \brief Get the minimum pulse width at the counter gate
///
/// Get the minimum pulse width in ms the counter recognizes at its gate.
/// Any pulse whose width is smaller will be ignored.
/// \param channelHandle The handle to an existing channel
/// \param minWidth the current minimum pulse width
/// \return The status code
/// \sa UeiDaqSetCOMinimumGatePulseWidth
UeiDaqAPI int UeiDaqGetCOMinimumGatePulseWidth(ChannelHandle channelHandle, double* minWidth);

/// \brief Set the minimum pulse width at the counter gate
///
/// Set the minimum pulse width in ms the counter recognizes at its gate.
/// Any pulse whose width is smaller will be ignored.
/// \param channelHandle The handle to an existing channel
/// \param minWidth the minimum pulse width
/// \return The status code
/// \sa UeiDaqGetCOMinimumGatePulseWidth
UeiDaqAPI int UeiDaqSetCOMinimumGatePulseWidth(ChannelHandle channelHandle, double minWidth);

/// \brief Get the gate mode
///
/// Get the gate mode which determines whether the counter/timer will
/// run continuously once the gate is asserted
/// \param channelHandle The handle to an existing channel
/// \param gateMode the current gate mode.
/// \return The status code
/// \sa UeiDaqSetCOGateMode
UeiDaqAPI int UeiDaqGetCOGateMode(ChannelHandle channelHandle, tUeiCounterGateMode* gateMode);

/// \brief Set the gate mode
///
/// Set the gate mode which determines whether the counter/timer will
/// run continuously once the gate is asserted
/// \param channelHandle The handle to an existing channel
/// \param gateMode the new gate mode.
/// \return The status code
/// \sa UeiDaqGetCOGateMode
UeiDaqAPI int UeiDaqSetCOGateMode(ChannelHandle channelHandle, tUeiCounterGateMode gateMode);

/// \brief Get the pulse count
///
/// Get the number of pulses to generate (-1 for continuous)
///
/// \param channelHandle The handle to an existing channel
/// \param numberOfPulses the current number of pulses.
/// \return The status code
/// \sa SetNumberOfPulses  
UeiDaqAPI int UeiDaqGetCONumberOfPulses(ChannelHandle channelHandle, Int32* numberOfPulses);

/// \brief Set the pulse count
///
/// Set the number of pulses to generate (-1 for continuous)
///
/// \param channelHandle The handle to an existing channel
/// \param numberOfPulses the new number of pulses.
/// \return The status code
/// \sa GetNumberOfPulses 
UeiDaqAPI int UeiDaqSetCONumberOfPulses(ChannelHandle channelHandle, Int32 numberOfPulses);

/// \brief Get the thermocouple type
///
/// Get the type of the thermocouple connected to the channel.
///
/// \param channelHandle The handle to an existing TC channel
/// \param pTCType The actual thermocouple type
/// \return The status code.
/// \sa UeiDaqSetTCThermocoupleType
UeiDaqAPI int UeiDaqGetTCThermocoupleType(ChannelHandle channelHandle, tUeiThermocoupleType* pTCType);

/// \brief Set the thermocouple type
///
/// Set the type of the thermocouple connected to the channel.
///
/// \param channelHandle The handle to an existing TC channel
/// \param tcType the thermocouple type.
/// \return The status code.
/// \sa UeiDaqGetTCThermocoupleType
UeiDaqAPI int UeiDaqSetTCThermocoupleType(ChannelHandle channelHandle, tUeiThermocoupleType tcType);

/// \brief Get the temperature scale
///
/// Get the temperature scale used to convert the measured voltage to temperature.
///
/// \param channelHandle The handle to an existing TC channel
/// \param pTempScale the actual temperature scale.
/// \return The status code.
/// \sa UeiDaqSetTCTemperatureScale
UeiDaqAPI int UeiDaqGetTCTemperatureScale(ChannelHandle channelHandle, tUeiTemperatureScale *pTempScale);

/// \brief Set the temperature scale type
///
/// Set the temperature scale used to convert the measured voltage to temperature.
///
/// \param channelHandle The handle to an existing TC channel
/// \param tempScale the temperature scale.
/// \return The status code.
/// \sa UeiDaqGetTCTemperatureScale
UeiDaqAPI int UeiDaqSetTCTemperatureScale(ChannelHandle channelHandle, tUeiTemperatureScale tempScale);

/// \brief Get the cold junction compensation type
///
/// Get the type of the cold junction compensation used to convert from
/// volts to temperature.
///
/// \param channelHandle The handle to an existing TC channel
/// \param pCJCType the actual cold junction compensation type.
/// \return The status code.
/// \sa UeiDaqSetTCCJCType
UeiDaqAPI int UeiDaqGetTCCJCType(ChannelHandle channelHandle, tUeiColdJunctionCompensationType* pCJCType);

/// \brief Set the cold junction compensation type
///
/// Set the type of the cold junction compensation used to convert from
/// volts to temperature.
///
/// \param channelHandle The handle to an existing TC channel
/// \param cjcType the cold junction compensation type.
/// \return The status code.
/// \sa UeiDaqGetTCCJCType
UeiDaqAPI int UeiDaqSetTCCJCType(ChannelHandle channelHandle, tUeiColdJunctionCompensationType cjcType);

/// \brief Get the cold junction compensation resource
///
/// Get the resource string describing how to measure the cold junction temperature.
/// This setting is only used when the CJC type is set to UeiCJCTypeResource.
/// The CJC resource format is similar to the channel list format:
/// [cjcSensorType]://[Channel(s)]?[Paramters]
/// For example: to measure CJC from a linear IC sensor connected to channel 20
/// the resource string is "ic://20?K=0.00295"
/// this will measure the voltage on channel 20 and compute the CJC temperature
/// with the formula: degK = V / 0.00295
///
/// \param channelHandle The handle to an existing TC channel
/// \param cjcResource the actual cold junction compensation resource.
/// \param cjcResourceLength the cold junction compensation resource string length.
/// \return The status code.
/// \sa UeiDaqSetTCCJCResource
UeiDaqAPI int UeiDaqGetTCCJCResource(ChannelHandle channelHandle, char* cjcResource, int* cjcResourceLength);

/// \brief Set the cold junction compensation resource
///
/// Set the resource string describing how to measure the cold junction temperature.
/// This setting is only used when the CJC type is set to UeiCJCTypeResource.
/// The CJC resource format is similar to the channel list format:
/// [cjcSensorType]://[Channel(s)]?[Paramters]
/// For example: to measure CJC from a linear IC sensor connected to channel 20
/// the resource string is "ic://20?K=0.00295"
/// this will measure the voltage on channel 20 and compute the CJC temperature
/// with the formula: degK = V / 0.00295
///
/// \param channelHandle The handle to an existing TC channel
/// \param cjcResource the cold junction compensation resource.
/// \return The status code.
/// \sa UeiDaqGetTCCJCResource
UeiDaqAPI int UeiDaqSetTCCJCResource(ChannelHandle channelHandle, char* cjcResource);

/// \brief Get the cold junction compensation constant
///
/// Get the cold junction compensation temperature constant. This setting
/// is only used when the CJC type is set to UeiCJCTypeConstant. The unit
/// is the same as the configured temperature scale.
///
/// \param channelHandle The handle to an existing TC channel
/// \param pCJCConstant the actual cold junction compensation constant.
/// \return The status code.
/// \sa UeiDaqSetTCCJCConstant
UeiDaqAPI int UeiDaqGetTCCJCConstant(ChannelHandle channelHandle, double* pCJCConstant);

/// \brief Set the cold junction compensation constant
///
/// Set the cold junction compensation temperature constant. This setting
/// is only used when the CJC type is set to UeiCJCTypeConstant. The unit
/// is the same as the configured temperature scale.
///
/// \param channelHandle The handle to an existing TC channel
/// \param cjcConstant the cold junction compensation constant.
/// \return The status code.
/// \sa UeiDaqGetTCCJCConstant
UeiDaqAPI int UeiDaqSetTCCJCConstant(ChannelHandle channelHandle, double cjcConstant);

/// \brief Get the wiring scheme
///
/// Get the current wiring scheme used for this channel.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param pWiring The current wiring scheme.
/// \return The status code.
/// \sa UeiDaqSetResistanceWiringScheme
UeiDaqAPI int UeiDaqGetResistanceWiringScheme(ChannelHandle channelHandle, tUeiWiringScheme* pWiring);

/// \brief Set the resistance channel wiring scheme
///
/// Specifies the wiring scheme used to connect the resistive sensor to the channel.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param wiring The new wiring scheme.
/// \return The status code.
/// \sa UeiDaqGetResistanceWiringScheme
UeiDaqAPI int UeiDaqSetResistanceWiringScheme(ChannelHandle channelHandle, tUeiWiringScheme wiring);

/// \brief Get the excitation voltage
///
/// Get the excitation voltage configured for the channel.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param pVex The excitation voltage
/// \return The status code.
/// \sa UeiDaqSetResistanceExcitationVoltage
UeiDaqAPI int UeiDaqGetResistanceExcitationVoltage(ChannelHandle channelHandle, double* pVex);

/// \brief Set the excitation voltage
///
/// Set the excitation voltage for this channel.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param vex The excitation voltage
/// \return The status code.
/// \sa UeiDaqGetResistanceExcitationVoltage
UeiDaqAPI int UeiDaqSetResistanceExcitationVoltage(ChannelHandle channelHandle, double vex);

/// \brief Get the reference resistor type
///
/// The reference resistor can be built-in the connector block if you are using
/// a DNA-STP-AIU or connected externally.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param pRefResistorType The current reference resistor type.
/// \return The status code.
/// \sa UeiDaqSetResistanceReferenceResistorType
UeiDaqAPI int UeiDaqGetResistanceReferenceResistorType(ChannelHandle channelHandle, tUeiReferenceResistorType* pRefResistorType);

/// \brief Set the reference resistor type
///
/// The reference resistor can be built-in the connector block if you are using
/// a DNA-STP-AIU or connected externally.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param refResistorType The reference resistor type.
/// \return The status code.
/// \sa UeiDaqGetResistanceReferenceResistorType
UeiDaqAPI int UeiDaqSetResistanceReferenceResistorType(ChannelHandle channelHandle, tUeiReferenceResistorType refResistorType);

/// \brief Get the reference resistance
///
/// Get the reference resistance used to measure the current flowing through
/// the resistive sensor.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param pRref The current reference resistance.
/// \return The status code.
/// \sa UeiDaqSetResistanceReferenceResistance
UeiDaqAPI int UeiDaqGetResistanceReferenceResistance(ChannelHandle channelHandle, double *pRref);

/// \brief Set the reference resistance
///
/// Set the reference resistance used to measure the current flowing through
/// the resistive sensor.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param rref The reference resistance
/// \return The status code.
/// \sa UeiDaqGetResistanceReferenceResistance
UeiDaqAPI int UeiDaqSetResistanceReferenceResistance(ChannelHandle channelHandle, double rref);

/// \brief Get the RTD type
///
/// RTD sensors are specified using the "alpha" (a) constant
/// It is also known as the temperature coefficient of resistance,
/// and symbolizes the resistance change factor per degree of
/// temperature change.
/// The RTD type is used to select the proper coefficients A, B and C
/// for the Callendar Van-Dusen equation used to convert resistance
/// measurements to temperature.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param pRTDType The current RTD type.
/// \return The status code.
/// \sa UeiDaqSetRTDType
UeiDaqAPI int UeiDaqGetRTDType(ChannelHandle channelHandle, tUeiRTDType* pRTDType);

/// \brief Set the RTD type
///
/// RTD sensors are specified using the "alpha" (a) constant
/// It is also known as the temperature coefficient of resistance,
/// and symbolizes the resistance change factor per degree of
/// temperature change.
/// The RTD type is used to select the proper coefficients A, B and C
/// for the Callendar Van-Dusen equation used to convert resistance
/// measurements to temperature.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param type The RTD type
/// \return The status code.
/// \sa UeiDaqGetRTDType
UeiDaqAPI int UeiDaqSetRTDType(ChannelHandle channelHandle, tUeiRTDType type);

/// \brief Get the RTD nominal resistance
///
/// Get the RTD nominal resistance at 0 deg.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param pR0 The current RTD nominal resistance.
/// \return The status code.
/// \sa UeiDaqSetRTDNominalResistance
UeiDaqAPI int UeiDaqGetRTDNominalResistance(ChannelHandle channelHandle, double* pR0);

/// \brief Set the RTD nominal resistance
///
/// Set the RTD nominal resistance at 0 deg.
///
/// \param channelHandle The handle to an existing resistance channel
/// \param r0 The RTD nominal resistance
/// \return The status code.
/// \sa UeiDaqGetRTDNominalResistance
UeiDaqAPI int UeiDaqSetRTDNominalResistance(ChannelHandle channelHandle, double r0);

/// \brief Get the Callendar Van-Dusen coefficient A
///
/// The Callendar-Van Dusen equation is an equation that describes
/// the relationship between resistance (R) and temperature (t) of platinum
/// resistance thermometers.
/// t < 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
/// t > 0: R(t) = R(0)(1 + A * t + B * t * t).
///
/// \param channelHandle The handle to an existing resistance channel
/// \param pA The current CVD A coefficient.
/// \return The status code.
/// \sa UeiDaqSetRTDCoefficientA
UeiDaqAPI int UeiDaqGetRTDCoefficientA(ChannelHandle channelHandle, double* pA);

/// \brief Set the Callendar Van-Dusen coefficient A
///
/// The Callendar-Van Dusen equation is an equation that describes
/// the relationship between resistance (R) and temperature (t) of platinum
/// resistance thermometers.
/// t < 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
/// t > 0: R(t) = R(0)(1 + A * t + B * t * t).
///
/// \param channelHandle The handle to an existing resistance channel
/// \param A The CVD A coefficient
/// \return The status code.
/// \sa UeiDaqGetRTDCoefficientA
UeiDaqAPI int UeiDaqSetRTDCoefficientA(ChannelHandle channelHandle, double A);

/// \brief Get the Callendar Van-Dusen coefficient B
///
/// The Callendar-Van Dusen equation is an equation that describes
/// the relationship between resistance (R) and temperature (t) of platinum
/// resistance thermometers.
/// t < 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
/// t > 0: R(t) = R(0)(1 + A * t + B * t * t).
///
/// \param channelHandle The handle to an existing resistance channel
/// \param pB The current CVD B coefficient.
/// \return The status code.
/// \sa UeiDaqSetRTDCoefficientB
UeiDaqAPI int UeiDaqGetRTDCoefficientB(ChannelHandle channelHandle, double* pB);

/// \brief Set the Callendar Van-Dusen coefficient B
///
/// The Callendar-Van Dusen equation is an equation that describes
/// the relationship between resistance (R) and temperature (t) of platinum
/// resistance thermometers.
/// t < 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
/// t > 0: R(t) = R(0)(1 + A * t + B * t * t).
///
/// \param channelHandle The handle to an existing resistance channel
/// \param B The CVD B coefficient
/// \return The status code.
/// \sa UeiDaqGetRTDCoefficientB
UeiDaqAPI int UeiDaqSetRTDCoefficientB(ChannelHandle channelHandle, double B);

/// \brief Get the Callendar Van-Dusen coefficient C
///
/// The Callendar-Van Dusen equation is an equation that describes
/// the relationship between resistance (R) and temperature (t) of platinum
/// resistance thermometers.
/// t < 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
/// t > 0: R(t) = R(0)(1 + A * t + B * t * t).
///
/// \param channelHandle The handle to an existing resistance channel
/// \param pC The current CVD C coefficient.
/// \return The status code.
/// \sa UeiDaqSetRTDCoefficientC
UeiDaqAPI int UeiDaqGetRTDCoefficientC(ChannelHandle channelHandle, double* pC);

/// \brief Set the Callendar Van-Dusen coefficient C
///
/// The Callendar-Van Dusen equation is an equation that describes
/// the relationship between resistance (R) and temperature (t) of platinum
/// resistance thermometers.
/// t < 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
/// t > 0: R(t) = R(0)(1 + A * t + B * t * t).
///
/// \param channelHandle The handle to an existing resistance channel
/// \param C The CVD C coefficient
/// \return The status code.
/// \sa UeiDaqGetRTDCoefficientC
UeiDaqAPI int UeiDaqSetRTDCoefficientC(ChannelHandle channelHandle, double C);

/// \brief Get the RTD channel temperature scale
///
/// Get the temperature scale used to convert the measured resistance to temperature.
///
/// \param channelHandle The handle to an existing RTD channel
/// \param pTempScale the actual temperature scale.
/// \return The status code.
/// \sa UeiDaqSetTCTemperatureScale
UeiDaqAPI int UeiDaqGetRTDTemperatureScale(ChannelHandle channelHandle, tUeiTemperatureScale *pTempScale);

/// \brief Set the RTD channel temperature scale type
///
/// Set the temperature scale used to convert the measured resistance to temperature.
///
/// \param channelHandle The handle to an existing RTD channel
/// \param tempScale the temperature scale.
/// \return The status code.
/// \sa UeiDaqGetTCTemperatureScale
UeiDaqAPI int UeiDaqSetRTDTemperatureScale(ChannelHandle channelHandle, tUeiTemperatureScale tempScale);

/// \brief Get the bridge type
///
/// Get the bridge type configured for the sensor connected to this channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pBridgeType The bridge type
/// \return The status code.
/// \sa UeiDaqSetAIVExBridgeType
UeiDaqAPI int UeiDaqGetAIVExBridgeType(ChannelHandle channelHandle, tUeiSensorBridgeType *pBridgeType);

/// \brief Set the bridge type
///
/// Set the bridge type for the sensor connected to this channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param type The bridge type
/// \return The status code.
/// \sa UeiDaqGetAIVExBridgeType
UeiDaqAPI int UeiDaqSetAIVExBridgeType(ChannelHandle channelHandle, tUeiSensorBridgeType type);

/// \brief Get the excitation voltage
///
/// Get the excitation voltage configured for the channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pVex The excitation voltage
/// \return The status code.
/// \sa UeiDaqSetAIVExExcitationVoltage
UeiDaqAPI int UeiDaqGetAIVExExcitationVoltage(ChannelHandle channelHandle, double* pVex);

/// \brief Set the excitation voltage
///
/// Set the excitation voltage for this channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param vex The excitation voltage
/// \return The status code.
/// \sa UeiDaqGetAIVExExcitationVoltage
UeiDaqAPI int UeiDaqSetAIVExExcitationVoltage(ChannelHandle channelHandle, double vex);

/// \brief Get the actual excitation voltage
///
/// Get the actual excitation voltage measured by the channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pVex The actual excitation voltage
/// \return The status code.
/// \sa UeiDaqGetAIVExExcitationVoltage UeiDaqSetAIVExExcitationVoltage
UeiDaqAPI int UeiDaqGetAIVExMeasuredExcitationVoltage(ChannelHandle channelHandle, double* pVex);

/// \brief Get the excitation frequency
///
/// Get the excitation frequency configured for the channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pFex The excitation frequency
/// \return The status code.
/// \sa UeiDaqSetAIVExExcitationFrequency
UeiDaqAPI int UeiDaqGetAIVExExcitationFrequency(ChannelHandle channelHandle, double* pFex);

/// \brief Set the excitation frequency
///
/// Set the excitation frequency for this channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param fex The excitation frequency
/// \return The status code.
/// \sa UeiDaqGetAIVExExcitationFrequency
UeiDaqAPI int UeiDaqSetAIVExExcitationFrequency(ChannelHandle channelHandle, double fex);

/// \brief Get the actual excitation frequency
///
/// Get the actual excitation frequency generated for the channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pFex The excitation frequency
/// \return The status code.
/// \sa UeiDaqSetAIVExExcitationFrequency,UeiDaqGetAIVExExcitationFrequency
UeiDaqAPI int UeiDaqGetAIVExActualExcitationFrequency(ChannelHandle channelHandle, double* pFex);

/// \brief Get the scaling mode
///
/// Determines if acquired data will be divided by the excitation
/// before being returned.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pScaleWithExcitation The actual scaling mode
/// \return The status code.
/// \sa UeiDaqSetAIVExScalingWithExcitation
UeiDaqAPI int UeiDaqGetAIVExScalingWithExcitation(ChannelHandle channelHandle, int* pScaleWithExcitation);

/// \brief Set the scaling mode
///
/// Specifies whether the acquired data will be divided by the excitation
/// voltage before it is returned.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param scaleWithExcitation The scaling mode
/// \return The status code.
/// \sa UeiDaqGetAIVExScalingWithExcitation
UeiDaqAPI int UeiDaqSetAIVExScalingWithExcitation(ChannelHandle channelHandle, int scaleWithExcitation);

/// \brief Get the shunt calibration resistor status
///
/// Determines whether the shunt calibration resistor is connected.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pIsShuntCalEnabled true the shunt resistor is enabled, false otherwise
/// \return The status code.
/// \sa UeiDaqEnableAIVExShuntCalibration
UeiDaqAPI int UeiDaqIsAIVExShuntCalibrationEnabled(ChannelHandle channelHandle, int *pIsShuntCalEnabled);

/// \brief Control the shunt calibration resistor
///
/// Connect or disconnect the shunt calibration resistor.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param engageShuntCal true to enable the shunt resistor, false to disable it
/// \return The status code.
/// \sa UeiDaqIsAIVExShuntCalibrationEnabled
UeiDaqAPI int UeiDaqEnableAIVExShuntCalibration(ChannelHandle channelHandle, int engageShuntCal);

/// \brief Get the shunt resistor location
///
/// Get the branch of the wheatstone bridge on which the shunt resistor
/// is connected.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pShuntedBranch The actual shunted branch.
/// \return The status code.
/// \sa UeiDaqSetAIVExShuntLocation
UeiDaqAPI int UeiDaqGetAIVExShuntLocation(ChannelHandle channelHandle, tUeiWheatstoneBridgeBranch* pShuntedBranch);

/// \brief Set the shunt resistor location
///
/// Specifies the wheatstone bridge branch to shunt.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param shuntedBranch The bridge branch to shunt.
/// \return The status code.
/// \sa UeiDaqGetAIVExShuntLocation
UeiDaqAPI int UeiDaqSetAIVExShuntLocation(ChannelHandle channelHandle, tUeiWheatstoneBridgeBranch shuntedBranch);

/// \brief Get the shunt resistance
///
/// Get the resistance programmed to the shunt resistor in Ohms.
/// NOTE: This is not the actual resistance used to perform the calibration.
/// The resistance of other components must be accounted for, use
/// GetActualShuntResistance() to get the shunt resistance to use to calculate
/// the gain adjustment factor.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pResistance The actual resistance programmed on the shunt resistor.
/// \return The status code.
/// \sa UeiDaqSetAIVExShuntResistance UeiDaqGetAIVExActualShuntResistance
UeiDaqAPI int UeiDaqGetAIVExShuntResistance(ChannelHandle channelHandle, double* pResistance);

/// \brief Set the shunt resistance
///
/// Specifies the resistance to program to the shunt resistor in Ohms.
/// NOTE: Don't use this value to calculate the gain adjustment factor,
/// Use the value returned by GetActualShuntResitance() which takes into
/// account the resistance of other non-programmable parts in the shunt
/// circuit.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param resistance The resistance to program on the shunt resistor.
/// \return The status code.
/// \sa UeiDaqGetAIVExShuntResistance UeiDaqGetAIVExActualShuntResistance
UeiDaqAPI int UeiDaqSetAIVExShuntResistance(ChannelHandle channelHandle, double resistance);

/// \brief Get the actual shunt resistance
///
/// Get the actual shunt resistance in Ohms.
/// This resistance includes the programmed shunt resistance plus the
/// resistance of other parts in the shunt circuitry.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pActualResistance The actual shunt circuitry resistance.
/// \return The status code.
/// \sa UeiDaqSetAIVExShuntResistance UeiDaqGetAIVExShuntResistance
UeiDaqAPI int UeiDaqGetAIVExActualShuntResistance(ChannelHandle channelHandle, double* pActualResistance);

/// \brief Get the gain adjustment factor
///
/// Get the gain adjustment factor.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pGaf The actual gain adjustment factor.
/// \return The status code.
/// \sa UeiDaqSetAIVExGainAdjustmentFactor
UeiDaqAPI int UeiDaqGetAIVExGainAdjustmentFactor(ChannelHandle channelHandle, double* pGaf);

/// \brief Set the gain adjustment factore
///
/// Setting the gain adjustment factor is part of the shunt calibration
/// procedure:
/// You must first program the shunt resistance, engage the
/// the shunt resistor and measure some values.
/// You can then calculate the gain adjustment factor with the formula:
/// gaf = Vex*(Rg/(4*Rs + 2*Rg))/Vin
/// Vex: excitation voltage
/// Vin: measured voltage
/// Rg: Resistance of the strain gages.
/// Rs: Resistance of the shunt.
///
/// Once the gain adjustment factor is set, the framework automatically
/// uses it to scale measurements to engennering unit.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param gaf The new gain adjustment factor.
/// \return The status code.
/// \sa UeiDaqGetAIVExGainAdjustmentFactor
UeiDaqAPI int UeiDaqSetAIVExGainAdjustmentFactor(ChannelHandle channelHandle, double gaf);

/// \brief Get the wiring scheme
///
/// Get the current wiring scheme used for this channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pWiring The current wiring scheme.
/// \return The status code.
/// \sa UeiDaqSetAIVExWiringScheme
UeiDaqAPI int UeiDaqGetAIVExWiringScheme(ChannelHandle channelHandle, tUeiWiringScheme* pWiring);

/// \brief Set the wiring schme
///
/// Specifies the wiring scheme used to connect the strain gage or load
/// cell to the channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param wiring The new wiring scheme.
/// \return The status code.
/// \sa UeiDaqGetAIVExWiringScheme
UeiDaqAPI int UeiDaqSetAIVExWiringScheme(ChannelHandle channelHandle, tUeiWiringScheme wiring);

/// \brief Get the offset nulling circuitry status
///
/// Determines whether the offset nulling circuitry is enabled.
/// With Offset nulling enabled, a nulling circuit adds an adjustable DC
/// voltage to the output of the amplifier making sure that the bridge
/// output is 0V when no strain is applied.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param nullingEnabled 1 if nulling is enabled, 0 otherwise.
/// \return The status code.
/// \sa UeiDaqEnableAIVExOffsetNulling
UeiDaqAPI int UeiDaqIsAIVExOffsetNullingEnabled(ChannelHandle channelHandle, int* nullingEnabled);

/// \brief Control the offset nulling circuitry
///
/// Enables or Disables offset nulling circuitry
/// With Offset nulling enabled, a nulling circuit adds an adjustable DC
/// voltage to the output of the amplifier making sure that the bridge
/// output is 0V when no strain is applied.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param enableNulling 1 to enable offset nulling, 0 to disable it
/// \return The status code.
/// \sa UeiDaqIsAIVExOffsetNullingEnabled
UeiDaqAPI int UeiDaqEnableAIVExOffsetNulling(ChannelHandle channelHandle, int enableNulling);

/// \brief Get the offset nulling setting
///
/// Get the offset nulling setting used to program the nulling circuitry.
/// Set it to 0.0 to automatically perform offset nulling next time the session is started.
/// Make sure no strain is applied on the bridge before nulling the offset.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param setting The current offset nulling setting.
/// \return The status code.
/// \sa UeiDaqSetAIVExOffsetNullingSetting
UeiDaqAPI int UeiDaqGetAIVExOffsetNullingSetting(ChannelHandle channelHandle, double* setting);

/// \brief Set the offset nulling setting
///
/// Set the offset nulling setting used to program the nulling circuitry.
/// Set it to 0.0 to automatically perform offset nulling next time the session is started.
/// Make sure no strain is applied on the bridge before nulling the offset.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param setting The setting value used to program the offset nulling circuitry.
/// \return The status code.
/// \sa UeiDaqGetAIVExOffsetNullingSetting
UeiDaqAPI int UeiDaqSetAIVExOffsetNullingSetting(ChannelHandle channelHandle, double setting);

/// \brief Get the bridge completion setting
///
/// Get the bridge completion setting used to program the bridge completion circuitry.
/// Set it to 0.0 to automatically perform bridge completion next time the session is started.
/// Make sure no strain is applied on the bridge.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param setting The current bridge completion setting.
/// \return The status code.
/// \sa UeiDaqSetAIVExBridgeCompletionSetting 
UeiDaqAPI int UeiDaqGetAIVExBridgeCompletionSetting(ChannelHandle channelHandle, double* setting);

/// \brief Set the offset nulling setting
///
/// Set the offset nulling setting used to program the nulling circuitry.
/// Set it to 0.0 to automatically perform offset nulling next time the session is started.
/// Make sure no strain is applied on the bridge before nulling the offset.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param setting The setting value used to program the bridge completion circuitry.
/// \return The status code.
/// \sa UeiDaqGetAIVExBridgeCompletionSetting  
UeiDaqAPI int UeiDaqSetAIVExBridgeCompletionSetting(ChannelHandle channelHandle, double setting);

/// \brief Get the coupling type
///
/// Get the channel coupling type, AC or DC
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param pCoupling The coupling type
/// \return The status code.
/// \sa UeiDaqSetAccelCouplingType
UeiDaqAPI int UeiDaqGetAccelCouplingType(ChannelHandle channelHandle, tUeiCoupling* pCoupling);

/// \brief Set the coupling type
///
/// Configure the channel in AC or DC coupling.
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param coupling The coupling type
/// \return The status code.
/// \sa UeiDaqGetAccelCouplingType
UeiDaqAPI int UeiDaqSetAccelCouplingType(ChannelHandle channelHandle, tUeiCoupling coupling);

/// \brief Get the low-pass filter state
///
/// Get the low-pass filter state
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param pEnabled The low-pass filter state
/// \return The status code.
/// \sa UeiDaqEnableAccelLowPassfilter
UeiDaqAPI int UeiDaqIsAccelLowPassFilterEnabled(ChannelHandle channelHandle, int* pEnabled);

/// \brief Enable or Disable the low-pass filter
///
/// Enable or disable the low-pass filter.
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param enabled The low-pass filter state
/// \return The status code.
/// \sa UeiDaqIsAccelLowPassFilterEnabled
UeiDaqAPI int UeiDaqEnableAccelLowPassfilter(ChannelHandle channelHandle, int enabled);

/// \brief Get the sensor sensitivity
///
/// Get the sensor sensitivity, it usually is in mVolts/g
/// Independently of the unit, the voltage read will be converted
/// to mV and divided by the sensitivity
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param pSensitivity The current sensitivity
/// \return The status code.
/// \sa UeiDaqSetAccelSensorSensitivity
UeiDaqAPI int UeiDaqGetAccelSensorSensitivity(ChannelHandle channelHandle, double* pSensitivity);

/// \brief Set the sensor sensitivity
///
/// Set the sensor sensitivity, it usually is in mVolts/g
/// Independently of the unit, the voltage read will be converted
/// to mV and divided by the sensitivity
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param sensitivity The new sensitivity
/// \return The status code.
/// \sa UeiDaqGetAccelSensorSensitivity
UeiDaqAPI int UeiDaqSetAccelSensorSensitivity(ChannelHandle channelHandle, double sensitivity);

/// \brief Get the excitation current
///
/// Get the excitation current in mAmps
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param pExcCurrent The excitation current
/// \return The status code.
/// \sa UeiDaqSetAccelExcitationCurrent
UeiDaqAPI int UeiDaqGetAccelExcitationCurrent(ChannelHandle channelHandle, double* pExcCurrent);

/// \brief Set the excitation current
///
/// Set the excitation current in mAmps
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param excCurrent The new excitation current
/// \return The status code.
/// \sa UeiDaqGetAccelExcitationCurrent
UeiDaqAPI int UeiDaqSetAccelExcitationCurrent(ChannelHandle channelHandle, double excCurrent);

/// \brief Get the excitation low comparator voltage
///
/// The excitation current can be measured back and trigger an alarm
/// when it is out of range (due to an open connection or a short).
/// It is measured as a voltage which depends on the sensor resistance and
/// the programmed excitation current.
/// The alarm state is made visible with the LED color on the terminal block
/// Green means that the measured excitation is within range, red means that
/// the connection with the sensor is open and blinking red means that the
/// connection with the sensor is shorted.
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param pLowComparator the low excitation comparator voltage
/// \return The status code.
/// \sa UeiDaqSetAccelLowExcitationComparator
UeiDaqAPI int UeiDaqGetAccelLowExcitationComparator(ChannelHandle channelHandle, double *pLowComparator);

/// \brief Set the excitation low comparator voltage
///
/// The excitation current can be measured back and trigger an alarm
/// when it is out of range (due to an open connection or a short).
/// It is measured as a voltage which depends on the sensor resistance and
/// the programmed excitation current.
/// The alarm state is made visible with the LED color on the terminal block
/// Green means that the measured excitation is within range, red means that
/// the connection with the sensor is open and blinking red means that the
/// connection with the sensor is shorted.
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param lowComparator the new low excitation comparator voltage
/// \return The status code.
/// \sa UeiDaqGetAccelLowExcitationComparator
UeiDaqAPI int UeiDaqSetAccelLowExcitationComparator(ChannelHandle channelHandle, double lowComparator);

/// \brief Get the excitation high comparator voltage
///
/// The excitation current can be measured back and trigger an alarm
/// when it is out of range (due to an open connection or a short).
/// It is measured as a voltage which depends on the sensor resistance and
/// the programmed excitation current.
/// The alarm state is made visible with the LED color on the terminal block
/// Green means that the measured excitation is within range, red means that
/// the connection with the sensor is open and blinking red means that the
/// connection with the sensor is shorted.
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param pHighComparator the high excitation comparator voltage
/// \return The status code.
/// \sa UeiDaqSetAccelHighExcitationComparator
UeiDaqAPI int UeiDaqGetAccelHighExcitationComparator(ChannelHandle channelHandle, double *pHighComparator);

/// \brief Set the excitation high comparator voltage
///
/// The excitation current can be measured back and trigger an alarm
/// when it is out of range (due to an open connection or a short).
/// It is measured as a voltage which depends on the sensor resistance and
/// the programmed excitation current.
/// The alarm state is made visible with the LED color on the terminal block
/// Green means that the measured excitation is within range, red means that
/// the connection with the sensor is open and blinking red means that the
/// connection with the sensor is shorted.
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param highComparator the new high excitation comparator voltage
/// \return The status code.
/// \sa UeiDaqGetAccelHighExcitationComparator
UeiDaqAPI int UeiDaqSetAccelHighExcitationComparator(ChannelHandle channelHandle, double highComparator);

/// \brief Get the low alarm status
///
/// Return the low alarm status which indicates whether the connection
/// to the sensor is shorted. It also is visible on the terminal block
/// as a red blinking LED.
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param pLowStatus the low alarm status
/// \sa UeiDaqSetAccelLowExcitationComparator
UeiDaqAPI int UeiDaqGetAccelLowAlarmStatus(ChannelHandle channelHandle, int *pLowStatus);

/// \brief Get the high alarm status
///
/// Return the high alarm status which indicates whether the connection
/// to the sensor is open. It also is visible on the terminal block
/// as a steady red LED.
///
/// \param channelHandle The handle to an existing accelerometer channel
/// \param pHighStatus the high alarm status
/// \sa UeiDaqSetAccelHighExcitationComparator
UeiDaqAPI int UeiDaqGetAccelHighAlarmStatus(ChannelHandle channelHandle, int *pHighStatus);

/// \brief Get the wiring scheme
///
/// Get the current wiring scheme used for this channel.
///
/// \param channelHandle The handle to an existing voltage with excitation channel
/// \param pWiring The current wiring scheme.
/// \return The status code.
/// \sa UeiDaqSetLVDTWiringScheme
UeiDaqAPI int UeiDaqGetLVDTWiringScheme(ChannelHandle channelHandle, tUeiLVDTWiringScheme* pWiring);

/// \brief Set the wiring scheme
///
/// Specifies the wiring scheme used to connect the resistive sensor to the channel.
///
/// \param channelHandle The handle to an existing LVDT channel
/// \param wiring The new wiring scheme.
/// \return The status code.
/// \sa UeiDaqGetLVDTWiringScheme
UeiDaqAPI int UeiDaqSetLVDTWiringScheme(ChannelHandle channelHandle, tUeiLVDTWiringScheme wiring);

/// \brief Get the external excitation state
///
/// Determines whether the excitation will be provided by the acquisition device
/// or by an external source
///
/// \param channelHandle The handle to an existing LVDT channel
/// \param pEnabled The current external excitation state
/// \return The status code.
/// \sa UeiDaqEnableLVDTExternalExcitation
UeiDaqAPI int UeiDaqIsLVDTExternalExcitationEnabled(ChannelHandle channelHandle, int* pEnabled);

/// \brief Enable or Disable external excitation
///
/// Enable or disable the external excitation.
///
/// \param channelHandle The handle to an existing LVDT channel
/// \param enabled The new external excitation state
/// \return The status code.
/// \sa UeiDaqIsLVDTExternalExcitationEnabled
UeiDaqAPI int UeiDaqEnableLVDTExternalExcitation(ChannelHandle channelHandle, int enabled);

/// \brief Get the excitation RMS voltage
///
/// Get the excitation RMS voltage configured for the channel.
///
/// \param channelHandle The handle to an existing LVDT channel
/// \param pVex The excitation voltage
/// \return The status code.
/// \sa UeiDaqSetLVDTExcitationVoltage
UeiDaqAPI int UeiDaqGetLVDTExcitationVoltage(ChannelHandle channelHandle, double* pVex);

/// \brief Set the excitation RMS voltage
///
/// Set the excitation RMS voltage for this channel.
///
/// \param channelHandle The handle to an existing LVDT channel
/// \param vex The excitation voltage
/// \return The status code.
/// \sa UeiDaqGetLVDTExcitationVoltage
UeiDaqAPI int UeiDaqSetLVDTExcitationVoltage(ChannelHandle channelHandle, double vex);

/// \brief Get the excitation frequency
///
/// Get the excitation frequency configured for the channel.
///
/// \param channelHandle The handle to an existing LVDT channel
/// \param pFex The excitation frequency
/// \return The status code.
/// \sa UeiDaqSetLVDTExcitationFrequency
UeiDaqAPI int UeiDaqGetLVDTExcitationFrequency(ChannelHandle channelHandle, double* pFex);

/// \brief Set the excitation frequency
///
/// Set the excitation frequency for this channel.
///
/// \param channelHandle The handle to an existing LVDT channel
/// \param fex The excitation frequency
/// \return The status code.
/// \sa UeiDaqGetLVDTExcitationFrequency
UeiDaqAPI int UeiDaqSetLVDTExcitationFrequency(ChannelHandle channelHandle, double fex);

/// \brief Get the sensor sensitivity
///
/// Get the sensor sensitivity, it usually is in mVolts/V/mm
/// Independently of the unit, the voltage read will be converted
/// to mV and divided by the excitation voltage and the sensitivity
///
/// \param channelHandle The handle to an existing LVDT channel
/// \param pSensitivity The current sensitivity
/// \return The status code.
/// \sa UeiDaqSetLVDTSensorSensitivity
UeiDaqAPI int UeiDaqGetLVDTSensorSensitivity(ChannelHandle channelHandle, double* pSensitivity);

/// \brief Set the sensor sensitivity
///
/// Set the sensor sensitivity, it usually is in mVolts/g
/// Independently of the unit, the voltage read will be converted
/// to mV and divided by the excitation voltage and the sensitivity
///
/// \param channelHandle The handle to an existing LVDT channel
/// \param sensitivity The new sensitivity
/// \return The status code.
/// \sa UeiDaqGetLVDTSensorSensitivity
UeiDaqAPI int UeiDaqSetLVDTSensorSensitivity(ChannelHandle channelHandle, double sensitivity);

/// \brief Get the wiring scheme
///
/// Get the current wiring scheme used for this channel.
///
/// \param channelHandle The handle to an existing simulated LVDT channel
/// \param pWiring The current wiring scheme.
/// \return The status code.
/// \sa UeiDaqSetSimulatedLVDTWiringScheme
UeiDaqAPI int UeiDaqGetSimulatedLVDTWiringScheme(ChannelHandle channelHandle, tUeiLVDTWiringScheme* pWiring);

/// \brief Set the wiring scheme
///
/// Specifies the wiring scheme used to connect the resistive sensor to the channel.
///
/// \param channelHandle The handle to an existing simulated LVDT channel
/// \param wiring The new wiring scheme.
/// \return The status code.
/// \sa UeiDaqGetSimulatedLVDTWiringScheme
UeiDaqAPI int UeiDaqSetSimulatedLVDTWiringScheme(ChannelHandle channelHandle, tUeiLVDTWiringScheme wiring);

/// \brief Get the excitation RMS voltage
///
/// Get the excitation RMS voltage configured for the channel.
///
/// \param channelHandle The handle to an existing simulated LVDT channel
/// \param pVex The excitation voltage
/// \return The status code.
/// \sa UeiDaqSetSimulatedLVDTExcitationVoltage
UeiDaqAPI int UeiDaqGetSimulatedLVDTExcitationVoltage(ChannelHandle channelHandle, double* pVex);

/// \brief Set the excitation RMS voltage
///
/// Set the excitation RMS voltage for this channel.
///
/// \param channelHandle The handle to an existing simulated LVDT channel
/// \param vex The excitation voltage
/// \return The status code.
/// \sa UeiDaqGetSimulatedLVDTExcitationVoltage
UeiDaqAPI int UeiDaqSetSimulatedLVDTExcitationVoltage(ChannelHandle channelHandle, double vex);

/// \brief Get the excitation frequency
///
/// Get the excitation frequency configured for the channel.
///
/// \param channelHandle The handle to an existing simulated LVDT channel
/// \param pFex The excitation frequency
/// \return The status code.
/// \sa UeiDaqSetSimulatedLVDTExcitationFrequency
UeiDaqAPI int UeiDaqGetSimulatedLVDTExcitationFrequency(ChannelHandle channelHandle, double* pFex);

/// \brief Set the excitation frequency
///
/// Set the excitation frequency for this channel.
///
/// \param channelHandle The handle to an existing simulated LVDT channel
/// \param fex The excitation frequency
/// \return The status code.
/// \sa UeiDaqGetSimulatedLVDTExcitationFrequency
UeiDaqAPI int UeiDaqSetSimulatedLVDTExcitationFrequency(ChannelHandle channelHandle, double fex);

/// \brief Get the sensor sensitivity
///
/// Get the sensor sensitivity, it usually is in mVolts/V/mm
/// Independently of the unit, the voltage read will be converted
/// to mV and divided by the excitation voltage and the sensitivity
///
/// \param channelHandle The handle to an existing simulated LVDT channel
/// \param pSensitivity The current sensitivity
/// \return The status code.
/// \sa UeiDaqSetSimulatedLVDTSensorSensitivity
UeiDaqAPI int UeiDaqGetSimulatedLVDTSensorSensitivity(ChannelHandle channelHandle, double* pSensitivity);

/// \brief Set the sensor sensitivity
///
/// Set the sensor sensitivity, it usually is in mVolts/g
/// Independently of the unit, the voltage read will be converted
/// to mV and divided by the excitation voltage and the sensitivity
///
/// \param channelHandle The handle to an existing simulated LVDT channel
/// \param sensitivity The new sensitivity
/// \return The status code.
/// \sa UeiDaqGetSimulatedLVDTSensorSensitivity
UeiDaqAPI int UeiDaqSetSimulatedLVDTSensorSensitivity(ChannelHandle channelHandle, double sensitivity);

/// \brief Get the type of input sensor
///
/// Specifies whether the input sensor is a synchro or a resolver.
///
/// \param channelHandle The handle to an existing synchro/resolver channel
/// \param pMode The current input sensor type.
/// \return The status code.
/// \sa UeiDaqSetSynchroResolverMode
UeiDaqAPI int UeiDaqGetSynchroResolverMode(ChannelHandle channelHandle, tUeiSynchroResolverMode* pMode);

/// \brief Set the type of input sensor
///
/// Specifies whether the input sensor is a synchro or a resolver.
///
/// \param channelHandle The handle to an existing synchro/resolver channel
/// \param mode The new input sensor type.
/// \return The status code.
/// \sa UeiDaqGetSynchroResolverMode
UeiDaqAPI int UeiDaqSetSynchroResolverMode(ChannelHandle channelHandle, tUeiSynchroResolverMode mode);

/// \brief Get the external excitation state
///
/// Determines whether the excitation will be provided by the acquisition device
/// or by an external source
///
/// \param channelHandle The handle to an existing synchro/resolver channel
/// \param pEnabled the external excitation state.
/// \return The status code.
/// \sa UeiDaqEnableSynchroResolverExternalExcitation
UeiDaqAPI int UeiDaqIsSynchroResolverExternalExcitationEnabled(ChannelHandle channelHandle, int *pEnabled);

/// \brief Enable or Disable external excitation
///
/// Enable or disable the external excitation.
///
/// \param channelHandle The handle to an existing synchro/resolver channel
/// \param enabled The new external excitation state
/// \return The status code.
/// \sa UeiDaqIsSynchroResolverExternalExcitationEnabled
UeiDaqAPI int UeiDaqEnableSynchroResolverExternalExcitation(ChannelHandle channelHandle, int enabled);

/// \brief Get the excitation RMS voltage
///
/// Get the excitation RMS voltage configured for the channel.
///
/// \param channelHandle The handle to an existing synchro/resolver channel
/// \param pVex The excitation voltage.
/// \return The status code.
/// \sa UeiDaqSetSynchroResolverExcitationVoltage
UeiDaqAPI int UeiDaqGetSynchroResolverExcitationVoltage(ChannelHandle channelHandle, double* pVex);

/// \brief Set the excitation RMS voltage
///
/// Set the excitation RMS voltage for this channel.
///
/// \param channelHandle The handle to an existing synchro/resolver channel
/// \param vex The excitation voltage
/// \return The status code.
/// \sa UeiDaqGetSynchroResolverExcitationVoltage
UeiDaqAPI int UeiDaqSetSynchroResolverExcitationVoltage(ChannelHandle channelHandle, double vex);

/// \brief Get the excitation frequency
///
/// Get the excitation frequency configured for the channel.
///
/// \param channelHandle The handle to an existing synchro/resolver channel
/// \param pFex The excitation frequency.
/// \return The status code.
/// \sa UeiDaqSetSynchroResolverExcitationFrequency
UeiDaqAPI int UeiDaqGetSynchroResolverExcitationFrequency(ChannelHandle channelHandle, double* pFex);

/// \brief Set the excitation frequency
///
/// Set the excitation frequency for this channel.
///
/// \param channelHandle The handle to an existing synchro/resolver channel
/// \param fex The excitation frequency
/// \return The status code.
/// \sa UeiDaqGetSynchroResolverExcitationFrequency
UeiDaqAPI int UeiDaqSetSynchroResolverExcitationFrequency(ChannelHandle channelHandle, double fex);

/// \brief Get the type of sensor simulated
///
/// Specifies whether the sensor simulated is a synchro or a resolver.
///
/// \param channelHandle The handle to an existing simulated synchro/resolver channel
/// \param pMode The current simulated sensor type.
/// \return The status code.
/// \sa UeiDaqSetSimulatedSynchroResolverMode
UeiDaqAPI int UeiDaqGetSimulatedSynchroResolverMode(ChannelHandle channelHandle, tUeiSynchroResolverMode* pMode);

/// \brief Set the type of sensor simulated
///
/// Specifies whether the sensor simulated is a synchro or a resolver.
///
/// \param channelHandle The handle to an existing simulated synchro/resolver channel
/// \param mode The new simulated sensor type.
/// \return The status code.
/// \sa UeiDaqGetSimulatedSynchroResolverMode
UeiDaqAPI int UeiDaqSetSimulatedSynchroResolverMode(ChannelHandle channelHandle, tUeiSynchroResolverMode mode);

/// \brief Get the external excitation state
///
/// Determines whether the excitation will be provided by the acquisition device
/// or by an external source
///
/// \param channelHandle The handle to an existing simulated synchro/resolver channel
/// \param pEnabled the external excitation state.
/// \return The status code.
/// \sa UeiDaqEnableSimulatedSynchroResolverExternalExcitation
UeiDaqAPI int UeiDaqIsSimulatedSynchroResolverExternalExcitationEnabled(ChannelHandle channelHandle, int *pEnabled);

/// \brief Enable or Disable external excitation
///
/// Enable or disable the external excitation.
///
/// \param channelHandle The handle to an existing simulated synchro/resolver channel
/// \param enabled The new external excitation state
/// \return The status code.
/// \sa UeiDaqIsSimulatedSynchroResolverExternalExcitationEnabled
UeiDaqAPI int UeiDaqEnableSimulatedSynchroResolverExternalExcitation(ChannelHandle channelHandle, int enabled);

/// \brief Get the excitation RMS voltage
///
/// Get the excitation RMS voltage configured for the channel.
///
/// \param channelHandle The handle to an existing simulated synchro/resolver channel
/// \param pVex The excitation voltage.
/// \return The status code.
/// \sa UeiDaqSetSimulatedSynchroResolverExcitationVoltage
UeiDaqAPI int UeiDaqGetSimulatedSynchroResolverExcitationVoltage(ChannelHandle channelHandle, double* pVex);

/// \brief Set the excitation RMS voltage
///
/// Set the excitation RMS voltage for this channel.
///
/// \param channelHandle The handle to an existing simulated synchro/resolver channel
/// \param vex The excitation voltage
/// \return The status code.
/// \sa UeiDaqGetSimulatedSynchroResolverExcitationVoltage
UeiDaqAPI int UeiDaqSetSimulatedSynchroResolverExcitationVoltage(ChannelHandle channelHandle, double vex);

/// \brief Get the excitation frequency
///
/// Get the excitation frequency configured for the channel.
///
/// \param channelHandle The handle to an existing simulated synchro/resolver channel
/// \param pFex The excitation frequency.
/// \return The status code.
/// \sa UeiDaqSetSimulatedSynchroResolverExcitationFrequency
UeiDaqAPI int UeiDaqGetSimulatedSynchroResolverExcitationFrequency(ChannelHandle channelHandle, double* pFex);

/// \brief Set the excitation frequency
///
/// Set the excitation frequency for this channel.
///
/// \param channelHandle The handle to an existing simulated synchro/resolver channel
/// \param fex The excitation frequency
/// \return The status code.
/// \sa UeiDaqGetSimulatedSynchroResolverExcitationFrequency
UeiDaqAPI int UeiDaqSetSimulatedSynchroResolverExcitationFrequency(ChannelHandle channelHandle, double fex);

/// \brief Get the undercurrent limit
///
/// Get the minimum amount of current allowed in Amps.
/// If less than the minimum current flows through the digital output line,
/// the circuit will open.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param pUnderCurrent The under current limit.
/// \return The status code.
/// \sa UeiDaqSetDOProtectedUnderCurrentLimit UeiDaqGetDOProtectedOverCurrentLimit UeiDaqSetDOProtectedOverCurrentLimit
UeiDaqAPI int UeiDaqGetDOProtectedUnderCurrentLimit(ChannelHandle channelHandle, int line, double* pUnderCurrent);

/// \brief Set the undercurrent limit
///
/// Set the minimum amount of current allowed in Amps.
/// If less than the minimum current flows through the digital output line,
/// the circuit will open.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param underCurrent The under current limit.
/// \return The status code.
/// \sa UeiDaqGetDOProtectedUnderCurrentLimit UeiDaqGetDOProtectedOverCurrentLimit UeiDaqSetDOProtectedOverCurrentLimit
UeiDaqAPI int UeiDaqSetDOProtectedUnderCurrentLimit(ChannelHandle channelHandle, int line, double underCurrent);

/// \brief Get the overcurrent limit
///
/// Get the maximum amount of current allowed in Amps.
/// If more than the maximum current flows through the digital output line,
/// the circuit will open.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param pOverCurrent The over current limit.
/// \return The status code.
/// \sa UeiDaqSetDOProtectedUnderCurrentLimit UeiDaqGetDOProtectedUnderCurrentLimit UeiDaqSetDOProtectedOverCurrentLimit
UeiDaqAPI int UeiDaqGetDOProtectedOverCurrentLimit(ChannelHandle channelHandle, int line, double* pOverCurrent);

/// \brief Set the overcurrent limit
///
/// Set the maximum amount of current allowed in Amps.
/// If more than the maximum current flows through the digital output line,
/// the circuit will open.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param overCurrent The over current limit.
/// \return The status code.
/// \sa UeiDaqGetDOProtectedUnderCurrentLimit UeiDaqGetDOProtectedOverCurrentLimit UeiDaqSetDOProtectedUnderCurrentLimit
UeiDaqAPI int UeiDaqSetDOProtectedOverCurrentLimit(ChannelHandle channelHandle, int line, double overCurrent);

/// \brief Get the current measurement rate
///
/// Get the rate at which the current is measured.
/// This rate determines how fast the device react when an under or over current
/// condition occurs.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param pMeasurementRate The current measurement rate.
/// \return The status code.
/// \sa UeiDaqGetDOProtectedCurrentMeasurementRate
UeiDaqAPI int UeiDaqGetDOProtectedCurrentMeasurementRate(ChannelHandle channelHandle, double* pMeasurementRate);

/// \brief Set the current measurement rate
///
/// Set the rate at which the current is measured.
/// This rate determines how fast the device react when an under or over current
/// condition occurs.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param measurementRate The current measurement rate.
/// \return The status code.
/// \sa UeiDaqGetDOProtectedCurrentMeasurementRate
UeiDaqAPI int UeiDaqSetDOProtectedCurrentMeasurementRate(ChannelHandle channelHandle, double measurementRate);

/// \brief Determines whether the CB is currently protecting the output line
/// 
/// Return true is circuit breaker for this output line is enabled and
/// false otherwise
///
/// \param channelHandle The handle to an existing channel
/// \param line The output line to configure within the port
/// \param pEnabled The current circuit breaker state
/// \return The status code
UeiDaqAPI int UeiDaqIsDOProtectedCircuitBreakerEnabled(ChannelHandle channelHandle, int line, int* pEnabled);

/// \brief Enable or Disable channel protection 
/// 
/// Enable or disable circuit breaker on this output line. when enabled a circuit
/// breaker monitors the current flowing through the line and opens the circuit
/// if the current goes out of pre-set limits.
///
/// \param channelHandle The handle to an existing channel
/// \param line The output line to configure within the port
/// \param enable 1 to turn-on protection, 0 to turn it off
/// \return The status code
UeiDaqAPI int UeiDaqEnableDOProtectedCircuitBreaker(ChannelHandle channelHandle, int line, int enable);

/// \brief Get the auto retry setting.
///
/// The auto retry setting specifies wheter the device should attempt
/// to close the circuit after it was opened because of an over or
/// under current condition.
/// If it is set to true the device will try to close the circuit at a rate
/// set by the autoRetryRate setting.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param pAutoRetry true if autoRetry is on, false otherwise.
/// \return The status code.
/// \sa UeiDaqSetDOProtectedAutoRetry
UeiDaqAPI int UeiDaqGetDOProtectedAutoRetry(ChannelHandle channelHandle, int* pAutoRetry);

/// \brief Set the auto retry setting.
///
/// The auto retry setting specifies wheter the device should attempt
/// to close the circuit after it was opened because of an over or
/// under current condition.
/// If it is set to true the device will try to close the circuit at a rate
/// set by the autoRetryRate setting.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param autoRetry true to turn auto-retry on, false to turn it off.
/// \return The status code.
/// \sa UeiDaqGetDOProtectedAutoRetry
UeiDaqAPI int UeiDaqSetDOProtectedAutoRetry(ChannelHandle channelHandle, int autoRetry);

/// \brief Get the auto retry rate.
///
/// Specifies how often the device will attemp to close a circuit that
/// was opened because of an over or under current condition.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param pAutoRetryRate The number of retries per second.
/// \return The status code.
/// \sa UeiDaqSetDOProtectedAutoRetryRate
UeiDaqAPI int UeiDaqGetDOProtectedAutoRetryRate(ChannelHandle channelHandle, double* pAutoRetryRate);

/// \brief Set the auto retry rate.
///
/// Specifies how often the device will attemp to close a circuit that
/// was opened because of an over or under current condition.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param autoRetryRate The number of retries per second.
/// \return The status code.
/// \sa UeiDaqGetDOProtectedAutoRetryRate
UeiDaqAPI int UeiDaqSetDOProtectedAutoRetryRate(ChannelHandle channelHandle, double autoRetryRate);

/// \brief Get the over/under count. 
///
/// Specifies number of consecutive over/under limit diagnostic readings that must 
/// occur in order to trip breaker. 
///
/// \param channelHandle The handle to an existing channel
/// \param pOverUnderCount The maximum number of over/under readings.
/// \return The status code
UeiDaqAPI int UeiDaqGetDOProtectedOverUnderCount(ChannelHandle channelHandle, uInt32* pOverUnderCount);

/// \brief Set the over/under count. 
///
/// Specifies number of consecutive over/under limit diagnostic readings that must 
/// occur in order to trip breaker. 
///
/// \param channelHandle The handle to an existing channel
/// \param overUnderCount The new maximum number of over/under readings.
/// \return The status code
UeiDaqAPI int UeiDaqSetDOProtectedOverUnderCount(ChannelHandle channelHandle, uInt32 overUnderCount);

/// \brief Get the PWM mode.
///
/// Specifies the PWM mode for DO channels that support the capability
/// With PWM mode you can replace the rising and falling edges with a pulse
/// train to allow for soft start and/or stop
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param pMode The current PWM mode.
/// \return The status code.
/// \sa UeiDaqSetDOProtectedPWMMode
UeiDaqAPI int UeiDaqGetDOProtectedPWMMode(ChannelHandle channelHandle, int line, tUeiDOPWMMode* pMode);

/// \brief Set the PWM mode.
///
/// Specifies the PWM mode for DO channels that support the capability
/// With PWM mode you can replace the rising and falling edges with a pulse
/// train to allow for soft start and/or stop
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param mode The new PWM mode.
/// \return The status code.
/// \sa UeiDaqGetDOProtectedPWMMode
UeiDaqAPI int UeiDaqSetDOProtectedPWMMode(ChannelHandle channelHandle, int line, tUeiDOPWMMode mode);

/// \brief Get the pulse train length.
///
/// Specifies soft start/stop pulse train length in micro-seconds
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param pLengthus The current pulse train length.
/// \return The status code.
/// \sa UeiDaqSetDOProtectedPWMLength
UeiDaqAPI int UeiDaqGetDOProtectedPWMLength(ChannelHandle channelHandle, int line, uInt32* pLengthus);

/// \brief Set pulse train length.
///
/// Specifies soft start/stop pulse train length in micro-seconds
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param lengthus The new pulse train length.
/// \return The status code.
/// \sa UeiDaqGetDOProtectedPWMLength
UeiDaqAPI int UeiDaqSetDOProtectedPWMLength(ChannelHandle channelHandle, int line, uInt32 lengthus);

/// \brief Get the pulse train period.
///
/// Specifies soft start/stop or continuous pulse train period in micro-seconds
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param pPeriodus The current pulse train period.
/// \return The status code.
/// \sa UeiDaqSetDOProtectedPWMPeriod
UeiDaqAPI int UeiDaqGetDOProtectedPWMPeriod(ChannelHandle channelHandle, int line, uInt32* pPeriodus);

/// \brief Set pulse train period.
///
/// Specifies soft start/stop or continuous pulse train period in micro-seconds
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param periodus The new pulse train period.
/// \return The status code.
/// \sa UeiDaqGetDOProtectedPWMPeriod
UeiDaqAPI int UeiDaqSetDOProtectedPWMPeriod(ChannelHandle channelHandle, int line, uInt32 periodus);

/// \brief Get the pulse train duty cycle.
///
/// Specifies the continuous pulse train duty cycle
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param pDutyCycle The current pulse train period.
/// \return The status code.
/// \sa UeiDaqSetDOProtectedPWMDutyCycle
UeiDaqAPI int UeiDaqGetDOProtectedPWMDutyCycle(ChannelHandle channelHandle, int line, double* pDutyCycle);

/// \brief Set pulse train duty cycle.
///
/// Specifies the continuous pulse train duty cycle
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The output line to configure within the port
/// \param dutyCycle The new pulse train duty cycle.
/// \return The status code.
/// \sa UeiDaqGetDOProtectedPWMDutyCycle
UeiDaqAPI int UeiDaqSetDOProtectedPWMDutyCycle(ChannelHandle channelHandle, int line, double dutyCycle);

/// \brief Get the digital input filter minimum pulse width
///
/// The digital input filter is used to block digital noise from switching the
/// input line state.
/// It filters glitches or spikes based on their width.
///
/// \param channelHandle The handle to an existing DO protected channel
/// \param line The input line to query or configure within the port
/// \param pMinWidth the current minimum pulse width in ms
/// \return The status code.
/// \sa UeiDaqSetDIIndustrialMinimumPulseWidth
UeiDaqAPI int UeiDaqGetDIIndustrialMinimumPulseWidth(ChannelHandle channelHandle, int line, double* pMinWidth);

/// \brief Set the digital input filter minimum pulse width
///
/// The digital input filter is used to block digital noise from switching the
/// input line state.
/// It filters glitches or spikes based on their width.
///
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to query or configure within the port
/// \param minWidth the minimum pulse width in ms. Use 0.0 to disable digital input filter.
/// \return The status code.
/// \sa UeiDaqGetDIIndustrialMinimumPulseWidth
UeiDaqAPI int UeiDaqSetDIIndustrialMinimumPulseWidth(ChannelHandle channelHandle, int line, double minWidth);

/// \brief Get the low input threshold
///
/// The low input threshold is used in combination with the high input threshold
/// to define an hysteresis window. The input line state will change only when
/// the input signal crosses both threshold.
///
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to query or configure within the port
/// \param pLowThreshold the current low threshold
/// \return The status code.
/// \sa UeiDaqSetDIIndustrialLowThreshold
UeiDaqAPI int UeiDaqGetDIIndustrialLowThreshold(ChannelHandle channelHandle, int line, double *pLowThreshold);

/// \brief Set the low input threshold
///
/// The low input threshold is used in combination with the high input threshold
/// to define an hysteresis window. The input line state will change only when
/// the input signal crosses both threshold
///
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to query or configure within the port
/// \param lowThreshold the low hysteresis threshold
/// \return The status code.
/// \sa UeiDaqGetDIIndustrialLowThreshold
UeiDaqAPI int UeiDaqSetDIIndustrialLowThreshold(ChannelHandle channelHandle, int line, double lowThreshold);

/// \brief Get the high input threshold
///
/// The high input threshold is used in combination with the low input threshold
/// to define an hysteresis window. The input line state will change only when
/// the input signal crosses both threshold.
///
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to query or configure within the port
/// \param pHighThreshold the current high threshold
/// \return The status code.
/// \sa UeiDaqSetDIIndustrialHighThreshold
UeiDaqAPI int UeiDaqGetDIIndustrialHighThreshold(ChannelHandle channelHandle, int line, double *pHighThreshold);

/// \brief Set the high input threshold
///
/// The high input threshold is used in combination with the low input threshold
/// to define an hysteresis window. The input line state will change only when
/// the input signal crosses both threshold
///
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to query or configure within the port
/// \param highThreshold the high hysteresis threshold
/// \return The status code.
/// \sa UeiDaqGetDIIndustrialHighThreshold
UeiDaqAPI int UeiDaqSetDIIndustrialHighThreshold(ChannelHandle channelHandle, int line, double highThreshold);

/// \brief Get AC mode
///
/// Verify whether AC mode is enabled or disabled
/// In AC mode, the RMS voltage measured at each input is compared with lowa nd high thresholds
/// to determine the state of the input
///  
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to query 
/// \param pAcMode the AC mode status
/// \return The status code.
UeiDaqAPI int UeiDaqIsDIIndustrialACModeEnabled(ChannelHandle channelHandle, int line, int* pAcMode);

/// \brief Enable or disable AC mode 
/// 
/// Enable or disable AC mode
/// In AC mode, the RMS voltage measured at each input is compared with lowa nd high thresholds
/// to determine the state of the input
///  
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to configure
/// \param acMode true to enable AC mode, false otherwise 
/// \return The status code.
UeiDaqAPI int UeiDaqEnableDIIndustrialACMode(ChannelHandle channelHandle, int line, int acMode);

/// \brief Get the digital input mux configuration 
/// 
/// Select how voltage supply is connected to each input line.
/// Disconnected: Set the mux to tri-state mode to disconnect voltage supply
///               from input line
/// Diag mode: Set mux to Diagnostic mode to connect internal voltage source
///            to each input line in order to test that it is functional
/// Pull-up mode: Setting mux to pull-up mode connects a pull-up resistor between 
///               the internal voltage source and the input line to monitor switches  
///               or contacts without external circuitry.
/// 
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to query
/// \param pMux the current mux state
/// \return The status code.
UeiDaqAPI int UeiDaqGetDIIndustrialMux(ChannelHandle channelHandle, int line, tUeiDigitalInputMux* pMux);

/// \brief Set the digital input mux configuration
/// 
/// Select how voltage supply is connected to each input line.
/// Disconnected: Set the mux to tri-state mode to disconnect voltage supply
///               from input line
/// Diag mode: Set mux to Diagnostic mode to connect internal voltage source
///            to each input line in order to test that it is functional
/// Pull-up mode: Setting mux to pull-up mode connects a pull-up resistor between 
///               the internal voltage source and the input line to monitor switches  
///               or contacts without external circuitry.
/// 
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to configure
/// \param mux the new mux state
/// \return The status code.
UeiDaqAPI int UeiDaqSetDIIndustrialMux(ChannelHandle channelHandle, int line, tUeiDigitalInputMux mux);

/// \brief Get the test/pull-up voltage 
/// 
/// Get the voltage supplied to selected line.
/// Test mode: Guardian feature that connects an internal voltage source
///            to each input line in order to test that it is functional
/// Pull-up mode: connect a pull-up resistor between the internal voltage
///               source and the input line to monitor switch or contacts 
///               without external circuitry.
/// 
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to query
/// \param pVoltage the test voltage
/// \return The status code.
UeiDaqAPI double UeiDaqGetDIIndustrialVoltageSupply(ChannelHandle channelHandle, int line, double* pVoltage);

/// \brief Set the test/pull-up voltage 
/// 
/// Program the voltage supplied to selected line.
/// Test mode: Guardian feature that connects an internal voltage source
///            to each input line in order to test that it is functional
/// Pull-up mode: connect a pull-up resistor between the internal voltage
///               source and the input line to monitor switch or contacts 
///               without external circuitry.
/// 
/// 
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to configure
/// \param voltage the test voltage
/// \return The status code.
UeiDaqAPI int SetDIIndustrialVoltageSupply(ChannelHandle channelHandle, int line, double voltage);

/// \brief Get the input gain 
/// 
/// Some DI devices use an ADC to measure the input line state. This
/// setting provides a way to select the input gain for the ADC.
/// The input gain value is an index in the gain list starting with 0
/// 
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to query
/// \param pInputGain the line's input gain
/// \return The status code.
UeiDaqAPI int UeiDaqGetDIIndustrialInputGain(ChannelHandle channelHandle, int line, int* pInputGain);

/// \brief Set the input gain 
/// 
/// Some DI devices use an ADC to measure the input line state. This
/// setting provides a way to select the input gain for the ADC.
/// The input gain value is an index in the gain list starting with 0.
/// 
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to configure
/// \param inputGain the new input gain
/// \return The status code.
UeiDaqAPI int UeiDaqSetDIIndustrialInputGain(ChannelHandle channelHandle, int line, int inputGain);

/// \brief Get the mux delay 
/// 
/// Some DI devices use an ADC to measure the input line state. This
/// setting provides a way to set the delay for the multiplexer 
/// in front of the ADC
/// 
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to query
/// \param pMuxDelayUs the mux delay in us
/// \return The status code.
UeiDaqAPI int UeiDaqGetDIIndustrialMuxDelay(ChannelHandle channelHandle, int line, int* pMuxDelayUs);

/// \brief Set the mux delay 
/// 
/// Some DI devices use an ADC to measure the input line state. This
/// setting provides a way to set the delay for the multiplexer 
/// in front of the ADC
/// 
/// \param channelHandle The handle to an existing industrial DI channel
/// \param line The input line to configure
/// \param muxDelayUs the mux delay in us
/// \return The status code.
UeiDaqAPI int UeiDaqSetDIIndustrialMuxDelay(ChannelHandle channelHandle, int line, int muxDelayUs);

/// \brief Get the serial port mode
///
/// Get the mode used by the serial port. Possible modes are RS-232,
/// RS-485 half duplex and RS-485 full duplex
///
/// \param channelHandle The handle to an existing serial port
/// \param pMode the serial port mode.
/// \return The status code.
/// \sa UeiDaqSetSerialPortMode
UeiDaqAPI int UeiDaqGetSerialPortMode(ChannelHandle channelHandle, tUeiSerialPortMode* pMode);

/// \brief Set the serial port mode
///
/// Set the mode used by the serial port. Possible modes are RS-232,
/// RS-485 half duplex and RS-485 full duplex
///
/// \param channelHandle The handle to an existing serial port
/// \param mode The new serial port mode
/// \return The status code.
/// \sa UeiDaqGetSerialPortMode
UeiDaqAPI int UeiDaqSetSerialPortMode(ChannelHandle channelHandle, tUeiSerialPortMode mode);

/// \brief Get the serial port speed
///
/// Get the number of data bits transmitted per second.
///
/// \param channelHandle The handle to an existing serial port
/// \param pBitsPerSecond the serial port speed .
/// \return The status code.
/// \sa UeiDaqSetSerialPortSpeed
UeiDaqAPI int UeiDaqGetSerialPortSpeed(ChannelHandle channelHandle, tUeiSerialPortSpeed* pBitsPerSecond);

/// \brief Set the serial port speed
///
/// Set the number of data bits transmitted per second.
///
/// \param channelHandle The handle to an existing serial port
/// \param bitsPerSecond The serial port speed
/// \return The status code.
/// \sa UeiDaqGetSerialPortSpeed
UeiDaqAPI int UeiDaqSetSerialPortSpeed(ChannelHandle channelHandle, tUeiSerialPortSpeed bitsPerSecond);

/// \brief Get the serial port custom speed
///
/// Get the number of data bits transmitted per second.
/// Call this function when using a non-standard port speed
///
/// \param channelHandle The handle to an existing serial port
/// \param pBitsPerSecond the serial port speed .
/// \return The status code.
/// \sa UeiDaqSetSerialPortCustomSpeed
UeiDaqAPI int UeiDaqGetSerialPortCustomSpeed(ChannelHandle channelHandle, uInt32* pBitsPerSecond);

/// \brief Set the serial port speed
///
/// Set the number of data bits transmitted per second.
/// Call this function when using a non-standard port speed
///
/// \param channelHandle The handle to an existing serial port
/// \param bitsPerSecond The serial port speed
/// \return The status code.
/// \sa UeiDaqGetSerialPortCustomSpeed
UeiDaqAPI int UeiDaqSetSerialPortCustomSpeed(ChannelHandle channelHandle, uInt32 bitsPerSecond);

/// \brief Get the serial port data bits
///
/// Get the number of data bits that hold the data to be transferred.
///
/// \param channelHandle The handle to an existing serial port
/// \param pDataBits The number of data bits.
/// \return The status code.
/// \sa UeiDaqSetSerialPortDataBits
UeiDaqAPI int UeiDaqGetSerialPortDataBits(ChannelHandle channelHandle, tUeiSerialPortDataBits* pDataBits);

/// \brief Set the serial port data bits
///
/// Set the number of data bits that hold the data to be transferred.
///
/// \param channelHandle The handle to an existing serial port
/// \param dataBits The number of data bits
/// \return The status code.
/// \sa UeiDaqGetSerialPortDataBits
UeiDaqAPI int UeiDaqSetSerialPortDataBits(ChannelHandle channelHandle, tUeiSerialPortDataBits dataBits);

/// \brief Get the serial port parity
///
/// Get the parity used to detect transmission errors.
///
/// \param channelHandle The handle to an existing serial port
/// \param pParity the parity.
/// \return The status code.
/// \sa UeiDaqSetSerialPortParity
UeiDaqAPI int UeiDaqGetSerialPortParity(ChannelHandle channelHandle, tUeiSerialPortParity* pParity);

/// \brief Set the serial port parity
///
/// Set the parity used to detect transmission errors.
///
/// \param channelHandle The handle to an existing serial port
/// \param parity The serial port parity
/// \return The status code.
/// \sa UeiDaqGetSerialPortParity
UeiDaqAPI int UeiDaqSetSerialPortParity(ChannelHandle channelHandle, tUeiSerialPortParity parity);

/// \brief Get the serial port stop bits
///
/// Get the number of stop bits that indicate the end of a data message.
///
/// \param channelHandle The handle to an existing serial port
/// \param pStopBits the number of stop bits.
/// \return The status code.
/// \sa UeiDaqSetSerialPortStopBits
UeiDaqAPI int UeiDaqGetStopBits(ChannelHandle channelHandle, tUeiSerialPortStopBits* pStopBits);

/// \brief Set the serial port stop bits
///
/// Set the number of stop bits that indicate the end of a data message.
///
/// \param channelHandle The handle to an existing serial port
/// \param stopBits The number of stop bits
/// \return The status code.
/// \sa UeiDaqGetSerialPortStopBits
UeiDaqAPI int UeiDaqSetSerialPortStopBits(ChannelHandle channelHandle, tUeiSerialPortStopBits stopBits);

/// \brief Get the "end of line" character sequence
///
/// Get the sequence of characters used to define the end of a line.
///
/// \param channelHandle The handle to an existing serial port
/// \param pEol The termination characters
/// \param eolLength The maximum length of the termination string
/// \return The status code.
/// \sa UeiDaqSetSerialPortTermination
UeiDaqAPI int UeiDaqGetSerialPortTermination(ChannelHandle channelHandle, char* pEol, int* eolLength);

/// \brief Set the "end of line" character sequence
///
/// Set the sequence of characters used to define the end of a line.
///
/// \param channelHandle The handle to an existing serial port
/// \param eol The termination characters
/// \return The status code.
/// \sa UeiDaqGetSerialPortTermination
UeiDaqAPI int UeiDaqSetSerialPortTermination(ChannelHandle channelHandle, char* eol);

/// \brief Get the TX termination resistor state
///
/// Determines whether the TX termination resistor is enabled
///
/// \param channelHandle The handle to an existing serial port
/// \param pEnabled The TX termination resistor state.
/// \return The status code.
/// \sa UeiDaqEnableSerialPortTxTerminationResistor
UeiDaqAPI int UeiDaqIsSerialPortTxTerminationResistorEnabled(ChannelHandle channelHandle, int* pEnabled);

/// \brief Enable or Disable TX termination resistor
///
/// Enable or disable the TX termination resistor.
///
/// \param channelHandle The handle to an existing serial port
/// \param enabled The new TX termination resistor state
/// \return The status code.
/// \sa UeiDaqIsSerialPortTxTerminationResistorEnabled
UeiDaqAPI int UeiDaqEnableSerialPortTxTerminationResistor(ChannelHandle channelHandle, int enabled);

/// \brief Get the RX termination resistor state
///
/// Determines whether the RX termination resistor is enabled
///
/// \param channelHandle The handle to an existing serial port
/// \param pEnabled The RX termination resistor state.
/// \return The status code.
/// \sa UeiDaqEnableSerialPortRxTerminationResistor
UeiDaqAPI int UeiDaqIsSerialPortRxTerminationResistorEnabled(ChannelHandle channelHandle, int* pEnabled);

/// \brief Enable or Disable RX termination resistor
///
/// Enable or disable the RX termination resistor.
///
/// \param channelHandle The handle to an existing serial port
/// \param enabled The new RX termination resistor state
/// \return The status code.
/// \sa UeiDaqIsSerialPortRxTerminationResistorEnabled
UeiDaqAPI int UeiDaqEnableSerialPortRxTerminationResistor(ChannelHandle channelHandle, int enabled);

/// \brief Get the error reporting state
///
/// Determines whether the framing errors or parity errors will be reported
///
/// \param channelHandle The handle to an existing serial port
/// \param pEnabled The error reporting state.
/// \return The status code.
/// \sa UeiDaqEnableSerialPortErrorReporting
UeiDaqAPI int UeiDaqIsSerialPortErrorReportingEnabled(ChannelHandle channelHandle, int *pEnabled);

/// \brief Enable or disable error reproting
///
/// Enable or disable reproting of framing and parity errors.
///
/// \param channelHandle The handle to an existing serial port
/// \param enabled The new error reporting state
/// \return The status code.
/// \sa UeiDaqIsSerialPortErrorReportingEnabled
UeiDaqAPI int UeiDaqEnableSerialPortErrorReporting(ChannelHandle channelHandle, int enabled);

/// \brief Get Flow control
///
/// Get flow control setting
///
/// \param channelHandle The handle to an existing serial port
/// \param pFlowControl The current flow control setting
/// \return The status code.
/// \sa UeiDaqSetSerialPortFlowControl
UeiDaqAPI int UeiDaqGetSerialPortFlowControl(ChannelHandle channelHandle, tUeiSerialPortFlowControl* pFlowControl);

/// \brief Set Flow control
///
/// Set flow control setting
///
/// \param channelHandle The handle to an existing serial port
/// \param flowControl The new flow control setting
/// \return The status code.
/// \sa UeiDaqGetSerialPortFlowControl
UeiDaqAPI int UeiDaqSetSerialPortFlowControl(ChannelHandle channelHandle, tUeiSerialPortFlowControl flowControl);

/// \brief Get the half-duplex echo suppression state
///
/// Determines whether the half duplex echo suppression is enabled
///
/// \param channelHandle The handle to an existing serial port
/// \param pEnabled The half-duplex echo suppression state.
/// \return The status code.
/// \sa UeiDaqEnableSerialPortHDEchoSuppression  
UeiDaqAPI int UeiDaqIsSerialPortHDEchoSuppressionEnabled(ChannelHandle channelHandle, int* pEnabled);

/// \brief Enable or disable half-duplex echo suppression
///
/// Enable or disable the half-duplex echo suppression.
///
/// \param channelHandle The handle to an existing serial port
/// \param enabled The new half-duplex echo suppression state
/// \return The status code.
/// \sa UeiDaqIsSerialPortHDEchoSuppressionEnabled  
UeiDaqAPI int UeiDaqEnableSerialPortHDEchoSuppression(ChannelHandle channelHandle, int enabled);

/// \brief Get the TX auto-disable state
///
/// Determines whether transmitter should automatically disable itself 
/// whenever the TX FIFO is empty (only used in RS-485 full duplex mode)
/// This allows multiple RS-485 devices to share the same bus
///
/// \param channelHandle The handle to an existing serial port
/// \param pEnabled The TX auto-disable state
/// \return The status code.
/// \sa UeiDaqEnableSerialPortTxAutoDisable  
UeiDaqAPI int UeiDaqIsSerialPortTxAutoDisableEnabled(ChannelHandle channelHandle, int* pEnabled);

/// \brief Enable or disable TX auto-disable
///
/// Specifies whether transmitter should automatically disable itself 
/// whenever the TX FIFO is empty (only used in RS-485 full duplex mode)
/// This allows multiple RS-485 devices to share the same bus
///
/// \param channelHandle The handle to an existing serial port
/// \param enabled The new TX auto-disable state
/// \return The status code.
/// \sa UeiDaqIsSerialPortTxAutoDisableEnabled  
UeiDaqAPI int UeiDaqEnableSerialPortTxAutoDisable(ChannelHandle channelHandle, int enabled);

/// \brief Get the on the fly parity bit state
///
/// Determines whether the parity bit can be specified on the fly
/// as part of the data stream (using uInt16 data instead of uInt8)
///
/// \param channelHandle The handle to an existing serial port
/// \param pEnabled The parity bit state.
/// \return The status code.
/// \sa UeiDaqEnableSerialPortOnTheFlyParityBit  
UeiDaqAPI int UeiDaqIsSerialPortOnTheFlyParityBitEnabled(ChannelHandle channelHandle, int* pEnabled);

/// \brief Enable or disable on the fly parity bit
///
/// Enable or disable on the fly parity bit update
/// as part of the data stream (using uInt16 data instead of uInt8)
///
/// \param channelHandle The handle to an existing serial port
/// \param enabled The new on the fly parity bit state
/// \return The status code.
/// \sa UeiDaqIsSerialPortOnTheFlyParityBitEnabled  
UeiDaqAPI int UeiDaqEnableSerialPortOnTheFlyParityBit(ChannelHandle channelHandle, int enabled);

/// \brief Get the CAN port speed
///
/// Get the number of data bits transmitted per second.
///
/// \param channelHandle The handle to an existing CAN port
/// \param pBitsPerSecond the CAN port speed.
/// \return The status code.
/// \sa UeiDaqSetCANPortSpeed
UeiDaqAPI int UeiDaqGetCANPortSpeed(ChannelHandle channelHandle, tUeiCANPortSpeed *pBitsPerSecond);

/// \brief Set the CAN port speed
///
/// Set the number of data bits transmitted per second.
///
/// \param channelHandle The handle to an existing CAN port
/// \param bitsPerSecond The port speed
/// \return The status code.
/// \sa UeiDaqGetCANPortSpeed
UeiDaqAPI int UeiDaqSetCANPortSpeed(ChannelHandle channelHandle, tUeiCANPortSpeed bitsPerSecond);

/// \brief Get the frame format
///
/// Get the format of frames transmitted by this port
///
/// \param channelHandle The handle to an existing CAN port
/// \param pFrameFormat The frame format.
/// \return The status code.
/// \sa UeiDaqSetCANPortFrameFormat
UeiDaqAPI int UeiDaqGetCANPortFrameFormat(ChannelHandle channelHandle, tUeiCANFrameFormat* pFrameFormat);

/// \brief Set the frame format
///
/// Set the format of frames transmitted by this port (CAN frames can be basic or extended).
///
/// \param channelHandle The handle to an existing CAN port
/// \param frameFormat The Frame format
/// \return The status code.
/// \sa UeiDaqGetCANPortFrameFormat
UeiDaqAPI int UeiDaqSetCANPortFrameFormat(ChannelHandle channelHandle, tUeiCANFrameFormat frameFormat);

/// \brief Get the operation mode
///
/// Get the CAN port operation mode. Possible values are normal and passive
///
/// \param channelHandle The handle to an existing CAN port
/// \param pMode The operation mode.
/// \return The status code.
/// \sa UeiDaqSetCANPortMode
UeiDaqAPI int UeiDaqGetCANPortMode(ChannelHandle channelHandle, tUeiCANPortMode* pMode);

/// \brief Set the operation mode
///
/// Set the CAN port operation mode. Possible values are normal and passive
///
/// \param channelHandle The handle to an existing CAN port
/// \param mode The operation mode
/// \return The status code.
/// \sa UeiDaqGetCANPortMode
UeiDaqAPI int UeiDaqSetCANPortMode(ChannelHandle channelHandle, tUeiCANPortMode mode);

/// \brief Get the acceptance mask
///
/// The acceptance mask is used to filter incoming frames. The mask selects
/// which bits within arbitration ID will be used for filtering.
///
/// \param channelHandle The handle to an existing CAN port
/// \param pMask The current acceptance mask.
/// \return The status code.
/// \sa UeiDaqSetCANPortAcceptanceMask
UeiDaqAPI int UeiDaqGetCANPortAcceptanceMask(ChannelHandle channelHandle, uInt32* pMask);

/// \brief Set the acceptance mask
///
/// The acceptance mask is used to filter incoming frames. The mask selects
/// which bits within arbitration ID will be used for filtering.
///
/// \param channelHandle The handle to an existing CAN port
/// \param mask The acceptance mask
/// \return The status code.
/// \sa UeiDaqGetCANPortAcceptanceMask
UeiDaqAPI int UeiDaqSetCANPortAcceptanceMask(ChannelHandle channelHandle, uInt32 mask);

/// \brief Get the acceptance code
///
/// The acceptance code is used to filter incoming frames. The arbitration ID bits selected
/// by the mask are compared to the code and the frame is rejected if there is any difference.
/// If (mask XOR id) AND code == 0 the frame is accepted
///
/// \param channelHandle The handle to an existing CAN port
/// \param pCode The current acceptance code.
/// \return The status code.
/// \sa UeiDaqSetCANPortAcceptanceCode
UeiDaqAPI int UeiDaqGetCANPortAcceptanceCode(ChannelHandle channelHandle, uInt32* pCode);

/// \brief Set the acceptance code
///
/// The acceptance code is used to filter incoming frames. The arbitration ID bits selected
/// by the mask are compared to the code and the frame is rejected if there is any difference.
/// If (mask XOR id) AND code == 0 the frame is accepted
///
/// \param channelHandle The handle to an existing CAN port
/// \param code The acceptance code
/// \return The status code.
/// \sa UeiDaqGetCANPortAcceptanceCode
UeiDaqAPI int UeiDaqSetCANPortAcceptanceCode(ChannelHandle channelHandle, uInt32 code);

/// \brief Add a filter entry
///
/// Add a filter entry to the port's filter table. 
/// Each incoming CAN frame that doesn't match any of the filter 
/// ranges is rejected.
///
/// \param channelHandle The handle to an existing CAN port
/// \param entry A struture that represents the new filter entry
/// \return The status code.
/// \sa UeiDaqClearCANPortFilterEntries, UeiDaqGetCANPortFilterEntry
UeiDaqAPI int UeiDaqAddCANPortFilterEntry(ChannelHandle channelHandle, tUeiCANFilterEntry entry);

/// \brief Retrieve a filter entry
///
/// Retrieve a filter entry from the port's frame filter table.
/// Returns NULL when retrieving past the end of the table.
///
/// \param channelHandle The handle to an existing CAN port
/// \param index The index of the filter entry to retrieve
/// \param entry A pointer to the retrieved filter entry
/// \return The status code.
/// \sa UeiDaqAddCANPortFilterEntry, UeiDaqClearCANPortFilterEntries
UeiDaqAPI int UeiDaqGetCANPortFilterEntry(ChannelHandle channelHandle, int index, tUeiCANFilterEntry** entry);

/// \brief Clear filter table
///
/// Empties the port's filter table.
///
/// \param channelHandle The handle to an existing CAN port
/// \return The status code.
/// \sa UeiDaqAddCANPortFilterEntry, UeiDaqGetCANPortFilterEntry
UeiDaqAPI int UeiDaqClearCANPortFilterEntries(ChannelHandle channelHandle);

/// \brief Determines whether bus errors and warnings are logged
///
/// When logging is enabled, bus warnings and errors are sent in the data stream.
/// Use the Type field of the CANDataFrame structure to determine whether received
/// frames are data or error frames.
///
/// \param channelHandle The handle to an existing CAN port
/// \param pEnabled 1 if logging is enabled, 0 otherwise.
/// \sa UeiDaqEnableCANPortWarningAndErrorLogging  
UeiDaqAPI int UeiDaqIsCANPortWarningAndErrorLoggingEnabled(ChannelHandle channelHandle, int *pEnabled);

/// \brief Specifies whether bus errors and warnings are logged
///
/// When logging is enabled, bus warnings and errors are sent in the data stream.
/// Use the Type field of the CANDataFrame structure to determine whether received
/// frames are data or error frames.
///
/// \param channelHandle The handle to an existing CAN port
/// \param enable 1 to enable error logging, 0 to disable it
/// \return The status code.
/// \sa UeiDaqIsCANPortWarningAndErrorLoggingEnabled
UeiDaqAPI int UeiDaqEnableCANPortWarningAndErrorLogging(ChannelHandle channelHandle, int enable);

/// \brief Get the transmit error counter
///
/// Get the number of transmit errors detected on the bus since the session
/// started.
///
/// \param channelHandle The handle to an existing CAN port
/// \param pTxErrorCounter  The transmit error counter.
/// \return The status code.
/// \sa UeiDaqGetCANPortReceiveErrorCounter  
UeiDaqAPI int UeiDaqGetCANPortTransmitErrorCounter(ChannelHandle channelHandle, uInt32* pTxErrorCounter);

/// \brief Get the receive error counter
///
/// Get the number of receive errors detected on the bus since the session
/// started.
///
/// \param channelHandle The handle to an existing CAN port
/// \param pRxErrorCounter The receive error counter.
/// \return The status code.
/// \sa UeiDaqGetCANPortTransmitErrorCounter  
UeiDaqAPI int UeiDaqGetCANPortReceiveErrorCounter(ChannelHandle channelHandle, uInt32* pRxErrorCounter);

/// \brief Get the error code capture register
///
/// Get the current values of the Error Code Capture register from 
/// the NXP SJA1000 CAN controller chip.
/// The Error Code Capture register provides information on bus errors
/// that occur according to the CAN standard. A bus error increments
/// either the Transmit Error Counter or the Receive Error Counter.
/// When communication starts on the interface, the first bus error is
/// captured into the Error Code Capture register, and retained until you
/// get this value. Then the Error Code Capture register is again enabled 
/// to capture information for the next bus error.
///
/// \param channelHandle The handle to an existing CAN port
/// \param pErrorCodeCaptureReg The error code capture register. 
/// \return The status code.
UeiDaqAPI int UeiDaqGetCANPortErrorCodeCaptureRegister(ChannelHandle channelHandle, uInt32* pErrorCodeCaptureReg);

/// \brief Get the arbitration lost capture register
///
/// Get the current values of the Arbitration Lost Capture register from 
/// the NXP SJA1000 CAN controller chip.
///
/// The Arbitration Lost Capture register provides information on a loss of
/// arbitration during transmits. Loss of arbitration is not considered an
/// error. When communication starts on the interface, the first arbitration
/// loss is captured into the Arbitration Lost Capture register, and retained
/// until you get this value. Then, the Arbitration Lost Capture register 
/// is again enabled to capture information for the next arbitration loss.
///
/// \param channelHandle The handle to an existing CAN port
/// \param pArbLostCaptureReg The arbitration lost capture register.
/// \return The status code.
UeiDaqAPI int UeiDaqGetCANPortArbitrationLostCaptureRegister(ChannelHandle channelHandle, uInt32* pArbLostCaptureReg);

/// \brief Get the bit timing registers BTR0 and BTR1
///
/// Get the current values of the bit timing registers from
/// the NXP SJA1000 CAN controller chip.
/// BTR0 and BTR1 set the baud rate for the CAN port. 
/// For information on CAN bit timing registers, refer to the datasheet of 
/// the NXP SJA1000 CAN controller, available for download on www.nxp.com.
///
/// \param channelHandle The handle to an existing CAN port
/// \param pBtrValues The bit timing regiters, BTR0 is LSB and BTR1 is MSB. 
/// \return The status code.
UeiDaqAPI int UeiDaqGetCANPortBitTimingRegisters(ChannelHandle channelHandle, uInt16* pBtrValues);

/// \brief Set the bit timing registers BTR0 and BTR1
///
/// Set the values of the bit timing registers from
/// the NXP SJA1000 CAN controller chip.
/// BTR0 and BTR1 set the baud rate for the CAN port. 
/// For information on CAN bit timing registers, refer to the datasheet of 
/// the NXP SJA1000 CAN controller, available for download on www.nxp.com.
///
/// \param channelHandle The handle to an existing CAN port
/// \param btrValues The new bit timing regiters, BTR0 is LSB and BTR1 is MSB. 
/// \return The status code.
UeiDaqAPI int UeiDaqSetCANPortBitTimingRegisters(ChannelHandle channelHandle, uInt16 btrValues);

/// \brief Get the ARINC port speed
///
/// Get the number of bits transmitted per second.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param pBitsPerSecond The ARINC port speed
/// \return The status code.
/// \sa UeiDaqSetARINCInputSpeed
UeiDaqAPI int UeiDaqGetARINCInputSpeed(ChannelHandle channelHandle, tUeiARINCPortSpeed* pBitsPerSecond);

/// \brief Set the ARINC port speed
///
/// Set the number of bits transmitted per second.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param bitsPerSecond The ARINC port speed
/// \return The status code.
/// \sa UeiDaqGetARINCInputSpeed
UeiDaqAPI int UeiDaqSetARINCInputSpeed(ChannelHandle channelHandle, tUeiARINCPortSpeed bitsPerSecond);

/// \brief Get the ARINC port parity
///
/// Get the parity used to detect transmission errors.
/// The parity bit of each ARINC frame is set to 0 or 1 so that the number
/// of bits set to 1 matches the specified parity.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param pParity The ARINC port parity
/// \return The status code.
/// \sa UeiDaqSetARINCInputParity
UeiDaqAPI int UeiDaqGetARINCInputParity(ChannelHandle channelHandle, tUeiARINCPortParity *pParity);

/// \brief Set the ARINC port parity
///
/// Set the parity used to detect transmission errors.
/// The parity bit of each ARINC frame is set to 0 or 1 so that the number
/// of bits set to 1 matches the specified parity.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param parity The ARINC port parity
/// \return The status code.
/// \sa UeiDaqGetARINCInputParity
UeiDaqAPI int UeiDaqSetARINCInputParity(ChannelHandle channelHandle, tUeiARINCPortParity parity);

/// \brief Get the SDI filter state
///
/// Determines whether the SDI filter is turned on or off.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param pSDIFilterEnabled true if SDI filtering is on, false otherwise
/// \return The status code.
/// \sa UeiDaqEnableARINCInputSDIFilter
UeiDaqAPI int UeiDaqIsARINCInputSDIFilterEnabled(ChannelHandle channelHandle, int *pSDIFilterEnabled);

/// \brief Set the SDI filter state
///
/// Specifies whether the SDI filter is turned on or off.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param enableSDIFilter true to turn SDI filtering on, false otherwise
/// \return The status code.
/// \sa UeiDaqIsARINCInputSDIFilterEnabled
UeiDaqAPI int UeiDaqEnableARINCInputSDIFilter(ChannelHandle channelHandle, int enableSDIFilter);

/// \brief Get the SDI filter mask
///
/// Get the SDI filter mask, only bits 0 and 1 are meaningful.
/// ARINC frames whose SDI bits don't match the SDI mask are rejected.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param pSDIFilterMask The current SDI filter mask
/// \return The status code.
/// \sa UeiDaqSetARINCInputSDIFilterMask
UeiDaqAPI int UeiDaqGetARINCInputSDIFilterMask(ChannelHandle channelHandle, uInt32 *pSDIFilterMask);

/// \brief Set the SDI filter mask
///
/// Set the SDI filter mask, only bits 0 and 1 are meaningful.
/// ARINC frames whose SDI bits don't match the SDI mask are rejected.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param SDIFilterMask The new SDI filter mask
/// \return The status code.
/// \sa UeiDaqGetARINCInputSDIFilterMask
UeiDaqAPI int UeiDaqSetARINCInputSDIFilterMask(ChannelHandle channelHandle, uInt32 SDIFilterMask);

/// \brief Get the timestamping state
///
/// Determines whether each received frame is timestamped.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param pTimestampingEnabled 1 if timestamping is on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqEnableARINCInputTimestamping
UeiDaqAPI int UeiDaqIsARINCInputTimestampingEnabled(ChannelHandle channelHandle, int *pTimestampingEnabled);

/// \brief Set the timestamping state
///
/// Specifies whether each received frame is timestamped.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param enableTimestamping 1 to turn timestamping on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqIsARINCInputTimestampingEnabled
UeiDaqAPI int UeiDaqEnableARINCInputTimestamping(ChannelHandle channelHandle, int enableTimestamping);

/// \brief Get the slow slew rate state
///
/// Determines whether slow slew rate is enabled.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param pSlowSlewRateEnabled 1 if slow slew rate is on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqEnableARINCInputSlowSlewRate
UeiDaqAPI int UeiDaqIsARINCInputSlowSlewRateEnabled(ChannelHandle channelHandle, int *pSlowSlewRateEnabled);

/// \brief Set the slow slew state
///
/// Enables slow slew rate.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param enableSlowSlewRate 1 to turn slow slew rate on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqIsARINCInputSlowSlewRateEnabled
UeiDaqAPI int UeiDaqEnableARINCInputSlowSlewRate(ChannelHandle channelHandle, int enableSlowSlewRate);

/// \brief Add a filter entry
///
/// Add a filter entry to the port's frame filter table.
/// Each incoming ARINC frame that doesn't match any of the filter
/// entries is rejected.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param entry A struture that represents the new filter entry
/// \return The status code.
/// \sa UeiDaqClearARINCInputFilterEntries, UeiDaqGetARINCInputFilterEntry
UeiDaqAPI int UeiDaqAddARINCInputFilterEntry(ChannelHandle channelHandle, tUeiARINCFilterEntry entry);

/// \brief Retrieve a filter entry
///
/// Retrieve a filter entry from the port's frame filter table.
/// Returns NULL when retrieving past the end of the table.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param index The index of the filter entry to retrieve
/// \param entry A pointer to the retrieved filter entry
/// \return The status code.
/// \sa UeiDaqAddARINCInputFilterEntry, UeiDaqClearARINCInputFilterEntries
UeiDaqAPI int UeiDaqGetARINCInputFilterEntry(ChannelHandle channelHandle, int index, tUeiARINCFilterEntry** entry);

/// \brief Clear filter table
///
/// Empties the port's filter table.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \return The status code.
/// \sa UeiDaqAddARINCInputFilterEntry, UeiDaqGetARINCInputFilterEntry
UeiDaqAPI int UeiDaqClearARINCInputFilterEntries(ChannelHandle channelHandle);

/// \brief Get the label filter state
///
/// Determines whether label filtering is enabled.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param pLabelFilterEnabled The label filter state.
/// \return The status code.
/// \sa UeiDaqEnableARINCInputLabelFilter
UeiDaqAPI int UeiDaqIsARINCInputLabelFilterEnabled(ChannelHandle channelHandle, int *pLabelFilterEnabled);

/// \brief Set the label filter state
///
/// Enables label filtering.
///
/// \param channelHandle The handle to an existing ARINC-429 input channel
/// \param enableLabelFilter 1 to turn label filtering on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqIsARINCInputLabelFilterEnabled
UeiDaqAPI int UeiDaqEnableARINCInputLabelFilter(ChannelHandle channelHandle, int enableLabelFilter);


/// \brief Get the ARINC port speed
///
/// Get the number of bits transmitted per second.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param pBitsPerSecond The ARINC port speed
/// \return The status code.
/// \sa UeiDaqSetARINCOutputSpeed
UeiDaqAPI int UeiDaqGetARINCOutputSpeed(ChannelHandle channelHandle, tUeiARINCPortSpeed *pBitsPerSecond);

/// \brief Set the ARINC port speed
///
/// Set the number of bits transmitted per second.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param bitsPerSecond The ARINC port speed
/// \return The status code.
/// \sa UeiDaqGetARINCOutputSpeed
UeiDaqAPI int UeiDaqSetARINCOutputSpeed(ChannelHandle channelHandle, tUeiARINCPortSpeed bitsPerSecond);

/// \brief Get the ARINC port parity
///
/// Get the parity used to detect transmission errors.
/// The parity bit of each ARINC frame is set to 0 or 1 so that the number
/// of bits set to 1 matches the specified parity.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param pParity The ARINC port parity
/// \return The status code.
/// \sa UeiDaqSetARINCOutputParity
UeiDaqAPI int UeiDaqGetARINCOutputParity(ChannelHandle channelHandle, tUeiARINCPortParity *pParity);

/// \brief Set the ARINC port parity
///
/// Set the parity used to detect transmission errors.
/// The parity bit of each ARINC frame is set to 0 or 1 so that the number
/// of bits set to 1 matches the specified parity.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param parity The ARINC port parity
/// \return The status code.
/// \sa UeiDaqGetARINCOutputParity
UeiDaqAPI int UeiDaqSetARINCOutputParity(ChannelHandle channelHandle, tUeiARINCPortParity parity);

/// \brief Get the loopback state
///
/// Determines whether loopback is enabled. When enabled you can read back packet
/// sent to this port on a dedicated loopback port.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param pLoopbackEnabled 1 if loopback is enabled, 0 if it is disabled.
/// \return The status code.
/// \sa UeiDaqEnableARINCOutputLoopback
UeiDaqAPI int UeiDaqIsARINCOutputLoopbackEnabled(ChannelHandle channelHandle, int *pLoopbackEnabled);

/// \brief Set the loopback state
///
/// Enables loopback. When enabled you can read back packet
/// sent to this port on a dedicated loopback port.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param enableLoopback 1 to enable loopback, 0 to disable it.
/// \return The status code.
/// \sa UeiDaqIsARINCOutputLoopbackEnabled
UeiDaqAPI int UeiDaqEnableARINCOutputLoopback(ChannelHandle channelHandle, int enableLoopback);

/// \brief Get the slow slew rate state
///
/// Determines whether slow slew rate is enabled.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param pSlowSlewRateEnabled 1 if slow slew rate is on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqEnableARINCOutputSlowSlewRate
UeiDaqAPI int UeiDaqIsARINCOutputSlowSlewRateEnabled(ChannelHandle channelHandle, int* pSlowSlewRateEnabled);

/// \brief Set the slow slew state
///
/// Enables slow slew rate.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param enableSlowSlewRate 1 to turn slow slew rate on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqIsSlowARINCOutputSlewRateEnabled
UeiDaqAPI int UeiDaqEnableARINCOutputSlowSlewRate(ChannelHandle channelHandle, int enableSlowSlewRate);

/// \brief Add a scheduler entry
///
/// Add a scheduler entry to the port's scheduler table.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param entry A struture that represents the new scheduler entry
/// \return The status code.
/// \sa UeiDaqClearARINCOutputSchedulerEntries, UeiDaqGetARINCOutputSchedulerEntry
UeiDaqAPI int UeiDaqAddARINCOutputSchedulerEntry(ChannelHandle channelHandle, tUeiARINCSchedulerEntry entry);

/// \brief Retrieve a scheduler entry
///
/// Retrieve a scheduler entry from the port's scheduler table.
/// Returns NULL when retrieving past the end of the table.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param index The index of the scheduler entry to retrieve
/// \param entry A pointer to the retrieved scheduler entry
/// \return The status code.
/// \sa UeiDaqAddARINCOutputSchedulerEntry, UeiDaqClearARINCOutputSchedulerEntries
UeiDaqAPI int UeiDaqGetARINCOutputSchedulerEntry(ChannelHandle channelHandle, int index, tUeiARINCSchedulerEntry** entry);

/// \brief Clear scheduler table
///
/// Empties the port's scheduler table.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \return The status code.
/// \sa UeiDaqAddARINCOutputSchedulerEntry, UeiDaqGetARINCOutputSchedulerEntry
UeiDaqAPI int UeiDaqClearARINCOutputSchedulerEntries(ChannelHandle channelHandle);

/// \brief Get the scheduler state
///
/// Determines whether scheduling is enabled.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param pSchedulerEnabled The scheduler state.
/// \return The status code.
/// \sa UeiDaqEnableARINCOutputScheduler
UeiDaqAPI int UeiDaqIsARINCOutputSchedulerEnabled(ChannelHandle channelHandle, int *pSchedulerEnabled);

/// \brief Set the scheduler state
///
/// Enables scheduling.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param enableScheduler 1 to turn scheduling on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqIsARINCOutputSchedulerEnabled
UeiDaqAPI int UeiDaqEnableARINCOutputScheduler(ChannelHandle channelHandle, int enableScheduler);

/// \brief Get the scheduler type
///
/// Gets scheduler type.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param type The current scheduler type.
/// \return The status code.
/// \sa UeiDaqSetARINCOutputSchedulerType 
UeiDaqAPI int UeiDaqGetARINCOutputSchedulerType(ChannelHandle channelHandle, tUeiARINCSchedulerType* type);

/// \brief Set the scheduler type
///
/// Sets scheduler type.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param type the new scheduler type
/// \return The status code.
/// \sa UeiDaqGetARINCOutputSchedulerType  
UeiDaqAPI int UeiDaqSetARINCOutputSchedulerType(ChannelHandle channelHandle, tUeiARINCSchedulerType type);

/// \brief Get the scheduler rate
///
/// Gets scheduler rate.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param rate The current scheduler rate.
/// \return The status code.
/// \sa UeiDaqSetARINCOutputSchedulerRate 
UeiDaqAPI int UeiDaqGetARINCOutputSchedulerRate(ChannelHandle channelHandle, double* rate);

/// \brief Set the scheduler rate
///
/// Sets scheduler rate.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param rate the new scheduler rate
/// \return The status code.
/// \sa UeiDaqGetARINCOutputSchedulerRate  
UeiDaqAPI int UeiDaqSetARINCOutputSchedulerRate(ChannelHandle channelHandle, double rate);

/// \brief Get the TX FIFO rate
///
/// Gets TX FIFO rate.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param rate The new TX FIFO rate.
/// \return The status code.
/// \sa UeiDaqSetARINCOutputFIFORate 
UeiDaqAPI int UeiDaqGetARINCOutputFIFORate(ChannelHandle channelHandle, double* rate);

/// \brief Set the TX FIFO rate
///
/// Sets TX FIFO rate.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param rate the new TX FIFO rate
/// \return The status code.
/// \sa UeiDaqGetARINCOutputFIFORate  
UeiDaqAPI int UeiDaqSetARINCOutputFIFORate(ChannelHandle channelHandle, double rate);

/// \brief Add a minor frame entry
///
/// Add a minor frame entry to the port's scheduler table.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param entry A struture that represents the new minor frame entry
/// \return The status code.
/// \sa UeiDaqClearARINCOutputMinorFrameEntries, UeiDaqGetARINCOutputMinorFrameEntry
UeiDaqAPI int UeiDaqAddARINCOutputMinorFrameEntry(ChannelHandle channelHandle, tUeiARINCMinorFrameEntry entry);

/// \brief Retrieve a minor frame entry
///
/// Retrieve a minor frame entry from the port's minor frame table.
/// Returns NULL when retrieving past the end of the table.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \param index The index of the minor frame entry to retrieve
/// \param entry A pointer to the retrieved minor frame entry
/// \return The status code.
/// \sa UeiDaqAddARINCOutputMinorFrameEntry, UeiDaqClearARINCOutputMinorFrameEntries
UeiDaqAPI int UeiDaqGetARINCOutputMinorFrameEntry(ChannelHandle channelHandle, int index, tUeiARINCMinorFrameEntry** entry);

/// \brief Clear major frame
///
/// Empties the port's major frame.
///
/// \param channelHandle The handle to an existing ARINC-429 output channel
/// \return The status code.
/// \sa UeiDaqAddARINCOutputMinorFrameEntry, UeiDaqGetARINCOutputMinorFrameEntry
UeiDaqAPI int UeiDaqClearARINCOutputMinorFrameEntries(ChannelHandle channelHandle);

/// \brief Get the 1553 port coupling
///
/// Get the coupling used to to connect the port to the bus
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param pCoupling The 1553 port coupling.
/// \return The status code.
/// \sa UeiDaqSetMIL1553Coupling
UeiDaqAPI int UeiDaqGetMIL1553Coupling(ChannelHandle channelHandle, tUeiMIL1553PortCoupling* pCoupling);

/// \brief Set the 1553 port coupling
///
/// Set the coupling needed to connect port to 1553 bus
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param coupling The 1553 port coupling
/// \return The status code.
/// \sa UeiDaqGetMIL1553Coupling
UeiDaqAPI int UeiDaqSetMIL1553Coupling(ChannelHandle channelHandle, tUeiMIL1553PortCoupling coupling);

/// \brief Get the 1553 port mode of operation
///
/// Get the port mode of operation: BM, RT or BC
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param pPortMode The 1553 port mode of operation
/// \return The status code.
/// \sa UeiDaqSetMIL1553PortMode
UeiDaqAPI int UeiDaqGetMIL1553PortMode(ChannelHandle channelHandle, tUeiMIL1553PortOpMode* pPortMode);

/// \brief Set the 1553 port mode of operation
///
/// Set the port mode of operation: BM, RT or BC
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param portMode The 1553 port mode of operation
/// \return The status code.
/// \sa UeiDaqGetMIL1553PortMode
UeiDaqAPI int UeiDaqSetMIL1553PortMode(ChannelHandle channelHandle, tUeiMIL1553PortOpMode portMode);

/// \brief Get the 1553 active transmission bus
///
/// Get the active bus: A or B
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param pPortBus The 1553 port active bus for transmission
/// \return The status code.
/// \sa UeiDaqSetMIL1553TxBus
UeiDaqAPI int UeiDaqGetMIL1553TxBus(ChannelHandle channelHandle, tUeiMIL1553PortActiveBus* pPortBus);

/// \brief Set the 1553 active transmission bus
///
/// Set the active bus: A or B
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param portBus The 1553 port active bus for transmission
/// \return The status code.
/// \sa UeiDaqGetMIL1553TxBus
UeiDaqAPI int UeiDaqSetMIL1553TxBus(ChannelHandle channelHandle, tUeiMIL1553PortActiveBus portBus);

/// \brief Get the 1553 active reception bus
///
/// Get the active bus: A or B or both
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param pPortBus The 1553 port active bus for reception
/// \return The status code.
/// \sa UeiDaqSetMIL1553RxBus
UeiDaqAPI int UeiDaqGetMIL1553RxBus(ChannelHandle channelHandle, tUeiMIL1553PortActiveBus* pPortBus);

/// \brief Set the 1553 active reception bus
///
/// Set the active bus: A or B or both
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param portBus The 1553 port active bus for reception
/// \return The status code.
/// \sa UeiDaqGetMIL1553RxBus
UeiDaqAPI int UeiDaqSetMIL1553RxBus(ChannelHandle channelHandle, tUeiMIL1553PortActiveBus portBus);

/// \brief Get the timestamping state
///
/// Determines whether each received frame is timestamped.
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param pTimestampingEnabled 1 if timestamping is on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqEnableMIL1553Timestamping
UeiDaqAPI int UeiDaqIsMIL1553TimestampingEnabled(ChannelHandle channelHandle, int *pTimestampingEnabled);

/// \brief Set the timestamping state
///
/// Specifies whether each received frame is timestamped.
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param enableTimestamping 1 to turn timestamping on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqIsMIL1553TimestampingEnabled
UeiDaqAPI int UeiDaqEnableMIL1553Timestamping(ChannelHandle channelHandle, int enableTimestamping);

/// \brief Add a filter entry
///
/// Add a filter entry to the port's frame filter table.
/// Each incoming MIL-1553 frame that doesn't match any of the filter
/// entries is rejected.
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param entry A struture that represents the new filter entry
/// \return The status code.
/// \sa UeiDaqClearMIL1553FilterEntries, UeiDaqGetMIL1553FilterEntry
UeiDaqAPI int UeiDaqAddMIL1553FilterEntry(ChannelHandle channelHandle, tUeiMIL1553FilterEntry entry);

/// \brief Retrieve a filter entry
///
/// Retrieve a filter entry from the port's frame filter table.
/// Returns NULL when retrieving past the end of the table.
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param index The index of the filter entry to retrieve
/// \param entry A pointer to the retrieved filter entry
/// \return The status code.
/// \sa UeiDaqAddMIL1553FilterEntry, UeiDaqClearMIL1553FilterEntries
UeiDaqAPI int UeiDaqGetMIL1553FilterEntry(ChannelHandle channelHandle, int index, tUeiMIL1553FilterEntry** entry);

/// \brief Clear filter table
///
/// Empties the port's filter table.
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \return The status code.
/// \sa UeiDaqAddMIL1553FilterEntry, UeiDaqGetMIL1553FilterEntry
UeiDaqAPI int UeiDaqClearMIL1553FilterEntries(ChannelHandle channelHandle);

/// \brief Get the input filter state
///
/// Determines whether frame filtering is enabled.
///
/// \param channelHandle The handle to an existing MIL-1553 input channel
/// \param pFilterEnabled The label filter state.
/// \return The status code.
/// \sa UeiDaqEnableMIL1553Filter
UeiDaqAPI int UeiDaqIsMIL1553FilterEnabled(ChannelHandle channelHandle, int *pFilterEnabled);

/// \brief Set the input filter state
///
/// Enables filtering.
///
/// \param channelHandle The handle to an existing MIL-1553 input channel
/// \param enableFilter 1 to turn label filtering on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqIsMIL1553FilterEnabled
UeiDaqAPI int UeiDaqEnableMIL1553Filter(ChannelHandle channelHandle, int enableFilter);

/// \brief Add a scheduler entry
///
/// Add a scheduler entry to the port's scheduler table.
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param entry A struture that represents the new scheduler entry
/// \return The status code.
/// \sa UeiDaqClearMIL1553SchedulerEntries, UeiDaqGetMIL1553SchedulerEntry
UeiDaqAPI int UeiDaqAddMIL1553SchedulerEntry(ChannelHandle channelHandle, tUeiMIL1553SchedulerEntry entry);

/// \brief Retrieve a scheduler entry
///
/// Retrieve a scheduler entry from the port's scheduler table.
/// Returns NULL when retrieving past the end of the table.
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param index The index of the scheduler entry to retrieve
/// \param entry A pointer to the retrieved scheduler entry
/// \return The status code.
/// \sa UeiDaqAddMIL1553SchedulerEntry, UeiDaqClearMIL1553SchedulerEntries
UeiDaqAPI int UeiDaqGetMIL1553SchedulerEntry(ChannelHandle channelHandle, int index, tUeiMIL1553SchedulerEntry** entry);

/// \brief Clear scheduler table
///
/// Empties the port's scheduler table.
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \return The status code.
/// \sa UeiDaqAddMIL1553SchedulerEntry, UeiDaqGetMIL1553SchedulerEntry
UeiDaqAPI int UeiDaqClearMIL1553SchedulerEntries(ChannelHandle channelHandle);

/// \brief Get the scheduler state
///
/// Determines whether scheduling is enabled.
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param pSchedulerEnabled The scheduler state.
/// \return The status code.
/// \sa UeiDaqEnableMIL1553Scheduler
UeiDaqAPI int UeiDaqIsMIL1553SchedulerEnabled(ChannelHandle channelHandle, int *pSchedulerEnabled);

/// \brief Set the scheduler state
///
/// Enables scheduling.
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param enableScheduler 1 to turn scheduling on, 0 otherwise
/// \return The status code.
/// \sa UeiDaqIsMIL1553SchedulerEnabled
UeiDaqAPI int UeiDaqEnableMIL1553Scheduler(ChannelHandle channelHandle, int enableScheduler);

/// \brief Get the time keeper source
///
/// For proper functioning, the timekeeper requires a 1PPS signal.
/// which can be delivered from multiple sources: internal, external, GPS...
/// This method gets the current time keeper 1PPS source
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param source the 1PPS source.
/// \return The status code
/// \sa UeiDaqSetIRIG1PPSSource  
UeiDaqAPI int UeiDaqGetIRIGTimeKeeper1PPSSource(ChannelHandle channelHandle, tUeiIRIGTimeKeeper1PPSSource* source);

/// \brief Set the time keeper source
///
/// For proper functioning, the timekeeper requires a 1PPS signal.
/// which can be delivered from multiple sources: internal, external, GPS...
/// This method sets the new time keeper 1PPS source
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param source the new 1 PPS source.
/// \return The status code
/// \sa UeiDaqGetIRIG1PPSSource  
UeiDaqAPI int UeiDaqSetIRIGTimeKeeper1PPSSource(ChannelHandle channelHandle, tUeiIRIGTimeKeeper1PPSSource source);

/// \brief Get the auto-follow state
///
/// If selected external 1PPS source does not deliver pulses (because of a break in timecode
/// transmission, for example). Timekeeper can switch to internal timebase when externally
/// derived one is not available
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param autoFollowEnabled The auto-follow state.
/// \return The status code
/// \sa UeiDaqEnableIRIGAutoFollow 
UeiDaqAPI int UeiDaqIsIRIGTimeKeeperAutoFollowEnabled(ChannelHandle channelHandle, int* autoFollowEnabled);

/// \brief Set the auto-follow state
///
/// If selected external 1PPS source does not deliver pulses (because of a break in timecode
/// transmission, for example). Timekeeper can switch to internal timebase when externally
/// derived one is not available
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param enableAutoFollow true to turn auto-follow on, false otherwise
/// \return The status code
/// \sa UeiDaqIsIRIGAutoFollowEnabled  
UeiDaqAPI int UeiDaqEnableIRIGTimeKeeperAutoFollow(ChannelHandle channelHandle, int enableAutoFollow);

/// \brief Get the nominal value state
///
/// Select whether to use nominal period (i.e. 100e6 pulses of 100MHz base clock) 
/// or the period measured by timekeeper (it measures and averages number of base clock cycles
/// between externally derived 1PPS pulses when they are valid).
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param nominalValueEnabled The nominal value state.
/// \return The status code
/// \sa UeiDaqEnableIRIGNominalValue 
UeiDaqAPI int UeiDaqIsIRIGTimeKeeperNominalValueEnabled(ChannelHandle channelHandle, int* nominalValueEnabled);

/// \brief Set the nominal value state
///
/// Select whether to use nominal period (i.e. 100e6 pulses of 100MHz base clock) 
/// or the period measured by timekeeper (it measures and averages number of base clock cycles
/// between externally derived 1PPS pulses when they are valid).
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param enableNominalValue true to turn nominal value on, false otherwise
/// \return The status code
/// \sa UeiDaqIsIRIGNominalValueEnabled  
UeiDaqAPI int UeiDaqEnableIRIGTimeKeeperNominalValue(ChannelHandle channelHandle, int enableNominalValue);

/// \brief Get the sub PPS state
///
/// Select whether external timebase is slower than 1PPS
/// or is not derived from the timecode
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param subPPSEnabled The sub PPS state.
/// \return The status code
/// \sa UeiDaqEnableIRIGSubPPS 
UeiDaqAPI int UeiDaqIsIRIGTimeKeeperSubPPSEnabled(ChannelHandle channelHandle, int* subPPSEnabled);

/// \brief Set the nominal value state
///
/// Select whether external timebase is slower than 1PPS
/// or is not derived from the timecode
///
/// \param channelHandle The handle to an existing MIL-1553 channel
/// \param enableSubPPS true to turn sub PPS on, false otherwise
/// \return The status code
/// \sa UeiDaqIsIRIGSubPPSEnabled  
UeiDaqAPI int UeiDaqEnableIRIGTimeKeeperSubPPS(ChannelHandle channelHandle, int enableSubPPS);

/// \brief Get the SBS state
///
/// Select whether to use SBS timecode section for TimeKeeper hour/min decoding
/// (if BCD data in the incoming timecode is corrupted)
///
/// \param channelHandle The handle to an existing IRIG input channel
/// \param SBSenabled The SBS state.
/// \return The status code
/// \sa UeiDaqEnableIRIGSBS 
UeiDaqAPI int UeiDaqIsIRIGTimeKeeperSBSEnabled(ChannelHandle channelHandle, int* SBSenabled);

/// \brief Set the SBS state
///
/// Select whether to use SBS timecode section for TimeKeeper hour/min decoding
/// (if BCD data in the incoming timecode is corrupted)
///
/// \param channelHandle The handle to an existing IRIG input channel
/// \param enableSBS true to use SBS data instead of BCD data, false otherwise
/// \return The status code
/// \sa UeiDaqIsIRIGSBSEnabled  
UeiDaqAPI int UeiDaqEnableIRIGTimeKeeperSBS(ChannelHandle channelHandle, int enableSBS);

/// \brief Get the invalid second state
///
/// Select whether seconds information is invalid in the input timecode
///
/// \param channelHandle The handle to an existing IRIG channel
/// \param invalidSecondEnabled The invalid second state.
/// \return The status code
/// \sa UeiDaqEnableIRIGInvalidSecond 
UeiDaqAPI int UeiDaqIsIRIGTimeKeeperInvalidSecondEnabled(ChannelHandle channelHandle, int* invalidSecondEnabled);

/// \brief Set the invalid second state
///
/// Select whether seconds information is invalid in the input timecode
///
/// \param channelHandle The handle to an existing IRIG channel
/// \param enableInvalidSecond true to specify that second is invalid, false otherwise
/// \return The status code
/// \sa UeiDaqIsIRIGInvalidSecondEnabled  
UeiDaqAPI int UeiDaqEnableIRIGTimeKeeperInvalidSecond(ChannelHandle channelHandle, int enableInvalidSecond);

/// \brief Get the invalid minute state
///
/// Select whether minutes information is invalid in the input timecode
///
/// \param channelHandle The handle to an existing IRIG channel
/// \param invalidMinuteEnabled The invalid minute state.
/// \return The status code
/// \sa UeiDaqEnableIRIGInvalidMinute 
UeiDaqAPI int UeiDaqIsIRIGTimeKeeperInvalidMinuteEnabled(ChannelHandle channelHandle, int* invalidMinuteEnabled);

/// \brief Set the invalid minute state
///
/// Select whether minutes information is invalid in the input timecode
///
/// \param channelHandle The handle to an existing IRIG channel
/// \param enableInvalidMinute true to specify that minute is invalid, false otherwise
/// \return The status code
/// \sa UeiDaqIsIRIGInvalidMinuteEnabled  
UeiDaqAPI int UeiDaqEnableIRIGTimeKeeperInvalidMinute(ChannelHandle channelHandle, int enableInvalidMinute);

/// \brief Get the invalid day state
///
/// Select whether days information is invalid in the input timecode
///
/// \param channelHandle The handle to an existing IRIG channel
/// \param invalidDayEnabled The invalid day state.
/// \return The status code
/// \sa UeiDaqEnableIRIGInvalidDay 
UeiDaqAPI int UeiDaqIsIRIGTimeKeeperInvalidDayEnabled(ChannelHandle channelHandle, int* invalidDayEnabled);

/// \brief Set the invalid day state
///
/// Select whether days information is invalid in the input timecode
///
/// \param channelHandle The handle to an existing IRIG channel
/// \param enableInvalidDay true to specify that day is invalid, false otherwise
/// \return The status code
/// \sa IsInvalidIRIGDayEnabled  
UeiDaqAPI int UeiDaqEnableIRIGTimeKeeperInvalidDay(ChannelHandle channelHandle, int enableInvalidDay);

/// \brief Get the time decoder input type
///
/// Get the type of time code connected to the device.
///
/// \param channelHandle The handle to an existing IRIG channel
/// \param input the time decoder input type.
/// \return The status code
/// \sa UeiDaqSetIRIGTimeDecoderInput  
UeiDaqAPI int UeiDaqGetIRIGInputTimeDecoderInput(ChannelHandle channelHandle, tUeiIRIGDecoderInputType* input);

/// \brief Set the time decoder input type
///
/// Set the type of time code/ connected to the device.
///
/// \param channelHandle The handle to an existing IRIG channel
/// \param input the new time decoder type.
/// \return The status code
/// \sa UeiDaqGetIRIGTimeDecoderInput  
UeiDaqAPI int UeiDaqSetIRIGInputTimeDecoderInput(ChannelHandle channelHandle, tUeiIRIGDecoderInputType input);

/// \brief Get the time code format
///
/// Get the time code format used by the signal connected to the device.
///
/// \param channelHandle The handle to an existing IRIG channel
/// \param format the time code format.
/// \return The status code
/// \sa UeiDaqSetIRIGTimeCodeFormat  
UeiDaqAPI int UeiDaqGetIRIGInputTimeCodeFormat(ChannelHandle channelHandle, tUeiIRIGTimeCodeFormat* format);

/// \brief Set the time code format
///
/// Set the time code format used by the signal connected to the device.
///
/// \param channelHandle The handle to an existing IRIG channel
/// \param format the new time code format.
/// \return The status code
/// \sa UeiDaqGetIRIGTimeCodeFormat  
UeiDaqAPI int UeiDaqSetIRIGInputTimeCodeFormat(ChannelHandle channelHandle, tUeiIRIGTimeCodeFormat format);

/// \brief Get the current VR channel input mode. 
///
/// The VR-608 can use four different modes to measure velocity, position or direction 
/// The counting mode can be set to:
/// * Decoder: Even and Odd channels are used in pair to determine direction and position
/// * Timed: Count number of teeth detected during a timed interval
/// * N pulses: Measure the time taken to detect N teeth (Number of teeth needs to be set separately)
/// * Z pulse: Measure the number of teeth and the time elapsed between two Z pulses (The Z tooth is usually a gap or a double tooth on the encoder wheel)
///
/// In decoder mode the settings for the even channel are applied to both even and odd channels.
///
/// \param channelHandle The handle to an existing VR channel
/// \param mode the current VR mode
/// \return The status code
UeiDaqAPI int UeiDaqGetVRMode(ChannelHandle channelHandle, tUeiVRMode* mode);

/// \brief Set the VR channel input mode.
///
/// The VR-608 can use four different modes to measure velocity, position or direction 
/// The counting mode can be set to:
/// * Decoder: Even and Odd channels are used in pair to determine direction and position
/// * Timed: Count number of teeth detected during a timed interval
/// * N pulses: Measure the time taken to detect N teeth (Number of teeth needs to be set separately)
/// * Z pulse: Measure the number of teeth and the time elapsed between two Z pulses (The Z tooth is usually a gap or a double tooth on the encoder wheel) 
///
/// In decoder mode the settings for the even channel are applied to both even and odd channels.
///
/// \param channelHandle The handle to an existing VR channel
/// \param mode the new VR mode
/// \return The status code
UeiDaqAPI int UeiDaqSetVRMode(ChannelHandle channelHandle, tUeiVRMode mode);

/// \brief Get the current zero-crossing mode
///
/// Zero crossing finds the point in time where the VR sensor output voltage goes from positive
/// to negative voltage. This point is when the center of the tooth is lining up with the center
/// of the VR sensor.
///
/// \param channelHandle The handle to an existing VR channel
/// \param mode the current Zero Crossing mode
/// \return The status code
UeiDaqAPI int UeiDaqGetVRZCMode(ChannelHandle channelHandle, tUeiVRZCMode* mode);

/// \brief Set the zero-crossing mode
///
/// Zero crossing finds the point in time where the VR sensor output voltage goes from positive
/// to negative voltage. This point is when the center of the tooth is lining up with the center
/// of the VR sensor.
///
/// \param channelHandle The handle to an existing VR channel
/// \param mode the new zero-crossing mode
/// \return The status code
UeiDaqAPI int UeiDaqSetVRZCMode(ChannelHandle channelHandle, tUeiVRZCMode mode);

/// \brief Get the current adaptive peak threshold mode
///
/// APT finds the point in time where the VR sensor output voltage falls below a certain
/// threshold. This point marks the beginning of the gap between two teeth.
///
/// \param channelHandle The handle to an existing VR channel
/// \param mode the current APT mode
/// \return The status code
UeiDaqAPI int UeiDaqGetVRAPTMode(ChannelHandle channelHandle, tUeiVRAPTMode* mode);

/// \brief Set the adaptive peak threshold mode
///
/// APT finds the point in time where the VR sensor output voltage falls below a certain
/// threshold. This point marks the beginning of the gap between two teeth.
///
/// \param channelHandle The handle to an existing VR channel
/// \param mode the new APT mode
/// \return The status code
UeiDaqAPI int UeiDaqSetVRAPTMode(ChannelHandle channelHandle, tUeiVRAPTMode mode);

/// \brief Get the ADC measurement rate 
///
/// Get the rate at which the VR sensor signal is measured.
///
/// \param channelHandle The handle to an existing VR channel
/// \param rate The current ADC rate.
/// \return The status code
UeiDaqAPI int UeiDaqGetVRADCRate(ChannelHandle channelHandle, double* rate);

/// \brief Set the ADC rate 
///
/// Set the rate at which the VR sensor is measured.
///
/// \param channelHandle The handle to an existing VR channel
/// \param rate The new ADC rate.
/// \return The status code
UeiDaqAPI int UeiDaqSetVRADCRate(ChannelHandle channelHandle, double rate);

/// \brief Get the ADC moving average 
///
/// Get the size of the moving average window applied to the VR sensor signal
/// while it is measured.
///
/// \param channelHandle The handle to an existing VR channel
/// \param mvAvrg The current ADC moving average.
/// \return The status code
UeiDaqAPI int UeiDaqGetVRADCMovingAverage(ChannelHandle channelHandle, int* mvAvrg);

/// \brief Set the ADC moving average 
///
/// Set the size of the moving average window applied to the VR sensor signal
/// while it is measured.
///
/// \param channelHandle The handle to an existing VR channel
/// \param mvAvrg The new ADC moving average.
/// \return The status code
UeiDaqAPI int UeiDaqSetVRADCMovingAverage(ChannelHandle channelHandle, int mvAvrg);

/// \brief Get the APT threshold divider 
///
/// The APT threshold divider is used when APT mode is set to "Logic"
///
/// \param channelHandle The handle to an existing VR channel
/// \param divider The current APT threshold divider.
/// \return The status code
UeiDaqAPI int UeiDaqGetVRAPTThresholdDivider(ChannelHandle channelHandle, int* divider);

/// \brief Set the APT threshold divider 
///
/// The APT threshold divider is used when APT mode is set to "Logic"
///
/// \param channelHandle The handle to an existing VR channel
/// \param divider The new APT threshold divider.
/// \return The status code
UeiDaqAPI int UeiDaqSetVRAPTThresholdDivider(ChannelHandle channelHandle, int divider);

/// \brief Get the APT threshold 
///
/// The APT threshold is used when APT mode is set to "Fixed"
///
/// \param channelHandle The handle to an existing VR channel
/// \param threshold The current APT threshold.
/// \return The status code
UeiDaqAPI int UeiDaqGetVRAPTThreshold(ChannelHandle channelHandle, double* threshold);

/// \brief Set the APT threshold 
///
/// The APT threshold is used when APT mode is set to "Fixed"
///
/// \param channelHandle The handle to an existing VR channel
/// \param threshold The new APT threshold.
/// \return The status code
UeiDaqAPI int UeiDaqSetVRAPTThreshold(ChannelHandle channelHandle, double threshold);

/// \brief Get the ZC level 
///
/// The ZC level is used when ZC mode is set to "Fixed"
///
/// \param channelHandle The handle to an existing VR channel
/// \param level The current ZC level.
/// \return The status code
UeiDaqAPI int UeiDaqGetVRZCLevel(ChannelHandle channelHandle, double* level);

/// \brief Set the ZC level 
///
/// The ZC level is used when ZC mode is set to "Fixed"
///
/// \param channelHandle The handle to an existing VR channel
/// \param level The new ZC level.
/// \return The status code
UeiDaqAPI int UeiDaqSetVRZCLevel(ChannelHandle channelHandle, double level);

/// \brief Get the number of teeth on the encoder wheel 
///
/// The number of teeth on the encoder wheel
///
/// \param channelHandle The handle to an existing VR channel
/// \param numTeeth The current number of teeth.
/// \return The status code
UeiDaqAPI int UeiDaqGetVRNumberOfTeeth(ChannelHandle channelHandle, int* numTeeth);

/// \brief Set the number of teeth on the encoder wheel 
///
/// The number of teeth on the encoder wheel
///
/// \param channelHandle The handle to an existing VR channel
/// \param numTeeth The new number of teeth.
/// \return The status code
UeiDaqAPI int UeiDaqSetVRNumberOfTeeth(ChannelHandle channelHandle, int numTeeth);

/// \brief Get port break before make setting
///
/// Get the current port break before make setting
/// \param channelHandle The handle to a MUX port
/// \param enabled the current break before make
/// \return The status code
UeiDaqAPI int UeiDaqIsMuxBreakBeforeMakeEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Set port break before make setting
///
/// Set the port break before make setting
/// \param channelHandle The handle to a MUX port
/// \param enable true to enable, false otherwise
/// \return The status code
UeiDaqAPI int UeiDaqEnableMuxBreakBeforeMake(ChannelHandle channelHandle, int enable);

/// \brief Get port synchronization input setting
///
/// Get the current port synchronization input setting
/// A MUX device can wait for a pulse on its synchronization input before
/// configuring its relays
/// \param channelHandle The handle to a MUX port
/// \param enabled the current synchronization input
/// \return The status code
UeiDaqAPI int UeiDaqIsMuxSyncInputEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Set port synchronization input setting
///
/// Set the port synchronization input setting
/// A MUX device can wait for a pulse on its synchronization input before
/// configuring its relays
/// \param channelHandle The handle to a MUX port
/// \param enable true to enable, false otherwise
/// \return The status code
UeiDaqAPI int UeiDaqEnableMuxSyncInput(ChannelHandle channelHandle, int enable);

/// \brief Get port synchronization input edge/level setting
///
/// Get the current port synchronization input edge/level setting
/// The sync input can work in level or edge mode
/// \param channelHandle The handle to a MUX port
/// \param enabled the current synchronization input
/// \return The status code
UeiDaqAPI int UeiDaqIsMuxSyncInputEdgeModeEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Set port synchronization input edge/level setting
///
/// Set the port synchronization input edge/level setting
/// The sync input can work in level or edge mode
/// \param channelHandle The handle to a MUX port
/// \param enable true to enable, false otherwise
/// \return The status code
UeiDaqAPI int UeiDaqEnableMuxSyncInputEdgeMode(ChannelHandle channelHandle, int enable);

/// \brief Get port synchronization input edge/level polarity
///
/// Get the current port synchronization input edge/level polarity
/// \param channelHandle The handle to a MUX port
/// \param polarity the current synchronization input polarity
/// \return The status code
UeiDaqAPI int UeiDaqGetMuxSyncInputEdgePolarity(ChannelHandle channelHandle, tUeiDigitalEdge* polarity);

/// \brief Set port synchronization input edge/level polarity
///
/// Set the port synchronization input edge/level polarity
/// \param channelHandle The handle to a MUX port
/// \param polarity the new polarity
/// \return The status code
UeiDaqAPI int UeiDaqSetMuxSyncInputEdgePolarity(ChannelHandle channelHandle, tUeiDigitalEdge polarity);

/// \brief Get port synchronization output mode
///
/// Get the current port synchronization output mode
/// A MUX device can emit a pulse on its synchronization output when
/// configuring its relays
/// \param channelHandle The handle to a MUX port
/// \param mode the current synchronization output mode
/// \return The status code
UeiDaqAPI int UeiDaqGetMuxSyncOutputMode(ChannelHandle channelHandle, tUeiMuxSyncOutputMode* mode);

/// \brief Set port synchronization output mode
///
/// Set the port synchronization output mode
/// A MUX device can emit a pulse on its synchronization output when
/// configuring its relays
/// \param channelHandle The handle to a MUX port
/// \param mode the new synchronization output mode
/// \return The status code
UeiDaqAPI int UeiDaqSetMuxSyncOutputMode(ChannelHandle channelHandle, tUeiMuxSyncOutputMode mode);

/// \brief Get port synchronization output pulse width
///
/// Get the current port synchronization output pulse width in microseconds
/// \param channelHandle The handle to a MUX port
/// \param width the current synchronization output pulse width
/// \return The status code
UeiDaqAPI int UeiDaqGetMuxSyncOutputPulseWidth(ChannelHandle channelHandle, int* width);

/// \brief Set port synchronization output pulse width
///
/// Set the port synchronization output oulse width in microseconds
/// \param channelHandle The handle to a MUX port
/// \param width the new synchronization output pulse width
/// \return The status code
UeiDaqAPI int UeiDaqSetMuxSyncOutputPulseWidth(ChannelHandle channelHandle, int width);

/// \brief Get port on delay
///
/// Get the current port on delay in microseconds
/// \param channelHandle The handle to a MUX port
/// \param delay the current on delay
/// \return The status code
UeiDaqAPI int UeiDaqGetMuxOnDelay(ChannelHandle channelHandle, int* delay);

/// \brief Set port on delay
///
/// Set the port on delay
/// \param channelHandle The handle to a MUX port
/// \param delay the new on delay
/// \return The status code
UeiDaqAPI int UeiDaqSetMuxOnDelay(ChannelHandle channelHandle, int delay);

/// \brief Get port off delay
///
/// Get the current port off delay in microseconds
/// \param channelHandle The handle to a MUX port
/// \param delay the current off delay
/// \return The status code
UeiDaqAPI int UeiDaqGetMuxOffDelay(ChannelHandle channelHandle, int* delay);

/// \brief Set port on delay
///
/// Set the port off delay
/// \param channelHandle The handle to a MUX port
/// \param delay the new off delay
/// \return The status code
UeiDaqAPI int UeiDaqSetMuxOffDelay(ChannelHandle channelHandle, int delay);

/// \brief Get the I2C bus bit rate
///
/// Get the I2C bus bit rate
/// \param channelHandle The handle to an I2C slave or master port
/// \param bitRate The current I2C bus bit rate
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CSpeed(ChannelHandle channelHandle, tUeiI2CPortSpeed* bitRate);

/// \brief Set the I2C bus bit rate
///
/// Set the I2C bus bit rate
///
/// \param channelHandle The handle to an I2C slave or master port
/// \param bitRate The new I2C bus bit rate
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CSpeed(ChannelHandle channelHandle, tUeiI2CPortSpeed bitRate);

/// \brief Get the I2C bus custom bit rate
///
/// Get the I2C bus custom bit rate
/// \param channelHandle The handle to an I2C slave or master port
/// \param bitRate The current I2C bus custom bit rate
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CCustomSpeed(ChannelHandle channelHandle, float* bitRate);

/// \brief Set the I2C bus custom bit rate
///
/// Set the I2C bus custom bit rate
///
/// \param channelHandle The handle to an I2C slave or master port
/// \param bitRate The new I2C bus custom bit rate
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CCustomSpeed(ChannelHandle channelHandle, float bitRate);

/// \brief Get the I2C bus TTL level
///
/// Get the I2C bus TTL level
///
/// \param channelHandle The handle to an I2C slave or master port
/// \param ttlLevel The current I2C bus TTL level
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CTTLLevel(ChannelHandle channelHandle, tUeiI2CTTLLevel* ttlLevel);

/// \brief Set the I2C bus TTL level
///
/// Set the I2C bus TTL level
///
/// \param channelHandle The handle to an I2C slave or master port
/// \param ttlLevel The new I2C bus TTL level
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CTTLLevel(ChannelHandle channelHandle, tUeiI2CTTLLevel ttlLevel);

/// \brief Get the I2C secure shell setting
///
/// Get the I2C secure shell setting
///
/// \param channelHandle The handle to an I2C master port
/// \param enabled The current I2C secure shell setting
/// \return The status code
UeiDaqAPI int UeiDaqIsI2CMasterSecureShellEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Set the I2C secure shell setting
///
/// Set the I2C secure shell setting
///
/// \param channelHandle The handle to an I2C master port
/// \param enable The new I2C secure shell setting
/// \return The status code
UeiDaqAPI int UeiDaqEnableI2CMasterSecureShell(ChannelHandle channelHandle, int enable);

/// \brief Get the I2C multi-master setting
///
/// Get the I2C multi-master setting
///
/// \param channelHandle The handle to an I2C master port
/// \param enabled The current I2C multi-master setting
/// \return The status code
UeiDaqAPI int UeiDaqIsI2CMultiMasterEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Set the I2C multi-master setting
///
/// Set the I2C multi-master setting
///
/// \param channelHandle The handle to an I2C master port
/// \param enable The new I2C multi-master setting
/// \return The status code
UeiDaqAPI int UeiDaqEnableI2CMultiMaster(ChannelHandle channelHandle, int enable);

/// \brief Get the I2C termination resistor setting
///
/// Get the I2C termination resistor setting
///
/// \param channelHandle The handle to an I2C master port
/// \param resistance The current I2C termination resistor setting
/// \return The status code
UeiDaqAPI int UeiDaqIsI2CMasterTerminationResistorEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Set the I2C termination resistor setting
///
/// Set the I2C termination resistor setting
///
/// \param channelHandle The handle to an I2C master port
/// \param resistance The new I2C termination resistor setting
/// \return The status code
UeiDaqAPI int UeiDaqEnableI2CMasterTerminationResistor(ChannelHandle channelHandle, int enable);

/// \brief Get the I2C loopback mode
///
/// Get the I2C loopback setting
///
/// \param channelHandle The handle to an I2C master port
/// \param mode The current I2C loopback mode
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CMasterLoopbackMode(ChannelHandle channelHandle, tUeiI2CLoopback* mode);

/// \brief Set the I2C loopback mode
///
/// Set the I2C loopback mode
///
/// \param channelHandle The handle to an I2C master port
/// \param mode The new I2C loopback mode
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CMasterLoopbackMode(ChannelHandle channelHandle, tUeiI2CLoopback mode);

/// \brief Get the delay in microseconds that the master will delay between bytes
///
/// Get the delay in microseconds that the master will delay between sending bytes
///
/// \param channelHandle The handle to an I2C master port
/// \param delayUs the current delay in microseconds
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CMasterByteToByteDelay(ChannelHandle channelHandle, uInt16* delayUs);

/// \brief Set the delay in microseconds that the master will delay between bytes
///
/// Set the delay in microseconds that the master will delay between sending bytes.
///
/// \param channelHandle The handle to an I2C master port
/// \param delayUs the new delay in microseconds
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CMasterByteToByteDelay(ChannelHandle channelHandle, uInt16 delayUs);

/// \brief Get the time in microseconds that the master will allow a slave to delay the clock
///
/// Get the time in microseconds that the master will allow a slave to delay the clock
///
/// \param channelHandle The handle to an I2C master port
/// \param delayUs current the time in microseconds
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CMasterMaxClockStretchingDelay(ChannelHandle channelHandle, uInt16* delayUs);

/// \brief Set the delay in microseconds that the master will allow a slave to delay the clock
///
/// Set the delay in microseconds that the master will allow a slave to delay the clock
///
/// \param channelHandle The handle to an I2C master port
/// \param delayUs the new delay in microseconds
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CMasterMaxClockStretchingDelay(ChannelHandle channelHandle, uInt16 delayUs);

/// \brief Get the I2C slave address width
///
/// Get the I2C slave address width
///
/// \param channelHandle The handle to an I2C slave port
/// \param width The current I2C slave address width
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CSlaveAddressWidth(ChannelHandle channelHandle, tUeiI2CSlaveAddressWidth* width);

/// \brief Set the I2C slave address width
///
/// Set the I2C slave address width
///
/// \param channelHandle The handle to an I2C slave port
/// \param width The new I2C slave address width
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CSlaveAddressWidth(ChannelHandle channelHandle, tUeiI2CSlaveAddressWidth width);

/// \brief Get the I2C slave address
///
/// Get the I2C slave address
///
/// \param channelHandle The handle to an I2C slave port
/// \param address The current I2C slave address
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CSlaveAddress(ChannelHandle channelHandle, int* address);

/// \brief Set the I2C slave address
///
/// Set the I2C slave address
///
/// \param channelHandle The handle to an I2C slave port
/// \param address The new I2C slave address
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CSlaveAddress(ChannelHandle channelHandle, int address);

/// \brief Get the I2C bus monitor setting
///
/// Get the I2C bus monitor setting
///
/// \param channelHandle The handle to an I2C slave port
/// \param enabled The current I2C bus monitor setting
/// \return The status code
UeiDaqAPI int UeiDaqIsI2CSlaveBusMonitorEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Set the I2C bus monitor setting
///
/// Set the I2C bus monitor setting
///
/// \param channelHandle The handle to an I2C slave port
/// \param enable The new I2C bus monitor setting
/// \return The status code
UeiDaqAPI int UeiDaqEnableI2CSlaveBusMonitor(ChannelHandle channelHandle, int enable);

/// \brief Get the I2C bus monitor ACK setting
///
/// Get the I2C bus monitor ACK setting
///
/// \param channelHandle The handle to an I2C slave port
/// \param enabled The current I2C bus monitor ACK setting
/// \return The status code
UeiDaqAPI int UeiDaqIsI2CSlaveBusMonitorAckEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Set the I2C bus monitor ACK setting
///
/// Set the I2C bus monitor ACK setting
///
/// \param channelHandle The handle to an I2C slave port
/// \param enable The new I2C bus monitor ACK setting
/// \return The status code
UeiDaqAPI int UeiDaqEnableI2CSlaveBusMonitorAck(ChannelHandle channelHandle, int enable);

/// \brief Get slave transmit data mode
///
/// Get slave transmit data mode
///
/// \param channelHandle The handle to an I2C slave port
/// \param dataMode the slave transmit data mode
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CSlaveTransmitDataMode(ChannelHandle channelHandle, tUeiI2CSlaveDataMode* dataMode);

/// \brief Set slave transmit data mode
///
/// Set slave transmit data mode
///
/// \param channelHandle The handle to an I2C slave port
/// \param dataMode the new slave transmit data mode
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CSlaveTransmitDataMode(ChannelHandle channelHandle, tUeiI2CSlaveDataMode dataMode);

/// \brief Get data transmitted when in Register mode or padding data when in FIFO mode
///
/// Get data transmitted when in Register mode or padding data when in FIFO mode.
///
/// \param channelHandle The handle to an I2C slave port
/// \param byteIndex Index of the byte to get, 0-3
/// \param data The current byte data
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CSlaveRegisterData(ChannelHandle channelHandle, int byteIndex, uInt8* data);

/// \brief Set the I2C slave padding data
///
/// Set the I2C slave padding data
///
/// \param channelHandle The handle to an I2C slave port
/// \param byteIndex Index of the byte to set, 0-3
/// \param data The new byte data
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CSlaveRegisterData(ChannelHandle channelHandle, int byteIndex, uInt8 data);


/// \brief Get the number of bytes used in slave data when in Register data mode
///
/// Get the number of bytes used in slave data when in Register data mode.
///
/// \param channelHandle The handle to an I2C master port
/// \param size the number of bytes used in slave data when in Register data mode
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CSlaveRegisterDataSize(ChannelHandle channelHandle, int* size);

/// \brief Set the number of bytes used in slave data when in Register data mode
///
/// Set the number of bytes used in slave data when in Register data mode.
///
/// \param channelHandle The handle to an I2C master port
/// \param size the new number of bytes used in slave data when in Register data mode
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CSlaveRegisterDataSize(ChannelHandle channelHandle, int size);

/// \brief Get maximum number of words slave will receive per transmission
///
/// Get maximum number of words slave will receive per transmission
///
/// \param channelHandle The handle to an I2C master port
/// \param maxWords the maximum number of words slave will receive per transmission
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CSlaveMaxWordsPerAck(ChannelHandle channelHandle, int* maxWords);

/// \brief Set maximum number of words slave will receive per transmission
///
/// Set maximum number of words slave will receive per transmission
///
/// \param channelHandle The handle to an I2C master port
/// \param maxWords the new maximum number of words slave will receive per transmission
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CSlaveMaxWordsPerAck(ChannelHandle channelHandle, int maxWords);

/// \brief Get the number of clocks the slave will delay an ACK
///
/// Get the delay in 15ns clock increments that the slave will delay an ACK.
/// The clock stretching delay must also be individually enabled for address, transmit,
/// and receive cycles. Max clock stretching delay is ~62ms.
///
/// \param channelHandle The handle to an I2C master port
/// \param clocks the delay in clocks
/// \return The status code
UeiDaqAPI int UeiDaqGetI2CSlaveClockStretchingDelay(ChannelHandle channelHandle, uInt16* clocks);

/// \brief Get the number of clocks the slave will delay an ACK
///
/// Get the delay in 15ns clock increments that the slave will delay an ACK.
/// The clock stretching delay must also be individually enabled for address, transmit,
/// and receive cycles. Max clock stretching delay is ~62ms.
///
/// \param channelHandle The handle to an I2C master port
/// \param clocks the delay in clocks
/// \return The status code
UeiDaqAPI int UeiDaqSetI2CSlaveClockStretchingDelay(ChannelHandle channelHandle, uInt16 clocks);

/// \brief Query the status of clock stretching during address cycle
///
/// Query the status of clock stretching during address cycle.
///
/// \param channelHandle The handle to an I2C master port
/// \param enabled the status of clock stretching during address cycle.
/// \return The status code
UeiDaqAPI int UeiDaqIsI2CSlaveAddressClockStretchingEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Enable clock stretching during address cycle
///
/// Enable clock stretching during address cycle.
///
/// \param channelHandle The handle to an I2C master port
/// \param enable the new clock stretching during address cycle state
/// \return The status code
UeiDaqAPI int UeiDaqEnableI2CSlaveAddressClockStretching(ChannelHandle channelHandle, int enable);

/// \brief Query the status of clock stretching during transmit cycle
///
/// Query the status of clock stretching during transmit cycle.
///
/// \param channelHandle The handle to an I2C master port
/// \param enabled the status of clock stretching during transmit cycle.
/// \return The status code
UeiDaqAPI int UeiDaqIsI2CSlaveTransmitClockStretchingEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Enable clock stretching during transmit cycle
///
/// Enable clock stretching during transmit cycle.
///
/// \param channelHandle The handle to an I2C master port
/// \param enable the new clock stretching during transmit cycle state
/// \return The status code
UeiDaqAPI int UeiDaqEnableI2CSlaveTransmitClockStretching(ChannelHandle channelHandle, int enable);

/// \brief Query the status of clock stretching during receive cycle
///
/// Query the status of clock stretching during receive cycle.
///
/// \param channelHandle The handle to an I2C master port
/// \param enabled the status of clock stretching during receive cycle.
/// \return The status code
UeiDaqAPI int UeiDaqIsI2CSlaveReceiveClockStretchingEnabled(ChannelHandle channelHandle, int* enabled);

/// \brief Enable clock stretching during receive cycle
///
/// Enable clock stretching during receive cycle.
///
/// \param channelHandle The handle to an I2C master port
/// \param enable the new clock stretching during receive cycle state
/// \return The status code
UeiDaqAPI int UeiDaqEnableI2CSlaveReceiveClockStretching(ChannelHandle channelHandle, int enable);

/// \brief Get the FIR cutoff frequency
///
/// Get the FIR cutoff frequency
///
/// \param channelHandle The handle to a DMM channel
/// \param frequency The current cutoff frequency setting
/// \return The status code
UeiDaqAPI int UeiDaqGetDMMFIRCutoff(ChannelHandle channelHandle, tUeiDMMFIRCutoff* frequency);

/// \brief Set the FIR cutoff frequency
///
/// Set the FIR cutoff frequency
///
/// \param channelHandle The handle to a DMM channel
/// \param frequency The new cutoff frequency setting
/// \return The status code
UeiDaqAPI int UeiDaqSetDMMFIRCutoff(ChannelHandle channelHandle, tUeiDMMFIRCutoff frequency);

/// \brief Get the FIR decimation rate
///
/// Get the FIR decimation rate
///
/// \param channelHandle The handle to a DMM channel
/// \param decimation The current decimation rate setting
/// \return The status code
//UeiDaqAPI int UeiDaqGetDMMFIRDecimation(ChannelHandle channelHandle, int* decimation);

/// \brief Set the FIR decimation rate
///
/// Set the FIR decimation rate
///
/// \param channelHandle The handle to a DMM channel
/// \param decimation The new decimation rate setting
/// \return The status code
//UeiDaqAPI int UeiDaqSetDMMFIRDecimation(ChannelHandle channelHandle, int decimation);

/// \brief Get the number of scans to read at a time
///
/// Get the number of scans to read at a time
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param numScans The returned number of scans.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle
UeiDaqAPI int UeiDaqGetDataStreamNumberOfScans(DataStreamHandle dataStreamHandle, Int32* numScans);

/// \brief Set the number of scans to read at a time
///
/// Set the number of scans to read at a time
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param numScans The number of scans.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle
UeiDaqAPI int UeiDaqSetDataStreamNumberOfScans(DataStreamHandle dataStreamHandle, Int32 numScans);

/// \brief Get the size of a scan
///
/// Get the size of a scan, usually equal to the number
/// of channels in the session's channel list.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param scanSize The returned number of scans.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqGetDataStreamScanSize(DataStreamHandle dataStreamHandle, Int32* scanSize);

/// \brief Set the size of a scan
///
/// Set the size of a scan, usually equal to the number
/// of channels in the session's channel list.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param scanSize The number of scans.
/// \return The status code
/// \sa UeiDaqGetDatastreamHandle.
UeiDaqAPI int UeiDaqSetDataStreamScanSize(DataStreamHandle dataStreamHandle, Int32 scanSize);

/// \brief Get the size of a raw sample
///
/// Get the size of a raw sample in bytes.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param sampleSize The returned sample size.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqGetDataStreamSampleSize(DataStreamHandle dataStreamHandle, Int32* sampleSize);

/// \brief Get the number of frames
///
/// Get the number of frames. Each frame is accessed
/// independently by the device.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param numFrames The returned number of frames.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqGetDataStreamNumberOfFrames(DataStreamHandle dataStreamHandle, Int32* numFrames);

/// \brief Set the number of frames
///
/// Set the number of frames. Each frame is accessed
/// independently by the device.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param numFrames The number of frames.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqSetDataStreamNumberOfFrames(DataStreamHandle dataStreamHandle, Int32 numFrames);

/// \brief Get the regenerate setting
///
/// Get the parameter that determines whether the output device
/// continuously regenerate the first buffer it received.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param regenerate The regenerate setting.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqGetDataStreamRegenerate(DataStreamHandle dataStreamHandle, Int32* regenerate);

/// \brief Set the regenerate setting
///
/// Specifies whether the output device will continuously regenerate
/// the first buffer it received.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param regenerate The regenerate setting.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqSetDataStreamRegenerate(DataStreamHandle dataStreamHandle, Int32 regenerate);

/// \brief Get the burst setting
///
/// Get the parameter that determines whether the input device
/// should acquire all the requested data in its internal memory
/// before transferring it to the host PC.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param pBurst the current burst setting value.
/// \sa UeiDaqSetDataStreamBurst
UeiDaqAPI int UeiDaqGetDataStreamBurst(DataStreamHandle dataStreamHandle, Int32* pBurst);

/// \brief Set the burst setting
///
/// Specifies whether the input device will acquire all the
/// requested data in its internal memory before transferring
/// it to the host PC.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param burst the new burst setting value.
/// \return The status code
/// \sa UeiDaqGetDataStreamBurst
UeiDaqAPI int UeiDaqSetDataStreamBurst(DataStreamHandle dataStreamHandle, Int32 burst);

/// \brief Get the Overrun/underrun setting
///
/// For an input session, Determines whether the device overwrite
/// acquired data if it was not read fast enough.
/// For an output session, Determines whether the device regenerate
/// previously generated data if it didn't receive new data fast enough.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param overunderrun The returned overrun/underrun setting.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqGetDataStreamOverUnderRun(DataStreamHandle dataStreamHandle, Int32* overunderrun);

/// \brief Set the Overrun/underrun setting
///
/// For an input session, Specifies whether the device overwrite
/// acquired data if it was not read fast enough.
/// For an output session, Specifies whether the device regenerate
/// previously generated data if it didn't receive new data fast enough.
/// If overUnderRun is set to 1, the framework ignore the overrun or underrun
/// condition. If it is set to 0 an exception is thrown.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param overunderrun The overrun/underrun setting.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqSetDataStreamOverUnderRun(DataStreamHandle dataStreamHandle, Int32 overunderrun);

/// \brief Get the value of the blocking setting  
///
/// When enabled, read operations will block until the requested amount
/// of data is received from the device.
/// when disabled, read operations return immediately with the amount
/// of data available.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param enabled the blocking setting value.
/// \return The status code
UeiDaqAPI int UeiDaqIsDataStreamBlockingEnabled(DataStreamHandle dataStreamHandle, Int32* enabled);

/// \brief Set the value of the blocking setting
///
/// When enabled, read operations will block until the requested amount
/// of data is received from the device.
/// when disabled, read operations return immediately with the amount
/// of data available.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param blocking the blocking setting value.
/// \return The status code
UeiDaqAPI int UeiDaqEnableDataStreamBlocking(DataStreamHandle dataStreamHandle, Int32 enable);

/// \brief Get the current scan position
///
/// Get the latest acquired scan position in the
/// acquisition buffer.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param currentScan The returned current scan position.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqGetDataStreamCurrentScan(DataStreamHandle dataStreamHandle, Int32* currentScan);

/// \brief Get the number of available scans
///
/// Get the number of scans ready to be read or written
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param availableScans The returned number of available scans.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqGetDataStreamAvailableScans(DataStreamHandle dataStreamHandle, Int32* availableScans);


/// \brief Get the total number of scans
///
/// Get the total number of scans read or written since
/// the session started.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param totalScans The returned number of total scans.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqGetDataStreamTotalScans(DataStreamHandle dataStreamHandle, Int32* totalScans);


/// \brief Change the pointer position
///
/// Move the position of the next scan to read or write.
/// The offset is relative to the reference specified with SetRelativeTo().
/// Use a negative offset to read or write scans below the reference position.
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param offset The new offset.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqSetDataStreamOffset(DataStreamHandle dataStreamHandle, Int32 offset);

/// \brief Get the reference of the offset
///
/// Get the position used as a reference in the framework's internal buffer
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param relativeTo The returned reference.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqGetDataStreamRelativeTo(DataStreamHandle dataStreamHandle, tUeiDataStreamRelativeTo* relativeTo);

/// \brief Set the reference of the offset
///
/// Set the position to use as a reference in the framework's internal buffer
///
/// \param dataStreamHandle The handle to an existing data stream
/// \param relativeTo The new reference.
/// \return The status code
/// \sa UeiDaqGetDataStreamHandle.
UeiDaqAPI int UeiDaqSetDataStreamRelativeTo(DataStreamHandle dataStreamHandle, tUeiDataStreamRelativeTo relativeTo);

/// \brief Get the device name
///
/// Get the name from the device database
///
/// \param deviceHandle The handle to an existing device
/// \param deviceName A string to contain the returned device name.
/// \param deviceNameLength The length of the string, on function return contains the number of characters copied. If deviceName is NULL, deviceNameLength contains the required length for deviceName
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceName(DeviceHandle deviceHandle, char* deviceName, int* deviceNameLength);


/// \brief Get the serial number
///
/// Get the serial number from the device EEPROM
///
/// \param deviceHandle The handle to an existing device
/// \param serialNumber A string to contain the returned device serial number.
/// \param serialNumberLength The length of the string, on function return contains the number of characters copied. If serialNumber is NULL, serialNumberLength contains the required length for serialNumber
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceSerialNumber(DeviceHandle deviceHandle, char* serialNumber, int* serialNumberLength);

/// \brief Get the index
///
/// Get the index of this device in the device class
///
/// \param deviceHandle The handle to an existing device
/// \param index The returned device index
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceIndex(DeviceHandle deviceHandle, Int32* index);

/// \brief Get the number of Analog Input differential channels
///
/// Get the number of Analog Input differential channels
///
/// \param deviceHandle The handle to an existing device
/// \param numChannels The returned number of Analog Input differential channels
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfAIDifferentialChannels(DeviceHandle deviceHandle, Int32* numChannels);

/// \brief Get the number of Analog Input single-ended channels
///
/// Get the number of Analog Input single-ended channels
///
/// \param deviceHandle The handle to an existing device
/// \param numChannels The returned number of Analog Input single-ended channels
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfAISingleEndedChannels(DeviceHandle deviceHandle, Int32* numChannels);

/// \brief Get the number of Analog Outout channels
///
/// Get the number of Analog Output channels
///
/// \param deviceHandle The handle to an existing device
/// \param numChannels The returned number of Analog Outout channels
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfAOChannels(DeviceHandle deviceHandle, Int32* numChannels);


/// \brief Get the number of Digital Input channels
///
/// Get the number of Digital Input channels
///
/// \param deviceHandle The handle to an existing device
/// \param numChannels The returned number of Digital Input channels
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfDIChannels(DeviceHandle deviceHandle, Int32* numChannels);


/// \brief Get the number of Digital Output channels
///
/// Get the number of Digital Output channels
///
/// \param deviceHandle The handle to an existing device
/// \param numChannels The returned number of Digital Output channels
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfDOChannels(DeviceHandle deviceHandle, Int32* numChannels);


/// \brief Get the number of Counter Input channels
///
/// Get the number of Counter Input channels
///
/// \param deviceHandle The handle to an existing device
/// \param numChannels The returned number of Counter Input channels
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfCIChannels(DeviceHandle deviceHandle, Int32* numChannels);


/// \brief Get the number of Counter Output channels
///
/// Get the number of Counter Output channels
///
/// \param deviceHandle The handle to an existing device
/// \param numChannels The returned number of Counter Output channels
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfCOChannels(DeviceHandle deviceHandle, Int32* numChannels);

/// \brief Get the number of serial ports
///
/// Get the number of serial ports
///
/// \param deviceHandle The handle to an existing device
/// \param numSerialPorts The returned number of serial ports
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfSerialPorts(DeviceHandle deviceHandle, Int32* numSerialPorts);

/// \brief Get the number of synchronous serial ports
///
/// Get the number of synchronous serial ports
///
/// \param deviceHandle The handle to an existing device
/// \param numSynchronousSerialPorts The returned number of serial ports
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfSynchronousSerialPorts(DeviceHandle deviceHandle, Int32* numSynchronousSerialPorts);

/// \brief Get the number of CAN ports
///
/// Get the number of CAN ports
///
/// \param deviceHandle The handle to an existing device
/// \param numCANPorts The returned number of CAN ports
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfCANPorts(DeviceHandle deviceHandle, Int32* numCANPorts);

/// \brief Get the number of ARINC-429 input ports
///
/// Get the number of ARINC-429 input ports
///
/// \param deviceHandle The handle to an existing device
/// \param numARINCInputPorts The returned number of ARINC-429 input ports
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfARINCInputPorts(DeviceHandle deviceHandle, Int32* numARINCInputPorts);

/// \brief Get the number of ARINC-429 output ports
///
/// Get the number of ARINC-429 output ports
///
/// \param deviceHandle The handle to an existing device
/// \param numARINCOutputPorts The returned number of ARINC-429 output ports
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceNumberOfARINCOutputPorts(DeviceHandle deviceHandle, Int32* numARINCOutputPorts);

/// \brief Get the low ranges
///
/// Get the low values for specifed AI subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param type The session type
/// \param subsystem The index of the subsystem (for devices with multiple sub-systems)
/// \param numValues The values array capacity as input, actual number of values copied as output
/// \param lowValues Array containing the low range values
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceLowRanges(DeviceHandle deviceHandle, tUeiSessionType type, int subsystem, Int32* numValues, double* lowValues);

/// \brief Get the high ranges
///
/// Get the high values for specifed AI subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param type The session type
/// \param subsystem The index of the subsystem (for devices with multiple sub-systems)
/// \param numValues The values array capacity as input, actual number of values copied as output
/// \param highValues Array containing the high range values
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceHighRanges(DeviceHandle deviceHandle, tUeiSessionType type, int subsystem, Int32* numValues, double* highValues);

/// \brief Get the maximum AI rate
///
/// Get the maximum rate of the Analog Input subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param maxRate The returned maximum Analog Input rate
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceMaxAIRate(DeviceHandle deviceHandle, Int32* maxRate);

/// \brief Get the maximum AO rate
///
/// Get the maximum rate of the Analog Output subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param maxRate The returned maximum Analog Output rate
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceMaxAORate(DeviceHandle deviceHandle, Int32* maxRate);


/// \brief Get the maximum DI rate
///
/// Get the maximum rate of the Digital Input subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param maxRate The returned maximum Digital Input rate
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceMaxDIRate(DeviceHandle deviceHandle, Int32* maxRate);


/// \brief Get the maximum DO rate
///
/// Get the maximum rate of the Digital Output subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param maxRate The returned maximum Digital Output rate
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceMaxDORate(DeviceHandle deviceHandle, Int32* maxRate);


/// \brief Get the maximum CI rate
///
/// Get the maximum rate of the Counter Input subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param maxRate The returned maximum Counter Input rate
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceMaxCIRate(DeviceHandle deviceHandle, Int32* maxRate);


/// \brief Get the maximum CO rate
///
/// Get the maximum rate of the Counter Output subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param maxRate The returned maximum Counter Output rate
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceMaxCORate(DeviceHandle deviceHandle, Int32* maxRate);


/// \brief Get the AI resolution
///
/// Get the resolution of the Analog Input subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param resolution The returned Analog Input resolution
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceAIResolution(DeviceHandle deviceHandle, Int32* resolution);


/// \brief Get the AO resolution
///
/// Get the resolution of the Analog Output subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param resolution The returned Analog Output resolution
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceAOResolution(DeviceHandle deviceHandle, Int32* resolution);

/// \brief Get the DI resolution
///
/// Get the resolution of the Digital Input subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param resolution The returned Digital Input resolution
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceDIResolution(DeviceHandle deviceHandle, Int32* resolution);

/// \brief Get the DO resolution
///
/// Get the resolution of the Digital Output subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param resolution The returned Digital Output resolution
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceDOResolution(DeviceHandle deviceHandle, Int32* resolution);

/// \brief Get the CI resolution
///
/// Get the resolution of the Counter/Timer Input subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param resolution The returned Counter Input resolution
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceCIResolution(DeviceHandle deviceHandle, Int32* resolution);

/// \brief Get the CO resolution
///
/// Get the resolution of the Counter/Timer Output subsystem
///
/// \param deviceHandle The handle to an existing device
/// \param resolution The returned Timer Output resolution
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceCOResolution(DeviceHandle deviceHandle, Int32* resolution);

/// \brief Get the AI data size
///
/// Get the number of bytes needed to store each Analog input sample
///
/// \param deviceHandle The handle to an existing device
/// \param dataSize The number of bytes per sample
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceAIDataSize(DeviceHandle deviceHandle, Int32* dataSize);

/// \brief Get the AI data size
///
/// Get the number of bytes needed to store each Analog output sample
///
/// \param deviceHandle The handle to an existing device
/// \param dataSize The number of bytes per sample
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceAODataSize(DeviceHandle deviceHandle, Int32* dataSize);

/// \brief Get the AI data size
///
/// Get the number of bytes needed to store each Digital input sample
///
/// \param deviceHandle The handle to an existing device
/// \param dataSize The number of bytes per sample
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceDIDataSize(DeviceHandle deviceHandle, Int32* dataSize);

/// \brief Get the AI data size
///
/// Get the number of bytes needed to store each Digital output sample
///
/// \param deviceHandle The handle to an existing device
/// \param dataSize The number of bytes per sample
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceDODataSize(DeviceHandle deviceHandle, Int32* dataSize);

/// \brief Get the AI data size
///
/// Get the number of bytes needed to store each counter input sample
///
/// \param deviceHandle The handle to an existing device
/// \param dataSize The number of bytes per sample
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceCIDataSize(DeviceHandle deviceHandle, Int32* dataSize);

/// \brief Get the AI data size
///
/// Get the number of bytes needed to store each counter output sample
///
/// \param deviceHandle The handle to an existing device
/// \param dataSize The number of bytes per sample
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceCODataSize(DeviceHandle deviceHandle, Int32* dataSize);

/// \brief Check if the device supports simultaneous sampling
///
/// Check if the device can do simultaneous analog input sampling
///
/// \param deviceHandle The handle to an existing device
/// \param simultaneous Set to 1 if the device supports simultaneous analog input
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceAISimultaneous(DeviceHandle deviceHandle, Int32* simultaneous);

/// \brief Check if the device supports simultaneous update
///
/// Check if the device can do simultaneous analog output update
///
/// \param deviceHandle The handle to an existing device
/// \param simultaneous Set to 1 if the device supports simultaneous analog output
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceAOSimultaneous(DeviceHandle deviceHandle, Int32* simultaneous);

/// \brief Get the size of the input FIFO
///
/// Get the size of the input FIFO in number of samples
///
/// \param deviceHandle The handle to an existing device
/// \param inputFIFOSize the number of samples that can be stored in the input FIFO
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceInputFIFOSize(DeviceHandle deviceHandle, Int32* inputFIFOSize);

/// \brief Get the size of the output FIFO
///
/// Get the size of the output FIFO in number of samples
///
/// \param deviceHandle The handle to an existing device
/// \param outputFIFOSize the number of samples that can be stored in the output FIFO
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceOutputFIFOSize(DeviceHandle deviceHandle, Int32* outputFIFOSize);

/// \brief Check if the device supports output regeneration
///
/// Check if the device supports output regeneration
///
/// \param deviceHandle The handle to an existing device
/// \param canRegenerate set to 1 if the device can regenerate on its analog outputs
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceCanRegenerate(DeviceHandle deviceHandle, Int32* canRegenerate);

/// \brief Check if the device digital ports are bidirectional
///
/// Check if the device digital ports are bidirectional
///
/// \param deviceHandle The handle to an existing device
/// \param isBidirectional set to 1 if the device's digital ports are bidirectional
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceBidirectionalDigitalPorts(DeviceHandle deviceHandle, Int32* isBidirectional);

/// \brief Check if the device supports digital filtering (debouncing)
///
/// Check if the device supports digital filtering on its
/// Counter/timer inputs
///
/// \param deviceHandle The handle to an existing device
/// \param digitalFiltering set to 1 if the device has digital FIR filters
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceSupportsDigitalFiltering(DeviceHandle deviceHandle, Int32* digitalFiltering);

/// \brief Get the device hardware information
///
/// Get a string containing low-level information about the device
///
/// \param deviceHandle The handle to an existing device
/// \param info the hardware information string
/// \param infoLength The length of the info string, on function return contains the number of characters copied. If info is NULL, infoLength contains the required length for info
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceHardwareInformation(DeviceHandle deviceHandle, char* info, int* infoLength);

/// \brief Get the device status information
///
/// Get a string containing low-level information about the device status
///
/// \param deviceHandle The handle to an existing device
/// \param status the hardware information string
/// \param statusLength The length of the info string, on function return contains the number of characters copied. If info is NULL, infoLength contains the required length for info
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceStatus(DeviceHandle deviceHandle, char* status, int* statusLength);

/// \brief Read Device EEPROM
///
/// Read the device EEPROM content. EEPROM contains informations
/// such as Manufacture date, calibration date and calibration data
/// The EEPROM content is returned as an opaque array of bytes.
/// Each device has a unique way of storing informations in its EEPROM
/// and it is up to the calling application to interpret its content.
///
/// Some devices have multiple EEPROM areas. Use the bank parameter to
/// specify which EEPROM you wish to read from
///
/// \param deviceHandle The handle to an existing device
/// \param bank The EEPROM bank to read from
/// \param subSystem The sub-system to read from
/// \param buffer Buffer big enough to store the EEPROM content
/// \param size The number of bytes read
/// \param area The area to access in the EEPROM
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqReadDeviceEEPROM(DeviceHandle deviceHandle, int bank, int subSystem, uInt8* buffer, int* size, tUeiEEPROMArea area);

/// \brief Write Device EEPROM
///
/// Write the device EEPROM content. EEPROM contains informations
/// such as Manufacture date, calibration date and calibration data
/// The EEPROM content is sent as an opaque array of bytes.
/// Each device has a unique way of storing informations in its EEPROM
/// and it is up to the calling application to prepare the buffer to
/// match the EERPROM structure.
///
/// Some devices have multiple EEPROM areas. Use the bank parameter to
/// specify which EEPROM you wish to write to
///
/// \param deviceHandle The handle to an existing device
/// \param bank The EEPROM bank to write to
/// \param subSystem The sub-system to write to
/// \param size The number of bytes to write
/// \param buffer Buffer containing the new EEPROM content
/// \param area The area to access in the EEPROM
/// \param saveEEPROM True to commit changes to EEPROM
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqWriteDeviceEEPROM(DeviceHandle deviceHandle, int bank, int subSystem, int size, uInt8* buffer, tUeiEEPROMArea area, int saveEEPROM);

/// \brief Read Device register
///
/// Read a device register as a 32 bits value.
///
/// \param deviceHandle The handle to an existing device
/// \param offset Offset of the register relative to device's base address
/// \param value The register content
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqReadDeviceRegister32(DeviceHandle deviceHandle, uInt32 offset, uInt32* value);

/// \brief Write Device register
///
/// Write a device register as a 32 bits value.
///
/// \param deviceHandle The handle to an existing device
/// \param offset Offset of the register relative to device's base address
/// \param value The value to write to the register
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqWriteDeviceRegister32(DeviceHandle deviceHandle, uInt32 offset, uInt32 value);

/// \brief Performs a write and read of multiple values into the address space of the Device.
/// 
/// \param deviceHandle The handle to an existing device
/// \param writeAddr Start of address offset that will be written to. Length determined by writeData.Length.
/// \param writeSize Number of 32-bit values to write to Device.
/// \param writeData Buffer containing data to be written, up to 361 elements.
/// \param readAddr Start of address offset that will be read from.
/// \param readSize Number of 32-bit values to read from Device.
/// \param readData Buffer to store data read from the device, up to 361 elements.
/// \param doReadFirst Perform the read before the write.
/// \param noIncrement Does not increment to next address (useful for FIFOs).
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqWriteReadDeviceRegisters32(DeviceHandle deviceHandle, uInt32 writeAddr, uInt32 writeSize, uInt32* writeData, uInt32 readAddr, uInt32 readSize, uInt32* readData, int doReadFirst, int noIncrement);

/// \brief Read from device RAM
///    
/// Read from the device RAM. Only for devices that actually have RAM.
///
/// \param deviceHandle The handle to an existing device
/// \param address address of the first element to read
/// \param buffer Buffer to store the RAM content
/// \param size The number of bytes to read from RAM
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqReadDeviceRAM(DeviceHandle deviceHandle, uInt32 address, int size, uInt8* buffer);

/// \brief Write to device RAM
///    
/// Write to the device RAM. Only for devices that actually have RAM.
/// 
/// \param deviceHandle The handle to an existing device
/// \param address address of the first element to write
/// \param size The number of bytes to write
/// \param buffer Buffer containing the new value to store in RAM
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqWriteDeviceRAM(DeviceHandle deviceHandle, uInt32 address, int size, uInt8* buffer);

/// \brief Get the low-level access timeout
///
/// Get the maximum amount of time (in ms) for a low-level access request to complete.
///
/// \param deviceHandle The handle to an existing device
/// \param pTimeout the timeout
/// \return The status code
/// \sa UeiDaqSetDeviceTimeout, UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqGetDeviceTimeout(DeviceHandle deviceHandle, Int32* pTimeout);

/// \brief Set the low-level access timeout
///
/// Set the maximum amount of time (in ms) for a low-level access request to complete.
/// Set to -1 to use default value (depends on hardware)
///
/// \param deviceHandle The handle to an existing device
/// \param timeout the timeout
/// \return The status code
/// \sa UeiDaqGetDeviceTimeout, UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqSetDeviceTimeout(DeviceHandle deviceHandle, Int32 timeout);

/// \brief Reset device
///
/// Executes a hardware reset on the device.
/// To reboot a PowerDNA or PowerDNR unit call this method on the 
/// CPU device (device 14).
///
/// \param deviceHandle The handle to an existing device
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqResetDevice(DeviceHandle deviceHandle);

/// \brief Set watchdog command
///
/// Enable/Disable watchdog and configure mode.
/// This is only supported on PowerDNA/DNR/DNF CPU devices (device 14)
/// \param deviceHandle The handle to a watchdog capable device
/// \param cmd the watchdog command
/// \param timeout the watchdog expiration timeout
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqSetDeviceWatchDogCommand(DeviceHandle deviceHandle, tUeiWatchDogCommand cmd, int timeout);

/// \brief Write calibration value in device's EEPROM
///
/// Write/Replace calibration value in the EEPROM area reserved for the specified channel
/// \param deviceHandle The handle to a watchdog capable device
/// \param channel The channel 
/// \param dacMode The DAC mode
/// \param value The new calibration value
/// \param saveEEPROM True to commit all changes to EEPROM
/// \return The status code
/// \sa UeiDaqGetDeviceHandle
UeiDaqAPI int UeiDaqWriteDeviceCalibration(DeviceHandle deviceHandle, int channel, uInt8 dacMode, uInt32 value, int saveEEPROM);

/// \brief Get the timing mode
///
/// Get the timing mode
///
/// \param timingHandle The handle to an existing timing object
/// \param mode The returned timing mode
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqGetTimingMode(TimingHandle timingHandle, tUeiTimingMode* mode);

/// \brief Set the timing mode
///
/// Set the timing mode
///
/// \param timingHandle The handle to an existing timing object
/// \param mode The new timing mode
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqSetTimingMode(TimingHandle timingHandle, tUeiTimingMode mode);

/// \brief Get the Conversion clock source
///
/// Get the source of the A/D conversion clock
///
/// \param timingHandle The handle to an existing timing object
/// \param source The returned clock source
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqGetTimingConvertClockSource(TimingHandle timingHandle, tUeiTimingClockSource* source);

/// \brief Set the Conversion clock source
///
/// Set the source of the A/D conversion clock
///
/// \param timingHandle The handle to an existing timing object
/// \param source The new clock source
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqSetTimingConvertClockSource(TimingHandle timingHandle, tUeiTimingClockSource source);

/// \brief Get the Scan clock source
///
/// Get the source of the scan clock
///
/// \param timingHandle The handle to an existing timing object
/// \param source The returned clock source
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqGetTimingScanClockSource(TimingHandle timingHandle, tUeiTimingClockSource* source);

/// \brief Set the Scan clock source
///
/// Set the source of the scan clock
///
/// \param timingHandle The handle to an existing timing object
/// \param source The new clock source
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqSetTimingScanClockSource(TimingHandle timingHandle, tUeiTimingClockSource source);

/// \brief Get the conversion clock rate
///
/// Get the rate of the conversion clock
///
/// \param timingHandle The handle to an existing timing object
/// \param rate The returned clock rate
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqGetTimingConvertClockRate(TimingHandle timingHandle, f64* rate);

/// \brief Set the conversion clock rate
///
/// Set the rate of the conversion clock
///
/// \param timingHandle The handle to an existing timing object
/// \param rate The new clock rate
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqSetTimingConvertClockRate(TimingHandle timingHandle, f64 rate);

/// \brief Get the scan clock rate
///
/// Get the rate of the scan clock
///
/// \param timingHandle The handle to an existing timing object
/// \param rate The returned clock rate
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqGetTimingScanClockRate(TimingHandle timingHandle, f64* rate);

/// \brief Set the scan clock rate
///
/// Set the rate of the scan clock
///
/// \param timingHandle The handle to an existing timing object
/// \param rate The new clock rate
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqSetTimingScanClockRate(TimingHandle timingHandle, f64 rate);

/// \brief Get the conversion clock edge
///
/// Get the active edge of the conversion clock.
///
/// \param timingHandle The handle to an existing timing object
/// \param edge The returned active edge
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqGetTimingConvertClockEdge(TimingHandle timingHandle, tUeiDigitalEdge* edge);

/// \brief Set the conversion clock edge
///
/// Set the active edge of the conversion clock.
///
/// \param timingHandle The handle to an existing timing object
/// \param edge The new active edge
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqSetTimingConvertClockEdge(TimingHandle timingHandle, tUeiDigitalEdge edge);

/// \brief Get the scan clock edge
///
/// Get the active edge of the scan clock.
///
/// \param timingHandle The handle to an existing timing object
/// \param edge The returned active edge
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqGetTimingScanClockEdge(TimingHandle timingHandle, tUeiDigitalEdge* edge);

/// \brief Set the scan clock edge
///
/// Set the active edge of the scan clock.
///
/// \param timingHandle The handle to an existing timing object
/// \param edge The new active edge
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqSetTimingScanClockEdge(TimingHandle timingHandle, tUeiDigitalEdge edge);

/// \brief Get the duration
///
/// Get the duration of the timed operation.
///
/// \param timingHandle The handle to an existing timing object
/// \param duration The returned duration
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqGetTimingDuration(TimingHandle timingHandle, tUeiTimingDuration* duration);

/// \brief Set the duration
///
/// Set the duration of the timed operation.
///
/// \param timingHandle The handle to an existing timing object
/// \param duration The new duration
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqSetTimingDuration(TimingHandle timingHandle, tUeiTimingDuration duration);

/// \brief Get the timeout
///
/// Get the delay after which the session is aborted.
///
/// \param timingHandle The handle to an existing timing object
/// \param timeout The returned timeout in ms
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqGetTimingTimeout(TimingHandle timingHandle, Int32* timeout);

/// \brief Set the timeout
///
/// Set the delay after which the session is aborted.
///
/// \param timingHandle The handle to an existing timing object
/// \param timeout The new timeout in ms
/// \return The status code
/// \sa UeiDaqGetTimingHandle
UeiDaqAPI int UeiDaqSetTimingTimeout(TimingHandle timingHandle, Int32 timeout);

/// \brief Get the scan clock divisor
///
/// Get the scan clock divisor. This divisor is used to divide
/// an external clock using one of the on-board counter/timers.
/// \param timingHandle The handle to an existing timing object
/// \param divisor the timebase divisor
/// \return the status code
/// \sa UeiDaqSetTimingScanClockTimebaseDivisor
UeiDaqAPI int UeiDaqGetTimingScanClockTimebaseDivisor(TimingHandle timingHandle, int* divisor);

/// \brief Set the scan clock divisor
///
/// Set the scan clock divisor. This divisor is used to divide
/// an external clock using one of the on-board counter/timers.
/// \param timingHandle The handle to an existing timing object
/// \param divisor the timebase divisor
/// \return the status code
/// \sa UeiDaqGetTimingScanClockTimebaseDivisor
UeiDaqAPI int UeiDaqSetTimingScanClockTimebaseDivisor(TimingHandle timingHandle, int divisor);

/// \brief Get the convert clock divisor
///
/// Get the convert clock divisor. This divisor is used to divide
/// an external clock using one of the on-board counter/timers.
/// \param timingHandle The handle to an existing timing object
/// \param divisor the timebase divisor
/// \return the status code
/// \sa UeiDaqSetTimingConvertClockTimebaseDivisor
UeiDaqAPI int UeiDaqGetTimingConvertClockTimebaseDivisor(TimingHandle timingHandle, int* divisor);

/// \brief Set the convert clock divisor
///
/// Set the convert clock divisor. This divisor is used to divide
/// an external clock using one of the on-board counter/timers.
/// \param timingHandle The handle to an existing timing object
/// \param divisor the timebase divisor
/// \return the status code
/// \sa UeiDaqGetTimingConvertClockTimebaseDivisor
UeiDaqAPI int UeiDaqSetTimingConvertClockTimebaseDivisor(TimingHandle timingHandle, int divisor);

/// \brief Get the scan clock dividing counter
///
/// Get the scan clock dividing counter. This counter is used to divide
/// an external clock signal.
/// \param timingHandle The handle to an existing timing object
/// \param counter the timebase dividing counter
/// \return the status code
/// \sa UeiDaqSetTimingScanClockTimebaseDividingCounter
UeiDaqAPI int UeiDaqGetTimingScanClockTimebaseDividingCounter(TimingHandle timingHandle, int* counter);

/// \brief Set the scan clock dividing counter
///
/// Set the scan clock dividing counter. This counter is used to divide
/// an external clock.
/// \param timingHandle The handle to an existing timing object
/// \param counter the timebase dividing counter
/// \return the status code
/// \sa UeiDaqGetTimingScanClockTimebaseDividingCounter
UeiDaqAPI int UeiDaqSetTimingScanClockTimebaseDividingCounter(TimingHandle timingHandle, int counter);

/// \brief Get the convert clock dividing counter
///
/// Get the convert clock dividing counter. This counter is used to divide
/// an external clock.
/// \param timingHandle The handle to an existing timing object
/// \param counter the timebase dividing counter
/// \return the status code
/// \sa UeiDaqSetTimingConvertClockTimebaseDividingCounter
UeiDaqAPI int UeiDaqTimingGetConvertClockTimebaseDividingCounter(TimingHandle timingHandle, int* counter);

/// \brief Set the convert clock dividing counter
///
/// Set the convert clock dividing counter. This counter is used to divide
/// an external.
/// \param timingHandle The handle to an existing timing object
/// \param counter the timebase dividing counter
/// \return the status code
/// \sa UeiDaqTimingGetConvertClockTimebaseDividingCounter
UeiDaqAPI int UeiDaqSetTimingConvertClockTimebaseDividingCounter(TimingHandle timingHandle, int counter);

/// \brief Get the name of the signal to use as Scan clock
///
/// Get the name of the signal to use as Scan clock
/// The signal name is device dependent.
/// \param timingHandle The handle to an existing timing object
/// \param signal The string to contain the current scan clock source signal
/// \param signalLength The length of the string, on function return contains the number of characters copied. If signal is NULL, signalLength contains the required length for signal
/// \return the status code
/// \sa UeiDaqSetTimingScanClockSourceSignal
UeiDaqAPI int UeiDaqGetTimingScanClockSourceSignal(TimingHandle timingHandle, char* signal, int* signalLength);

/// \brief Set the name of the signal to use as Scan clock
///
/// Set the name of the signal to use as Scan clock.
/// The signal name is device dependent.
/// \param timingHandle The handle to an existing timing object
/// \param signal the new scan clock source signal
/// \return the status code
/// \sa UeiDaqGetTimingScanClockSourceSignal
UeiDaqAPI int UeiDaqSetTimingScanClockSourceSignal(TimingHandle timingHandle, char* signal);

/// \brief Get the name of the signal to route the Scan clock to
///
/// Get the name of the signal driven by the Scan clock
/// The signal name is device dependent.
/// \param timingHandle The handle to an existing timing object
/// \param signal The string to contain the current scan clock destination signal
/// \param signalLength The length of the string, on function return contains the number of characters copied. If signal is NULL, signalLength contains the required length for signal
/// \return the status code
/// \sa UeiDaqSetTimingScanClockDestinationSignal
UeiDaqAPI int UeiDaqGetTimingScanClockDestinationSignal(TimingHandle timingHandle, char* signal, int* signalLength);

/// \brief Set the name of the signal to route the Scan clock to
///
/// Set the name of the signal to use as Scan clock.
/// The signal name is device dependent.
/// \param timingHandle The handle to an existing timing object
/// \param signal the new scan clock destination signal
/// \return the status code
/// \sa UeiDaqGetTimingScanClockDestinationSignal
UeiDaqAPI int UeiDaqSetTimingScanClockDestinationSignal(TimingHandle timingHandle, char* signal);

/// \brief Get the name of the signal to use as conversion clock
///
/// Get the name of the signal to use as conversion clock
/// The signal name is device dependent.
/// \param timingHandle The handle to an existing timing object
/// \param signal The string to contain the current conversion clock signal
/// \param signalLength The length of the string, on function return contains the number of characters copied. If signal is NULL, signalLength contains the required length for signal
/// \return the status code
/// \sa UeiDaqSetTimingConvertClockSourceSignal
UeiDaqAPI int UeiDaqGetTimingConvertClockSourceSignal(TimingHandle timingHandle, char* signal, int* signalLength);

/// \brief Set the name of the signal to use as conversion clock
///
/// Set the name of the signal to use as conversion clock.
/// The signal name is device dependent.
/// \param timingHandle The handle to an existing timing object
/// \param signal the new conversion clock signal
/// \return the status code
/// \sa UeiDaqGetTimingConvertClockSourceSignal
UeiDaqAPI int UeiDaqSetTimingConvertClockSourceSignal(TimingHandle timingHandle, char* signal);

// \brief Get the name of the signal to route the conversion clock to
///
/// Get the name of the signal driven by the conversion clock
/// The signal name is device dependent.
/// \param timingHandle The handle to an existing timing object
/// \param signal The string to contain the current conversion clock destination signal
/// \param signalLength The length of the string, on function return contains the number of characters copied. If signal is NULL, signalLength contains the required length for signal
/// \return the status code
/// \sa UeiDaqSetTimingConvertClockDestinationSignal
UeiDaqAPI int UeiDaqGetTimingConvertClockDestinationSignal(TimingHandle timingHandle, char* signal, int* signalLength);

/// \brief Set the name of the signal to route the conversion clock to
///
/// Set the name of the signal driven by the conversion clock.
/// The signal name is device dependent.
/// \param timingHandle The handle to an existing timing object
/// \param signal the new conversion clock destination signal
/// \return the status code
/// \sa UeiDaqGetTimingConvertClockDestinationSignal
UeiDaqAPI int UeiDaqSetTimingConvertClockDestinationSignal(TimingHandle timingHandle, char* signal);

/// \brief Get the trigger source
///
/// Get the source of the signal that will trigger the start of the session
///
/// \param triggerHandle The handle to an existing trigger object
/// \param source The returned trigger source
/// \return The status code
/// \sa UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqGetTriggerSource(TriggerHandle triggerHandle, tUeiTriggerSource* source);

/// \brief Set the trigger source
///
/// Set the source of the signal that will trigger the start of the session
///
/// \param triggerHandle The handle to an existing trigger object
/// \param source The new trigger source
/// \return The status code
/// \sa UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqSetTriggerSource(TriggerHandle triggerHandle, tUeiTriggerSource source);

/// \brief Get the trigger edge
///
/// Get the active edge of the trigger signal
///
/// \param triggerHandle The handle to an existing trigger object
/// \param edge The returned trigger edge
/// \return The status code
/// \sa UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqGetTriggerDigitalEdge(TriggerHandle triggerHandle, tUeiDigitalEdge* edge);

/// \brief Set the trigger edge
///
/// Set the active edge of the trigger signal
///
/// \param triggerHandle The handle to an existing trigger object
/// \param edge The new trigger edge
/// \return The status code
/// \sa UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqSetTriggerDigitalEdge(TriggerHandle triggerHandle, tUeiDigitalEdge edge);

/// \brief Get the trigger source signal
///
/// Get the signal used to transmit the trigger to the device.
/// The signal name is device dependent.
/// \param triggerHandle The handle to an existing trigger object
/// \param signal The string to contain the current trigger source signal
/// \param signalLength The length of the string, on function return contains the number of characters copied. If signal is NULL, signalLength contains the required length for signal
/// \return The status code
/// \sa UeiDaqSetTriggerSourceSignal
UeiDaqAPI int UeiDaqGetTriggerSourceSignal(TriggerHandle triggerHandle, char* signal, int* signalLength);

/// \brief Set the trigger source signal
///
/// Set the signal used to transmit the trigger to the device.
/// The signal name is device dependent.
/// \param triggerHandle The handle to an existing trigger object
/// \param signal the new trigger source signal
/// \return The status code
/// \sa UeiDaqGetTriggerSourceSignal
UeiDaqAPI int UeiDaqSetTriggerSourceSignal(TriggerHandle triggerHandle, char* signal);

/// \brief Get the trigger destination signal
///
/// Get the signal where the trigger is routed out of the device.
/// The signal name is device dependent.
/// \param triggerHandle The handle to an existing trigger object
/// \param signal The string to contain the current trigger destination signal
/// \param signalLength The length of the string, on function return contains the number of characters copied. If signal is NULL, signalLength contains the required length for signal
/// \return The status code
/// \sa UeiDaqSetTriggerDestinationSignal
UeiDaqAPI int UeiDaqGetTriggerDestinationSignal(TriggerHandle triggerHandle, char* signal, int* signalLength);


/// \brief Set the trigger destination signal
///
/// Set the signal where the trigger is routed out of the device.
/// The signal name is device dependent.
/// \param triggerHandle The handle to an existing trigger object
/// \param signal the new trigger destination signal
/// \return The status code
/// \sa UeiDaqGetTriggerDestinationSignal
UeiDaqAPI int UeiDaqSetTriggerDestinationSignal(TriggerHandle triggerHandle, char* signal);

/// \brief Get the trigger action
///
/// Get the action to execute when the trigger will occur
/// \param triggerHandle The handle to an existing trigger object
/// \param pAction the current trigger action
/// \return The status code
/// \sa UeiDaqSetTriggerAction UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqGetTriggerAction(TriggerHandle triggerHandle, tUeiTriggerAction *pAction);

/// \brief Set the trigger action
///
/// Set the action to execute when the trigger will occur
/// \param triggerHandle The handle to an existing trigger object
/// \param action the new trigger action
/// \return The status code
/// \sa UeiDaqGetTriggerAction UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqSetTriggerAction(TriggerHandle triggerHandle, tUeiTriggerAction action);

/// \brief Get the analog trigger condition
///
/// Get the condition for the analog software trigger
/// \param triggerHandle The handle to an existing trigger object
/// \param pCondition the current condition
/// \return The status code
/// \sa UeiDaqSetTriggerCondition UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqGetTriggerCondition(TriggerHandle triggerHandle, tUeiTriggerCondition *pCondition);

/// \brief Set the analog trigger condition
///
/// Set the condition for the analog software trigger
/// \param triggerHandle The handle to an existing trigger object
/// \param condition the new condition
/// \return The status code
/// \sa UeiDaqGetTriggerCondition UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqSetTriggerCondition(TriggerHandle triggerHandle, tUeiTriggerCondition condition);

/// \brief Get the trigger channel
///
/// Get the channel to monitor for the trigger condition.
/// \param triggerHandle The handle to an existing trigger object
/// \param pChannel the current channel to monitor.
/// \return The status code
/// \sa UeiDaqSetTriggerChannel UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqGetTriggerChannel(TriggerHandle triggerHandle, Int32 *pChannel);

/// \brief Set the trigger channel
///
/// Set the channel to monitor for the trigger condition.
/// \param triggerHandle The handle to an existing trigger object
/// \param channel the new channel to monitor
/// \return The status code
/// \sa UeiDaqGetTriggerChannel UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqSetSetTriggerChannel(TriggerHandle triggerHandle, Int32 channel);

/// \brief Get the trigger level
///
/// Get the scaled value at which the trigger occurs.
/// The value is in the same unit as the measurement.
/// \param triggerHandle The handle to an existing trigger object
/// \param pLevel the current level
/// \return The status code
/// \sa UeiDaqSetTriggerLevel UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqGetTriggerLevel(TriggerHandle triggerHandle, f64 *pLevel);

/// \brief Set the trigger level
///
/// Set the scaled value at which the trigger occurs.
/// The value must be specified in the same unit as the measurement.
/// \param triggerHandle The handle to an existing trigger object
/// \param level the new level
/// \return The status code
/// \sa UeiDaqGetTriggerLevel UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqSetTriggerLevel(TriggerHandle triggerHandle, f64 level);

/// \brief Get the trigger hysteresis
///
/// Get the hysteresis window scaled value.
/// The hysteresis window is a noise filter. The trigger occurs
/// when the signal leave the window.
/// \param triggerHandle The handle to an existing trigger object
/// \param pHysteresis the current hysteresis
/// \return The status code
/// \sa UeiDaqSetTriggerHysteresis UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqGetTriggerHysteresis(TriggerHandle triggerHandle, f64 *pHysteresis);

/// \brief Set the trigger hysteresis
///
/// Set the hysteresis window scaled value.
/// The hysteresis window is a noise filter. The trigger occurs
/// when the signal leave the window.
/// \param triggerHandle The handle to an existing trigger object
/// \param hysteresis the new hysteresis
/// \return The status code
/// \sa UeiDaqGetTriggerHysteresis UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqSetTriggerHysteresis(TriggerHandle triggerHandle, f64 hysteresis);

/// \brief Get the number of pre-trigger scans
///
/// The number of scans saved before the trigger occurred.
/// \param triggerHandle The handle to an existing trigger object
/// \param pNumPreTriggerScans the number of pre-trigger scans
/// \return The status code
/// \sa UeiDaqSetNumberOfPreTriggerScans UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqGetNumberOfPreTriggerScans(TriggerHandle triggerHandle, Int32 *pNumPreTriggerScans);

/// \brief Set the number of pre-trigger scans
///
/// The number of scans to save before the trigger occurs
/// \param triggerHandle The handle to an existing trigger object
/// \param numPreTriggerScans the new nunber of pre-trigger scans
/// \return The status code
/// \sa UeiDaqGetNumberOfPreTriggerScans UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqSetNumberOfPreTriggerScans(TriggerHandle triggerHandle, Int32 numPreTriggerScans);

/// \brief Manually send a trigger
///
/// Manually send a trigger event. This method can only be called
/// When trigger source is set to UeiTriggerSourceSignal and
/// the trigger signal is set to a software assertable signal.
/// \param triggerHandle The handle to an existing trigger object
/// \return The status code
/// \sa UeiDaqGetStartTriggerHandle UeiDaqGetStopTriggerHandle
UeiDaqAPI int UeiDaqFireTrigger(TriggerHandle triggerHandle);

/// \brief Translate error code
///
/// Translate error code to a human readable message
///
/// \param error The error code to translate
/// \return The error message
UeiDaqAPI const char* UeiDaqTranslateError(int error);

/// \brief Enumerate drivers
///
/// Enumerate the installed drivers
///
/// \param index The index of the driver to enumerate
/// \param driverName The name of the driver enumerated
/// \return The status code
/// \sa UeiDaqEnumDevice
UeiDaqAPI int UeiDaqEnumDriver(int index, char* driverName);

/// \brief Enumerate devices
///
/// Enumerate the devices handled by the specified driver
///
/// \param deviceResourceName The name of the driver
/// \param deviceHandle The handle the device enumerated
/// \return The status code
/// \sa UeiDaqEnumDriver
UeiDaqAPI int UeiDaqEnumDevice(char* deviceResourceName, DeviceHandle *deviceHandle);

/// \brief Parse resource string
///
/// Parse the resource string and return its components.
/// You can pass NULL for the components you are not interested in.
/// When the function is called channelListSize should contain the
/// size of the channelList array.
/// When the function returns channelListSize contains the actual
/// number of elements copied to channelList
///
/// \param resource The resource string
/// \param deviceClass The name of the device class
/// \param remoteAddress The remote address, NULL if the ersource is local
/// \param deviceID The ID number of the device
/// \param type The session type
/// \param channelList An array of integer representing the channel list
/// \param channelListSize The size of the channel list
/// \return The status code
/// \sa UeiDaqEnumDriver
UeiDaqAPI int UeiDaqParseResource(char* resource, char* deviceClass, char* remoteAddress, int* deviceID, tUeiSessionType* type, int* channelList, int* channelListSize);

/// \brief Set a custom property
///
/// Set a custom property on the device or subsystem associated with this session
/// Custom properties are device dependent, refer to the device user manual to learn
/// about the properties supported by your device
///
/// \param sessionHandle The handle of the session
/// \param property string containing the name of the property to set
/// \param valueSize size in bytes of the memory block containing the property value
/// \param value pointer to the memory block containing the property value
/// \return The status code
UeiDaqAPI int UeiDaqSetSessionCustomProperty(SessionHandle sessionHandle, char* property, int valueSize, void* value);

/// \brief Get a custom property
///
/// Get a custom property on the device or subsystem associated with this session
/// Custom properties are device dependent, refer to the device user manual to learn
/// about the properties supported by your device
///
/// \param sessionHandle The handle of the session
/// \param property string containing the name of the property to get
/// \param valueSize size in bytes of the memory block receiving the property value
/// \param value pointer to the memory block receiving the property value
/// \return The status code
UeiDaqAPI int UeiDaqGetSessionCustomProperty(SessionHandle sessionHandle, char* property, int valueSize, void* value);

/// \brief Get the session type
///
/// Get the session type of this session. The session type is set by the first channel
/// added to the session.
///
/// \param sessionHandle The handle of the session
/// \param sessionType The type of the session
/// \return The status code
UeiDaqAPI int UeiDaqGetSessionType(SessionHandle sessionHandle, tUeiSessionType* sessionType);

/// \brief Load Session settings from an XML stream
///
/// Load Session settings from an XML stream, session is ready to be started
///
/// \param sessionHandle The handle of the session
/// \param xmlSettings String containing the session settings in XML format
/// \return The status code
UeiDaqAPI int UeiDaqLoadSessionFromXml(SessionHandle sessionHandle, char* xmlSettings);

/// \brief Load Session settings from a file
///
/// Load Session settings from a file, session is ready to be started
///
/// \param sessionHandle The handle of the session
/// \param sessionFile String containing the session settings file path
/// \return The status code
UeiDaqAPI int UeiDaqLoadSessionFromFile(SessionHandle sessionHandle, char* sessionFile);

/// \brief Get the framework version string
///
/// Get the the four parts version string.
/// "major.minor.extra.build"
///
/// \param version The string that will contain the version once the function returns
/// \param versionSize The size of the version string
/// \return The status code.
UeiDaqAPI int UeiDaqGetFrameworkVersion(char* version, int versionSize);

/// \brief Get a driver plugin version string
///
/// Get the the four parts version string of the specified
/// driver plugin.
/// "major.minor.extra.build"
///
/// \param driverName The name of the driver plugin
/// \param version The string that will contain the version once the function returns
/// \param versionSize The size of the version string
/// \return The status code.
UeiDaqAPI int UeiDaqGetPluginLowLevelDriverVersion(char* driverName, char* version, int versionSize);

/// \brief Get the framework installation directory
///
/// Get the framework installation directory
///
/// \param installDir The string that will contain the installation directory once the function returns
/// \param installDirSize The size of the string
/// \return The status code.
UeiDaqAPI int UeiDaqGetFrameworkInstallationDirectory(char* installDir, int installDirSize);

/// \brief Get the framework plugins directory
///
/// Get the framework plugins directory
///
/// \param installDir The string that will contain the installation directory once the function returns
/// \param installDirSize The size of the string
/// \return The status code.
UeiDaqAPI int UeiDaqGetPluginsInstallationDirectory(char* installDir, int installDirSize);

/// \brief Get a session group directory
///
/// Get a session group directory
///
/// \param sessionGroup the name of the session group
/// \param sessionGroupDir The string that will contain the installation directory once the function returns
/// \param sessionGroupDirSize The size of the string
/// \return The status code.
UeiDaqAPI int UeiDaqGetSessionGroupDirectory(char* sessionGroup, char* sessionGroupDir, int sessionGroupDirSize);

/// \brief Get the operating system type
///
/// Get the type of the operating system installed on this computer
///
/// \return The operating system type.
UeiDaqAPI tUeiOSType UeiDaqGetOperatingSystemType();

/// \brief Reload driver plugins
///
/// Un-load/re-load driver plugins
UeiDaqAPI void UeiDaqReloadDrivers();

#ifdef __cplusplus
   }
#endif

#endif
