#ifndef __UEIREADER_H__
#define __UEIREADER_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif


#include <memory>
#include "UeiConstants.h"

namespace UeiDaq
{

// Private classes
class CUeiAnalogRawReaderImpl;
class CUeiAnalogCalibratedRawReaderImpl;
class CUeiDigitalReaderImpl;
class CUeiCounterReaderImpl;
class CUeiAnalogScaledReaderImpl;
class CUeiLVDTReaderImpl;
class CUeiDMMReaderImpl;

// Forward declaration
class CUeiDataStream;
class IUeiEventListener;
class CUeiException;

/// \brief Analog Raw Reader class
/// 
/// Class that handles reading raw data of 
/// a stream coming from an analog input
class CUeiAnalogRawReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   UeiDaqAPI CUeiAnalogRawReader(CUeiDataStream* pDataStream);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAnalogRawReader();

   /// \brief Read a 16 bits wide scan
   ///
   /// Read only one scan from the input stream
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScan(uInt16* pBuffer);

   /// \brief Read a 32 bits wide scan
   ///
   /// Read only one scan from the input stream
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScan(uInt32* pBuffer);
   
   /// \brief Read multiple 16 bits wide scans
   ///
   /// Read several scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScans(Int32 numScans, uInt16* pBuffer);

   /// \brief Read multiple 32 bits wide scans
   ///
   /// Read several scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScans(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Read a 16 bits wide scan asynchronously
   ///
   /// Read only one scan asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScanAsync(uInt16* pBuffer);

   /// \brief Read a 32 bits wide scan asynchronously
   ///
   /// Read only one scan asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScanAsync(uInt32* pBuffer);
   
   /// \brief Read multiple 16 bits wide scans asynchronously
   ///
   /// Read several scans asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScansAsync(Int32 numScans, uInt16* pBuffer);

   /// \brief Read multiple 32 bits wide scans asynchronously
   ///
   /// Read several scans asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScansAsync(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Add an asynchronous listener
   ///
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAnalogRawReaderImpl> m_pImpl;
};


/// \brief Analog Calibrated Raw Reader class
/// 
/// Class that handles reading calibrated raw data of 
/// a stream coming from an analog input
class CUeiAnalogCalibratedRawReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   UeiDaqAPI CUeiAnalogCalibratedRawReader(CUeiDataStream* pDataStream);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAnalogCalibratedRawReader();

   /// \brief Read a 16 bits wide scan
   ///
   /// Read only one scan from the input stream
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScan(uInt16* pBuffer);

   /// \brief Read a 32 bits wide scan
   ///
   /// Read only one scan from the input stream
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScan(uInt32* pBuffer);
   
   /// \brief Read multiple 16 bits wide scans
   ///
   /// Read several scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScans(Int32 numScans, uInt16* pBuffer);

   /// \brief Read multiple 32 bits wide scans
   ///
   /// Read several scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScans(Int32 numScans, uInt32* pBuffer);

   /// \brief Read a 16 bits wide scan asynchronously
   ///
   /// Read only one scan asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScanAsync(uInt16* pBuffer);

   /// \brief Read a 32 bits wide scan asynchronously
   ///
   /// Read only one scan asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScanAsync(uInt32* pBuffer);
   
   /// \brief Read multiple 16 bits wide scans asynchronously
   ///
   /// Read several scans asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScansAsync(Int32 numScans, uInt16* pBuffer);

   /// \brief Read multiple 32 bits wide scans asynchronously
   ///
   /// Read several scans asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScansAsync(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Add an asynchronous listener
   ///
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAnalogCalibratedRawReaderImpl> m_pImpl;
};


/// \brief Analog Scaled Reader class
/// 
/// Class that handles reading scaled data of 
/// a stream coming from an analog input
class CUeiAnalogScaledReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   UeiDaqAPI CUeiAnalogScaledReader(CUeiDataStream* pDataStream);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAnalogScaledReader();

   /// \brief Read a scan
   ///
   /// Read only one scan from the input stream
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScan(f64* pBuffer);
   
   /// \brief Read multiple scans
   ///
   /// Read several scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScans(Int32 numScans, f64* pBuffer);
   
   /// \brief Read a scan asynchronously
   ///
   /// Read only one scan asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScanAsync(f64* pBuffer);
   
   /// \brief Read multiple scans asynchronously
   ///
   /// Read several scans asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScansAsync(Int32 numScans, f64* pBuffer);
   
   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events.
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAnalogScaledReaderImpl> m_pImpl;
};

/// \brief LVDT Reader class
/// 
/// Class that handles reading data of 
/// a stream coming from an LVDT input
class CUeiLVDTReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   UeiDaqAPI CUeiLVDTReader(CUeiDataStream* pDataStream);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiLVDTReader();

   /// \brief Read displacement measured by LVDT sensor
   ///
   /// Read one displacement scan from the input stream
   /// Ratiometric measurements are multiplied by the LVDT
   /// sensor sensitivity to obtain displacement
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleDisplacement(f64* pBuffer);

   /// \brief Read multiple displacements
   ///
   /// Read several displacements scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleDisplacements(Int32 numScans, f64* pBuffer);

   /// \brief Read primary and secondary coils RMS voltages
   ///
   /// Read RMS amplitudes for the primary and secondary coils of each configured
   /// channel
   /// \param pPrimaryCoilsBuffer destination buffer for primary coils amplitudes
   /// \param pSecondaryCoilsBuffer destination buffer for secondary coils amplitudes
   UeiDaqAPI void ReadCoilAmplitudes(f64* pPrimaryCoilsBuffer, f64* pSecondaryCoilsBuffer);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiLVDTReaderImpl> m_pImpl;
};


/// \brief Digital Reader class
///
/// Class that handles reading  data of 
/// a stream coming from a digital input
class CUeiDigitalReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   UeiDaqAPI CUeiDigitalReader(CUeiDataStream* pDataStream);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDigitalReader();

   /// \brief Read a 16 bits wide scan
   ///
   /// Read only one scan from the input stream
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScan(uInt16* pBuffer);

   /// \brief Read a 32 bits wide scan
   ///
   /// Read only one scan from the input stream
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScan(uInt32* pBuffer);
   
   /// \brief Read multiple 16 bits wide scans
   ///
   /// Read several scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScans(Int32 numScans, uInt16* pBuffer);

   /// \brief Read multiple 32 bits wide scans
   ///
   /// Read several scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScans(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Read a 16 bits wide scan asynchronously
   ///
   /// Read only one scan asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScanAsync(uInt16* pBuffer);

   /// \brief Read a 32 bits wide scan asynchronously
   ///
   /// Read only one scan asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScanAsync(uInt32* pBuffer);
   
   /// \brief Read multiple 16 bits wide scans asynchronously
   ///
   /// Read several scans asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScansAsync(Int32 numScans, uInt16* pBuffer);

   /// \brief Read multiple 32 bits wide scans asynchronously
   ///
   /// Read several scans asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScansAsync(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDigitalReaderImpl> m_pImpl;
};

/// \brief Counter Reader class
///
/// Class that handles reading data of 
/// a stream coming from a Counter input
class CUeiCounterReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   UeiDaqAPI CUeiCounterReader(CUeiDataStream* pDataStream);
   
   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCounterReader();

   /// \brief Read a 16 bits wide scan
   ///
   /// Read only one scan from the input stream
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScan(uInt16* pBuffer);

   /// \brief Read a 32 bits wide scan
   ///
   /// Read only one scan from the input stream
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScan(uInt32* pBuffer);
   
   /// \brief Read multiple 16 bits wide scans
   ///
   /// Read several scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScans(Int32 numScans, uInt16* pBuffer);

   /// \brief Read multiple 32 bits wide scans
   ///
   /// Read several scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScans(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Read a 16 bits wide scan asynchronously
   ///
   /// Read only one scan asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScanAsync(uInt16* pBuffer);

   /// \brief Read a 32 bits wide scan asynchronously
   ///
   /// Read only one scan asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScanAsync(uInt32* pBuffer);
   
   /// \brief Read multiple 16 bits wide scans asynchronously
   ///
   /// Read several scans asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScansAsync(Int32 numScans, uInt16* pBuffer);

   /// \brief Read multiple 32 bits wide scans asynchronously
   ///
   /// Read several scans asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScansAsync(Int32 numScans, uInt32* pBuffer);
   
   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);
   
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCounterReaderImpl> m_pImpl;
};

/// \brief DMM Reader class
///
/// Class that handles reading data of 
/// a stream coming from a DMM input
class CUeiDMMReader
{
public:
   /// \brief Constructor
   /// 
   /// \param pDataStream represents the source of data to read
   UeiDaqAPI CUeiDMMReader(CUeiDataStream* pDataStream);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDMMReader();

   /// \brief Read a scan
   ///
   /// Read only one scan from the input stream
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScan(f64* pBuffer);

   /// \brief Read multiple scans
   ///
   /// Read several scans from the input stream
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScans(Int32 numScans, f64* pBuffer);

   /// \brief Read a scan asynchronously
   ///
   /// Read only one scan asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadSingleScanAsync(f64* pBuffer);

   /// \brief Read multiple scans asynchronously
   ///
   /// Read several scans asynchronously from the input stream.
   /// The destination buffer contains valid data once the listener
   /// is called.
   /// \param numScans number of scans to read
   /// \param pBuffer destination buffer
   UeiDaqAPI void ReadMultipleScansAsync(Int32 numScans, f64* pBuffer);

   /// \brief Read DMM status returned with last read data
   ///
   /// Read DMM status returned with last read data. Status
   /// is only updated when channel data is read.
   /// \param pStatus destination for status
   UeiDaqAPI void ReadStatus(uInt32* pStatus);

   /// \brief Read DMM protection tripped status
   ///
   /// Read DMM status returned with last read data and return
   /// if protection was tripped when data was read.
   /// \return protection tripped status
   UeiDaqAPI bool IsProtectionTripped();

   /// \brief Read DMM protection tripped in max range status
   ///
   /// Read DMM status returned with last read data and return
   /// if protection was tripped in max range when data was read.
   /// \return protection tripped in max range status
   UeiDaqAPI bool IsProtectionTrippedMaxRange();

   /// \brief Read DMM protection reconfigured to safe range status
   ///
   /// Read DMM status returned with last read data and return
   /// if protection reconfigured to safe range when data was read.
   /// \return protection reconfigured to safe range status
   UeiDaqAPI bool IsProtectionReconfiguredSafeRange();

   /// \brief Add an asynchronous listener
   /// 
   /// Subscribe a listener to receive asynchronous events
   /// \param pListener pointer to a class that implements IUeiEventListener interface
   UeiDaqAPI void AddEventListener(IUeiEventListener* pListener);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDMMReaderImpl> m_pImpl;
};

}

#endif // __UEIREADER_H__
