#ifndef __UEIOBJECT_H__
#define __UEIOBJECT_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

#include <string>
#include <memory>
#include "UeiConstants.h"

namespace UeiDaq
{

class CUeiObjectImpl;

/// Base class for all objects of the UeiDaq framework
class CUeiObject
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiObject();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiObject();

private:
   std::unique_ptr<CUeiObjectImpl> m_pImpl;
};

#define UEI_DOWNCAST(CLASS, PTR, HDL) \
   CUeiObject* pObject = reinterpret_cast<CUeiObject*>(HDL); \
   CLASS* PTR = dynamic_cast<CLASS*>(pObject);

}

#endif // __UEIOBJECT_H__