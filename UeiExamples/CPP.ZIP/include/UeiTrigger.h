#ifndef __UEITRIGGER_H__
#define __UEITRIGGER_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif


#include "UeiObject.h"

namespace UeiDaq
{

// private classes
class CUeiTriggerImpl;

// Forward declaration
class CUeiException;

/// \brief Trigger object
///
/// This object store the trigger parameters of a session
class CUeiTrigger : public CUeiObject
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiTrigger();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiTrigger();

   /// \brief Get the trigger source
   ///
   /// Get the source of the signal that will trigger the start of the session
   /// \return the current trigger source
   /// \sa SetTriggerSource
   UeiDaqAPI tUeiTriggerSource GetTriggerSource();
   
   /// \brief Set the trigger source
   ///
   /// Set the source of the signal that will trigger the start of the session
   /// \param src the new trigger source
   /// \sa GetTriggerSource
   UeiDaqAPI void SetTriggerSource(tUeiTriggerSource src);

   /// \brief Get the trigger digital edge
   ///
   /// Get the active edge of the trigger signal
   /// \return the current trigger edge
   /// \sa SetDigitalEdge
   UeiDaqAPI tUeiDigitalEdge GetDigitalEdge();
   
   /// \brief Set the trigger digital edge
   ///
   /// Set the active edge of the trigger signal
   /// \param edge the new trigger edge
   /// \sa GetDigitalEdge
   UeiDaqAPI void SetDigitalEdge(tUeiDigitalEdge edge);

   /// \brief Get the trigger source signal
   ///
   /// Get the signal used to transmit the trigger to the device.
   /// The signal name is device dependent.
   /// \return the current trigger source signal
   /// \sa SetSourceSignal
   UeiDaqAPI std::string GetSourceSignal();
   
   /// \brief Set the trigger source signal
   ///
   /// Set the signal used to transmit the trigger to the device.
   /// The signal name is device dependent.
   /// \param signal the new trigger source signal
   /// \sa GetSourceSignal
   UeiDaqAPI void SetSourceSignal(std::string signal);

   /// \brief Get the trigger destination signal
   ///
   /// Get the signal where the trigger is routed out of the device.
   /// The signal name is device dependent.
   /// \return the current trigger destination signal
   /// \sa SetDestinationSignal
   UeiDaqAPI std::string GetDestinationSignal();
   
   /// \brief Set the trigger destination signal
   ///
   /// Set the signal where the trigger is routed out of the device.
   /// The signal name is device dependent.
   /// \param signal the new trigger destination signal
   /// \sa GetSignal
   UeiDaqAPI void SetDestinationSignal(std::string signal);

   /// \brief Get the trigger action
   ///
   /// Get the action to execute when the trigger will occur 
   /// \return the current trigger action
   /// \sa SetAction
   UeiDaqAPI tUeiTriggerAction GetAction();
   
   /// \brief Set the trigger action
   ///
   /// Set the action to execute when the trigger will occur
   /// \param action the new trigger action
   /// \sa GetAction
   UeiDaqAPI void SetAction(tUeiTriggerAction action);

   /// \brief Get the analog trigger condition
   ///
   /// Get the condition for the analog software trigger
   /// \return the current condition
   /// \sa SetCondition
   UeiDaqAPI tUeiTriggerCondition GetCondition();
   
   /// \brief Set the analog trigger condition
   ///
   /// Set the condition for the analog software trigger
   /// \param condition the new condition
   /// \sa GetCondition
   UeiDaqAPI void SetCondition(tUeiTriggerCondition condition);

   /// \brief Get the trigger channel
   ///
   /// Get the channel to monitor for the trigger condition.
   /// \return the current channel to monitor.
   /// \sa SetChannel
   UeiDaqAPI Int32 GetChannel();
   
   /// \brief Set the trigger channel
   ///
   /// Set the channel to monitor for the trigger condition.
   /// \param channel the new channel to monitor
   /// \sa GetChannel
   UeiDaqAPI void SetChannel(Int32 channel);

   /// \brief Get the trigger level
   ///
   /// Get the scaled value at which the trigger occurs.
   /// The value is in the same unit as the measurement.
   /// \return the current level
   /// \sa SetLevel
   UeiDaqAPI f64 GetLevel();
   
   /// \brief Set the trigger level
   ///
   /// Set the scaled value at which the trigger occurs.
   /// The value must be specified in the same unit as the measurement.
   /// \param level the new level
   /// \sa GetLevel
   UeiDaqAPI void SetLevel(f64 level);

   /// \brief Get the trigger hysteresis
   ///
   /// Get the hysteresis window scaled value.
   /// The hysteresis window is a noise filter. The trigger occurs
   /// when the signal leave the window.
   /// \return the current hysteresis
   /// \sa SetHysteresis
   UeiDaqAPI f64 GetHysteresis();
   
   /// \brief Set the trigger hysteresis
   ///
   /// Set the hysteresis window scaled value.
   /// The hysteresis window is a noise filter. The trigger occurs
   /// when the signal leave the window.
   /// \param hysteresis the new hysteresis
   /// \sa GetHysteresis
   UeiDaqAPI void SetHysteresis(f64 hysteresis);

   /// \brief Get the number of pre-trigger scans
   ///
   /// The number of scans saved before the trigger occurred. 
   /// \return the number of pre-trigger scans
   /// \sa SetNumberOfPreTriggerScans
   UeiDaqAPI Int32 GetNumberOfPreTriggerScans();
   
   /// \brief Set the number of pre-trigger scans
   ///
   /// The number of scans to save before the trigger occurs
   /// \param numPreTriggerScans the new nunber of pre-trigger scans
   /// \sa GetNumberOfPreTriggerScans
   UeiDaqAPI void SetNumberOfPreTriggerScans(Int32 numPreTriggerScans);

   /// \brief Manually send a trigger
   ///
   /// Manually send a trigger event. This method can only be called
   /// When trigger source is set to UeiTriggerSourceSignal and
   /// the trigger signal is set to a software assertable signal.
   UeiDaqAPI void Fire();
   
   /// \cond DO_NOT_DOCUMENT
   UeiDaqAPI CUeiTriggerImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiTriggerImpl> m_pImpl;
};

}

#endif // __UEITRIGGER_H__
