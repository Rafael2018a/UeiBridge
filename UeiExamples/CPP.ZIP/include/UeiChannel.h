#ifndef __UEICHANNEL_H__
#define __UEICHANNEL_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

#include "UeiObject.h"

namespace UeiDaq
{

// private classes
class CUeiChannelImpl;
class CUeiAIChannelImpl;
class CUeiDiagnosticChannelImpl;
class CUeiAICurrentChannelImpl;
class CUeiAOChannelImpl;
class CUeiAOCurrentChannelImpl;
class CUeiDIChannelImpl;
class CUeiDOChannelImpl;
class CUeiCIChannelImpl;
class CUeiQuadratureEncoderChannelImpl;
class CUeiCOChannelImpl;
class CUeiTCChannelImpl;
class CUeiAIVExChannelImpl;
class CUeiAccelChannelImpl;
class CUeiDMMChannelImpl;
class CUeiLVDTChannelImpl;
class CUeiSimulatedLVDTChannelImpl;
class CUeiSynchroResolverChannelImpl;
class CUeiSimulatedSynchroResolverChannelImpl;
class CUeiResistanceChannelImpl;
class CUeiRTDChannelImpl;
class CUeiSimulatedRTDChannelImpl;
class CUeiSerialPortImpl;
class CUeiHDLCPortImpl;
class CUeiCANPortImpl;
class CUeiDIIndustrialChannelImpl;
class CUeiDOIndustrialChannelImpl;
class CUeiDOProtectedChannelImpl;
class CUeiARINCInputPortImpl;
class CUeiARINCOutputPortImpl;
class CUeiMIL1553PortImpl;
class CUeiTimestampChannelImpl;
class CUeiIRIGTKChannelImpl;
class CUeiIRIGInputChannelImpl;
class CUeiIRIGOutputChannelImpl;
class CUeiIRIGDOTTLChannelImpl;
class CUeiAOWaveformChannelImpl;
class CUeiAOProtectedChannelImpl;
class CUeiAOProtectedCurrentChannelImpl;
class CUeiVRChannelImpl;
class CUeiSync1PPSPortImpl;
class CUeiCSDBPortImpl;
class CUeiSSIMasterPortImpl;
class CUeiSSISlavePortImpl;
class CUeiSimulatedTCChannelImpl;
class CUeiMuxPortImpl;
class CUeiI2CMasterPortImpl;
class CUeiI2CSlavePortImpl;

// Forward declaration
class CUeiException;
class CUeiCustomScale;

/// \brief Channel base class
///
/// Parent class for AI, AO, DI, DO, CI, CO, Serial, CAN, 1555, ARINC-429 channels etc...
class CUeiChannel : public CUeiObject
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiChannel();
   
   /// \brief Get resource name
   ///
   /// Get the channel URL. Ex: pwrdaq://Dev1/ai0..
   ///
   /// \return A string that contains the resource name.
   /// \sa SetResourceName
   UeiDaqAPI std::string  GetResourceName();
   
   /// \brief Set resource name
   ///
   /// Set the channel URL. Ex: pwrdaq://Dev1/ai0..
   ///
   /// \param resName A string that contains the resource name.
   /// \sa GetResourceName
   UeiDaqAPI void SetResourceName(std::string resName);

   /// \brief Get alias name  
   ///
   /// Get the alias name of the channel
   ///
   /// \return A string that contains the alias name.
   /// \sa SetAliasName
   UeiDaqAPI std::string  GetAliasName();
   
   /// \brief Set alias name 
   ///
   /// Set the alias name of the channel
   ///
   /// \param name A string that contains the alias name.
   /// \sa GetAliasName
   UeiDaqAPI void SetAliasName(std::string name);

   /// \brief Get the index 
   ///
   /// Get the index of the channel in the session's channel list
   ///
   /// \return the channel index.
   /// \sa SetIndex
   UeiDaqAPI Int32 GetIndex();
   
   /// \brief Set the index 
   ///
   /// Set the index of the channel in the session's channel list
   ///
   /// \param index the channel index.
   /// \sa GetIndex
   UeiDaqAPI void SetIndex(Int32 index);

private:
   std::unique_ptr<CUeiChannelImpl> m_pImpl;
};


///  \brief Manages settings for each diagnostic input channel
///
/// Manages settings for each diagnostic input channel
class CUeiDiagnosticChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiDiagnosticChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDiagnosticChannel();

   /// \brief Get channel workable minimum value
   UeiDaqAPI f64 GetWorkableMinimum();

   /// \brief Set channel workable minimum value
   UeiDaqAPI void SetWorkableMinimum(f64 value);

   /// \brief Get channel workable maximum value
   UeiDaqAPI f64 GetWorkableMaximum();

   /// \brief Set channel workable maximum value
   UeiDaqAPI void SetWorkableMaximum(f64 value);

   /// \brief Get channel ideal minimum value
   UeiDaqAPI f64 GetIdealMinimum();

   /// \brief Set channel ideal minimum value
   UeiDaqAPI void SetIdealMinimum(f64 value);

   /// \brief Get channel ideal maximum value
   UeiDaqAPI f64 GetIdealMaximum();

   /// \brief Set channel ideal maximum value
   UeiDaqAPI void SetIdealMaximum(f64 value);

   /// \brief Get moving average window size
   ///
   /// Get the moving average windows size for devices that have this capability
   /// The device needs to be capable of averaging measurement in hardware
   ///
   /// \return the current moving average window size
   UeiDaqAPI int GetMovingAverageWindowSize();

   /// \brief Set moving average window size
   ///
   /// Set the moving average windows size for devices that have this capability
   /// This is the number of data points used to calculate the average
   /// The device needs to be capable of averaging measurements in hardware
   ///
   /// \param windowSize the new moving average window size
   UeiDaqAPI void SetMovingAverageWindowSize(int windowSize);

private:
   std::unique_ptr<CUeiDiagnosticChannelImpl> m_pImpl;
};


///  \brief Manages settings for each voltage Analog input channel
///
/// Manages settings for each voltage Analog input channel
class CUeiAIChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiAIChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAIChannel();
  
   /// \brief Get the minimum value
   ///
   /// Get the minimum expected value for the signal connected to the channel.
   ///
   /// \return the minimum value.
   /// \sa SetMinimum  
   UeiDaqAPI f64 GetMinimum();
   
   /// \brief Set the minimum value
   ///
   /// Set the minimum expected value for the signal connected to the channel.
   ///
   /// \param minimum the minimum value.
   /// \sa GetMinimum  
   UeiDaqAPI void SetMinimum(f64 minimum);

   /// \brief Get the maximum value 
   ///
   /// Get the maximum expected value for the signal connected to the channel.
   ///
   /// \return the maximum value.
   /// \sa SetMaximum  
   UeiDaqAPI f64 GetMaximum();
   
   /// \brief Set the maximum value 
   ///
   /// Set the maximum expected value for the signal connected to the channel.
   ///
   /// \param maximum the maximum value.
   /// \sa GetMaximum  
   UeiDaqAPI void SetMaximum(f64 maximum);
  
   /// \brief Get the input mode 
   ///
   /// Get the Input mode of the channel, possible values are "differential" or "single-ended".
   ///
   /// \return the input mode.
   /// \sa SetInputMode  
   UeiDaqAPI tUeiAIChannelInputMode GetInputMode();
   
   /// \brief Set the input mode  
   ///
   /// Set the Input mode of the channel, possible values are "differential" or "single-ended".
   ///
   /// \param mode the input mode.
   /// \sa GetInputMode  
   UeiDaqAPI void SetInputMode(tUeiAIChannelInputMode mode);

   /// \brief Get the gain
   ///
   /// Get the gain that best fits the requested input range
   ///
   /// \return the gain
   /// \sa SetGain
   UeiDaqAPI f64 GetGain();

   /// \brief Set the gain
   ///
   /// Set the gain
   ///
   /// \param gain the new gain
   /// \sa GetGain
   UeiDaqAPI void SetGain(f64 gain);

   /// \brief Get custom scale
   ///
   /// Get the custom scale applied to scaled measurements before
   /// they are returned to caller
   /// \return Pointer to the current custom scale object
   /// \sa SetCustomScale
   UeiDaqAPI CUeiCustomScale* GetCustomScale();

   /// \brief Set custom scale
   ///
   /// Set the custom scale to apply to scaled measurements before
   /// they are returned to caller
   /// \param pScale Pointer to the custom scale object
   /// \sa GetCustomScale
   UeiDaqAPI void SetCustomScale(CUeiCustomScale* pScale);
   
   /// \brief Get open circuit detection status
   ///
   /// Get status of open circuit detection
   /// \return true if open circuit detection is enabled, false otherwise
   /// \sa EnableOpenCircuitTest
   UeiDaqAPI bool IsOpenCircuitTestEnabled();

   /// \brief Enable or disable open cicuit detection
   ///
   /// Enable or disable open circuit detection
   /// \param enable true to enable open circuit detection
   /// \sa IsOpenCircuitTestEnabled
   UeiDaqAPI void EnableOpenCircuitTest(bool enable);

   /// \brief Get open circuit detection result
   ///
   /// Get result of open circuit detection
   /// \return true if circuit is open, false otherwise
   /// \sa EnableOpenCircuitTest
   UeiDaqAPI bool IsCircuitOpen();

   /// \brief Get bias resistor state
   ///
   /// Bias resistors connects the negative input to ground and positive input to
   /// a voltage source. This is useful to measure temperature from un-grounded
   /// thermocouple. Disable bias to measure from grounded thermocouples
   /// 
   /// \return the bias resistor state
   UeiDaqAPI bool IsBiasEnabled();

   /// \brief Set bias resistor state
   ///
   /// Bias resistors connects the negative input to ground and positive input to
   /// a voltage source. This is useful to measure temperature from un-grounded
   /// thermocouple. Disable bias to measure from grounded thermocouples
   /// 
   /// \param enable the new bias resistor state
   UeiDaqAPI void EnableBias(bool enable);

   /// \brief Get auto-zero state
   ///
   /// Some analog input devices come with a special channel to measure
   /// ground offset. auto-zero subtract the ground voltage measurement
   /// from the input voltage measurement.
   ///
   /// \return the auto-zero state
   UeiDaqAPI bool IsAutoZeroEnabled();

   /// \brief Set auto zero state
   ///
   /// Some analog input devices come with a special channel to measure
   /// ground offset. auto-zero subtract the ground voltage measurement
   /// from the input voltage measurement.
   ///
   /// \param enable the new auto-zero state
   UeiDaqAPI void EnableAutoZero(bool enable);

   /// \brief Get moving average window size
   ///
   /// Get the moving average windows size for devices that have this capability
   /// The device needs to be capable of averaging measurement in hardware
   ///
   /// \return the current moving average window size
   UeiDaqAPI int GetMovingAverageWindowSize();

   /// \brief Set moving average window size
   ///
   /// Set the moving average windows size for devices that have this capability
   /// This is the number of data points used to calculate the average
   /// The device needs to be capable of averaging measurements in hardware
   ///
   /// \param windowSize the new moving average window size
   UeiDaqAPI void SetMovingAverageWindowSize(int windowSize);

   /// \brief Get mux position mode
   ///
   /// Get the mux position mode for devices with self-test capability
   /// return the current mux position
   UeiDaqAPI tUeiAIChannelMuxPos GetMuxPos();

   /// \brief Set mux position mode
   ///
   /// Set the mux position mode for devices with self-test capability
   /// \param muxPos the new mux position
   UeiDaqAPI void SetMuxPos(tUeiAIChannelMuxPos muxPos);

   /// \brief Get state of input voltage divider
   ///
   /// check whether input voltage divider is enabled
   /// return the current mux position
   UeiDaqAPI bool IsVoltageDividerEnabled();

   /// \brief Set state of input voltage divider
   ///
   /// Enable or disable the input voltage divider
   /// \param enable true to enable voltage divider, false otherwise
   UeiDaqAPI void EnableVoltageDivider(bool enable);

   /// \cond DO_NOT_DOCUMENT
   CUeiAIChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAIChannelImpl> m_pImpl;
};


/// \brief Manages settings for each current input channel
///
/// Manages settings for each current input channel
class CUeiAICurrentChannel : public CUeiAIChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiAICurrentChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAICurrentChannel();

   /// \brief Determines whether the CB is currently protecting the channel
   /// 
   /// Return true is circuit breaker for this channels is enabled and
   /// false otherwise
   ///
   /// \return Circuit breaker state
   UeiDaqAPI tUeiFeatureEnable IsCircuitBreakerEnabled();

   /// \brief Enable or Disable channel protection 
   /// 
   /// Enable or disable circuit breaker on this channel. when enabled a circuit
   /// breaker monitors the current flowing through the channel and opens the circuit
   /// if the current goes out of pre-set limits.
   ///
   /// \param enable True to turn-on protection, false to turn it off
   UeiDaqAPI void EnableCircuitBreaker(tUeiFeatureEnable enable);

   /// Get Circuit breaker high limit
   /// 
   /// Current input channels are equipped with a circuit-breaker 
   /// that monitors current and open the circuit if the monitored current
   /// is higher than the high limit.
   ///
   /// \return the high current limit value.
   UeiDaqAPI double GetCircuitBreakerHighLimit();

   /// Set Circuit breaker high limit
   /// 
   /// Current input channels are equipped with a circuit-breaker 
   /// that monitors current and open the circuit if the monitored current
   /// is higher than the high limit.
   ///
   /// \param highLimit the new high current limit
   UeiDaqAPI void SetCircuitBreakerHighLimit(double highLimit);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAICurrentChannelImpl> m_pImpl;
};


/// \brief Manages settings for each voltage Analog output channel
///
/// Manages settings for each voltage Analog output channel
class CUeiAOChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiAOChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAOChannel();

   /// \brief Get the minimum value
   ///
   /// Get the minimum value for the generated signal.
   ///
   /// \return the minimum value.
   /// \sa SetMinimum  
   UeiDaqAPI f64 GetMinimum();
   
   /// \brief Set the minimum value
   ///
   /// Set the minimum value for the generated signal.
   ///
   /// \param minimum the minimum value.
   /// \sa GetMinimum  
   UeiDaqAPI void SetMinimum(f64 minimum);

   /// \brief Get the maximum value
   ///
   /// Get the maximum value for the generated signal.
   ///
   /// \return the maximum value.
   /// \sa SetMaximum  
   UeiDaqAPI f64 GetMaximum();
   
   /// \brief Set the maximum value
   ///
   /// Set the maximum value for the generated signal.
   ///
   /// \param maximum the maximum value.
   /// \sa GetMaximum  
   UeiDaqAPI void SetMaximum(f64 maximum);

   /// \brief Get the default value state
   ///
   /// Determines whether output will be set to a default value when session stops.
   ///
   /// \return The default value state.
   /// \sa EnableDefaultValue 
   UeiDaqAPI bool IsDefaultValueEnabled(void);

   /// \brief Set the default value state
   ///
   /// Enables default value. The output will be set to a default value when session stops.
   ///
   /// \param enableDefaultValue true to turn stop value on, false otherwise
   /// \sa IsDefaultValueEnabled  
   UeiDaqAPI void EnableDefaultValue(bool enableDefaultValue);

   /// \brief Get the default value
   ///
   /// Get the default value.
   ///
   /// \return the default value.
   /// \sa SetDefaultValue  
   UeiDaqAPI f64 GetDefaultValue();
   
   /// \brief Set the default value
   ///
   /// Set the default value.
   ///
   /// \param defaultVal the default value.
   /// \sa GetDefaultValue  
   UeiDaqAPI void SetDefaultValue(f64 defaultVal);
  
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAOChannelImpl> m_pImpl;
};

/// \brief Manages settings for each current output channel
///
/// Manages settings for each current output channel
class CUeiAOCurrentChannel : public CUeiAOChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiAOCurrentChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAOCurrentChannel();

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAOCurrentChannelImpl> m_pImpl;
};

/// \brief Manages settings for each digital input channel
///
/// Manages settings for each digital input channel
class CUeiDIChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiDIChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDIChannel();

   /// \brief Get the edge detection mask  
   ///
   /// Get the mask used to select wich digital line will be used to sense edges.
   /// When bit x is set to 1, line x is used.
   ///
   /// \param edgeType the edge type to detect 
   /// \return the edge detection mask.
   /// \sa SetEdgeMask  
   UeiDaqAPI uInt32 GetEdgeMask(tUeiDigitalEdge edgeType=UeiDigitalEdgeRising);
   
   /// \brief Set the edge detection mask
   ///
   /// Set the mask used to select wich digital line will be used to sense edges.
   /// When bit x is set to 1, line x is used.
   ///
   /// \param mask the edge detection mask.
   /// \param edgeType the edge type to detect 
   /// \sa GetEdgeMask  
   UeiDaqAPI void SetEdgeMask(uInt32 mask, tUeiDigitalEdge edgeType=UeiDigitalEdgeRising);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDIChannelImpl> m_pImpl;
};

/// \brief Manages settings for each digital output channel
///
/// Manages settings for each digital output channel
class CUeiDOChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiDOChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDOChannel();

   /// \brief Get the default value state
   ///
   /// Determines whether output will be set to a default value when session stops.
   ///
   /// \return The default value state.
   /// \sa EnableDefaultValue 
   UeiDaqAPI bool IsDefaultValueEnabled(void);

   /// \brief Set the default value state
   ///
   /// Enables default value. The output will be set to a default value when session stops.
   ///
   /// \param enableDefaultValue true to turn stop value on, false otherwise
   /// \sa IsDefaultValueEnabled  
   UeiDaqAPI void EnableDefaultValue(bool enableDefaultValue);

   /// \brief Get the default value
   ///
   /// Get the default value.
   ///
   /// \return the default value.
   /// \sa SetDefaultValue  
   UeiDaqAPI uInt32 GetDefaultValue();
   
   /// \brief Set the default value
   ///
   /// Set the default value.
   ///
   /// \param defaultVal the default value.
   /// \sa GetDefaultValue  
   UeiDaqAPI void SetDefaultValue(uInt32 defaultVal);

   /// \brief Get the line output mask  
   ///
   /// Some devices allow configuring different direction for lines in the same port.
   /// Get the mask used to select wich digital line will be used as output.
   /// When bit x is set to 1, line x is used as output.
   ///
   /// \return the output mask.
   /// \sa SetOutputMask  
   UeiDaqAPI uInt32 GetOutputMask();

   /// \brief Set the line output mask
   ///
   /// Some devices allow configuring different direction for lines in the same port.
   /// Set the mask used to select wich digital line will be used as output.
   /// When bit x is set to 1, line x is used as output.
   ///
   /// \param mask the new output mask.
   /// \sa GetOutputMask  
   UeiDaqAPI void SetOutputMask(uInt32 mask);
    
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDOChannelImpl> m_pImpl;
};

/// \brief Manages settings for each counter input channel
///
/// Manages settings for each counter input channel
class CUeiCIChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiCIChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCIChannel();

   /// \brief Get the counter source
   ///
   /// Get the source of the signal counted or used as a timebase
   ///
   /// \return the source.
   /// \sa SetCounterSource  
   UeiDaqAPI tUeiCounterSource GetCounterSource();
   
   /// \brief Set the counter source
   ///
   /// Set the source of the signal counted or used as a timebase
   ///
   /// \param source the source.
   /// \sa GetCounterSource  
   UeiDaqAPI void SetCounterSource(tUeiCounterSource source);

   /// \brief Get the counter mode
   ///
   /// Get the mode that specify whether the session counts events, measures a pulse width or measures a period on the signal configured as the source
   ///
   /// \return the mode.
   /// \sa SetCounterMode  
   UeiDaqAPI tUeiCounterMode GetCounterMode();
   
   /// \brief Set the counter mode
   ///
   /// Set the mode that specify whether the session counts events, measures a pulse width or measures a period on the signal configured as the source
   ///
   /// \param mode the mode.
   /// \sa GetCounterMode  
   UeiDaqAPI void SetCounterMode(tUeiCounterMode mode);

   /// \brief Get the counter gate 
   ///
   /// Get the signal that specify whether the counter/timer is on or off   
   ///
   /// \return the gate.
   /// \sa SetCounterGate  
   UeiDaqAPI tUeiCounterGate GetCounterGate();
   
   /// \brief Set the counter gate  
   ///
   /// Set the signal that specify whether the counter/timer is on or off   
   ///
   /// \param gate the gate.
   /// \sa GetCounterGate  
   UeiDaqAPI void SetCounterGate(tUeiCounterGate gate);

   /// \brief Get the inverted setting 
   ///
   /// Checks whether the signal at the source is inverted before performing the counting operation   
   ///
   /// \return the inverted setting.
   /// \sa SetInverted  
   UeiDaqAPI Int32 GetInverted();
   
   /// \brief Set the inverted setting 
   ///
   /// Specifies whether the signal at the source is inverted before performing the counting operation   
   ///
   /// \param inverted the inverted setting.
   /// \sa GetInverted  
   UeiDaqAPI void SetInverted(Int32 inverted);

   /// \brief Get the timebase divider
   ///
   /// Get the divider used to scale the timebase speed.  
   ///
   /// \return the divider.
   /// \sa SetTimebaseDivider  
   UeiDaqAPI Int32 GetTimebaseDivider();
   
   /// \brief Set the timebase divider
   ///
   /// Set the divider used to scale the timebase speed.  
   ///
   /// \param divider the new divider value.
   /// \sa GetTimebaseDivider 
   UeiDaqAPI void SetTimebaseDivider(Int32 divider);

   /// \brief Get the minimum pulse width at the counter source
   ///
   /// Get the minimum pulse width in ms the counter recognizes at its source. 
   /// Any pulse whose width is smaller will be ignored.
   /// \return the minimum pulse width
   /// \sa SetMinimumSourcePulseWidth
   UeiDaqAPI double GetMinimumSourcePulseWidth();

   /// \brief Set the minimum pulse width at the counter source
   ///
   /// Set the minimum pulse width in ms the counter recognizes at its source. 
   /// Any pulse whose width is smaller will be ignored.
   /// \param minWidth the minimum pulse width
   /// \sa GetMinimumSourcePulseWidth
   UeiDaqAPI void SetMinimumSourcePulseWidth(double minWidth);

   /// \brief Get the minimum pulse width at the counter gate
   ///
   /// Get the minimum pulse width in ms the counter recognizes at its gate. 
   /// Any pulse whose width is smaller will be ignored.
   /// \return the minimum pulse width
   /// \sa SetMinimumGatePulseWidth
   UeiDaqAPI double GetMinimumGatePulseWidth();

   /// \brief Set the minimum pulse width at the counter gate
   ///
   /// Set the minimum pulse width in ms the counter recognizes at its gate. 
   /// Any pulse whose width is smaller will be ignored.
   /// \param minWidth the minimum pulse width
   /// \sa GetMinimumGatePulseWidth
   UeiDaqAPI void SetMinimumGatePulseWidth(double minWidth);

   /// \brief Get the gate mode
   ///
   /// Get the gate mode which determines whether the counter/timer will
   /// run continuously once the gate is asserted
   ///
   /// \return the gate mode.
   /// \sa SetGateMode  
   UeiDaqAPI tUeiCounterGateMode GetGateMode();
   
   /// \brief Set the gate mode
   ///
   /// Set the gate mode which determines whether the counter/timer will
   /// run continuously once the gate is asserted  
   ///
   /// \param gateMode the new gate mode.
   /// \sa GetGateMode 
   UeiDaqAPI void SetGateMode(tUeiCounterGateMode gateMode);

   /// \brief Get the period count
   ///
   /// Get the number of periods used to average a period measurement
   ///
   /// \return the period count.
   /// \sa SetPeriodCount  
   UeiDaqAPI Int32 GetPeriodCount();
   
   /// \brief Set the period count
   ///
   /// Set the number of period(s) to measure. An average measurement is returned.
   ///
   /// \param periodCount the new period count.
   /// \sa GetPeriodCount 
   UeiDaqAPI void SetPeriodCount(Int32 periodCount);

   /// \brief Get the capture timebase
   ///
   /// Get the capture timebase which determines the precision of period, frequency
   /// and pulse width measurements
   ///
   /// \return the the capture timebase.
   /// \sa SetCaptureTimebase  
   UeiDaqAPI tUeiCounterCaptureTimebase GetCaptureTimebase();
   
   /// \brief Set the capture timebase
   ///
   /// Set the capture timebase which determines the precision of period, frequency
   /// and pulse width measurements
   ///
   /// \param captureTimebase the new capture timebase.
   /// \sa tUeiCounterCaptureTimebase 
   UeiDaqAPI void SetCaptureTimebase(tUeiCounterCaptureTimebase captureTimebase);

   /// \brief Get the counter source pin
   ///
   /// Get the pin used as counter source. The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI std::string GetSourcePin();

   /// \brief Set the counter source pin
   ///
   /// Set the pin used as counter source. The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI void SetSourcePin(std::string pin);

   /// \brief Get the counter gate pin
   ///
   /// Get the pin used as counter gate. The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI std::string GetGatePin();

   /// \brief Set the counter gate pin
   ///
   /// Set the pin used as counter gate. The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI void SetGatePin(std::string pin);

   /// \brief Get the counter output pin(s)
   ///
   /// Get the pin(s) used as counter output. 
   /// Multiple pins can be used as output when specified in a comma separated list
   /// The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI std::string GetOutputPins();

   /// \brief Set the counter output pin
   ///
   /// set the pin(s) used as counter output. 
   /// Multiple pins can be used as output when specified in a comma separated list.
   /// The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI void SetOutputPins(std::string pins);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCIChannelImpl> m_pImpl;
};


/// \brief Manages settings for each counter input channel
///
/// Manages settings for each counter input channel
class CUeiQuadratureEncoderChannel : public CUeiCIChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiQuadratureEncoderChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiQuadratureEncoderChannel();

   /// \brief Get the initial position
   ///
   /// Get the initial number of pulses when the measurement begins.
   /// This value is reloaded each time the Z input resets the measurement.
   /// \return the initial positions
   /// \sa SetInitialPosition
   UeiDaqAPI uInt32 GetInitialPosition();

   /// \brief Set the initial position
   ///
   /// Set the initial number of pulses when the measurement begins.
   /// This value is reloaded each time the Z input resets the measurement.
   /// \param initialPos the initial position
   /// \sa GetInitialPosition
   UeiDaqAPI void SetInitialPosition(uInt32 initialPos);

   /// \brief Get the decoding type
   ///
   /// Get the method used to count and interpret the pulses the encoder 
   /// generates on input A and B.
   /// 2x and 4x decoding are more sensitive to smaller changes in position. 
   /// \return the decoding type
   /// \sa SetDecodingType
   UeiDaqAPI tUeiQuadratureDecodingType GetDecodingType();

   /// \brief Set the decoding type
   ///
   /// Set the method used to count and interpret the pulses the encoder 
   /// generates on input A and B.
   /// 2x and 4x decoding are more sensitive to smaller changes in position. 
   /// \param decodingType the decoding type
   /// \sa GetDecodingType
   UeiDaqAPI void SetDecodingType(tUeiQuadratureDecodingType decodingType);

   /// \brief Get the zero indexing state
   ///
   /// Zero indexing resets the measurement to the initial value when the Z, A and B inputs
   /// are in a specified state.
   ///
   /// \return the zero indexing state.
   /// \sa EnableZeroIndexing  
   UeiDaqAPI bool IsZeroIndexingEnabled();

   /// \brief Enable or Disable zero indexing
   ///
   /// Zero indexing resets the measurement to the initial value when the Z, A and B inputs
   /// are in a specified state.
   ///
   /// \param enabled the zero indexing state
   /// \sa IsZeroIndexingEnabled  
   UeiDaqAPI void EnableZeroIndexing(bool enabled);

   /// \brief Get the zero indexing phase
   ///
   /// Get the states at which A and B input signals must be in when Z is high
   /// to trigger a measurement reset 
   /// \return the zero indexing phase
   /// \sa SetZeroIndexPhase
   UeiDaqAPI tUeiQuadratureZeroIndexPhase GetZeroIndexPhase();

   /// \brief Set the zero indexing phase
   ///
   /// Set the states at which A and B input signals must be in when Z is high
   /// to trigger a measurement reset
   /// \param zeroIndexPhase the zero indexing phase
   /// \sa GetZeroIndexPhase
   UeiDaqAPI void SetZeroIndexPhase(tUeiQuadratureZeroIndexPhase zeroIndexPhase);

   /// \brief Get the minimum pulse width at input A
   ///
   /// Get the minimum pulse width in ms the counter recognizes at input A. 
   /// Any pulse whose width is smaller will be ignored.
   /// \return the minimum pulse width
   /// \sa SetMinimumInputAPulseWidth
   UeiDaqAPI double GetMinimumInputAPulseWidth();

   /// \brief Set the minimum pulse width at input A
   ///
   /// Set the minimum pulse width in ms the counter recognizes at input A. 
   /// Any pulse whose width is smaller will be ignored.
   /// \param minWidth the minimum pulse width
   /// \sa GetMinimumInputAPulseWidth
   UeiDaqAPI void SetMinimumInputAPulseWidth(double minWidth);

   /// \brief Get the minimum pulse width at input B
   ///
   /// Get the minimum pulse width in ms the counter recognizes at input B. 
   /// Any pulse whose width is smaller will be ignored.
   /// \return the minimum pulse width
   /// \sa SetMinimumInputBPulseWidth
   UeiDaqAPI double GetMinimumInputBPulseWidth();

   /// \brief Set the minimum pulse width at input B
   ///
   /// Set the minimum pulse width in ms the counter recognizes at input B. 
   /// Any pulse whose width is smaller will be ignored.
   /// \param minWidth the minimum pulse width
   /// \sa GetMinimumInputBPulseWidth
   UeiDaqAPI void SetMinimumInputBPulseWidth(double minWidth);

   /// \brief Get the minimum pulse width at input Z
   ///
   /// Get the minimum pulse width in ms the counter recognizes at input Z. 
   /// Any pulse whose width is smaller will be ignored.
   /// \return the minimum pulse width
   /// \sa SetMinimumInputZPulseWidth
   UeiDaqAPI double GetMinimumInputZPulseWidth();

   /// \brief Set the minimum pulse width at input Z
   ///
   /// Set the minimum pulse width in ms the counter recognizes at input Z. 
   /// Any pulse whose width is smaller will be ignored.
   /// \param minWidth the minimum pulse width
   /// \sa GetMinimumInputZPulseWidth
   UeiDaqAPI void SetMinimumInputZPulseWidth(double minWidth);

   /// \brief Get the minimum pulse width at trigger input 
   ///
   /// Get the minimum pulse width in ms the counter recognizes at trigger input. 
   /// Any pulse whose width is smaller will be ignored.
   /// \return the minimum pulse width
   /// \sa SetMinimumTriggerInputPulseWidth
   UeiDaqAPI double GetMinimumTriggerInputPulseWidth();

   /// \brief Set the minimum pulse width at trigger input
   ///
   /// Set the minimum pulse width in ms the counter recognizes at trigger input. 
   /// Any pulse whose width is smaller will be ignored.
   /// \param minWidth the minimum pulse width
   /// \sa GetMinimumTriggerInputPulseWidth
   UeiDaqAPI void SetMinimumTriggerInputPulseWidth(double minWidth);

   /// \brief Get the timestamping state
   ///
   /// Determines whether each received measurement is timestamped.
   ///
   /// \return The timestamping state.
   /// \sa EnableTimestamping  
   UeiDaqAPI bool IsTimestampingEnabled(void);

   /// \brief Set the timestamping state
   ///
   /// Specifies whether each received measurement is timestamped.
   ///
   /// \param enableTimestamping true to turn timestamping on, false otherwise
   /// \sa IsTimestampingEnabled  
   UeiDaqAPI void EnableTimestamping(bool enableTimestamping);

   /// \brief Get the timestamp resolution
   ///
   /// Get the timestamp resolution in seconds.
   ///
   /// \return the timestamp resolution.
   /// \sa SetTimestampResolution  
   UeiDaqAPI f64 GetTimestampResolution();

   /// \brief Set the timestamp resolution
   ///
   /// Set the timestamp resolution in seconds.
   ///
   /// \param resolution the new resolution.
   /// \sa GetTimestampResolution  
   UeiDaqAPI void SetTimestampResolution(f64 resolution);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiQuadratureEncoderChannelImpl> m_pImpl;
};

/// \brief Manages settings for each frequency output channel
///
/// Manages settings for each frequency output channel
class CUeiCOChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiCOChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCOChannel();

   /// \brief Get the counter source
   ///
   /// Get the source of the signal used as a timebase
   ///
   /// \return the source.
   /// \sa GetCounterSource  
   UeiDaqAPI tUeiCounterSource GetCounterSource();
   
   /// \brief Set the counter source 
   ///
   /// Set the source of the signal used as a timebase
   ///
   /// \param source the source.
   /// \sa GetCounterSource  
   UeiDaqAPI void SetCounterSource(tUeiCounterSource source);

   /// \brief Get the counter mode
   ///
   /// Get the mode that specify whether the session generates a single pulse or a pulse train on the counter output
   ///
   /// \return the mode.
   /// \sa SetCounterMode  
   UeiDaqAPI tUeiCounterMode GetCounterMode();
   
   /// \brief Set the counter mode
   ///
   /// Set the mode that specify whether the session generates a single pulse or a pulse train on the counter output
   ///
   /// \param mode the mode.
   /// \sa GetCounterMode  
   UeiDaqAPI void SetCounterMode(tUeiCounterMode mode);

   /// \brief Get the counter gate
   ///
   /// Get the signal that specify whether the counter/timer is on or off   
   ///
   /// \return the gate.
   /// \sa SetCounterGate  
   UeiDaqAPI tUeiCounterGate GetCounterGate();
   
   /// \brief Set the counter gate 
   ///
   /// Set the signal that specify whether the counter/timer is on or off   
   ///
   /// \param gate the gate.
   /// \sa GetCounterGate  
   UeiDaqAPI void SetCounterGate(tUeiCounterGate gate);

   /// \brief Get the inverted setting
   ///
   /// Checks whether the signal at the source is inverted before performing the timing operation   
   ///
   /// \return the inverted setting.
   /// \sa SetInverted  
   UeiDaqAPI Int32 GetInverted();
   
   /// \brief Set the inverted setting
   ///
   /// Specifies whether the signal at the source is inverted before performing the timing operation   
   ///
   /// \param inverted the inverted setting.
   /// \sa GetInverted  
   UeiDaqAPI void SetInverted(Int32 inverted);

   /// \brief Get the number of ticks
   ///
   /// Specifies how long the output stays low.  
   ///
   /// \return the number of ticks of the signal connected at the source.
   /// \sa SetTick1  
   UeiDaqAPI Int32 GetTick1();
   
   /// \brief Set the number of ticks 
   ///
   /// Specifies how long the output stays low.  
   ///
   /// \param tick1 the number of ticks of the signal connected at the source.
   /// \sa GetTick1  
   UeiDaqAPI void SetTick1(Int32 tick1);

   /// \brief Get the number of ticks
   ///
   /// Specifies how long the output stays high.  
   ///
   /// \return the number of ticks of the signal connected at the source.
   /// \sa SetTick2  
   UeiDaqAPI Int32 GetTick2();
   
   /// \brief Set the number of ticks
   ///
   /// Specifies how long the output stays high.  
   ///
   /// \param tick2 the number of ticks of the signal connected at the source.
   /// \sa GetTick2 
   UeiDaqAPI void SetTick2(Int32 tick2);

   /// \brief Get the timebase divider
   ///
   /// Get the divider used to scale the timebase speed.  
   ///
   /// \return the divider.
   /// \sa SetTimebaseDivider  
   UeiDaqAPI Int32 GetTimebaseDivider();
   
   /// \brief Set the timebase divider
   ///
   /// Set the divider used to scale the timebase speed.  
   ///
   /// \param divider the new divider value.
   /// \sa GetTimebaseDivider 
   UeiDaqAPI void SetTimebaseDivider(Int32 divider);
    
   /// \brief Get the minimum pulse width at the counter source
   ///
   /// Get the minimum pulse width in ms the counter recognizes at its source. 
   /// Any pulse whose width is smaller will be ignored.
   /// \return the minimum pulse width
   /// \sa SetMinimumSourcePulseWidth
   UeiDaqAPI double GetMinimumSourcePulseWidth();

   /// \brief Set the minimum pulse width at the counter source
   ///
   /// Set the minimum pulse width in ms the counter recognizes at its source. 
   /// Any pulse whose width is smaller will be ignored.
   /// Set the minimum pulse width to 0 to disable digital filtering.
   /// \param minWidth the minimum pulse width
   /// \sa GetMinimumSourcePulseWidth
   UeiDaqAPI void SetMinimumSourcePulseWidth(double minWidth);

   /// \brief Get the minimum pulse width at the counter gate
   ///
   /// Get the minimum pulse width in ms the counter recognizes at its gate. 
   /// Any pulse whose width is smaller will be ignored.
   /// \return the minimum pulse width
   /// \sa SetMinimumGatePulseWidth
   UeiDaqAPI double GetMinimumGatePulseWidth();

   /// \brief Set the minimum pulse width at the counter gate
   ///
   /// Set the minimum pulse width in ms the counter recognizes at its gate. 
   /// Any pulse whose width is smaller will be ignored.
   /// Set the minimum width to 0 to disable digital filtering.
   /// \param minWidth the minimum pulse width
   /// \sa GetMinimumGatePulseWidth
   UeiDaqAPI void SetMinimumGatePulseWidth(double minWidth);

   /// \brief Get the gate mode
   ///
   /// Get the gate mode which determines whether the counter/timer will
   /// run continuously once the gate is asserted
   ///
   /// \return the gate mode.
   /// \sa SetGateMode  
   UeiDaqAPI tUeiCounterGateMode GetGateMode();
   
   /// \brief Set the gate mode
   ///
   /// Set the gate mode which determines whether the counter/timer will
   /// run continuously once the gate is asserted  
   ///
   /// \param gateMode the new gate mode.
   /// \sa GetGateMode 
   UeiDaqAPI void SetGateMode(tUeiCounterGateMode gateMode);

   /// \brief Get the pulse count
   ///
   /// Get the number of pulses to generate (-1 for continuous)
   ///
   /// \return the current number of pulses.
   /// \sa SetNumberOfPulses  
   UeiDaqAPI Int32 GetNumberOfPulses();
   
   /// \brief Set the pulse count
   ///
   /// Set the number of pulses to generate (-1 for continuous)
   ///
   /// \param numberOfPulses the new number of pulses.
   /// \sa GetNumberOfPulses 
   UeiDaqAPI void SetNumberOfPulses(Int32 numberOfPulses);

   /// \brief Get the counter source pin
   ///
   /// Get the pin used as counter source. The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI std::string GetSourcePin();

   /// \brief Set the counter source pin
   ///
   /// Set the pin used as counter source. The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI void SetSourcePin(std::string pin);

   /// \brief Get the counter gate pin
   ///
   /// Get the pin used as counter gate. The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI std::string GetGatePin();

   /// \brief Set the counter gate pin
   ///
   /// Set the pin used as counter gate. The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI void SetGatePin(std::string pin);

   /// \brief Get the counter output pin(s)
   ///
   /// Get the pin(s) used as counter output. 
   /// Multiple pins can be used as output when specified in a comma separated list
   /// The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI std::string GetOutputPins();

   /// \brief Set the counter output pin
   ///
   /// set the pin(s) used as counter output. 
   /// Multiple pins can be used as output when specified in a comma separated list.
   /// The pin name is device dependent
   /// Consult the device's user manual to learn about available pins
   UeiDaqAPI void SetOutputPins(std::string pins);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCOChannelImpl> m_pImpl;
};

/// \brief Manages settings for each thermocouple input channel
///
/// Manages settings for each thermocouple input channel
class CUeiTCChannel : public CUeiAIChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiTCChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiTCChannel();
    
   /// \brief Get the thermocouple type
   ///
   /// Get the type of the thermocouple connected to the channel.
   ///
   /// \return the thermocouple type.
   /// \sa SetThermocoupleType  
   UeiDaqAPI tUeiThermocoupleType GetThermocoupleType();
   
   /// \brief Set the thermocouple type
   ///
   /// Set the type of the thermocouple connected to the channel.
   ///
   /// \param tcType the thermocouple type.
   /// \sa GetThermocoupleType  
   UeiDaqAPI void SetThermocoupleType(tUeiThermocoupleType tcType);

   /// \brief Get the temperature scale
   ///
   /// Get the temperature scale used to convert the measured voltage to temperature.
   ///
   /// \return the temperature scale.
   /// \sa SetTemperatureScale  
   UeiDaqAPI tUeiTemperatureScale GetTemperatureScale();
   
   /// \brief Set the temperature scale
   ///
   /// Set the temperature scale used to convert the measured voltage to temperature.
   ///
   /// \param tempScale the temperature scale.
   /// \sa GetTemperatureScale  
   UeiDaqAPI void SetTemperatureScale(tUeiTemperatureScale tempScale);

   /// \brief Get the cold junction compensation type 
   ///
   /// Get the type of the cold junction compensation used to convert from
   /// volts to temperature.
   ///
   /// \return the cold junction compensation type.
   /// \sa SetCJCType  
   UeiDaqAPI tUeiColdJunctionCompensationType GetCJCType();
   
   /// \brief Set the cold junction compensation type
   ///
   /// Set the type of the cold junction compensation used to convert from
   /// volts to temperature.
   ///
   /// \param cjcType the cold junction compensation type.
   /// \sa GetCJCType  
   UeiDaqAPI void SetCJCType(tUeiColdJunctionCompensationType cjcType);

   /// \brief Get the cold junction compensation resource 
   ///
   /// Get the resource string describing how to measure the cold junction temperature.
   /// This setting is only used when the CJC type is set to UeiCJCTypeResource.
   /// The CJC resource format is similar to the channel list format:
   /// [cjcSensorType]://[Channel(s)]?[Paramters]
   /// cjcSensorType can be UTR, IC or AZ
   ///
   /// UTR (Universal temperature reference), CJC is measured from an UTR RTD connected on the specified channel(s)
   /// Resource format is utr://0,1?A=65.3835,B=22.4752,C=498.063
   /// where A,B and C are the RTD's coefficients for the Callendar Van-Dusen equation
   ///
   /// IC: CJC is measured from an IC temperature sensor connected on the specified channel
   /// Resource format is ic://24?K=0.00295
   /// where K is the sensor's coefficient
   ///
   /// AZ: CJC is measured from an IC temperature sensor and Autozero offset is measured from a specified channel
   /// Resource format is az://23,24?K=0.00295
   /// where K is the sensor's coefficient
   ///
   /// Example:
   /// To measure CJC from a linear IC sensor connected to channel 20
   /// the resource string is "ic://20?K=0.00295"
   /// this will measure the voltage on channel 20 and compute the CJC temperature
   /// with the formula: degK = V / 0.00295
   ///
   /// \return the cold junction compensation resource.
   /// \sa SetCJCResource  
   UeiDaqAPI std::string GetCJCResource();
   
   /// \brief Set the cold junction compensation resource
   ///
   /// Set the resource string describing how to measure the cold junction temperature.
   /// This setting is only used when the CJC type is set to UeiCJCTypeResource.
   /// The CJC resource format is similar to the channel list format:
   /// [cjcSensorType]://[Channel(s)]?[Paramters]
   /// cjcSensorType can be UTR, IC or AZ
   ///
   /// UTR (Universal temperature reference), CJC is measured from an UTR RTD connected on the specified channel(s)
   /// Resource format is utr://0,1?A=65.3835,B=22.4752,C=498.063
   /// where A,B and C are the RTD's coefficients for the Callendar Van-Dusen equation
   ///
   /// IC: CJC is measured from an IC temperature sensor connected on the specified channel
   /// Resource format is ic://24?K=0.00295
   /// where K is the sensor's coefficient
   ///
   /// AZ: CJC is measured from an IC temperature sensor and Autozero offset is measured from a specified channel
   /// Resource format is az://23,24?K=0.00295
   /// where K is the sensor's coefficient
   ///
   /// Example:
   /// To measure CJC from a linear IC sensor connected to channel 20
   /// the resource string is "ic://20?K=0.00295"
   /// this will measure the voltage on channel 20 and compute the CJC temperature
   /// with the formula: degK = V / 0.00295
   ///
   /// \param cjcResource the cold junction compensation resource.
   /// \sa GetCJCResource  
   UeiDaqAPI void SetCJCResource(std::string cjcResource);

   /// \brief Get the cold junction compensation constant 
   ///
   /// Get the cold junction compensation temperature constant. This setting
   /// is only used when the CJC type is set to UeiCJCTypeConstant. The unit
   /// is the same as the configured temperature scale.
   ///
   /// \return the cold junction compensation constant.
   /// \sa SetCJCConstant  
   UeiDaqAPI UeiDaq::f64 GetCJCConstant();
   
   /// \brief Set the cold junction compensation constant
   ///
   /// Set the cold junction compensation temperature constant. This setting
   /// is only used when the CJC type is set to UeiCJCTypeConstant. The unit
   /// is the same as the configured temperature scale.
   ///
   /// \param cjcConstant the cold junction compensation constant.
   /// \sa GetCJCConstant  
   UeiDaqAPI void SetCJCConstant(UeiDaq::f64 cjcConstant);

   /// \cond DO_NOT_DOCUMENT
   CUeiTCChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond 

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiTCChannelImpl> m_pImpl;
};


/// \brief Manages settings for each resistance input channel
///
/// Manages settings for each resistance input channel
class CUeiResistanceChannel : public CUeiAIChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiResistanceChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiResistanceChannel();

   /// \brief Get the wiring scheme
   ///
   /// Get the current wiring scheme used for this channel.
   ///
   /// \return The current wiring scheme.
   /// \sa SetWiringScheme   
   UeiDaqAPI tUeiWiringScheme GetWiringScheme();

   /// \brief Set the wiring scheme
   ///
   /// Specifies the wiring scheme used to connect the resistive sensor to the channel. 
   ///
   /// \param wiring The new wiring scheme.
   /// \sa GetWiringScheme  
   UeiDaqAPI void SetWiringScheme(tUeiWiringScheme wiring);

   /// \brief Get the excitation voltage
   ///
   /// Get the excitation voltage configured for the channel.
   ///
   /// \return The excitation voltage.
   /// \sa SetExcitationVoltage  
   UeiDaqAPI double GetExcitationVoltage();

   /// \brief Set the excitation voltage
   ///
   /// Set the excitation voltage for this channel.
   ///
   /// \param vex The excitation voltage
   /// \sa GetExcitationVoltage  
   UeiDaqAPI void SetExcitationVoltage(double vex);

   /// \brief Get the reference resistor type
   ///
   /// The reference resistor can be built-in the connector block if you are using
   /// a DNA-STP-AIU or connected externally.
   ///
   /// \return The reference resistor type.
   /// \sa SetReferenceResistorType   
   UeiDaqAPI tUeiReferenceResistorType GetReferenceResistorType();

   /// \brief Set the reference resistor type
   ///
   /// The reference resistor can be built-in the connector block if you are using
   /// a DNA-STP-AIU or connected externally. 
   ///
   /// \param refResistorType The reference resistor type.
   /// \sa GetReferenceResistorType  
   UeiDaqAPI void SetReferenceResistorType(tUeiReferenceResistorType refResistorType);

   /// \brief Get the reference resistance
   ///
   /// Get the reference resistance used to measure the current flowing through 
   /// the resistive sensor.
   ///
   /// \return The reference resistance.
   /// \sa SetReferenceResistance  
   UeiDaqAPI double GetReferenceResistance();

   /// \brief Set the reference resistance
   ///
   /// Set the reference resistance used to measure the current flowing through 
   /// the resistive sensor.
   ///
   /// \param rref The reference resistance
   /// \sa GetReferenceResistance  
   UeiDaqAPI void SetReferenceResistance(double rref);

   /// \cond DO_NOT_DOCUMENT
   CUeiResistanceChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond 

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiResistanceChannelImpl> m_pImpl;
};


/// \brief Manages settings for each RTD input channel
///
/// Manages settings for each RTD input channel
class CUeiRTDChannel : public CUeiResistanceChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiRTDChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiRTDChannel();

   /// \brief Get the RTD type
   ///
   /// RTD sensors are specified using the "alpha" (a) constant
   /// It is also known as the temperature coefficient of resistance, 
   /// and symbolizes the resistance change factor per degree of 
   /// temperature change.
   /// The RTD type is used to select the proper coefficients A, B and C
   /// for the Callendar Van-Dusen equation used to convert resistance
   /// measurements to temperature.
   ///
   /// \return The RTD type.
   /// \sa SetRTDType  
   UeiDaqAPI tUeiRTDType GetRTDType();

   /// \brief Set the RTD type
   ///
   /// RTD sensors are specified using the "alpha" (a) constant
   /// It is also known as the temperature coefficient of resistance, 
   /// and symbolizes the resistance change factor per degree of 
   /// temperature change.
   /// The RTD type is used to select the proper coefficients A, B and C
   /// for the Callendar Van-Dusen equation used to convert resistance
   /// measurements to temperature.
   ///
   /// \param type The RTD type
   /// \sa GetRTDType  
   UeiDaqAPI void SetRTDType(tUeiRTDType type);

   /// \brief Get the RTD nominal resistance
   ///
   /// Get the RTD nominal resistance at 0 deg.
   ///
   /// \return The RTD nominal resistance.
   /// \sa SetRTDNominalResistance  
   UeiDaqAPI double GetRTDNominalResistance();

   /// \brief Set the RTD nominal resistance
   ///
   /// Set the RTD nominal resistance at 0 deg.
   ///
   /// \param r0 The RTD nominal resistance
   /// \sa GetRTDNominalResistance  
   UeiDaqAPI void SetRTDNominalResistance(double r0);

   /// \brief Get the Callendar Van-Dusen coefficient A
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \return The CVD A coefficient.
   /// \sa SetCoefficientA  
   UeiDaqAPI double GetCoefficientA();

   /// \brief Set the Callendar Van-Dusen coefficient A
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \param A The CVD A coefficient
   /// \sa GetCoefficientA  
   UeiDaqAPI void SetCoefficientA(double A);

   /// \brief Get the Callendar Van-Dusen coefficient B
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \return The CVD B coefficient.
   /// \sa SetCoefficientB  
   UeiDaqAPI double GetCoefficientB();

   /// \brief Set the Callendar Van-Dusen coefficient B
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \param B The CVD B coefficient
   /// \sa GetCoefficientB  
   UeiDaqAPI void SetCoefficientB(double B);

   /// \brief Get the Callendar Van-Dusen coefficient C
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \return The CVD C coefficient.
   /// \sa SetCoefficientC  
   UeiDaqAPI double GetCoefficientC();

   /// \brief Set the Callendar Van-Dusen coefficient C
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \param C The CVD C coefficient
   /// \sa GetCoefficientC  
   UeiDaqAPI void SetCoefficientC(double C);

   /// \brief Get the temperature scale
   ///
   /// Get the temperature scale used to convert the measured resistance to temperature.
   ///
   /// \return the temperature scale.
   /// \sa SetTemperatureScale  
   UeiDaqAPI tUeiTemperatureScale GetTemperatureScale();
   
   /// \brief Set the temperature scale
   ///
   /// Set the temperature scale used to convert the measured resistance to temperature.
   ///
   /// \param tempScale the temperature scale.
   /// \sa GetTemperatureScale  
   UeiDaqAPI void SetTemperatureScale(tUeiTemperatureScale tempScale);

   /// \cond DO_NOT_DOCUMENT
   CUeiRTDChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond 

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiRTDChannelImpl> m_pImpl;
};

/// \brief Manages settings for each simulated RTD output channel
///
/// Manages settings for each simulated RTD output channel
class CUeiSimulatedRTDChannel : public CUeiAOChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiSimulatedRTDChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSimulatedRTDChannel();

   /// \brief Get the simulated RTD type
   ///
   /// RTD sensors are specified using the "alpha" (a) constant
   /// It is also known as the temperature coefficient of resistance, 
   /// and symbolizes the resistance change factor per degree of 
   /// temperature change.
   /// The RTD type is used to select the proper coefficients A, B and C
   /// for the Callendar Van-Dusen equation used to convert temperature to 
   /// resistance.
   ///
   /// \return The simulated RTD type.
   /// \sa SetRTDType  
   UeiDaqAPI tUeiRTDType GetRTDType();

   /// \brief Set the simulated RTD type
   ///
   /// RTD sensors are specified using the "alpha" (a) constant
   /// It is also known as the temperature coefficient of resistance, 
   /// and symbolizes the resistance change factor per degree of 
   /// temperature change.
   /// The RTD type is used to select the proper coefficients A, B and C
   /// for the Callendar Van-Dusen equation used to convert temperature
   /// to resistance.
   ///
   /// \param type The simulated RTD type
   /// \sa GetRTDType  
   UeiDaqAPI void SetRTDType(tUeiRTDType type);

   /// \brief Get the simulated RTD nominal resistance
   ///
   /// Get the simulated RTD nominal resistance at 0 deg.
   ///
   /// \return The simulated RTD nominal resistance.
   /// \sa SetRTDNominalResistance  
   UeiDaqAPI double GetRTDNominalResistance();

   /// \brief Set the simulated RTD nominal resistance
   ///
   /// Set the simulated RTD nominal resistance at 0 deg.
   ///
   /// \param r0 The simulated RTD nominal resistance
   /// \sa GetRTDNominalResistance  
   UeiDaqAPI void SetRTDNominalResistance(double r0);

   /// \brief Get the Callendar Van-Dusen coefficient A
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \return The CVD A coefficient.
   /// \sa SetCoefficientA  
   UeiDaqAPI double GetCoefficientA();

   /// \brief Set the Callendar Van-Dusen coefficient A
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \param A The CVD A coefficient
   /// \sa GetCoefficientA  
   UeiDaqAPI void SetCoefficientA(double A);

   /// \brief Get the Callendar Van-Dusen coefficient B
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \return The CVD B coefficient.
   /// \sa SetCoefficientB  
   UeiDaqAPI double GetCoefficientB();

   /// \brief Set the Callendar Van-Dusen coefficient B
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \param B The CVD B coefficient
   /// \sa GetCoefficientB  
   UeiDaqAPI void SetCoefficientB(double B);

   /// \brief Get the Callendar Van-Dusen coefficient C
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \return The CVD C coefficient.
   /// \sa SetCoefficientC  
   UeiDaqAPI double GetCoefficientC();

   /// \brief Set the Callendar Van-Dusen coefficient C
   ///
   /// The Callendar-Van Dusen equation is an equation that describes 
   /// the relationship between resistance (R) and temperature (t) of platinum 
   /// resistance thermometers.
   /// t &lt; 0: R(t) = R(0)[1 + A * t + B * t * t + (t - 100)C * t * t * t].
   /// t &gt; 0: R(t) = R(0)(1 + A * t + B * t * t).
   ///
   /// \param C The CVD C coefficient
   /// \sa GetCoefficientC  
   UeiDaqAPI void SetCoefficientC(double C);

   /// \brief Get the temperature scale
   ///
   /// Get the temperature scale used to convert the simulated temperature to resistance.
   ///
   /// \return the temperature scale.
   /// \sa SetTemperatureScale  
   UeiDaqAPI tUeiTemperatureScale GetTemperatureScale();

   /// \brief Set the temperature scale
   ///
   /// Set the temperature scale used to convert the simulated temperature to resistance.
   ///
   /// \param tempScale the temperature scale.
   /// \sa GetTemperatureScale  
   UeiDaqAPI void SetTemperatureScale(tUeiTemperatureScale tempScale);

   /// \brief Determines whether the CB is currently protecting the channel
   /// 
   /// Return true if circuit breaker for this channel is enabled and
   /// false otherwise
   ///
   /// \return Circuit breaker state
   UeiDaqAPI bool IsCircuitBreakerEnabled();

   /// \brief Enable or Disable channel protection 
   /// 
   /// Enable or disable circuit breaker on this channel. when enabled a circuit
   /// breaker monitors up a diagnostic channel and opens the circuit
   /// if any of the measurements goes out of pre-set limits.
   ///
   /// \param enable True to turn-on protection, false to turn it off
   UeiDaqAPI void EnableCircuitBreaker(bool enable);

   /// \brief Get the circuit breaker maximum current limit
   ///
   /// Each circuit-breaker can monitor one diagnostic channels.
   /// Get the maximum current allowed on the specified channel.
   /// The circuit will open if more than the maximum value is monitored.
   ///
   /// \return The current limit.
   UeiDaqAPI double GetCircuitBreakerCurrentLimit();

   /// \brief Set the circuit breaker maximum current limit
   ///
   /// Each circuit-breaker can monitor one diagnostic channel.
   /// Set the maximum current allowed on the specified channel.
   /// The circuit will open if more than the maximum value is monitored.
   ///
   /// \param currentLimit The new current limit.
   UeiDaqAPI void SetCircuitBreakerCurrentLimit(double currentLimit);

   /// \brief Get the maximum circuit breaker temperature limit
   ///
   /// Each circuit-breaker can monitor one diagnostic channel.
   /// Get the maximum temperature allowed on the specified channel.
   /// The circuit will open if more than the maximum value is monitored.
   ///
   /// \return The current temperature limit in celsius.
   UeiDaqAPI double GetCircuitBreakerTemperatureLimit();

   /// \brief Set the maximum circuit breaker temperature limit
   ///
   /// Each circuit-breaker can monitor one diagnostic channel.
   /// Set the maximum temperature allowed on the specified channel.
   /// The circuit will open if more than the maximum value is monitored.
   ///
   /// \param temperatureLimit The new temperature limit in celsius.
   UeiDaqAPI void SetCircuitBreakerTemperatureLimit(double temperatureLimit);

   /// \brief Get the over/under count. 
   ///
   /// Specifies number of consecutive over/under limit diagnostic readings that must 
   /// occur in order to trip breaker. 
   ///
   /// \return The maximum number of over/under readings.
   /// \sa SetOverUnderCount
   UeiDaqAPI uInt32 GetOverUnderCount(void);

   /// \brief Set the over/under count. 
   ///
   /// Specifies number of consecutive over/under limit diagnostic readings that must 
   /// occur in order to trip breaker. 
   ///
   /// \param overUnderCount The new maximum number of over/under readings.
   /// \sa GetOverUnderCount
   UeiDaqAPI void SetOverUnderCount(uInt32 overUnderCount);

   /// \cond DO_NOT_DOCUMENT
   CUeiSimulatedRTDChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond 

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSimulatedRTDChannelImpl> m_pImpl;
};

/// \brief Manages settings for each voltage with excitation input channel
///
/// Manages settings for each voltage with excitation input channel
/// for sensors that require excitation such as load cells and pressure sensors.
class CUeiAIVExChannel : public CUeiAIChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiAIVExChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAIVExChannel();

   /// \brief Get the bridge type
   ///
   /// Get the bridge type configured for the sensor connected to this channel.
   ///
   /// \return the bridge type.
   /// \sa SetBridgeType  
   UeiDaqAPI tUeiSensorBridgeType GetBridgeType();

   /// \brief Set the bridge type
   ///
   /// Set the bridge type for the sensor connected to this channel.
   ///
   /// \param type The bridge type
   /// \sa GetBridgeType  
   UeiDaqAPI void SetBridgeType(tUeiSensorBridgeType type);

   /// \brief Get the excitation voltage
   ///
   /// Get the excitation voltage configured for the channel.
   ///
   /// \return The excitation voltage.
   /// \sa SetExcitationVoltage  
   UeiDaqAPI double GetExcitationVoltage();

   /// \brief Set the excitation voltage
   ///
   /// Set the excitation voltage for this channel.
   ///
   /// \param vex The excitation voltage
   /// \sa GetExcitationVoltage  
   UeiDaqAPI void SetExcitationVoltage(double vex);

   /// \brief Get the measured excitation voltage
   ///
   /// Get the actual excitation voltage measured on this channel.
   ///
   /// \return The actual measured excitation voltage.
   /// \sa GetExcitationVoltage SetExcitationVoltage  
   UeiDaqAPI double GetMeasuredExcitationVoltage();

   /// \brief Set the excitation frequency
   ///
   /// Set the excitation frequency for this channel.
   /// Set frequency to 0.0 for DC excitation.
   ///
   /// \param fex The excitation frequency
   /// \sa GetExcitationFrequency  
   UeiDaqAPI void SetExcitationFrequency(double fex);

   /// \brief Get the excitation frequency
   ///
   /// Get the excitation frequency configured for the channel.
   ///
   /// \return The excitation frequency.
   /// \sa SetExcitationFrequency  
   UeiDaqAPI double GetExcitationFrequency();

   /// \brief Get the actual excitation frequency
   ///
   /// Get the actual excitation frequency generated for this channel.
   ///
   /// \return The actual excitation frequency.
   /// \sa GetExcitationFrequency SetExcitationFrequency  
   UeiDaqAPI double GetActualExcitationFrequency();

   /// \brief Get the scaling mode
   ///
   /// Determines if acquired data will be divided by the excitation
   /// before being returned.
   ///
   /// \return the scaling mode .
   /// \sa SetScalingWithExcitation  
   UeiDaqAPI bool GetScalingWithExcitation();

   /// \brief Set the scaling mode
   ///
   /// Specifies whether the acquired data will be divided by the excitation
   /// voltage before it is returned.
   ///
   /// \param scaleWithExcitation The scaling mode
   /// \sa GetScalingWithExcitation  
   UeiDaqAPI void SetScalingWithExcitation(bool scaleWithExcitation);

   /// \brief Get the shunt calibration resistor status
   ///
   /// Determines whether the shunt calibration resistor is connected.
   ///
   /// \return true is the shunt resistor is connected, false otherwise.
   /// \sa EnableShuntCalibration
   UeiDaqAPI bool IsShuntCalibrationEnabled();

   /// \brief Control the shunt calibration resistor
   ///
   /// Connect or disconnect the shunt calibration resistor.
   ///
   /// \param engageShuntCal true to enable the shunt resistor, false to disable it
   /// \sa IsShuntCalibrationEnabled
   UeiDaqAPI void EnableShuntCalibration(bool engageShuntCal);

   /// \brief Get the shunt resistor location
   ///
   /// Get the branch of the wheatstone bridge on which the shunt resistor 
   /// is connected.
   ///
   /// \return The shunted bridge branch.
   /// \sa SetShuntLocation  
   UeiDaqAPI tUeiWheatstoneBridgeBranch GetShuntLocation();

   /// \brief Set the shunt resistor location
   ///
   /// Specifies the wheatstone bridge branch to shunt.
   ///
   /// \param shuntedBranch The bridge branch to shunt.
   /// \sa GetShuntLocation  
   UeiDaqAPI void SetShuntLocation(tUeiWheatstoneBridgeBranch shuntedBranch);

   /// \brief Get the shunt resistance
   ///
   /// Get the resistance programmed to the shunt resistor in Ohms.
   /// NOTE: This is not the actual resistance used to perform the calibration.
   /// The resistance of other components must be accounted for, use
   /// GetActualShuntResistance() to get the shunt resistance to use to calculate
   /// the gain adjustment factor.
   ///
   /// \return The programmed resistance.
   /// \sa SetShuntResistance GetActualShuntResistance  
   UeiDaqAPI double GetShuntResistance();

   /// \brief Set the shunt resistance
   ///
   /// Specifies the resistance to program to the shunt resistor in Ohms.
   /// NOTE: Don't use this value to calculate the gain adjustment factor,
   /// Use the value returned by GetActualShuntResitance() which takes into
   /// account the resistance of other non-programmable parts in the shunt
   /// circuit.
   ///
   /// \param resistance The resistance to program on the shunt resistor.
   /// \sa GetShuntResistance GetActualShuntResistance  
   UeiDaqAPI void SetShuntResistance(double resistance);

   /// \brief Get the actual shunt resistance 
   ///
   /// Get the actual shunt resistance in Ohms.
   /// This resistance includes the programmed shunt resistance plus the 
   /// resistance of other parts in the shunt circuitry.
   ///
   /// \return The programmed resistance.
   /// \sa SetShuntResistance GetShuntResistance  
   UeiDaqAPI double GetActualShuntResistance();

   /// \brief Get the gain adjustment factor
   ///
   /// Get the gain adjustment factor.
   ///
   /// \return The gain adjustment factor.
   /// \sa SetGainAdjustmentFactor  
   UeiDaqAPI double GetGainAdjustmentFactor();

   /// \brief Set the gain adjustment factor
   ///
   /// Setting the gain adjustment factor is part of the shunt calibration
   /// procedure:
   /// You must first program the shunt resistance, engage the
   /// the shunt resistor and measure some values.
   /// You can then calculate the gain adjustment factor with the formula:
   /// gaf = Vex*(Rg/(4*Rs + 2*Rg))/(VoutShunted - Vout)
   /// Vex: excitation voltage
   /// Vout: measured voltage with shunt disabled
   /// VoutShunted: measured voltage with shunt enabled
   /// Rg: Resistance of the strain gages.
   /// Rs: Resistance of the shunt.
   ///
   /// Once the gain adjustment factor is set, the framework automatically 
   /// uses it to scale measurements to engineering unit.
   ///
   /// \param gaf The new gain adjustment factor.
   /// \sa GetGainAdjustmentFactor  
   UeiDaqAPI void SetGainAdjustmentFactor(double gaf);

   /// \brief Set the wiring scheme
   ///
   /// Specifies the wiring scheme used to connect the strain gage or load
   /// cell to the channel. 
   ///
   /// \param wiring The new wiring scheme.
   /// \sa GetWiringScheme  
   UeiDaqAPI void SetWiringScheme(tUeiWiringScheme wiring);

   /// \brief Get the wiring scheme
   ///
   /// Get the current wiring scheme used for this channel.
   ///
   /// \return The current wiring scheme.
   /// \sa SetWiringScheme   
   UeiDaqAPI tUeiWiringScheme GetWiringScheme();

   /// \brief Get the offset nulling circuitry status
   ///
   /// Determines whether the offset nulling circuitry is enabled.
   /// With Offset nulling enabled, a nulling circuit adds an adjustable DC  
   /// voltage to the output of the amplifier making sure that the bridge 
   /// output is 0V when no strain is applied.
   ///
   /// \return true if offset nulling is enabled, false otherwise.
   /// \sa EnableOffsetNulling
   UeiDaqAPI bool IsOffsetNullingEnabled();

   /// \brief Control the offset nulling circuitry
   ///
   /// Enables or disables offset nulling circuitry.
   /// With Offset nulling enabled, a nulling circuit adds an adjustable DC  
   /// voltage to the output of the amplifier making sure that the bridge 
   /// output is 0V when no strain is applied.
   ///
   /// \param enableNulling true to enable offset nulling, false to disable it
   /// \sa IsOffsetNullingEnabled
   UeiDaqAPI void EnableOffsetNulling(bool enableNulling);

   /// \brief Get the automatic offset nulling status
   ///
   /// Determines whether the offset nulling is automatically set.
   ///
   /// \return true if automatic offset nulling is enabled, false otherwise.
   /// \sa EnableAutoOffsetNulling
   UeiDaqAPI bool IsAutoOffsetNullingEnabled();

   /// \brief Control the automatic offset nulling 
   ///
   /// Enables or disables automatic offset nulling.
   /// \param enableAutoNulling true to enable automatic offset nulling, false to disable it
   /// \sa IsAutoOffsetNullingEnabled
   UeiDaqAPI void EnableAutoOffsetNulling(bool enableAutoNulling);

   /// \brief Get the offset nulling setting
   ///
   /// Get the offset nulling setting used to program the nulling circuitry.
   /// Set it to 0.0 to automatically perform offset nulling next time the session is started.
   /// Make sure no strain is applied on the bridge before nulling the offset.
   ///
   /// \return The current offset nulling setting.
   /// \sa SetOffsetNullingSetting 
   UeiDaqAPI double GetOffsetNullingSetting();

   /// \brief Set the offset nulling setting
   ///
   /// Set the offset nulling setting used to program the nulling circuitry.
   /// Set it to 0.0 to automatically perform offset nulling next time the session is started.
   /// Make sure no strain is applied on the bridge before nulling the offset.
   ///
   /// \param setting The setting value used to program the offset nulling circuitry.
   /// \sa GetOffsetNullingSetting  
   UeiDaqAPI void SetOffsetNullingSetting(double setting);

   /// \brief Get the automatic bridge completion status
   ///
   /// Determines whether the bridge completion is automatically set.
   ///
   /// \return true if automatic bridge completion is enabled, false otherwise.
   /// \sa EnableAutoBridgeCompletion
   UeiDaqAPI bool IsAutoBridgeCompletionEnabled();

   /// \brief Control the automatic bridge completion 
   ///
   /// Enables or disables automatic bridge completion.
   ///
   /// \param enableAutoBridgeCompletion true to enable automatic bridge completion, false to disable it
   /// \sa IsAutoBridgeCompletionEnabled
   UeiDaqAPI void EnableAutoBridgeCompletion(bool enableAutoBridgeCompletion);

   /// \brief Get the bridge completion setting
   ///
   /// Get the bridge completion setting used to program the bridge completion circuitry.
   /// Set it to 0.0 to automatically perform bridge completion next time the session is started.
   /// Make sure no strain is applied on the bridge.
   ///
   /// \return The current bridge completion setting.
   /// \sa SetBridgeCompletionSetting 
   UeiDaqAPI double GetBridgeCompletionSetting();

   /// \brief Set the offset nulling setting
   ///
   /// Set the bridge completion setting used to program the bridge completion circuitry.
   /// Set it to 0.0 to automatically perform bridge completion next time the session is started.
   /// Make sure no strain is applied on the bridge.
   ///
   /// \param setting The setting value used to program the bridge completion circuitry.
   /// \sa GetBridgeCompletionSetting  
   UeiDaqAPI void SetBridgeCompletionSetting(double setting);

   /// \cond DO_NOT_DOCUMENT
   CUeiAIVExChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAIVExChannelImpl> m_pImpl;
};

/// \brief Manages settings for each accelerometer input channel
///
/// Manages settings for each accelerometer input channel
/// This type of channel works with IEPE sensors and microphones
class CUeiAccelChannel : public CUeiAIChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiAccelChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAccelChannel();

   /// \brief Get the coupling type
   ///
   /// Get the channel coupling type, AC or DC
   ///
   /// \return the Coupling type.
   /// \sa SetCouplingType  
   UeiDaqAPI tUeiCoupling GetCouplingType();

   /// \brief Set the coupling type
   ///
   /// Configure the channel in AC or DC coupling.
   ///
   /// \param coupling The coupling type
   /// \sa GetCouplingType  
   UeiDaqAPI void SetCouplingType(tUeiCoupling coupling);

   /// \brief Get the low-pass filter state
   ///
   /// Get the low-pass filter state
   ///
   /// \return the low pass filter state.
   /// \sa EnableLowPassfilter  
   UeiDaqAPI bool IsLowPassFilterEnabled();

   /// \brief Enable or Disable the low-pass filter
   ///
   /// Enable or disable the low-pass filter.
   ///
   /// \param enabled The low-pass filter state
   /// \sa IsLowPassFilterEnabled  
   UeiDaqAPI void EnableLowPassfilter(bool enabled);

   /// \brief Get the sensor sensitivity
   ///
   /// Get the sensor sensitivity, it usually is in mVolts/[EU]
   /// Independently of the Engineering Unit (EU), the voltage read will be converted
   /// to mV and divided by the sensitivity
   ///
   /// \return the current sensitivity.
   /// \sa SetSensorSensitivity  
   UeiDaqAPI double GetSensorSensitivity();

   /// \brief Set the sensor sensitivity
   ///
   /// Set the sensor sensitivity, it usually is in mVolts/[EU]
   /// Independently of the Engineering Unit (EU), the voltage read will be converted
   /// to mV and divided by the sensitivity
   ///
   /// \param sensitivity The new sensitivity
   /// \sa GetSensorSensitivity  
   UeiDaqAPI void SetSensorSensitivity(double sensitivity);

   /// \brief Get the excitation current
   ///
   /// Get the excitation current in mAmps
   ///
   /// \return the excitation current.
   /// \sa SetExcitationCurrent  
   UeiDaqAPI double GetExcitationCurrent();

   /// \brief Set the excitation current
   ///
   /// Set the excitation current in mAmps
   ///
   /// \param excCurrent The new excitation current
   /// \sa GetExcitationCurrent  
   UeiDaqAPI void SetExcitationCurrent(double excCurrent);

   /// \brief Get the excitation low comparator voltage
   ///
   /// The excitation current can be measured back and trigger an alarm
   /// when it is out of range (due to an open connection or a short).
   /// It is measured as a voltage which depends on the sensor resistance and 
   /// the programmed excitation current.
   /// The alarm state is made visible with the LED color on the terminal block
   /// Green means that the measured excitation is within range, red means that
   /// the connection with the sensor is open and blinking red means that the
   /// connection with the sensor is shorted.
   ///
   /// \return the low excitation comparator voltage
   /// \sa SetLowExcitationComparator, GetLowAlarmStatus   
   UeiDaqAPI double GetLowExcitationComparator();

   /// \brief Set the excitation low comparator voltage
   ///
   /// The excitation current can be measured back and trigger an alarm
   /// when it is out of range (due to an open connection or a short).
   /// It is measured as a voltage which depends on the sensor resistance and 
   /// the programmed excitation current.
   /// The alarm state is made visible with the LED color on the terminal block
   /// Green means that the measured excitation is within range, red means that
   /// the connection with the sensor is open and blinking red means that the
   /// connection with the sensor is shorted.
   ///
   /// \param lowComparator the new low excitation comparator voltage
   /// \sa GetLowExcitationComparator, GetLowAlarmStatus   
   UeiDaqAPI void SetLowExcitationComparator(double lowComparator);

   /// \brief Get the excitation high comparator voltage
   ///
   /// The excitation current can be measured back and trigger an alarm
   /// when it is out of range (due to an open connection or a short).
   /// It is measured as a voltage which depends on the sensor resistance and 
   /// the programmed excitation current.
   /// The alarm state is made visible with the LED color on the terminal block
   /// Green means that the measured excitation is within range, red means that
   /// the connection with the sensor is open and blinking red means that the
   /// connection with the sensor is shorted.
   ///
   /// \return the high excitation comparator voltage
   /// \sa SetHighExcitationComparator, GetHighAlarmStatus  
   UeiDaqAPI double GetHighExcitationComparator();

   /// \brief Set the excitation high comparator voltage
   ///
   /// The excitation current can be measured back and trigger an alarm
   /// when it is out of range (due to an open connection or a short).
   /// It is measured as a voltage which depends on the sensor resistance and 
   /// the programmed excitation current.
   /// The alarm state is made visible with the LED color on the terminal block
   /// Green means that the measured excitation is within range, red means that
   /// the connection with the sensor is open and blinking red means that the
   /// connection with the sensor is shorted.
   ///
   /// \param highComparator the new high excitation comparator voltage
   /// \sa GetHighExcitationComparator, GetHighAlarmStatus 
   UeiDaqAPI void SetHighExcitationComparator(double highComparator);

   /// \brief Get the low alarm status
   ///
   /// Return the low alarm status which indicates whether the connection
   /// to the sensor is shorted. It also is visible on the terminal block
   /// as a red blinking LED.
   ///
   /// \return the low alarm state
   /// \sa SetLowExcitationComparator  
   UeiDaqAPI bool GetLowAlarmStatus();

   /// \brief Get the high alarm status
   ///
   /// Return the high alarm status which indicates whether the connection
   /// to the sensor is open. It also is visible on the terminal block
   /// as a steady red LED.
   ///
   /// \return the high alarm state
   /// \sa SetHighExcitationComparator  
   UeiDaqAPI bool GetHighAlarmStatus();

   /// \cond DO_NOT_DOCUMENT
   CUeiAccelChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAccelChannelImpl> m_pImpl;
};

/// \brief Manages settings for each DMM input channel
///
/// Manages settings for each DMM input channel
class CUeiDMMChannel : public CUeiAIChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiDMMChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDMMChannel();

   /// \brief Get the measurement mode
   ///
   /// Get the measurement mode
   ///
   /// \return the Measurement mode.
   /// \sa SetMeasurementMode  
   UeiDaqAPI tUeiDMMMeasurementMode GetMeasurementMode();

   /// \brief Set the measurement mode
   ///
   /// Configure the measurement mode.
   ///
   /// \param mode The new measurement mode
   /// \sa GetMeasurementMode  
   UeiDaqAPI void SetMeasurementMode(tUeiDMMMeasurementMode mode);

   /// \brief Get the FIR cutoff frequency
   ///
   /// Get the FIR cutoff frequency
   ///
   /// \return the FIR cutoff frequency
   /// \sa SetFIRCutoff
   UeiDaqAPI tUeiDMMFIRCutoff GetFIRCutoff();

   /// \brief Set the FIR cutoff frequency
   ///
   /// Set the FIR cutoff frequency
   ///
   /// \param frequency The new FIR cutoff frequency
   /// \sa GetFIRCutoff
   UeiDaqAPI void SetFIRCutoff(tUeiDMMFIRCutoff frequency);

   /// \brief Get the FIR decimation factor
   ///
   /// Get the FIR decimation factor.
   ///
   /// \return the FIR decimation factor
   /// \sa SetFIRDecimation
   //UeiDaqAPI int GetFIRDecimation();

   /// \brief Set the FIR decimation factor
   ///
   /// Set the FIR decimation factor
   ///
   /// \param decimation The new FIR decimation factor
   /// \sa GetFIRDecimation
   //UeiDaqAPI void SetFIRDecimation(int decimation);

   /// \brief Get the zero crossing detection mode
   ///
   /// Zero crossing detection is used for RMS measurements.
   /// Get the current mode used to determine the zero crossing detection level.
   ///
   /// \return the current ZC detection mode
   /// \sa SetZeroCrossingMode
   UeiDaqAPI tUeiDMMZeroCrossingMode GetZeroCrossingMode();

   /// \brief Set the zero crossing detection mode
   ///
   /// Zero crossing detection is used for RMS measurements.
   /// Get the current mode used to determine the zero crossing detection level.
   ///
   /// \param zcMode The new ZC detection mode
   /// \sa GetZeroCrossingMode
   UeiDaqAPI void SetZeroCrossingMode(tUeiDMMZeroCrossingMode zcMode);

   /// \brief Get the number of samples used for zero crossing detection
   ///
   /// Zero crossing detection is used for RMS measurements.
   /// Get the number of samples used to detect a zero crossing.
   ///
   /// \return The number of samples for ZC detection
   /// \sa SetZeroCrossingNumberOfSamples
   UeiDaqAPI int GetZeroCrossingNumberOfSamples();

   /// \brief Set the zero crossing detection mode
   ///
   /// Zero crossing detection is used for RMS measurements.
   /// Get the current mode used to determine the zero crossing detection level.
   ///
   /// \param numSamples The number of samples for ZC detection
   /// \sa GetZeroCrossingNumberOfSamples
   UeiDaqAPI void SetZeroCrossingNumberOfSamples(int numSamples);

   /// \brief Get the zero crossing detection level
   ///
   /// Zero crossing detection is used for RMS measurements.
   /// Get the level used to detect a zero crossing.
   ///
   /// \return The ZC level
   /// \sa SetZeroCrossingLevel
   UeiDaqAPI float GetZeroCrossingLevel();

   /// \brief Set the zero crossing detection mode
   ///
   /// Zero crossing detection is used for RMS measurements.
   /// Get the current mode used to determine the zero crossing detection level.
   ///
   /// \param level The ZC level
   /// \sa GetZeroCrossingLevel
   UeiDaqAPI void SetZeroCrossingLevel(float level);

   /// \brief Get the power line frequency
   ///
   /// Get the power line frequency used to power the equipment
   /// This is used to reject power line induced noise from DC measurements.
   ///
   /// \return The power line frequency
   /// \sa SetPowerLineFrequency
   UeiDaqAPI int GetPowerLineFrequency();

   /// \brief Set the power line frequency
   ///
   /// Set the power line frequency used to power the equipment
   /// This is used to reject power line induced noise from DC measurements.
   ///
   /// \param frequency The power line frequency
   /// \sa GetPowerLineFrequency
   UeiDaqAPI void SetPowerLineFrequency(int frequency);

   /// \brief Get the number of power line cycles (NPLC)
   ///
   /// Get the integration time in number of power line cycles
   /// This is used to reject power line induced noise from DC measurements.
   ///
   /// \return The power line frequency
   /// \sa SetNumberOfPowerLineCycles
   UeiDaqAPI int GetNumberOfPowerLineCycles();

   /// \brief Set the number of power line cycles (NPLC)
   ///
   /// Set the integration time in number of power line cycles
   /// This is used to reject power line induced noise from DC measurements.
   ///
   /// \param frequency The power line frequency
   /// \sa GetNumberOfPowerLineCycles
   UeiDaqAPI void SetNumberOfPowerLineCycles(int numPowerLineCycles);

   /// \brief Get the number of seconds with no reads before inputs are disconnected
   ///
   /// Get the number of seconds with no reads before inputs are disconnected
   ///
   /// \return The number of seconds with no reads before inputs are disconnected
   /// \sa SetDisconnectTimeout
   UeiDaqAPI int GetDisconnectTimeout();

   /// \brief Set the number of seconds with no reads before inputs are disconnected
   ///
   /// Set the number of seconds with no reads before inputs are disconnected
   ///
   /// \param timeoutSeconds The number of seconds with no reads before inputs are disconnected
   /// \sa GetDisconnectTimeout
   UeiDaqAPI void SetDisconnectTimeout(int timeoutSeconds);

   /// \brief Get the auto-range state
   ///
   /// Determines whether auto-range is enabled
   ///
   /// \return the auto-range state.
   /// \sa EnableAutoRange
   UeiDaqAPI bool IsAutoRangeEnabled();

   /// \brief Enable or Disable auto-range
   ///
   /// Enable or disable auto-range
   ///
   /// \param enabled The new auto-range state
   /// \sa IsAutoRangeEnabled  
   UeiDaqAPI void EnableAutoRange(bool enabled);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDMMChannelImpl> m_pImpl;
};

/// \brief Manages settings for each LVDT/RVDT input channel
///
/// Manages settings for each LVDT/RVDT channel
class CUeiLVDTChannel : public CUeiAIChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiLVDTChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiLVDTChannel();

   /// \brief Get the wiring scheme
   ///
   /// Get the current wiring scheme used for this channel.
   ///
   /// \return The current wiring scheme.
   /// \sa SetWiringScheme   
   UeiDaqAPI tUeiLVDTWiringScheme GetWiringScheme();

   /// \brief Set the wiring scheme
   ///
   /// Specifies the wiring scheme used to connect the resistive sensor to the channel. 
   ///
   /// \param wiring The new wiring scheme.
   /// \sa GetWiringScheme  
   UeiDaqAPI void SetWiringScheme(tUeiLVDTWiringScheme wiring);

   /// \brief Get the external excitation state
   ///
   /// Determines whether the excitation will be provided by the acquisition device
   /// or by an external source
   ///
   /// \return the external excitation state.
   /// \sa EnableExternalExcitation  
   UeiDaqAPI bool IsExternalExcitationEnabled();

   /// \brief Enable or Disable external excitation
   ///
   /// Enable or disable the external excitation.
   ///
   /// \param enabled The new external excitation state
   /// \sa IsExternalExcitationEnabled  
   UeiDaqAPI void EnableExternalExcitation(bool enabled);

   /// \brief Get the excitation RMS voltage
   ///
   /// Get the excitation RMS voltage configured for the channel.
   ///
   /// \return The excitation voltage.
   /// \sa SetExcitationVoltage  
   UeiDaqAPI double GetExcitationVoltage();

   /// \brief Set the excitation RMS voltage
   ///
   /// Set the excitation RMS voltage for this channel.
   ///
   /// \param vex The excitation voltage
   /// \sa GetExcitationVoltage  
   UeiDaqAPI void SetExcitationVoltage(double vex);

   /// \brief Get the excitation frequency
   ///
   /// Get the excitation frequency configured for the channel.
   ///
   /// \return The excitation frequency.
   /// \sa SetExcitationFrequency  
   UeiDaqAPI double GetExcitationFrequency();

   /// \brief Set the excitation frequency
   ///
   /// Set the excitation frequency for this channel.
   ///
   /// \param fex The excitation frequency
   /// \sa GetExcitationFrequency  
   UeiDaqAPI void SetExcitationFrequency(double fex);
   
   /// \brief Get the sensor sensitivity
   ///
   /// Get the sensor sensitivity, it usually is in mVolts/V/[EU]
   /// Independently of the engineering unit (EU), the voltage read will be converted
   /// to mV and divided by the excitation voltage and the sensitivity
   ///
   /// \return the current sensitivity.
   /// \sa SetSensorSensitivity  
   UeiDaqAPI double GetSensorSensitivity();

   /// \brief Set the sensor sensitivity
   ///
   /// Set the sensor sensitivity, it usually is in mVolts/V/[EU]
   /// Independently of the engineering unit (EU), the voltage read will be converted
   /// to mV and divided by the excitation voltage and the sensitivity
   ///
   /// \param sensitivity The new sensitivity
   /// \sa GetSensorSensitivity  
   UeiDaqAPI void SetSensorSensitivity(double sensitivity);

   /// \brief Get the fine-tuning offset
   ///
   /// Get the fine-tuning offset
   ///
   /// \return the current offset.
   /// \sa SetOffset  
   UeiDaqAPI double GetFineTuningOffset();

   /// \brief Set the fine-tuning offset
   ///
   /// Set the fine-tuning offset
   ///
   /// \param offset The new offset
   /// \sa GetOffset  
   UeiDaqAPI void SetFineTuningOffset(double offset);

   /// \brief Get the fine-tuning gain
   ///
   /// Get the fine-tuning gain
   ///
   /// \return the current fain.
   /// \sa SetGain  
   UeiDaqAPI double GetFineTuningGain();

   /// \brief Set the fine-tuning gain
   ///
   /// Set the fine-tuning gain
   ///
   /// \param gain The new gain
   /// \sa GetGain  
   UeiDaqAPI void SetFineTuningGain(double gain);

   /// \cond DO_NOT_DOCUMENT
   CUeiLVDTChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiLVDTChannelImpl> m_pImpl;
};

/// \brief Manages settings for each LVDT/RVDT output channel
///
/// Manages settings for each LVDT/RVDT output channel
class CUeiSimulatedLVDTChannel : public CUeiAOChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiSimulatedLVDTChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSimulatedLVDTChannel();

   /// \brief Get the wiring scheme
   ///
   /// Get the current wiring scheme used for this channel.
   ///
   /// \return The current wiring scheme.
   /// \sa SetWiringScheme   
   UeiDaqAPI tUeiLVDTWiringScheme GetWiringScheme();

   /// \brief Set the wiring scheme
   ///
   /// Specifies the wiring scheme used to connect. 
   ///
   /// \param wiring The new wiring scheme.
   /// \sa GetWiringScheme  
   UeiDaqAPI void SetWiringScheme(tUeiLVDTWiringScheme wiring);

   /// \brief Get the excitation RMS voltage
   ///
   /// Get the excitation RMS voltage configured for the channel.
   ///
   /// \return The excitation voltage.
   /// \sa SetExcitationVoltage  
   UeiDaqAPI double GetExcitationVoltage();

   /// \brief Set the excitation RMS voltage
   ///
   /// Set the excitation RMS for this channel.
   ///
   /// \param vex The excitation voltage
   /// \sa GetExcitationVoltage  
   UeiDaqAPI void SetExcitationVoltage(double vex);

   /// \brief Get the excitation frequency
   ///
   /// Get the excitation frequency configured for the channel.
   ///
   /// \return The excitation frequency.
   /// \sa SetExcitationFrequency  
   UeiDaqAPI double GetExcitationFrequency();

   /// \brief Set the excitation frequency
   ///
   /// Set the excitation frequency for this channel.
   ///
   /// \param fex The excitation frequency
   /// \sa GetExcitationFrequency  
   UeiDaqAPI void SetExcitationFrequency(double fex);
   
   /// \brief Get the sensor sensitivity
   ///
   /// Get the simulated sensor sensitivity, it usually is in mVolts/V/[EU]
   ///
   /// \return the current sensitivity.
   /// \sa SetSensorSensitivity  
   UeiDaqAPI double GetSensorSensitivity();

   /// \brief Set the sensor sensitivity
   ///
   /// Set the simulated sensor sensitivity, it usually is in mVolts/V/[EU]
   ///
   /// \param sensitivity The new sensitivity
   /// \sa GetSensorSensitivity  
   UeiDaqAPI void SetSensorSensitivity(double sensitivity);

   /// \brief Get the fine-tuning offset
   ///
   /// Get the fine-tuning offset
   ///
   /// \return the current offset.
   /// \sa SetOffset  
   UeiDaqAPI double GetOffset();

   /// \brief Set the fine-tuning offset
   ///
   /// Set the fine-tuning offset
   ///
   /// \param offset The new offset
   /// \sa GetOffset  
   UeiDaqAPI void SetOffset(double offset);

   /// \brief Get the fine-tuning gain
   ///
   /// Get the fine-tuning gain
   ///
   /// \return the current fain.
   /// \sa SetGain  
   UeiDaqAPI double GetGain();

   /// \brief Set the fine-tuning gain
   ///
   /// Set the fine-tuning gain
   ///
   /// \param gain The new gain
   /// \sa GetGain  
   UeiDaqAPI void SetGain(double gain);

   /// \brief Get external amplitude auto follow
   ///
   /// Simulated LVDT signals amplitude follows external excitation
   /// amplitude by default. This setting overrides default amplitude with
   /// amplitude specified by excitation voltage setting.
   /// \return curent external amplitude setting
   UeiDaqAPI bool IsExternalAmplitudeAutoFollowEnabled();

   /// \brief Set external amplitude auto follow
   ///
   /// Simulated LVDT signals amplitude follows external excitation
   /// amplitude by default. This setting overrides default amplitude with
   /// amplitude specified by excitation voltage setting.
   /// \param enable set new external amplitude setting
   UeiDaqAPI void EnableExternalAmplitudeAutoFollow(bool enable);

   /// \cond DO_NOT_DOCUMENT
   CUeiSimulatedLVDTChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSimulatedLVDTChannelImpl> m_pImpl;
};

/// \brief Manages settings for each Synchro/Resolver input channel
///
/// Manages settings for each Synchro/Resolver channel
class CUeiSynchroResolverChannel : public CUeiAIChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiSynchroResolverChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSynchroResolverChannel();

   /// \brief Get the type of input sensor
   ///
   /// Specifies whether the input sensor is a synchro or a resolver.
   ///
   /// \return The current input sensor type.
   /// \sa SetMode   
   UeiDaqAPI tUeiSynchroResolverMode GetMode();

   /// \brief Set the type of input sensor
   ///
   /// Specifies whether the input sensor is a synchro or a resolver.
   ///
   /// \param mode The new input sensor type.
   /// \sa GetMode  
   UeiDaqAPI void SetMode(tUeiSynchroResolverMode mode);

   /// \brief Get the external excitation state
   ///
   /// Determines whether the excitation will be provided by the acquisition device
   /// or by an external source
   ///
   /// \return the external excitation state.
   /// \sa EnableExternalExcitation  
   UeiDaqAPI bool IsExternalExcitationEnabled();

   /// \brief Enable or Disable external excitation
   ///
   /// Enable or disable the external excitation.
   ///
   /// \param enabled The new external excitation state
   /// \sa IsExternalExcitationEnabled  
   UeiDaqAPI void EnableExternalExcitation(bool enabled);

   /// \brief Get the excitation RMS voltage
   ///
   /// Get the excitation RMS voltage configured for the channel.
   ///
   /// \return The excitation voltage.
   /// \sa SetExcitationVoltage  
   UeiDaqAPI double GetExcitationVoltage();

   /// \brief Set the excitation RMS voltage
   ///
   /// Set the excitation RMS voltage for this channel.
   ///
   /// \param vex The excitation voltage
   /// \sa GetExcitationVoltage  
   UeiDaqAPI void SetExcitationVoltage(double vex);

   /// \brief Get the excitation frequency
   ///
   /// Get the excitation frequency configured for the channel.
   ///
   /// \return The excitation frequency.
   /// \sa SetExcitationFrequency  
   UeiDaqAPI double GetExcitationFrequency();

   /// \brief Set the excitation frequency
   ///
   /// Set the excitation frequency for this channel.
   ///
   /// \param fex The excitation frequency
   /// \sa GetExcitationFrequency  
   UeiDaqAPI void SetExcitationFrequency(double fex);

   /// \cond DO_NOT_DOCUMENT
   CUeiSynchroResolverChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSynchroResolverChannelImpl> m_pImpl;
};


/// \brief Manages settings for each simulated Synchro/Resolver output channel
///
/// Manages settings for each simulated Synchro/Resolver channel
class CUeiSimulatedSynchroResolverChannel : public CUeiAOChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiSimulatedSynchroResolverChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSimulatedSynchroResolverChannel();

   /// \brief Get the type of sensor simulated
   ///
   /// Specifies whether the sensor simulated is a synchro or a resolver.
   ///
   /// \return The current simulated sensor type.
   /// \sa SetMode   
   UeiDaqAPI tUeiSynchroResolverMode GetMode();

   /// \brief Set the type of sensor simulated
   ///
   /// Specifies whether the sensor simulated is a synchro or a resolver.
   ///
   /// \param mode The new simulated sensor type.
   /// \sa GetMode  
   UeiDaqAPI void SetMode(tUeiSynchroResolverMode mode);

   /// \brief Get the external excitation state
   ///
   /// Determines whether the excitation will be provided by the acquisition device
   /// or by an external source
   ///
   /// \return the external excitation state.
   /// \sa EnableExternalExcitation  
   UeiDaqAPI bool IsExternalExcitationEnabled();

   /// \brief Enable or Disable external excitation
   ///
   /// Enable or disable the external excitation.
   ///
   /// \param enabled The new external excitation state
   /// \sa IsExternalExcitationEnabled  
   UeiDaqAPI void EnableExternalExcitation(bool enabled);

   /// \brief Get the excitation RMS voltage
   ///
   /// Get the excitation RMS voltage configured for the channel.
   ///
   /// \return The excitation voltage.
   /// \sa SetExcitationVoltage  
   UeiDaqAPI double GetExcitationVoltage();

   /// \brief Set the excitation RMS voltage
   ///
   /// Set the excitation RMS voltage for this channel.
   /// This sets the amplitude of the simulated synchro resolver signals
   /// when internal excitation voltage is selected
   ///
   /// \param vex The excitation voltage
   /// \sa GetExcitationVoltage  
   UeiDaqAPI void SetExcitationVoltage(double vex);

   /// \brief Get the excitation frequency
   ///
   /// Get the excitation frequency configured for the channel.
   ///
   /// \return The excitation frequency.
   /// \sa SetExcitationFrequency  
   UeiDaqAPI double GetExcitationFrequency();

   /// \brief Set the excitation frequency
   ///
   /// Set the excitation frequency for this channel.
   /// This sets the frequency of the simulated synchro resolver signals
   /// when internal excitation voltage is selected
   ///
   /// \param fex The excitation frequency
   /// \sa GetExcitationFrequency  
   UeiDaqAPI void SetExcitationFrequency(double fex);

   /// \brief Get external amplitude auto follow
   ///
   /// Simulated synchro/resolver signals amplitude follows external excitation
   /// amplitude by default. This setting overrides default amplitude with
   /// amplitude specified by excitation voltage setting.
   /// \return curent external amplitude setting
   UeiDaqAPI bool IsExternalAmplitudeAutoFollowEnabled();

   /// \brief Set external amplitude auto follow
   ///
   /// Simulated synchro/resolver signals amplitude follows external excitation
   /// amplitude by default. This setting overrides default amplitude with
   /// amplitude specified by excitation voltage setting.
   /// \param enable set new external amplitude setting
   UeiDaqAPI void EnableExternalAmplitudeAutoFollow(bool enable);

   /// \brief Get the phase delay
   ///
   /// Get the phase delay.
   /// phase delay is the number of D/A conversion cycles to offset phase 
   /// of the simulation waveform
   ///
   /// \return The phase delay.
   /// \sa SetPhaseDelay  
   UeiDaqAPI int GetPhaseDelay();

   /// \brief Set the phase delay
   ///
   /// Get the phase delay.
   /// phase delay is the number of D/A conversion cycles to offset phase 
   /// of the simulation waveform
   ///
   /// \param phaseDelay The new phase delay
   /// \sa GetPhaseDelay  
   UeiDaqAPI void SetPhaseDelay(int phaseDelay);

   /// \cond DO_NOT_DOCUMENT
   CUeiSimulatedSynchroResolverChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSimulatedSynchroResolverChannelImpl> m_pImpl;
};


/// \brief Manages settings for each serial port
///
/// Manages settings for each serial port
class CUeiSerialPort  : public CUeiChannel
{
public: 
   /// \brief Constructor
   UeiDaqAPI CUeiSerialPort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSerialPort();

   /// \brief Get the serial port mode
   ///
   /// Get the mode used by the serial port. Possible modes are RS-232,
   /// RS-485 half duplex and RS-485 full duplex
   ///
   /// \return the serial port mode .
   /// \sa SetMode  
   UeiDaqAPI tUeiSerialPortMode GetMode();

   /// \brief Set the serial port mode
   ///
   /// Set the mode used by the serial port. Possible modes are RS-232,
   /// RS-485 half duplex and RS-485 full duplex
   ///
   /// \param mode The new serial port mode
   /// \sa GetMode  
   UeiDaqAPI void SetMode(tUeiSerialPortMode mode);

   /// \brief Get the serial port speed
   ///
   /// Get the number of data bits transmitted per second.
   ///
   /// \return the serial port speed.
   /// \sa SetSpeed  
   UeiDaqAPI tUeiSerialPortSpeed GetSpeed();

   /// \brief Set the serial port speed
   ///
   /// Set the number of data bits transmitted per second.
   ///
   /// \param bitsPerSecond The serial port speed
   /// \sa GetSpeed  
   UeiDaqAPI void SetSpeed(tUeiSerialPortSpeed bitsPerSecond);

   /// \brief Get the serial port custom speed
   ///
   /// Get the number of data bits transmitted per second.
   /// Call this method when using a non-standard port speed
   ///
   /// \return the serial port speed.
   /// \sa SetCustomSpeed  
   UeiDaqAPI uInt32 GetCustomSpeed();

   /// \brief Set the serial port custom speed
   ///
   /// Set the number of data bits transmitted per second.
   /// Call this method when using a non-standard port speed
   ///
   /// \param bitsPerSecond The serial port speed
   /// \sa GetCustomSpeed  
   UeiDaqAPI void SetCustomSpeed(uInt32 bitsPerSecond);

   /// \brief Get the serial port data bits
   ///
   /// Get the number of data bits that hold the data to be transferred.
   ///
   /// \return the number of data bits.
   /// \sa SetDataBits  
   UeiDaqAPI tUeiSerialPortDataBits GetDataBits();

   /// \brief Set the serial port data bits
   ///
   /// Set the number of data bits that hold the data to be transferred.
   ///
   /// \param dataBits The number of data bits
   /// \sa GetDataBits  
   UeiDaqAPI void SetDataBits(tUeiSerialPortDataBits dataBits);

   /// \brief Get the serial port parity
   ///
   /// Get the parity used to detect transmission errors.
   ///
   /// \return the parity.
   /// \sa SetParity  
   UeiDaqAPI tUeiSerialPortParity GetParity();

   /// \brief Set the serial port parity
   ///
   /// Set the parity used to detect transmission errors.
   ///
   /// \param parity The serial port parity
   /// \sa GetParity  
   UeiDaqAPI void SetParity(tUeiSerialPortParity parity);

   /// \brief Get the serial port stop bits
   ///
   /// Get the number of stop bits that indicate the end of a data message.
   ///
   /// \return the number of stop bits.
   /// \sa SetStopBits  
   UeiDaqAPI tUeiSerialPortStopBits GetStopBits();

   /// \brief Set the serial port stop bits
   ///
   /// Set the number of stop bits that indicate the end of a data message.
   ///
   /// \param stopBits The number of stop bits
   /// \sa GetStopBits  
   UeiDaqAPI void SetStopBits(tUeiSerialPortStopBits stopBits);

   /// \brief Get the "end of line" character sequence
   ///
   /// Get the sequence of characters used to define the end of a line.
   ///
   /// \return The termination characters
   /// \sa SetTermination
   UeiDaqAPI std::string GetTermination(void);

   /// \brief Set the "end of line" character sequence
   ///
   /// Set the sequence of characters used to define the end of a line.
   ///
   /// \param eol The termination characters
   /// \sa GetTermination
   UeiDaqAPI void SetTermination(std::string eol);

   /// \brief Get the TX termination resistor state
   ///
   /// Determines whether the TX termination resistor is enabled
   ///
   /// \return The TX termination resistor state.
   /// \sa EnableTxTerminationResistor  
   UeiDaqAPI bool IsTxTerminationResistorEnabled();

   /// \brief Enable or disable TX termination resistor
   ///
   /// Enable or disable the TX termination resistor.
   ///
   /// \param enabled The new TX termination resistor state
   /// \sa IsTxTerminationResistorEnabled  
   UeiDaqAPI void EnableTxTerminationResistor(bool enabled);

   /// \brief Get the RX termination resistor state
   ///
   /// Determines whether the RX termination resistor is enabled
   ///
   /// \return The RX termination resistor state.
   /// \sa EnableRxTerminationResistor  
   UeiDaqAPI bool IsRxTerminationResistorEnabled();

   /// \brief Enable or disable RX termination resistor
   ///
   /// Enable or disable the RX termination resistor.
   ///
   /// \param enabled The new RX termination resistor state
   /// \sa IsRxTerminationResistorEnabled  
   UeiDaqAPI void EnableRxTerminationResistor(bool enabled);

   /// \brief Get the error reporting state
   ///
   /// Determines whether the framing errors or parity errors will be reported
   ///
   /// \return The error reporting state.
   /// \sa EnableErrorReporting  
   UeiDaqAPI bool IsErrorReportingEnabled();

   /// \brief Enable or disable error reporting
   ///
   /// Enable or disable reproting of framing and parity errors.
   ///
   /// \param enabled The new error reporting state
   /// \sa IsErrorReportingEnabled  
   UeiDaqAPI void EnableErrorReporting(bool enabled);

   /// \brief Get Flow control
   ///
   /// Get flow control setting
   ///
   /// \return The current flow control setting
   /// \sa SetFlowControl
   UeiDaqAPI tUeiSerialPortFlowControl GetFlowControl();

   /// \brief Set Flow control
   ///
   /// Set flow control setting
   ///
   /// \param flowControl The new flow control setting
   /// \sa GetFlowControl
   UeiDaqAPI void SetFlowControl(tUeiSerialPortFlowControl flowControl);

   /// \brief Get the half-duplex echo suppression state
   ///
   /// Determines whether the half duplex echo suppression is enabled
   ///
   /// \return The half-duplex echo suppression state.
   /// \sa EnableHDEchoSuppression  
   UeiDaqAPI bool IsHDEchoSuppressionEnabled();

   /// \brief Enable or disable half-duplex echo suppression
   ///
   /// Enable or disable the half-duplex echo suppression.
   ///
   /// \param enabled The new half-duplex echo suppression state
   /// \sa IsHDEchoSuppressionEnabled  
   UeiDaqAPI void EnableHDEchoSuppression(bool enabled);

   /// \brief Get the TX auto-disable state
   ///
   /// Determines whether transmitter should automatically disable itself 
   /// whenever the TX FIFO is empty (only used in RS-485 full duplex mode)
   /// This allows multiple RS-485 devices to share the same bus
   ///
   /// \return The TX auto-disable state
   /// \sa EnableTxAutoDisable  
   UeiDaqAPI bool IsTxAutoDisableEnabled();

   /// \brief Enable or disable TX auto-disable
   ///
   /// Specifies whether transmitter should automatically disable itself 
   /// whenever the TX FIFO is empty (only used in RS-485 full duplex mode)
   /// This allows multiple RS-485 devices to share the same bus
   ///
   /// \param enabled The new TX auto-disable state
   /// \sa IsTxAutoDisableEnabled  
   UeiDaqAPI void EnableTxAutoDisable(bool enabled);

   /// \brief Get the on the fly parity bit state
   ///
   /// Determines whether the parity bit can be specified on the fly
   /// as part of the data stream (using uInt16 data instead of uInt8)
   ///
   /// \return The parity bit state.
   /// \sa EnableOnTheFlyParityBit  
   UeiDaqAPI bool IsOnTheFlyParityBitEnabled();

   /// \brief Enable or disable on the fly parity bit
   ///
   /// Enable or disable on the fly parity bit update
   /// as part of the data stream (using uInt16 data instead of uInt8)
   ///
   /// \param enabled The new on the fly parity bit state
   /// \sa IsOnTheFlyParityBitEnabled  
   UeiDaqAPI void EnableOnTheFlyParityBit(bool enabled);

   /// \brief Get timeout error upon receiving data state
   ///
   /// Determines whether timeout error is thrown when not enough bytes are
   /// available for retrieval.
   ///
   /// \return enabled The new timeout upon read state
   /// \sa EnableTimeoutUponReceive
   UeiDaqAPI bool IsTimeoutUponReceiveEnabled();

   /// \brief Enable or disable timeout error upon reading data
   ///
   /// Enable or disable timeout error when not enough bytes are
   /// available for retrieval.
   ///
   /// \param enabled The new timeout upon read state
   /// \sa IsTimeoutUponReceiveEnabled
   UeiDaqAPI void EnableTimeoutUponReceive(bool enabled);

   /// \brief Get character delay in microseconds
   ///
   /// Get the delay between transmitted characters (useful when communicating with slow devices)
   /// \return The current character delay in microseconds
   UeiDaqAPI uInt32 GetCharDelay();

   /// \brief Set character delay in microseconds
   ///
   /// Configures a delay between transmitted characters (useful when communicating with slow devices)
   /// \param charDelayUs The new character delay in microseconds  
   UeiDaqAPI void SetCharDelay(uInt32 charDelayUs);

   /// \brief Get minor frame mode
   ///
   /// Get the mode used to group characters in minor frames
   /// \return The current frame mode
   UeiDaqAPI tUeiSerialPortMinorFrameMode GetMinorFrameMode();

   /// \brief Set minor frame mode
   ///
   /// Set the mode used to group characters in minor frames
   /// \param mode The new frame mode
   UeiDaqAPI void SetMinorFrameMode(tUeiSerialPortMinorFrameMode mode);

   /// \brief Get minor frame length
   ///
   /// Get the minor frame length. 
   /// This is only meaningful when frame mode is set to "fixed length"
   /// \return The current frame length
   UeiDaqAPI uInt32 GetMinorFrameLength();

   /// \brief Set minor frame length
   ///
   /// Set the minor frame length (number of characters per frame)
   /// This is only meaningful when frame mode is set to "fixed length"
   /// \param length The new frame length 
   UeiDaqAPI void SetMinorFrameLength(uInt32 length);

   /// \brief Get minor frame delay in microseconds
   ///
   /// Get the delay between transmitted minor frames 
   /// \return The current minor frame delay in microseconds
   UeiDaqAPI uInt32 GetMinorFrameDelay();

   /// \brief Set minor frame delay in microseconds
   ///
   /// Set the delay between transmitted minor frames
   /// \param frameDelayUs The new minor frame delay in microseconds 
   UeiDaqAPI void SetMinorFrameDelay(uInt32 frameDelayUs);

   /// \brief Get major frame period in microseconds
   ///
   /// Major framing pre-fills the FIFO with a sequence of characters (optionally including char delay and minor frames) 
   /// and periodically transmits the FIFO content. 
   /// It isn't possible to update the major frame data once it is started.
   /// Get the period used to re-transmit major frames 
   /// \return The current major frame period in microseconds
   UeiDaqAPI uInt32 GetMajorFramePeriod();

   /// \brief Set major frame period in microseconds
   ///
   /// Major framing pre-fills the FIFO with a sequence of characters (optionally including char delay and minor frames) 
   /// and periodically transmits the FIFO content. 
   /// It isn't possible to update the major frame data once it is started.
   /// Get the period used to re-transmit major frames 
   /// Set the period at which major frames are transmitted
   /// \param framePeriodUs The new major frame period in microseconds 
   UeiDaqAPI void SetMajorFramePeriod(uInt32 framePeriodUs);

   /// \brief Get the timestamp resolution
   ///
   /// Get the timestamp resolution in seconds.
   ///
   /// \return the timestamp resolution.
   /// \sa SetTimestampResolution  
   UeiDaqAPI f64 GetTimestampResolution();

   /// \brief Set the timestamp resolution
   ///
   /// Set the timestamp resolution in seconds.
   ///
   /// \param resolution the new resolution.
   /// \sa GetTimestampResolution  
   UeiDaqAPI void SetTimestampResolution(f64 resolution);

   /// \brief Get the loopback mode state
   ///
   /// Determines whether the loopback mode is enabled
   /// when enabled the port receives what it just transmitted
   ///
   /// \return The state.
   /// \sa EnableLoopback  
   UeiDaqAPI bool IsLoopbackEnabled();

   /// \brief Enable or disable half-duplex echo suppression
   ///
   /// Enable or disable the half-duplex echo suppression.
   /// when enabled the port receives what it just transmitted
   ///
   /// \param enabled The new loopback state
   /// \sa IsLoopbackEnabled  
   UeiDaqAPI void EnableLoopback(bool enabled);

   /// \brief Get break detection state
   ///
   /// Determines whether break detection is enabled
   /// when enabled serial break is used as a condition to determine end of serial messages
   ///
   /// \return The state.
   /// \sa EnableBreak  
   UeiDaqAPI bool IsBreakEnabled();

   /// \brief Enable or disable break detection
   ///
   /// Enable or disable the break detection.
   /// when enabled serial break is used as a condition to determine end of serial messages
   ///
   /// \param enabled The new break detection state
   /// \sa IsBreakEnabled  
   UeiDaqAPI void EnableBreak(bool enabled);

   /// \brief Get the receive break character
   ///
   /// Get the special character inserted in the byte stream upon reception of a serial break
   ///
   /// \return The break cahracter.
   /// \sa SetReceiveBreakCharacter  
   UeiDaqAPI char GetReceiveBreakCharacter();

   /// \brief Set the receive break character
   ///
   /// Set the special character inserted in the byte stream upon reception of a serial break
   ///
   /// \param breakChar The new break character
   /// \sa GetReceiveBreakCharacter  
   UeiDaqAPI void SetReceiveBreakCharacter(char breakChar);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSerialPortImpl> m_pImpl;
};

/// \brief Manages settings for each HDLC port
///
/// Manages settings for each HDLC port
class CUeiHDLCPort  : public CUeiChannel
{
public: 
   /// \brief Constructor
   UeiDaqAPI CUeiHDLCPort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiHDLCPort();

   /// \brief Get the HDLC port physical interface
   ///
   /// Get the interface used by the HDLC port. Possible interfaces are RS-232,
   /// RS-422, RS-485 and V35
   ///
   /// \return the HDLC port interface
   /// \sa SetPhysicalInterface  
   UeiDaqAPI tUeiHDLCPortPhysical GetPhysicalInterface();

   /// \brief Set the HDLC port physical interface
   ///
   /// Set the interface used by the HDLC port. Possible interfaces are RS-232,
   /// RS-422, RS-485 and V35
   ///
   /// \param physInterface The new HDLC port interface
   /// \sa GetPhysicalInterface  
   UeiDaqAPI void SetPhysicalInterface(tUeiHDLCPortPhysical physInterface);

   /// \brief Get the HDLC port speed
   ///
   /// Get the number of data bits transmitted per second.
   ///
   /// \return the serial port speed.
   /// \sa SetSpeed  
   UeiDaqAPI uInt32 GetSpeed();

   /// \brief Set the HDLC port speed
   ///
   /// Set the number of data bits transmitted per second.
   ///
   /// \param bitsPerSecond The serial port speed
   /// \sa GetSpeed  
   UeiDaqAPI void SetSpeed(uInt32 bitsPerSecond);

   /// \brief Get the termination resistor state
   ///
   /// Determines whether the termination resistor is enabled
   ///
   /// \return The termination resistor state.
   /// \sa EnableTerminationResistor  
   UeiDaqAPI bool IsTerminationResistorEnabled();

   /// \brief Enable or disable termination resistor
   ///
   /// Enable or disable the termination resistor.
   ///
   /// \param enabled The new termination resistor state
   /// \sa IsTerminationResistorEnabled  
   UeiDaqAPI void EnableTerminationResistor(bool enabled);

   /// \brief Get the half-duplex echo suppression state
   ///
   /// Determines whether the half duplex echo suppression is enabled
   ///
   /// \return The half-duplex echo suppression state.
   /// \sa EnableHDEchoSuppression  
   UeiDaqAPI bool IsHDEchoSuppressionEnabled();

   /// \brief Enable or disable half-duplex echo suppression
   ///
   /// Enable or disable the half-duplex echo suppression.
   ///
   /// \param enabled The new half-duplex echo suppression state
   /// \sa IsHDEchoSuppressionEnabled  
   UeiDaqAPI void EnableHDEchoSuppression(bool enabled);

   /// \brief Get the loopback mode state
   ///
   /// Determines whether the loopback mode is enabled
   /// when enabled the port receives what it just transmitted
   ///
   /// \return The state.
   /// \sa EnableLoopback  
   UeiDaqAPI bool IsLoopbackEnabled();

   /// \brief Enable or disable half-duplex echo suppression
   ///
   /// Enable or disable the half-duplex echo suppression.
   /// when enabled the port receives what it just transmitted
   ///
   /// \param enabled The new loopback state
   /// \sa IsLoopbackEnabled  
   UeiDaqAPI void EnableLoopback(bool enabled);

   /// \brief Get the HDLC port abort symbol
   ///
   /// Get abort symbol used to abort transmission of current frame
   ///
   /// \return the current abort symbol
   /// \sa SetAbortSymbol  
   UeiDaqAPI tUeiHDLCPortAbortSymbol GetAbortSymbol();

   /// \brief Set the HDLC port abort symbol
   ///
   /// Set the abort symbol used to abort transmission of the current frame
   ///
   /// \param abortSymbol The new abort symbol
   /// \sa GetAbortSymbol  
   UeiDaqAPI void SetAbortSymbol(tUeiHDLCPortAbortSymbol abortSymbol);

   /// \brief Get the HDLC port underrun action
   ///
   /// Get the action to be taken when an overrun condition occurs
   ///
   /// \return the current underrun action
   /// \sa SetUnderrunAction  
   UeiDaqAPI tUeiHDLCPortUnderrunAction GetUnderrunAction();

   /// \brief Set the HDLC port underrun action
   ///
   /// Set the action to be taken when an underrun condition occurs
   ///
   /// \param underrunAction The new underrun action
   /// \sa GetUnderrunAction  
   UeiDaqAPI void SetUnderrunAction(tUeiHDLCPortUnderrunAction underrunAction);

   /// \brief Get the HDLC port encoding
   ///
   /// Get the encoding used to transmit data over the serial lines
   ///
   /// \return the current encoding
   /// \sa SetEncoding  
   UeiDaqAPI tUeiHDLCPortEncoding GetEncoding();

   /// \brief Set the HDLC port encoding
   ///
   /// Set the encoding used to transmit data over the serial lines
   ///
   /// \param encoding The new encoding
   /// \sa GetEncoding  
   UeiDaqAPI void SetEncoding(tUeiHDLCPortEncoding encoding);

   /// \brief Get the HDLC port RX clock source
   ///
   /// Get the clock source for the receiver
   ///
   /// \return the current RX clock source
   /// \sa SetRXClockSource  
   UeiDaqAPI tUeiHDLCPortClockSource GetRXClockSource();

   /// \brief Set the HDLC port RX clock source
   ///
   /// Set the clock source for the receiver
   ///
   /// \param clockSource The new RX clock source
   /// \sa GetRXClockSource  
   UeiDaqAPI void SetRXClockSource(tUeiHDLCPortClockSource clockSource);

   /// \brief Get the HDLC port TX clock source
   ///
   /// Get the clock source for the transmitter
   ///
   /// \return the current TX clock source
   /// \sa SetTXClockSource  
   UeiDaqAPI tUeiHDLCPortClockSource GetTXClockSource();

   /// \brief Set the HDLC port TX clock source
   ///
   /// Set the clock source for the transmitter
   ///
   /// \param clockSource The new TX clock source
   /// \sa GetRXClockSource  
   UeiDaqAPI void SetTXClockSource(tUeiHDLCPortClockSource clockSource);

   /// \brief Get the HDLC port CRC mode
   ///
   /// Get the method used to calculate HDLC frame's CRC
   ///
   /// \return the current CRC mode
   /// \sa SetCRCMode  
   UeiDaqAPI tUeiHDLCPortCRCMode GetCRCMode();

   /// \brief Set the HDLC port CRC mode
   ///
   /// Set the method used to calculate HDLC frame's CRC
   ///
   /// \param crcMode The new CRC mode
   /// \sa GetCRCMode  
   UeiDaqAPI void SetCRCMode(tUeiHDLCPortCRCMode crcMode);

   /// \brief Get the HDLC port filter mode
   ///
   /// Get the mode used to filter incoming frames
   ///
   /// \return the current filter mode
   /// \sa SetFilterMode  
   UeiDaqAPI tUeiHDLCPortFilterMode GetFilterMode();

   /// \brief Set the HDLC port filter mode
   ///
   /// Set the mode used to filter incoming frames
   ///
   /// \param filterMode The new filter mode
   /// \sa GetFilterMode  
   UeiDaqAPI void SetFilterMode(tUeiHDLCPortFilterMode filterMode);

   /// \brief Get the HDLC port filter address
   ///
   /// Get the filter address
   ///
   /// \return the current filter address
   /// \sa SetFilterAddress  
   UeiDaqAPI uInt8 GetFilterAddress();

   /// \brief Set the HDLC port filter address
   ///
   /// Set the filter address
   ///
   /// \param filterAddress The new filter address
   /// \sa GetFilterAddress  
   UeiDaqAPI void SetFilterAddress(uInt8 filterAddress);

   /// \brief Get the HDLC port preamble
   ///
   /// Get the preamble
   ///
   /// \return the current preamble
   /// \sa SetPreamble  
   UeiDaqAPI tUeiHDLCPortPreamble GetPreamble();

   /// \brief Set the HDLC port preamble
   ///
   /// Set the preamble
   ///
   /// \param preamble The new preamble
   /// \sa GetPreamble  
   UeiDaqAPI void SetPreamble(tUeiHDLCPortPreamble preamble);

   /// \brief Get the HDLC port preamble size
   ///
   /// Get the preamble size
   ///
   /// \return the current preamble size
   /// \sa SetPreambleSize
   UeiDaqAPI tUeiHDLCPortPreambleSize GetPreambleSize();

   /// \brief Set the HDLC port preamble size
   ///
   /// Set the preamble size
   ///
   /// \param preambleSize The new preamble size
   /// \sa GetPreambleSize
   UeiDaqAPI void SetPreambleSize(tUeiHDLCPortPreambleSize preambleSize);

   /// \brief Get the HDLC port idle character
   ///
   /// Get the idle character
   ///
   /// \return the current idle character
   /// \sa SetIdleCharacter
   UeiDaqAPI tUeiHDLCPortIdleCharacter GetIdleCharacter();

   /// \brief Set the HDLC port idle character
   ///
   /// Set the idle character
   ///
   /// \param idleChar The new idle character
   /// \sa GetIdleCharacter
   UeiDaqAPI void SetIdleCharacter(tUeiHDLCPortIdleCharacter idleChar);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiHDLCPortImpl> m_pImpl;
};

/// \brief Manages settings for each CAN port
///
/// Manages settings for each CAN port.
class CUeiCANPort  : public CUeiChannel
{
public: 
   /// \brief Constructor
   UeiDaqAPI CUeiCANPort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCANPort();

   /// \brief Get the CAN port speed
   ///
   /// Get the number of data bits transmitted per second.
   ///
   /// \return the CAN port speed.
   /// \sa SetSpeed  
   UeiDaqAPI tUeiCANPortSpeed GetSpeed();

   /// \brief Set the CAN port speed
   ///
   /// Set the number of data bits transmitted per second.
   ///
   /// \param bitsPerSecond The port speed
   /// \sa GetSpeed  
   UeiDaqAPI void SetSpeed(tUeiCANPortSpeed bitsPerSecond);

   /// \brief Get the frame format
   ///
   /// Get the format of frames transmitted by this port
   ///
   /// \return The frame format.
   /// \sa SetFrameFormat  
   UeiDaqAPI tUeiCANFrameFormat GetFrameFormat();

   /// \brief Set the frame format
   ///
   /// Set the format of frames transmitted by this port (CAN frames can be basic or extended).
   ///
   /// \param frameFormat The Frame format
   /// \sa GetFrameFormat  
   UeiDaqAPI void SetFrameFormat(tUeiCANFrameFormat frameFormat);

   /// \brief Get the operation mode
   ///
   /// Get the CAN port operation mode. Possible values are normal and passive
   ///
   /// \return The operation mode.
   /// \sa SetMode  
   UeiDaqAPI tUeiCANPortMode GetMode();

   /// \brief Set the operation mode
   ///
   /// Set the CAN port operation mode. Possible values are normal and passive
   ///
   /// \param mode The operation mode
   /// \sa GetMode
   UeiDaqAPI void SetMode(tUeiCANPortMode mode);

   /// \brief Get the acceptance mask
   ///
   /// The acceptance mask programs the hardware filter to reject or accept incoming frames. 
   /// The mask selects which bits within arbitration ID will be used for filtering.
   ///
   /// \return The current acceptance mask.
   /// \sa SetAcceptanceMask  
   UeiDaqAPI uInt32 GetAcceptanceMask();

   /// \brief Set the acceptance mask
   ///
   /// The acceptance mask programs the hardware filter to reject or accept incoming frames. 
   /// The mask selects which bits within arbitration ID will be used for filtering.
   ///
   /// \param mask The acceptance mask
   /// \sa GetAcceptanceMask
   UeiDaqAPI void SetAcceptanceMask(uInt32 mask);

   /// \brief Get the acceptance code
   ///
   /// The acceptance code programs the hardware filter to reject or accept incoming frames.
   /// The arbitration ID bits selected by the mask are compared to the code and the frame
   /// is rejected if there is any difference.
   /// If (mask XOR id) AND code == 0 the frame is accepted
   ///
   /// \return The current acceptance code.
   /// \sa SetAcceptanceCode  
   UeiDaqAPI uInt32 GetAcceptanceCode();

   /// \brief Set the acceptance code
   ///
   /// The acceptance code programs the hardware filter to reject or accept incoming frames.
   /// The arbitration ID bits selected by the mask are compared to the code and the frame
   /// is rejected if there is any difference.
   ///
   /// \param code The acceptance code
   /// \sa GetAcceptanceCode
   UeiDaqAPI void SetAcceptanceCode(uInt32 code);

   /// \brief Add a filter entry
   ///
   /// Add a filter entry to the port's filter table. 
   /// Each incoming CAN frame that doesn't match any of the filter 
   /// ranges is rejected.
   ///
   /// \param entry A struture that represents the new filter entry
   /// \sa ClearFilterEntries, GetFilterEntry 
   UeiDaqAPI void AddFilterEntry(tUeiCANFilterEntry entry);

   /// \brief Retrieve a filter entry
   ///
   /// Retrieve a filter entry from the port's frame filter table.
   /// Returns NULL when retrieving past the end of the table.
   ///
   /// \return A struture that represents the retrieved filter entry
   /// \sa AddFilterEntry, ClearFilterEntries 
   UeiDaqAPI tUeiCANFilterEntry* GetFilterEntry(int index);

   /// \brief Clear filter table
   ///
   /// Empties the port's filter table.
   ///
   /// \sa AddFilterEntry, GetFilterEntry 
   UeiDaqAPI void ClearFilterEntries(void);

   /// \brief Determines whether bus errors and warnings are logged
   ///
   /// When logging is enabled, bus warnings and errors are sent in the data stream.
   /// Use the Type field of the CANDataFrame structure to determine whether received
   /// frames are data or error frames.
   ///
   /// \return true if logging is enabled, false otherwise.
   /// \sa EnableWarningAndErrorLogging  
   UeiDaqAPI bool IsWarningAndErrorLoggingEnabled();

   /// \brief Specifies whether bus errors and warnings are logged
   ///
   /// When logging is enabled, bus warnings and errors are sent in the data stream.
   /// Use the Type field of the CANDataFrame structure to determine whether received
   /// frames are data or error frames.
   ///
   /// \param enable true to enable error logging, false to disable it
   /// \sa IsWarningAndErrorLoggingEnabled
   UeiDaqAPI void EnableWarningAndErrorLogging(bool enable);

   /// \brief Get the transmit error counter
   ///
   /// Get the number of transmit errors detected on the bus since the session
   /// started.
   ///
   /// \return The transmit error counter.
   /// \sa GetReceiveErrorCounter  
   UeiDaqAPI uInt32 GetTransmitErrorCounter();

   /// \brief Get the receive error counter
   ///
   /// Get the number of receive errors detected on the bus since the session
   /// started.
   ///
   /// \return The receive error counter.
   /// \sa GetTransmitErrorCounter  
   UeiDaqAPI uInt32 GetReceiveErrorCounter();

   /// \brief Get the error code capture register
   ///
   /// Get the current values of the Error Code Capture register from 
   /// the NXP SJA1000 CAN controller chip.
   /// The Error Code Capture register provides information on bus errors
   /// that occur according to the CAN standard. A bus error increments
   /// either the Transmit Error Counter or the Receive Error Counter.
   /// When communication starts on the interface, the first bus error is
   /// captured into the Error Code Capture register, and retained until you
   /// get this value. Then the Error Code Capture register is again enabled 
   /// to capture information for the next bus error.
   ///
   /// \return The error code capture register. 
   UeiDaqAPI uInt32 GetErrorCodeCaptureRegister();

   /// \brief Get the arbitration lost capture register
   ///
   /// Get the current values of the Arbitration Lost Capture register from 
   /// the NXP SJA1000 CAN controller chip.
   ///
   /// The Arbitration Lost Capture register provides information on a loss of
   /// arbitration during transmits. Loss of arbitration is not considered an
   /// error. When communication starts on the interface, the first arbitration
   /// loss is captured into the Arbitration Lost Capture register, and retained
   /// until you get this value. Then, the Arbitration Lost Capture register 
   /// is again enabled to capture information for the next arbitration loss.
   ///
   /// \return The arbitration lost capture register. 
   UeiDaqAPI uInt32 GetArbitrationLostCaptureRegister();

   /// \brief Get the bit timing registers BTR0 and BTR1
   ///
   /// Get the current values of the bit timing registers from
   /// the NXP SJA1000 CAN controller chip.
   /// BTR0 and BTR1 set the baud rate for the CAN port. 
   /// For information on CAN bit timing registers, refer to the datasheet of 
   /// the NXP SJA1000 CAN controller, available for download on www.nxp.com.
   ///
   /// \return The bit timing regiters, BTR0 is LSB and BTR1 is MSB. 
   UeiDaqAPI uInt16 GetBitTimingRegisters();

   /// \brief Set the bit timing registers BTR0 and BTR1
   ///
   /// Set the values of the bit timing registers from
   /// the NXP SJA1000 CAN controller chip.
   /// BTR0 and BTR1 set the baud rate for the CAN port. 
   /// For information on CAN bit timing registers, refer to the datasheet of 
   /// the NXP SJA1000 CAN controller, available for download on www.nxp.com.
   ///
   /// \param btrValues The new bit timing regiters, BTR0 is LSB and BTR1 is MSB. 
   UeiDaqAPI void SetBitTimingRegisters(uInt16 btrValues);

   /// \brief Get the timestamp resolution
   ///
   /// Get the timestamp resolution in seconds.
   ///
   /// \return the timestamp resolution.
   /// \sa SetTimestampResolution  
   UeiDaqAPI f64 GetTimestampResolution();

   /// \brief Set the timestamp resolution
   ///
   /// Set the timestamp resolution in seconds.
   ///
   /// \param resolution the new resolution.
   /// \sa GetTimestampResolution  
   UeiDaqAPI void SetTimestampResolution(f64 resolution);

   /// \cond DO_NOT_DOCUMENT
   CUeiCANPortImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond 

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCANPortImpl> m_pImpl;
};


/// \brief Manages settings for each industrial digital input channel
///
/// Manages settings for each digital input channel
class CUeiDIIndustrialChannel : public CUeiDIChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiDIIndustrialChannel(int numLines);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDIIndustrialChannel();

   /// \brief Get the digital input filter minimum pulse width 
   ///
   /// The digital input filter is used to block digital noise from switching the 
   /// input line state. 
   /// It filters glitches or spikes based on their width.
   /// 
   /// \param line The input line to query
   /// \return the minimum pulse width in ms
   /// \sa SetMinimumPulseWidth
   UeiDaqAPI double GetMinimumPulseWidth(int line);

   /// \brief Set the digital input filter minimum pulse width
   ///
   /// The digital input filter is used to block digital noise from switching the 
   /// input line state. 
   /// It filters glitches or spikes based on their width.
   /// 
   /// \param line The input line to configure
   /// \param minWidth the minimum pulse width in ms. Use 0.0 to disable digital input filter.
   /// \sa GetMinimumPulseWidth
   UeiDaqAPI void SetMinimumPulseWidth(int line, double minWidth);

   /// \brief Get the low input threshold 
   ///
   /// The low input threshold is used in combination with the high input threshold 
   /// to define an hysteresis window. The input line state will change only when
   /// the input signal crosses both threshold.
   /// 
   /// \param line The input line to query
   /// \return the low threshold
   /// \sa SetLowThreshold
   UeiDaqAPI double GetLowThreshold(int line);

   /// \brief Set the low input threshold
   ///
   /// The low input threshold is used in combination with the high input threshold 
   /// to define an hysteresis window. The input line state will change only when
   /// the input signal crosses both threshold
   /// 
   /// \param line The input line to configure
   /// \param lowThreshold the low hysteresis threshold
   /// \sa GetLowThreshold
   UeiDaqAPI void SetLowThreshold(int line, double lowThreshold);

   /// \brief Get the high input threshold 
   ///
   /// The high input threshold is used in combination with the low input threshold 
   /// to define an hysteresis window. The input line state will change only when
   /// the input signal crosses both threshold.
   /// 
   /// \param line The input line to query
   /// \return the high threshold
   /// \sa SetHighThreshold
   UeiDaqAPI double GetHighThreshold(int line);

   /// \brief Set the high input threshold
   ///
   /// The high input threshold is used in combination with the low input threshold 
   /// to define an hysteresis window. The input line state will change only when
   /// the input signal crosses both threshold
   /// 
   /// \param line The input line to configure
   /// \param highThreshold the high hysteresis threshold
   /// \sa GetHighThreshold
   UeiDaqAPI void SetHighThreshold(int line, double highThreshold);

   /// \brief Get AC mode
   ///
   /// Verify whether AC mode is enabled or disabled
   /// In AC mode, the RMS voltage measured at each input is compared with low and high thresholds
   /// to determine the state of the input
   ///  
   /// \param line The input line to query 
   /// \return the AC mode status
   UeiDaqAPI bool IsACModeEnabled(int line);

   /// \brief Enable or disable AC mode 
   /// 
   /// Enable or disable AC mode
   /// In AC mode, the RMS voltage measured at each input is compared with low and high thresholds
   /// to determine the state of the input
   ///  
   /// \param line The input line to configure
   /// \param acMode true to enable AC mode, false otherwise 
   UeiDaqAPI void EnableACMode(int line, bool acMode);

   /// \brief Get the digital input mux configuration 
   /// 
   /// Select how voltage supply is connected to each input line.
   /// Disconnected: Set the mux to tri-state mode to disconnect voltage supply
   ///               from input line
   /// Diag mode: Set mux to Diagnostic mode to connect internal voltage source
   ///            to each input line in order to test that it is functional
   /// Pull-up mode: Setting mux to pull-up mode connects a pull-up resistor between 
   ///               the internal voltage source and the input line to monitor switches  
   ///               or contacts without external circuitry.
   /// 
   /// \param line The input line to query
   /// \return the mux state
   UeiDaqAPI tUeiDigitalInputMux GetMux(int line);

   /// \brief Set the digital input mux configuration
   /// 
   /// Select how voltage supply is connected to each input line.
   /// Disconnected: Set the mux to tri-state mode to disconnect voltage supply
   ///               from input line
   /// Diag mode: Set mux to Diagnostic mode to connect internal voltage source
   ///            to each input line in order to test that it is functional
   /// Pull-up mode: Setting mux to pull-up mode connects a pull-up resistor between 
   ///               the internal voltage source and the input line to monitor switches  
   ///               or contacts without external circuitry.
   /// 
   /// \param line The input line to configure
   /// \param mux the new mux state
   UeiDaqAPI void SetMux(int line, tUeiDigitalInputMux mux);

   /// \brief Get the test/pull-up voltage 
   /// 
   /// Get the voltage supplied to selected line.
   /// Test mode: Guardian feature that connects an internal voltage source
   ///            to each input line in order to test that it is functional
   /// Pull-up mode: connect a pull-up resistor between the internal voltage
   ///               source and the input line to monitor switch or contacts 
   ///               without external circuitry.
   /// 
   /// \param line The input line to query
   /// \return the supplied voltage
   UeiDaqAPI double GetVoltageSupply(int line);

   /// \brief Set the test/pull-up voltage 
   /// 
   /// Program the voltage supplied to selected line.
   /// Test mode: Guardian feature that connects an internal voltage source
   ///            to each input line in order to test that it is functional
   /// Pull-up mode: connect a pull-up resistor between the internal voltage
   ///               source and the input line to monitor switch or contacts 
   ///               without external circuitry.
   /// 
   /// \param line The input line to configure
   /// \param voltage the voltage to supply to the input line
   UeiDaqAPI void SetVoltageSupply(int line, double voltage);

   /// \brief Get the input gain 
   /// 
   /// Some DI devices use an ADC to measure the input line state. This
   /// setting provides a way to select the input gain for the ADC.
   /// The input gain value is an index in the gain list starting with 0
   /// 
   /// \param line The input line to query
   /// \return the line's input gain
   UeiDaqAPI int GetInputGain(int line);

   /// \brief Set the input gain 
   /// 
   /// Some DI devices use an ADC to measure the input line state. This
   /// setting provides a way to select the input gain for the ADC.
   /// The input gain value is an index in the gain list starting with 0.
   /// 
   /// \param line The input line to configure
   /// \param inputGain the input gain
   UeiDaqAPI void SetInputGain(int line, int inputGain);

   /// \brief Get the mux delay 
   /// 
   /// Some DI devices use an ADC to measure the input line state. This
   /// setting provides a way to set the delay for the multiplexer 
   /// in front of the ADC
   /// 
   /// \param line The input line to query
   /// \return the line's mux delay in us 
   UeiDaqAPI int GetMuxDelay(int line);

   /// \brief Set the mux delay 
   /// 
   /// Some DI devices use an ADC to measure the input line state. This
   /// setting provides a way to set the delay for the multiplexer 
   /// in front of the ADC
   /// 
   /// \param line The input line to configure
   /// \param muxDelayUs the mux delay in us
   UeiDaqAPI void SetMuxDelay(int line, int muxDelayUs);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDIIndustrialChannelImpl> m_pImpl;
};


/// \brief Manages settings for each industrial digital output channel
///
/// Manages settings for each industrial digital output channel.
class CUeiDOIndustrialChannel : public CUeiDOChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiDOIndustrialChannel(int numLines);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDOIndustrialChannel();

   /// \brief Get the PWM mode. 
   ///
   /// Specifies the PWM mode for DO channels that support the capability
   /// With PWM mode you can replace the rising and falling edges with a pulse
   /// train to allow for soft start and/or stop
   ///
   /// \param line The output line to configure.
   /// \return The PWM mode.
   /// \sa SetPWMMode
   UeiDaqAPI tUeiDOPWMMode GetPWMMode(int line);
 
   /// \brief Set the PWM mode. 
   ///
   /// Specifies the PWM mode for DO channels that support the capability
   /// With PWM mode you can replace the rising and falling edges with a pulse
   /// train to allow for soft start and/or stop
   ///
   /// \param line The output line to configure.
   /// \param mode The new PWM mode.
   /// \sa GetPWMMode
   UeiDaqAPI void SetPWMMode(int line, tUeiDOPWMMode mode);

   /// \brief Get the pulse train length. 
   ///
   /// Specifies soft start/stop pulse train length in micro-seconds
   ///
   /// \param line The output line to configure.
   /// \return The pulse train length.
   /// \sa SetPWMLength
   UeiDaqAPI uInt32 GetPWMLength(int line);
 
   /// \brief Set pulse train length. 
   ///
   /// Specifies soft start/stop pulse train length in micro-seconds
   ///
   /// \param line The output line to configure.
   /// \param lengthus The new pulse train length.
   /// \sa GetPWMLength
   UeiDaqAPI void SetPWMLength(int line, uInt32 lengthus);

   /// \brief Get the soft start/soft stop pulse train time in micro-seconds
   ///
   /// Specifies soft start/stop pulse train time in micro-seconds
   /// Note this is an alias for GetPWMLength
   ///
   /// \param line The output line to configure.
   /// \return The soft start/soft stop pulse train time.
   /// \sa SetSoftStartStopTime
   UeiDaqAPI uInt32 GetSoftStartStopTime(int line);

   /// \brief Set the soft start/soft stop pulse train time in micro-seconds
   ///
   /// Specifies soft start/stop pulse train time in micro-seconds
   /// Note this is an alias for SetPWMLength
   ///
   /// \param line The output line to configure.
   /// \param timeus The new soft start/soft stop pulse train time.
   /// \sa GetSoftStartStopTime
   UeiDaqAPI void SetSoftStartStopTime(int line, uInt32 timeus);

   /// \brief Get the pulse train period. 
   ///
   /// Specifies soft start/stop or continuous pulse train period in micro-seconds
   ///
   /// \param line The output line to configure.
   /// \return The pulse train period.
   /// \sa SetPWMPeriod
   UeiDaqAPI uInt32 GetPWMPeriod(int line);
 
   /// \brief Set pulse train period. 
   ///
   /// Specifies soft start/stop or continuous pulse train period in micro-seconds
   ///
   /// \param line The output line to configure.
   /// \param periodus The new pulse train period.
   /// \sa GetPWMPeriod
   UeiDaqAPI void SetPWMPeriod(int line, uInt32 periodus);

   /// \brief Get the pulse train duty cycle. 
   ///
   /// Specifies the continuous pulse train duty cycle
   ///
   /// \param line The output line to configure.
   /// \return The pulse train period.
   /// \sa SetPWMDutyCycle
   UeiDaqAPI double GetPWMDutyCycle(int line);
 
   /// \brief Set pulse train duty cycle. 
   ///
   /// Specifies the continuous pulse train duty cycle
   ///
   /// \param line The output line to configure.
   /// \param dutyCycle The new pulse train duty cycle.
   /// \sa GetPWMDutyCycle
   UeiDaqAPI void SetPWMDutyCycle(int line, double dutyCycle);

   /// \brief Get termination configuration
   ///
   /// Specifies whether a termination resistor is connected in pull up or down configuration
   ///
   /// \param line The output line to configure.
   /// \return The termination configuration.
   /// \sa SetTermination
   UeiDaqAPI tUeiDigitalTermination GetTermination(int line);

   /// \brief Set termination configuration. 
   ///
   /// Specifies whether a termination resistor is connected in pull up or down configuration
   ///
   /// \param line The output line to configure.
   /// \param term The new termination configuration.
   /// \sa GetTermination
   UeiDaqAPI void SetTermination(int line, tUeiDigitalTermination term);

   /// \brief Get the PWM ouput mode. 
   ///
   /// Specifies the PWM output mode for DO channels that support the capability
   ///
   /// \param line The output line to configure.
   /// \return The current PWM output mode.
   /// \sa SetPWMOutputMode
   UeiDaqAPI tUeiDOPWMOutputMode GetPWMOutputMode(int line);
 
   /// \brief Set the PWM output mode. 
   ///
   /// Specifies the PWM output mode for DO channels that support the capability
   ///
   /// \param line The output line to configure.
   /// \param mode The new PWM output mode.
   /// \sa GetPWMOutputMode
   UeiDaqAPI void SetPWMOutputMode(int line, tUeiDOPWMOutputMode mode);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDOIndustrialChannelImpl> m_pImpl;
};


/// \brief Manages settings for each protected digital output channel
///
/// Manages settings for each digital output channel protected by a circuit breaker.
class CUeiDOProtectedChannel : public CUeiDOIndustrialChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiDOProtectedChannel(int numLines);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiDOProtectedChannel();

   /// \brief Get the undercurrent limit
   ///
   /// Get the minimum amount of current allowed in Amps on the specified
   /// line of the port associated with the channel object.
   /// If less than the minimum current flows through the digital output line,
   /// the circuit will open.
   ///
   /// \param line The output line to configure
   /// \return The under current limit.
   /// \sa SetUnderCurrentLimit GetOverCurrentLimit SetOverCurrentLimit 
   UeiDaqAPI double GetUnderCurrentLimit(int line);

   /// \brief Set the undercurrent limit 
   ///
   /// Set the minimum amount of current allowed in Amps on the specified
   /// line of the port associated with the channel object.
   /// If less than the minimum current flows through the digital output line,
   /// the circuit will open.
   ///
   /// \param line The output line to configure
   /// \param underCurrent The under current limit.
   /// \sa GetUnderCurrentLimit GetOverCurrentLimit SetOverCurrentLimit 
   UeiDaqAPI void SetUnderCurrentLimit(int line, double underCurrent);

   /// \brief Get the overcurrent limit 
   ///
   /// Get the maximum amount of current allowed in Amps on the specified
   /// line of the port associated with the channel object.
   /// If more than the maximum current flows through the digital output line,
   /// the circuit will open.
   /// 
   /// \param line The output line to configure
   /// \return The over current limit.
   /// \sa SetUnderCurrentLimit GetUnderCurrentLimit SetOverCurrentLimit 
   UeiDaqAPI double GetOverCurrentLimit(int line);

   /// \brief Set the overcurrent limit 
   ///
   /// Set the maximum amount of current allowed in Amps on the specified
   /// line of the port associated with the channel object.
   /// If more than the maximum current flows through the digital output line,
   /// the circuit will open.
   ///
   /// \param line The output line to configure
   /// \param overCurrent The over current limit.
   /// \sa GetUnderCurrentLimit GetOverCurrentLimit SetUnderCurrentLimit 
   UeiDaqAPI void SetOverCurrentLimit(int line, double overCurrent);

   /// \brief Get the current measurement rate 
   ///
   /// Get the rate at which the current is measured.
   /// This rate determines how fast the device react when an under or over current
   /// condition occurs.
   ///
   /// \return The current measurement rate (in Hz).
   /// \sa GetCurrentMeasurementRate
   UeiDaqAPI double GetCurrentMeasurementRate(void);

   /// \brief Set the current measurement rate 
   ///
   /// Set the rate at which the current is measured.
   /// This rate determines how fast the device react when an under or over current
   /// condition occurs.
   ///
   /// \param measurementRate The current measurement rate (in Hz).
   /// \sa GetCurrentMeasurementRate
   UeiDaqAPI void SetCurrentMeasurementRate(double measurementRate);

   /// \brief Determines whether the CB is currently protecting the channel
   /// 
   /// Return true if circuit breaker for this channel is enabled and
   /// false otherwise
   ///
   /// \param line The output line to configure
   /// \return Circuit breaker state
   UeiDaqAPI bool IsCircuitBreakerEnabled(int line);

   /// \brief Enable or Disable channel protection 
   /// 
   /// Enable or disable circuit breaker on this channel. when enabled a circuit
   /// breaker monitors up a diagnostic channel and opens the circuit
   /// if any of the measurements goes out of pre-set limits.
   ///
   /// \param line The output line to configure
   /// \param enable True to turn-on protection, false to turn it off
   UeiDaqAPI void EnableCircuitBreaker(int line, bool enable);

   /// \brief Get the auto retry setting. 
   ///
   /// The auto retry setting specifies whether the device should attempt
   /// to close the circuit after it was opened because of an over or
   /// under current condition.
   /// If it is set to true the device will try to close the circuit at a rate
   /// set by the autoRetryRate setting.
   ///
   /// \return true if autoRetry is on, false otherwise.
   /// \sa SetAutoRetry
   UeiDaqAPI bool GetAutoRetry(void);

   /// \brief Set the auto retry setting. 
   ///
   /// The auto retry setting specifies whether the device should attempt
   /// to close the circuit after it was opened because of an over or
   /// under current condition.
   /// If it is set to true the device will try to close the circuit at a rate
   /// set by the autoRetryRate setting.
   ///
   /// \param autoRetry true to turn auto-retry on, false to turn it off.
   /// \sa GetAutoRetry
   UeiDaqAPI void SetAutoRetry(bool autoRetry);

   /// \brief Get the auto retry rate. 
   ///
   /// Specifies how often the device will attempt to close a circuit that
   /// was opened because of an over or under current condition.
   ///
   /// \return The number of retries per second.
   /// \sa SetAutoRetryRate
   UeiDaqAPI double GetAutoRetryRate(void);

   /// \brief Set the auto retry rate. 
   ///
   /// Specifies how often the device will attempt to close a circuit that
   /// was opened because of an over or under current condition.
   ///
   /// \param autoRetryRate The new number of retries per second.
   /// \sa GetAutoRetryRate
   UeiDaqAPI void SetAutoRetryRate(double autoRetryRate);

   /// \brief Get the over or under limit count. 
   ///
   /// Specifies how many consecutive times the monitored current must be out of limits
   /// before tripping the circuit breaker.
   ///
   /// \return The over or under limit count.
   /// \sa SetOverUnderCount
   UeiDaqAPI uInt32 GetOverUnderCount(void);

   /// \brief Set the over or under limit count. 
   ///
   /// Specifies how many consecutive times the monitored current must be out of limits
   /// before tripping the circuit breaker.
   ///
   /// \param overUnderCount The new over or under limit count.
   /// \sa GetOverUnderCount
   UeiDaqAPI void SetOverUnderCount(uInt32 overUnderCount);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDOProtectedChannelImpl> m_pImpl;
};

/// \brief Manages settings for each ARINC-429 input port
///
/// Manages settings for each ARINC-429 input port
class CUeiARINCInputPort  : public CUeiChannel
{
public: 
   /// \brief Constructor
   UeiDaqAPI CUeiARINCInputPort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiARINCInputPort();

   /// \brief Get the ARINC port speed
   ///
   /// Get the number of bits transmitted per second.
   ///
   /// \return The ARINC port speed.
   /// \sa SetSpeed  
   UeiDaqAPI tUeiARINCPortSpeed GetSpeed(void);

   /// \brief Set the ARINC port speed
   ///
   /// Set the number of bits transmitted per second.
   ///
   /// \param bitsPerSecond The ARINC port speed
   /// \sa GetSpeed  
   UeiDaqAPI void SetSpeed(tUeiARINCPortSpeed bitsPerSecond);

   /// \brief Get the ARINC port parity
   ///
   /// Get the parity used to detect transmission errors.
   /// The parity bit of each ARINC frame is set to 0 or 1 so that the number
   /// of bits set to 1 matches the specified parity.
   ///
   /// \return The ARINC port parity.
   /// \sa SetParity  
   UeiDaqAPI tUeiARINCPortParity GetParity(void);

   /// \brief Set the ARINC port parity
   ///
   /// Set the parity used to detect transmission errors.
   /// The parity bit of each ARINC frame is set to 0 or 1 so that the number
   /// of bits set to 1 matches the specified parity.
   ///
   /// \param parity The ARINC port parity
   /// \sa GetParity  
   UeiDaqAPI void SetParity(tUeiARINCPortParity parity);

   /// \brief Get the SDI filter state
   ///
   /// Determines whether the SDI filter is turned on or off.
   ///
   /// \return The SDI filter state.
   /// \sa EnableSDIFilter  
   UeiDaqAPI bool IsSDIFilterEnabled(void);

   /// \brief Set the SDI filter state
   ///
   /// Specifies whether the SDI filter is turned on or off.
   ///
   /// \param enableSDIFilter true to turn SDI filtering on, false otherwise
   /// \sa IsSDIFilterEnabled  
   UeiDaqAPI void EnableSDIFilter(bool enableSDIFilter);

   /// \brief Get the SDI filter mask
   ///
   /// Get the SDI filter mask, only bits 0 and 1 are meaningful.
   /// ARINC frames whose SDI bits don't match the SDI mask are rejected.
   ///
   /// \return The SDI filter mask.
   /// \sa SetSDIFilterMask  
   UeiDaqAPI uInt32 GetSDIFilterMask(void);

   /// \brief Set the SDI filter mask
   ///
   /// Set the SDI filter mask, only bits 0 and 1 are meaningful.
   /// ARINC frames whose SDI bits don't match the SDI mask are rejected.
   ///
   /// \param SDIFilterMask The new SDI filter mask
   /// \sa GetSDIFilterMask  
   UeiDaqAPI void SetSDIFilterMask(uInt32 SDIFilterMask);

   /// \brief Get the timestamping state
   ///
   /// Determines whether each received frame is timestamped.
   ///
   /// \return The timestamping state.
   /// \sa EnableTimestamping  
   UeiDaqAPI bool IsTimestampingEnabled(void);

   /// \brief Set the timestamping state
   ///
   /// Specifies whether each received frame is timestamped.
   ///
   /// \param enableTimestamping true to turn timestamping on, false otherwise
   /// \sa IsTimestampingEnabled  
   UeiDaqAPI void EnableTimestamping(bool enableTimestamping);

   /// \brief Get the slow slew rate state
   ///
   /// Determines whether slow slew rate is enabled.
   ///
   /// \return The slow slew rate state.
   /// \sa EnableSlowSlewRate 
   UeiDaqAPI bool IsSlowSlewRateEnabled(void);

   /// \brief Set the slow slew state
   ///
   /// Enables slow slew rate.
   ///
   /// \param enableSlowSlewRate true to turn slow slew rate on, false otherwise
   /// \sa IsSlowSlewRateEnabled  
   UeiDaqAPI void EnableSlowSlewRate(bool enableSlowSlewRate);

   /// \brief Add a filter entry
   ///
   /// Add a filter entry to the port's frame filter table. 
   /// Each incoming ARINC frame that doesn't match any of the filter 
   /// entries is rejected.
   ///
   /// \param entry A struture that represents the new filter entry
   /// \sa ClearFilterEntries, GetFilterEntry 
   UeiDaqAPI void AddFilterEntry(tUeiARINCFilterEntry entry);

   /// \brief Retrieve a filter entry
   ///
   /// Retrieve a filter entry from the port's frame filter table.
   /// Returns NULL when retrieving past the end of the table.
   ///
   /// \return A struture that represents the retrieved filter entry
   /// \sa AddFilterEntry, ClearFilterEntries 
   UeiDaqAPI tUeiARINCFilterEntry* GetFilterEntry(int index);

   /// \brief Clear filter table
   ///
   /// Empties the port's filter table.
   ///
   /// \sa AddFilterEntry, GetFilterEntry 
   UeiDaqAPI void ClearFilterEntries(void);

   /// \brief Get the label filter state
   ///
   /// Determines whether label filtering is enabled.
   ///
   /// \return The label filter state.
   /// \sa EnableLabelFilter 
   UeiDaqAPI bool IsLabelFilterEnabled(void);

   /// \brief Set the label filter state
   ///
   /// Enables label filtering.
   ///
   /// \param enableLabelFilter true to turn label filtering on, false otherwise
   /// \sa IsLabelFilterEnabled  
   UeiDaqAPI void EnableLabelFilter(bool enableLabelFilter);

   /// \brief Get the timestamp resolution
   ///
   /// Get the timestamp resolution in seconds.
   ///
   /// \return the timestamp resolution.
   /// \sa SetTimestampResolution  
   UeiDaqAPI f64 GetTimestampResolution();

   /// \brief Set the timestamp resolution
   ///
   /// Set the timestamp resolution in seconds.
   ///
   /// \param resolution the new resolution.
   /// \sa GetTimestampResolution  
   UeiDaqAPI void SetTimestampResolution(f64 resolution);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiARINCInputPortImpl> m_pImpl;
};


/// \brief Manages settings for each ARINC-429 output port
///
/// Manages settings for each ARINC-429 output port
class CUeiARINCOutputPort  : public CUeiChannel
{
public: 
   /// \brief Constructor
   UeiDaqAPI CUeiARINCOutputPort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiARINCOutputPort();

   /// \brief Get the ARINC port speed
   ///
   /// Get the number of bits transmitted per second.
   ///
   /// \return The ARINC port speed.
   /// \sa SetSpeed  
   UeiDaqAPI tUeiARINCPortSpeed GetSpeed(void);

   /// \brief Set the ARINC port speed
   ///
   /// Set the number of bits transmitted per second.
   ///
   /// \param bitsPerSecond The ARINC port speed
   /// \sa GetSpeed  
   UeiDaqAPI void SetSpeed(tUeiARINCPortSpeed bitsPerSecond);

   /// \brief Get the ARINC port parity
   ///
   /// Get the parity used to detect transmission errors.
   /// The parity bit of each ARINC frame is set to 0 or 1 so that the number
   /// of bits set to 1 matches the specified parity.
   ///
   /// \return The ARINC port parity.
   /// \sa SetParity  
   UeiDaqAPI tUeiARINCPortParity GetParity(void);

   /// \brief Set the ARINC port parity
   ///
   /// Set the parity used to detect transmission errors.
   /// The parity bit of each ARINC frame is set to 0 or 1 so that the number
   /// of bits set to 1 matches the specified parity.
   ///
   /// \param parity The ARINC port parity
   /// \sa GetParity  
   UeiDaqAPI void SetParity(tUeiARINCPortParity parity);

   /// \brief Get the loopback state
   ///
   /// Determines whether loopback is enabled. When enabled you can read back packet
   /// sent to this port on a dedicated loopback port.
   ///
   /// \return The loopback state.
   /// \sa EnableLoopback 
   UeiDaqAPI bool IsLoopbackEnabled(void);

   /// \brief Set the loopback state
   ///
   /// Enables loopback. When enabled you can read back packet
   /// sent to this port on a dedicated loopback port.
   ///
   /// \param enableLoopback true to enable loopback, false to disable it.
   /// \sa IsLoopbackEnabled  
   UeiDaqAPI void EnableLoopback(bool enableLoopback);

   /// \brief Get the slow slew rate state
   ///
   /// Determines whether slow slew rate is enabled.
   ///
   /// \return The slow slew rate state.
   /// \sa EnableSlowSlewRate 
   UeiDaqAPI bool IsSlowSlewRateEnabled(void);

   /// \brief Set the slow slew state
   ///
   /// Enables slow slew rate.
   ///
   /// \param enableSlowSlewRate true to turn slow slew rate on, false otherwise
   /// \sa IsSlowSlewRateEnabled  
   UeiDaqAPI void EnableSlowSlewRate(bool enableSlowSlewRate);

   /// \brief Add a scheduler entry
   ///
   /// Add a scheduler entry to the port's scheduler table. 
   ///
   /// \param entry A struture that represents the new scheduler entry
   /// \sa ClearSchedulerEntries, GetSchedulerEntry 
   UeiDaqAPI void AddSchedulerEntry(tUeiARINCSchedulerEntry entry);

   /// \brief Retrieve a scheduler entry
   ///
   /// Retrieve a scheduler entry from the port's scheduler table.
   /// Returns NULL when retrieving past the end of the table.
   ///
   /// \return A struture that represents the retrieved scheduler entry
   /// \sa AddSchedulerEntry, ClearSchedulerEntries 
   UeiDaqAPI tUeiARINCSchedulerEntry* GetSchedulerEntry(int index);

   /// \brief Clear scheduler table
   ///
   /// Empties the port's scheduler table.
   ///
   /// \sa AddSchedulerEntry, GetSchedulerEntry 
   UeiDaqAPI void ClearSchedulerEntries(void);

   /// \brief Get the scheduler state
   ///
   /// Determines whether scheduling is enabled.
   ///
   /// \return The scheduler state.
   /// \sa EnableScheduler 
   UeiDaqAPI bool IsSchedulerEnabled(void);

   /// \brief Set the scheduler state
   ///
   /// Enables scheduling.
   ///
   /// \param enableScheduler true to turn scheduling on, false otherwise
   /// \sa IsSchedulerEnabled  
   UeiDaqAPI void EnableScheduler(bool enableScheduler);

   /// \brief Get the scheduler type
   ///
   /// Gets scheduler type.
   ///
   /// \return The scheduler type.
   /// \sa SetSchedulerType 
   UeiDaqAPI tUeiARINCSchedulerType GetSchedulerType(void);

   /// \brief Set the scheduler type
   ///
   /// Sets scheduler type.
   ///
   /// \param type the new scheduler type
   /// \sa GetSchedulerType  
   UeiDaqAPI void SetSchedulerType(tUeiARINCSchedulerType type);

   /// \brief Get the scheduler rate
   ///
   /// Gets scheduler rate.
   ///
   /// \return The scheduler rate.
   /// \sa SetSchedulerRate 
   UeiDaqAPI double GetSchedulerRate(void);

   /// \brief Set the scheduler rate
   ///
   /// Sets scheduler rate.
   ///
   /// \param rate the new scheduler rate
   /// \sa GetSchedulerRate  
   UeiDaqAPI void SetSchedulerRate(double rate);

   /// \brief Get the TX FIFO rate
   ///
   /// Gets TX FIFO rate.
   ///
   /// \return The TX FIFO rate.
   /// \sa SetFIFORate 
   UeiDaqAPI double GetFIFORate(void);

   /// \brief Set the TX FIFO rate
   ///
   /// Sets TX FIFO rate.
   ///
   /// \param rate the new TX FIFO rate
   /// \sa GetFIFORate  
   UeiDaqAPI void SetFIFORate(double rate);

   /// \brief Get the transmit delay state
   ///
   /// Determines whether delay information can be instered in the transmit stream.
   ///
   /// \return The delay state.
   /// \sa EnableDelay  
   UeiDaqAPI bool IsDelayEnabled(void);

   /// \brief Set the transmit delay state
   ///
   /// Specifies whether delay information can be inserted in the transmit stream.
   ///
   /// \param enableDelay true to enable delay on, false otherwise
   /// \sa IsDelayEnabled  
   UeiDaqAPI void EnableDelay(bool enableDelay);

   /// \brief Add a minor frame entry
   ///
   /// Add a minor frame entry to the port's scheduler table. 
   ///
   /// \param entry A struture that represents the new minor frame entry
   /// \sa ClearMinorFrameEntries, GetMinorFrameEntry 
   UeiDaqAPI void AddMinorFrameEntry(tUeiARINCMinorFrameEntry entry);

   /// \brief Retrieve a minor frame entry
   ///
   /// Retrieve a scheduler entry from the port's scheduler table.
   /// Returns NULL when retrieving past the end of the table.
   ///
   /// \return A struture that represents the retrieved scheduler entry
   /// \sa AddMinorFrameEntry, ClearMinorFrameEntries 
   UeiDaqAPI tUeiARINCMinorFrameEntry* GetMinorFrameEntry(int index);

   /// \brief Clear major frame
   ///
   /// Empties the port's major frame.
   ///
   /// \sa AddMinorFrameEntry, GetMinorFrameEntry 
   UeiDaqAPI void ClearMinorFrameEntries();

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiARINCOutputPortImpl> m_pImpl;
};

/// \brief Manages settings for each 1553 port
///
/// Manages settings for each 1553-553 port
class CUeiMIL1553Port  : public CUeiChannel
{
public: 
   /// \brief Constructor
   UeiDaqAPI CUeiMIL1553Port();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiMIL1553Port();

   /// \brief Get the 1553 port coupling
   ///
   /// Get the coupling used to to connect the port to the bus
   ///
   /// \return The 1553 port coupling.
   /// \sa SetCoupling
   UeiDaqAPI tUeiMIL1553PortCoupling GetCoupling(void);

   /// \brief Set the 1553 port coupling
   ///
   /// Set the coupling needed to connect port to 1553 bus
   ///
   /// \param coupling The 1553 port coupling
   /// \sa GetCoupling  
   UeiDaqAPI void SetCoupling(tUeiMIL1553PortCoupling coupling);

   /// \brief Get the 1553 port mode of operation
   ///
   /// Get the port mode of operation: BM, RT or BC
   ///
   /// \return The 1553 port mode of operation
   /// \sa SetPortMode
   UeiDaqAPI tUeiMIL1553PortOpMode GetPortMode(void);

   /// \brief Set the 1553 port mode of operation
   ///
   /// Set the port mode of operation: BM, RT or BC
   ///
   /// \param portMode The 1553 port mode of operation
   /// \sa GetPortMode  
   UeiDaqAPI void SetPortMode(tUeiMIL1553PortOpMode portMode);

   /// \brief Get the 1553 active transmission bus
   ///
   /// Get the active bus: A or B
   ///
   /// \return The 1553 port active bus for transmission
   /// \sa SetTxBus
   UeiDaqAPI tUeiMIL1553PortActiveBus GetTxBus(void);

   /// \brief Set the 1553 active transmission bus
   ///
   /// Set the active bus: A or B
   ///
   /// \param portBus The 1553 port active bus for transmission
   /// \sa GetTxBus  
   UeiDaqAPI void SetTxBus(tUeiMIL1553PortActiveBus portBus);

   /// \brief Get the 1553 active reception bus
   ///
   /// Get the active bus: A or B or both
   ///
   /// \return The 1553 port active bus for reception
   /// \sa SetRxBus
   UeiDaqAPI tUeiMIL1553PortActiveBus GetRxBus(void);

   /// \brief Set the 1553 active reception bus
   ///
   /// Set the active bus: A or B or both
   ///
   /// \param portBus The 1553 port active bus for reception
   /// \sa GetRxBus  
   UeiDaqAPI void SetRxBus(tUeiMIL1553PortActiveBus portBus);

   /// \brief Get the ARINC-708 endian on reception bus Rx
   ///
   /// Get the endian on Rx: big or small
   ///
   /// \return The ARINC-708 endian notation on Rx
   /// \sa SetRxEndian
   UeiDaqAPI tUeiMIL1553Endian GetRxEndian(void);

   /// \brief Set the ARINC-708 endian on reception bus Rx
   ///
   /// Set the endian on Rx: big or small
   ///
   /// \param endian The new Rx endian notation
   /// \sa GetRxEndian
   UeiDaqAPI void SetRxEndian(tUeiMIL1553Endian endian);

   /// \brief Get the ARINC-708 endian on transmission bus Tx
   ///
   /// Get the endian on Tx: big or small
   ///
   /// \return The ARINC-708 endian  notation on Tx
   /// \sa SetTxEndian
   UeiDaqAPI tUeiMIL1553Endian GetTxEndian(void);

   /// \brief Set the ARINC-708 endian on transmission bus Tx
   ///
   /// Set the endian on Tx: big or small
   ///
   /// \param endian The new Tx endian notation
   /// \sa GetTxEndian
   UeiDaqAPI void SetTxEndian(tUeiMIL1553Endian endian);

   /// \brief Get the timestamping state
   ///
   /// Determines whether each received 1553 input message is timestamped.
   ///
   /// \return The timestamping state.
   /// \sa EnableTimestamping  
   UeiDaqAPI bool IsTimestampingEnabled(void);

   /// \brief Set the timestamping state
   ///
   /// Specifies whether each received 1553 input message is timestamped.
   ///
   /// \param enableTimestamping true to turn timestamping on, false otherwise
   /// \sa IsTimestampingEnabled  
   UeiDaqAPI void EnableTimestamping(bool enableTimestamping);

   /// \brief Get the timestamp resolution
   ///
   /// Get the timestamp resolution in seconds.
   ///
   /// \return the timestamp resolution.
   /// \sa SetTimestampResolution  
   UeiDaqAPI f64 GetTimestampResolution();

   /// \brief Set the timestamp resolution
   ///
   /// Set the timestamp resolution in seconds.
   ///
   /// \param resolution the new resolution.
   /// \sa GetTimestampResolution  
   UeiDaqAPI void SetTimestampResolution(f64 resolution);

   /// \brief Add a filter entry
   ///
   /// Add a filter entry to the port's frame filter table. 
   /// Each incoming 1553 message that doesn't match any of the filter 
   /// entries is rejected.
   ///
   /// \param entry A struture that represents the new filter entry
   /// \sa ClearFilterEntries, GetFilterEntry 
   UeiDaqAPI void AddFilterEntry(tUeiMIL1553FilterEntry entry);

   /// \brief Retrieve a filter entry
   ///
   /// Retrieve a filter entry from the port's frame filter table.
   /// Returns NULL when retrieving past the end of the table.
   ///
   /// \return A struture that represents the retrieved filter entry
   /// \sa AddFilterEntry, ClearFilterEntries 
   UeiDaqAPI tUeiMIL1553FilterEntry* GetFilterEntry(int index);

   /// \brief Clear filter table
   ///
   /// Empties the port's filter table.
   ///
   /// \sa AddFilterEntry, GetFilterEntry 
   UeiDaqAPI void ClearFilterEntries(void);

   /// \brief Get the filter state
   ///
   /// Determines whether the 1553 input filter is turned on or off.
   ///
   /// \return The filter state.
   /// \sa EnableFilter  
   UeiDaqAPI bool IsFilterEnabled(void);

   /// \brief Set the filter state
   ///
   /// Specifies whether the 1553 input filter is turned on or off.
   ///
   /// \param enableFilter true to turn filtering on, false otherwise
   /// \sa IsFilterEnabled  
   UeiDaqAPI void EnableFilter(bool enableFilter);

   /// \brief Add a scheduler entry
   ///
   /// Add a scheduler entry to the port's scheduler table. 
   ///
   /// \param entry A struture that represents the new scheduler entry
   /// \sa ClearSchedulerEntries, GetSchedulerEntry 
   UeiDaqAPI void AddSchedulerEntry(tUeiMIL1553SchedulerEntry entry);

   /// \brief Retrieve a scheduler entry
   ///
   /// Retrieve a scheduler entry from the port's scheduler table.
   /// Returns NULL when retrieving past the end of the table.
   ///
   /// \return A struture that represents the retrieved scheduler entry
   /// \sa AddSchedulerEntry, ClearSchedulerEntries 
   UeiDaqAPI tUeiMIL1553SchedulerEntry* GetSchedulerEntry(int index);

   /// \brief Clear scheduler table
   ///
   /// Empties the port's scheduler table.
   ///
   /// \sa AddSchedulerEntry, GetSchedulerEntry 
   UeiDaqAPI void ClearSchedulerEntries(void);

   /// \brief Get the scheduler state
   ///
   /// Determines whether scheduling is enabled.
   ///
   /// \return The scheduler state.
   /// \sa EnableScheduler 
   UeiDaqAPI bool IsSchedulerEnabled(void);

   /// \brief Set the scheduler state
   ///
   /// Enables scheduling.
   ///
   /// \param enableScheduler true to turn scheduling on, false otherwise
   /// \sa IsSchedulerEnabled  
   UeiDaqAPI void EnableScheduler(bool enableScheduler);

   /// \brief Get the auto delay state
   ///
   /// Determines whether auto delay between commands on transmit is enabled.
   ///
   /// \return The auto delay settings.
   /// \sa SetInterCommandAutoDelay 
   UeiDaqAPI bool GetInterCommandAutoDelay(void);

   /// \brief Set the auto delay state
   ///
   /// Defines whether auto delay between commands on transmit is enabled.
   ///
   /// \param enableAutoDelay true to turn auto delay on, false otherwise
   /// \sa GetInterCommandAutoDelay  
   UeiDaqAPI void SetInterCommandAutoDelay(bool enableAutoDelay);

   /// \brief Gets frame size for ARINC-708 implementation
   ///
   /// Determines frame size for ARINC-708 mode (in uint16s)
   ///
   /// \return The frame size
   /// \sa SetA708FrameSize 
   UeiDaqAPI int GetA708FrameSize(void);

   /// \brief Sets frame size for ARINC-708 implementation
   ///
   /// Sets frame size for ARINC-708 mode (in uint16s)
   ///
   /// \param framesize The frame size (in uint16s).
   /// \sa GetA708FrameSize 
   UeiDaqAPI void SetA708FrameSize(int framesize);

   /// \brief Gets low-level bus controller option flags
   ///
   /// Gets low-level bus controller option flags
   ///
   /// \return The current option flags
   /// \sa SetBCOptionFlags 
   UeiDaqAPI uInt32 GetBCOptionFlags(void);

   /// \brief Sets low-level bus controller option flags
   ///
   /// Sets low-level bus controller option flags
   ///
   /// \param optionFlags The new option flags.
   /// \sa GetBCOptionFlags 
   UeiDaqAPI void SetBCOptionFlags(uInt32 optionFlags);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiMIL1553PortImpl> m_pImpl;
};

///  \brief Manages settings for each timestamp channel
///
/// Manages settings for each timestamp channel
class CUeiTimestampChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiTimestampChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiTimestampChannel();
  
   /// \brief Get the timestamp resolution
   ///
   /// Get the timestamp resolution in seconds.
   ///
   /// \return the timestamp resolution.
   /// \sa SetResolution  
   UeiDaqAPI f64 GetResolution();
   
   /// \brief Set the timestamp resolution
   ///
   /// Set the timestamp resolution in seconds.
   ///
   /// \param resolution the new resolution.
   /// \sa GetResolution  
   UeiDaqAPI void SetResolution(f64 resolution);

   /// \brief Get the initial time offset
   ///
   /// A device timestamp channel start counting at 0 by default.
   /// The initial time offset is the decimal number of seconds since 00:00:00 UTC 01/01/1970
   /// that will be added to the hardware timestamp.
   ///
   /// \return the initial time offset in seconds.
   /// \sa SetInitialTime  
   UeiDaqAPI f64 GetInitialTime();
   
   /// \brief Set the initial time offset
   ///
   /// A device timestamp channel start counting at 0 by default.
   /// The initial time offset is the decimal number of seconds since 00:00:00 UTC 01/01/1970
   /// that will be added to the hardware timestamp.
   ///
   /// \param initialTimeSeconds the new initial time offset in seconds.
   /// \sa GetInitialTime  
   UeiDaqAPI void SetInitialTime(f64 initialTimeSeconds);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiTimestampChannelImpl> m_pImpl;
};

/// \brief Manages settings for each time keeper channel
///
/// Manages settings for each time keeper channel
class CUeiIRIGTimeKeeperChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiIRIGTimeKeeperChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiIRIGTimeKeeperChannel();

   /// \brief Get the time keeper source
   ///
   /// For proper functioning, the timekeeper requires a 1PPS signal.
   /// which can be delivered from multiple sources: internal, external, GPS...
   /// This method gets the current time keeper 1PPS source
   ///
   /// \return the 1PPS source.
   /// \sa Set1PPSSource  
   UeiDaqAPI tUeiIRIGTimeKeeper1PPSSource Get1PPSSource();
   
   /// \brief Set the time keeper source
   ///
   /// For proper functioning, the timekeeper requires a 1PPS signal.
   /// which can be delivered from multiple sources: internal, external, GPS...
   /// This method sets the new time keeper 1PPS source
   ///
   /// \param source the new 1 PPS source.
   /// \sa Get1PPSSource  
   UeiDaqAPI void Set1PPSSource(tUeiIRIGTimeKeeper1PPSSource source);

   /// \brief Get the auto-follow state
   ///
   /// If selected external 1PPS source does not deliver pulses (because of a break in timecode
   /// transmission, for example). Timekeeper can switch to internal timebase when externally
   /// derived one is not available
   ///
   /// \return The auto-follow state.
   /// \sa EnableAutoFollow 
   UeiDaqAPI bool IsAutoFollowEnabled(void);

   /// \brief Set the auto-follow state
   ///
   /// If selected external 1PPS source does not deliver pulses (because of a break in timecode
   /// transmission, for example). Timekeeper can switch to internal timebase when externally
   /// derived one is not available
   ///
   /// \param enableAutoFollow true to turn auto-follow on, false otherwise
   /// \sa IsAutoFollowEnabled  
   UeiDaqAPI void EnableAutoFollow(bool enableAutoFollow);

   /// \brief Get the nominal value state
   ///
   /// Select whether to use nominal period (i.e. 100e6 pulses of 100MHz base clock) 
   /// or the period measured by timekeeper (it measures and averages number of base clock cycles
   /// between externally derived 1PPS pulses when they are valid).
   ///
   /// \return The nominal value state.
   /// \sa EnableNominalValue 
   UeiDaqAPI bool IsNominalValueEnabled(void);

   /// \brief Set the nominal value state
   ///
   /// Select whether to use nominal period (i.e. 100e6 pulses of 100MHz base clock) 
   /// or the period measured by timekeeper (it measures and averages number of base clock cycles
   /// between externally derived 1PPS pulses when they are valid).
   ///
   /// \param enableNominalValue true to turn nominal value on, false otherwise
   /// \sa IsNominalValueEnabled  
   UeiDaqAPI void EnableNominalValue(bool enableNominalValue);

   /// \brief Get the sub PPS state
   ///
   /// Select whether external timebase is slower than 1PPS
   /// or is not derived from the timecode
   ///
   /// \return The sub PPS state.
   /// \sa EnableSubPPS 
   UeiDaqAPI bool IsSubPPSEnabled(void);

   /// \brief Set the nominal value state
   ///
   /// Select whether external timebase is slower than 1PPS
   /// or is not derived from the timecode
   ///
   /// \param enableSubPPS true to turn sub PPS on, false otherwise
   /// \sa IsSubPPSEnabled  
   UeiDaqAPI void EnableSubPPS(bool enableSubPPS);

   /// \brief Get the SBS state
   ///
   /// Select whether to use SBS timecode section for TimeKeeper hour/min decoding
   /// (if BCD data in the incoming timecode is corrupted)
   ///
   /// \return The SBS state.
   /// \sa EnableSBS 
   UeiDaqAPI bool IsSBSEnabled(void);

   /// \brief Set the SBS state
   ///
   /// Select whether to use SBS timecode section for TimeKeeper hour/min decoding
   /// (if BCD data in the incoming timecode is corrupted)
   ///
   /// \param enableSBS true to use SBS data instead of BCD data, false otherwise
   /// \sa IsSBSEnabled  
   UeiDaqAPI void EnableSBS(bool enableSBS);

   /// \brief Get the invalid second state
   ///
   /// Select whether seconds information is invalid in the input timecode
   ///
   /// \return The invalid second state.
   /// \sa EnableInvalidSecond 
   UeiDaqAPI bool IsInvalidSecondEnabled(void);

   /// \brief Set the invalid second state
   ///
   /// Select whether seconds information is invalid in the input timecode
   ///
   /// \param enableInvalidSecond true to specify that second is invalid, false otherwise
   /// \sa IsInvalidSecondEnabled  
   UeiDaqAPI void EnableInvalidSecond(bool enableInvalidSecond);

   /// \brief Get the invalid minute state
   ///
   /// Select whether minutes information is invalid in the input timecode
   ///
   /// \return The invalid minute state.
   /// \sa EnableInvalidMinute 
   UeiDaqAPI bool IsInvalidMinuteEnabled(void);

   /// \brief Set the invalid minute state
   ///
   /// Select whether minutes information is invalid in the input timecode
   ///
   /// \param enableInvalidMinute true to specify that minute is invalid, false otherwise
   /// \sa IsInvalidMinuteEnabled  
   UeiDaqAPI void EnableInvalidMinute(bool enableInvalidMinute);

   /// \brief Get the invalid day state
   ///
   /// Select whether days information is invalid in the input timecode
   ///
   /// \return The invalid day state.
   /// \sa EnableInvalidDay 
   UeiDaqAPI bool IsInvalidDayEnabled(void);

   /// \brief Set the invalid day state
   ///
   /// Select whether days information is invalid in the input timecode
   ///
   /// \param enableInvalidDay true to specify that day is invalid, false otherwise
   /// \sa IsInvalidDayEnabled  
   UeiDaqAPI void EnableInvalidDay(bool enableInvalidDay);

   /// \brief Get the initial time
   ///
   /// Get initial time programmed in time keeper when session started
   ///
   /// \return the current value for initial time
   UeiDaqAPI tUeiANSITime GetInitialANSITime(void);

   /// \brief Set the initial time
   ///
   /// Program initial time in time keeper, 1PPS signal received by timekeeper will increment
   /// the time to keep it current
   ///
   /// \param initialTime the new value for initial time
   UeiDaqAPI void SetInitialANSITime(tUeiANSITime initialTime);

   /// \brief Get the initial time
   ///
   /// Get initial time programmed in time keeper when session started
   ///
   /// \return the current value for initial time
   UeiDaqAPI tUeiSBSTime GetInitialSBSTime(void);

   /// \brief Set the initial time
   ///
   /// Program initial time in time keeper, 1PPS signal received by timekeeper will increment
   /// the time to keep it current
   ///
   /// \param initialTime the new value for initial time
   UeiDaqAPI void SetInitialSBSTime(tUeiSBSTime initialTime);

   /// \brief Is initial time set from GPS
   ///
   /// Program initial time in time keeper from GPS. 1PPS signal received by timekeeper will increment
   /// the time to keep it current
   /// \return true if initial time is taken from GPS, false otherwise
   UeiDaqAPI bool IsInitialTimeFromGPSEnabled(void);

   /// \brief Set initial time from GPS
   ///
   /// Program initial time in time keeper from GPS. 1PPS signal received by timekeeper will increment
   /// the time to keep it current
   /// \param setTimeFromGPS true to set initial time from GPS, false otherwise
   UeiDaqAPI void EnableInitialTimeFromGPS(bool setTimeFromGPS);

   /// \brief Get device timestamp reset mask
   ///
   /// The timestamp reset bit mask sets the layers which will have
   /// their timestamp counter reset when the IRIG session starts.
   /// The initial time is updated with the date/time of the reset.
   /// \return the current timestamp reset mask
   UeiDaqAPI uInt32 GetTimestampResetMask(void);

   /// \brief Set device timestamp reset mask
   ///
   /// The timestamp reset bit mask sets the layers which will have
   /// their timestamp counter reset when the IRIG session starts.
   /// The initial time is updated with the date/time of the reset.
   /// \param resetMask the new timestamp reset mask.
   UeiDaqAPI void SetTimestampResetMask(uInt32 resetMask);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiIRIGTKChannelImpl> m_pImpl;
};

/// \brief Manages settings for each IRIG time code input channel
///
/// Manages settings for each IRIG time code input channel
class CUeiIRIGInputChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiIRIGInputChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiIRIGInputChannel();

   /// \brief Get the time decoder input type
   ///
   /// Get the type of time code connected to the device.
   ///
   /// \return the time decoder input type.
   /// \sa SetTimeDecoderInput  
   UeiDaqAPI tUeiIRIGDecoderInputType GetTimeDecoderInput();
   
   /// \brief Set the time decoder input type
   ///
   /// Set the type of time code connected to the device.
   ///
   /// \param input the new time decoder type.
   /// \sa GetTimeDecoderInput  
   UeiDaqAPI void SetTimeDecoderInput(tUeiIRIGDecoderInputType input);

   /// \brief Get the time code format
   ///
   /// Get the time code format used by the signal connected to the device.
   ///
   /// \return the time code format.
   /// \sa SetTimeCodeFormat  
   UeiDaqAPI tUeiIRIGTimeCodeFormat GetTimeCodeFormat();
   
   /// \brief Set the time decoder input type
   ///
   /// Set the time code format used by the signal connected to the device.
   ///
   /// \param format the new time code format.
   /// \sa GetTimeCodeFormat  
   UeiDaqAPI void SetTimeCodeFormat(tUeiIRIGTimeCodeFormat format);

   /// \brief Get the external clock state
   ///
   /// Determines whether time decoder is using an external 10MHz clock connected to RFIn1
   ///
   /// \return The external clock state.
   /// \sa EnableExternalClock 
   UeiDaqAPI bool IsExternalClockEnabled(void);

   /// \brief Set the external clock state
   ///
   /// If selected, time decoder uses an external 10MHz clock connected to RFIn1
   ///
   /// \param enableExternalClock true to turn external clock on, false otherwise
   /// \sa IsExternalClockEnabled  
   UeiDaqAPI void EnableExternalClock(bool enableExternalClock);

   /// \brief Get the idle character state
   ///
   /// Determines whether idle character in the timing byte stream are accepted
   ///
   /// \return The idle character state.
   /// \sa EnableIdleCharacter 
   UeiDaqAPI bool IsIdleCharacterEnabled(void);

   /// \brief Set the idle character state
   ///
   /// If selected, idle characters in the timing byte stream will be accpeted
   ///
   /// \param enableIdleChars true to accept idle characters, false otherwise
   /// \sa IsIdleCharacterEnabled  
   UeiDaqAPI void EnableIdleCharacter(bool enableIdleChars);

   /// \brief Get the single P0 marker state
   ///
   /// Determines whether to use only one marker P0 in the timing byte stream
   ///
   /// \return The single P0 marker state.
   /// \sa EnableSingleP0Marker 
   UeiDaqAPI bool IsSingleP0MarkerEnabled(void);

   /// \brief Set the single P0 marker state
   ///
   /// If selected, Only one P0 marker is used in the timing byte stream 
   ///
   /// \param enableSingleP0Marker true to only use one P0 marker, false otherwise
   /// \sa IsSingleP0MarkerEnabled  
   UeiDaqAPI void EnableSingleP0Marker(bool enableSingleP0Marker);

   /// \brief Get the time keeper "time ready" connection state
   ///
   /// Determines whether "time ready" strobe is connected to time keeper
   ///
   /// \return The Time Keeper connection state.
   /// \sa EnableTimeKeeperConnection 
   UeiDaqAPI bool IsTimeKeeperConnectionEnabled(void);

   /// \brief Set the single P0 marker state
   ///
   /// If selected, "time ready" strobe is connected to time keeper
   ///
   /// \param enableTKConnect true to keep time decoder and time keeper connected, false otherwise
   /// \sa IsTimeKeeperConnectionEnabled  
   UeiDaqAPI void EnableTimeKeeperConnection(bool enableTKConnect);

   /// \brief Get the extra 1PPS state
   ///
   /// Determines whether an extra 1PPS pulse is emitted when PPM or PPH comes out of bounds
   ///
   /// \return The extra 1PPS state.
   /// \sa EnableExtra1PPS 
   UeiDaqAPI bool IsExtra1PPSEnabled(void);

   /// \brief Set the single P0 marker state
   ///
   /// If selected, an extra 1PPS pulse is emitted when PPM or PPH comes out of bounds
   ///
   /// \param enableExtra1PPS true to emit the extra 1PPS pulse, false otherwise
   /// \sa IsExtra1PPSEnabled  
   UeiDaqAPI void EnableExtra1PPS(bool enableExtra1PPS);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiIRIGInputChannelImpl> m_pImpl;
};

/// \brief Manages settings for each IRIG time code output channel
///
/// Manages settings for each IRIG time code output channel
class CUeiIRIGOutputChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiIRIGOutputChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiIRIGOutputChannel();

   /// \brief Get the time code format
   ///
   /// Get the time code format of the signal generated by the device.
   ///
   /// \return the time code format.
   /// \sa SetTimeCodeFormat  
   UeiDaqAPI tUeiIRIGTimeCodeFormat GetTimeCodeFormat();
   
   /// \brief Set the time code format
   ///
   /// Set the time code format of the signal generated by the device.
   ///
   /// \param format the new time code format.
   /// \sa GetTimeCodeFormat  
   UeiDaqAPI void SetTimeCodeFormat(tUeiIRIGTimeCodeFormat format);

   /// \brief Get the start condition state
   ///
   /// Determines whether the output time coder waits for the input time decoder
   /// to receive a valid time code before starting
   ///
   /// \return The start confdition state.
   /// \sa EnableStartWhenInputValid 
   UeiDaqAPI bool IsStartWhenInputValidEnabled(void);

   /// \brief Set the start condition state
   ///
   /// If selected, the output time coder waits for the input time decoder
   /// to receive a valid time code before starting
   ///
   /// \param enableStartWhenInputValid true to wiat for input time decoder, false otherwise
   /// \sa IsStartWhenInputValidEnabled  
   UeiDaqAPI void EnableStartWhenInputValid(bool enableStartWhenInputValid);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiIRIGOutputChannelImpl> m_pImpl;
};


/// \brief Manages settings for each IRIG digital TTL ouput port
///
/// Manages settings for each IRIG digital TTL ouput port
class CUeiIRIGDOTTLChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiIRIGDOTTLChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiIRIGDOTTLChannel();

   /// \brief Get the source for the specified TTL output
   ///
   /// Get the source for the specified TTL output
   ///
   /// \param line the TTL output line 
   /// \return the TTL source.
   /// \sa SetSource  
   UeiDaqAPI tUeiIRIGDOTTLSource GetSource(int line);
   
   /// \brief Set the source for the specified TTL output
   ///
   /// Set the source for the specified TTL output
   ///
   /// \param line the TTL output line 
   /// \param source the new source.
   /// \sa GetSource  
   UeiDaqAPI void SetSource(int line, tUeiIRIGDOTTLSource source);

   /// \brief Get the TTL buffers state
   ///
   /// Determines whether one or two TTL buffers are used to drive TTL lines.
   /// Enabling two drivers together provide stronger driving capabilities
   ///
   /// \return The TTL buffers state.
   /// \sa EnableTwoTTLBuffers 
   UeiDaqAPI bool IsTwoTTLBuffersEnabled(void);

   /// \brief Set the TTL buffers state
   ///
   /// If selected, two TTL buffers are used to drive TTL lines.
   /// Enabling two drivers together provide stronger driving capabilities
   ///
   /// \param enableTwoTTLBuffers true to use two buffers, false to use one buffer
   /// \sa IsTwoTTLBuffersEnabled  
   UeiDaqAPI void EnableTwoTTLBuffers(bool enableTwoTTLBuffers);

   /// \brief Get the pulse shape state
   ///
   /// Determines whether TTL pulses are 60us or 40ns wide
   ///
   /// \param line the TTL output line 
   /// \return The TTL buffers state.
   /// \sa Enable40nsPulse 
   UeiDaqAPI bool Is40nsPulseEnabled(int line);

   /// \brief Set the pulse shape state
   ///
   /// If selected, TTL pulses are 40ns wide otherwise they are 60us wide by default
   ///
   /// \param line the TTL output line 
   /// \param enable40nsPulse true to emit 40ns pulses, false to emit 60us pulses
   /// \sa Is40nsPulseEnabled  
   UeiDaqAPI void Enable40nsPulse(int line, bool enable40nsPulse);

   /// \brief Get the sync line state for the specified TTL output
   ///
   /// Determines whether the specified TTL output will be routed to the 
   /// corresponding SYNc line
   ///
   /// \param line the TTL output line 
   /// \return The sync line state.
   /// \sa DriveSyncLine 
   UeiDaqAPI bool IsSyncLineDriven(int line);

   /// \brief Set the sync line state for the specified TTL output
   ///
   /// If selected, the specified TTL output is routed to the 
   /// corresponding SYNc line
   ///
   /// \param line the TTL output line 
   /// \param driveSyncLine true to emit 40ns pulses, false to emit 60us pulses
   /// \sa IsSyncLineDriven  
   UeiDaqAPI void DriveSyncLine(int line, bool driveSyncLine);

   /// \brief Get event module PLL output rate
   ///
   /// The event module creates timed interrupts and provides synchronization signals 
   /// to the outside world through the TTL outputs or the sync lines.
   /// The event module includes four event channels, each channel is equipped with a DPLL
   /// that can generate a clock signal synchronized with a much slower reference clock such as
   /// the 1PPS signal fron the IRIG input or from the GPS input
   /// The rate is pecified in number of output pulses per reference pulse.
   ///
   /// \param eventChannel the event channel to configure
   /// \return the current rate of the signal generated by the event module PLL
   UeiDaqAPI int GetEventModuleRate(int eventChannel);

   /// \brief Set event module PLL output rate
   ///
   /// The event module creates timed interrupts and provides synchronization signals 
   /// to the outside world through the TTL outputs or the sync lines.
   /// The event module includes four event channels, each channel is equipped with a DPLL
   /// that can generate a clock signal synchronized with a much slower reference clock such as
   /// the 1PPS signal fron the IRIG input or from the GPS input
   // The rate is pecified in number of output pulses per reference pulse.
   ///
   /// \param eventChannel the event channel to configure
   /// \param rate the rate of the signal generated by the event module PLL
   UeiDaqAPI void SetEventModuleRate(int eventChannel, int rate);

   /// \brief Get event module reference clock
   ///
   /// The event module creates timed interrupts and provides synchronization signals 
   /// to the outside world through the TTL outputs or the sync lines.
   /// The event module includes four event channels, each channel is equipped with a DPLL
   /// that can generate a clock signal synchronized with a much slower reference clock such as
   /// the 1PPS signal fron the IRIG input or from the GPS input
   ///
   /// \param eventChannel the event channel to configure
   /// \return the current source of the event module PLL reference clock
   UeiDaqAPI tUeiIRIGEventSource GetEventModuleSource(int eventChannel);

   /// \brief Set event module reference clock
   ///
   /// The event module creates timed interrupts and provides synchronization signals 
   /// to the outside world through the TTL outputs or the sync lines.
   /// The event module includes four event channels, each channel is equipped with a DPLL
   /// that can generate a clock signal synchronized with a much slower reference clock such as
   /// the 1PPS signal fron the IRIG input or from the GPS input
   ///
   /// \param eventChannel the event channel to configure
   /// \param source the source of the event module PLL reference clock
   UeiDaqAPI void SetEventModuleSource(int eventChannel, tUeiIRIGEventSource source);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiIRIGDOTTLChannelImpl> m_pImpl;
};

/// \brief Manages settings for each waveform Analog output channel
///
/// Manages settings for each waveform Analog output channel
class CUeiAOWaveformChannel : public CUeiAOChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiAOWaveformChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAOWaveformChannel();

   /// \brief Get the main DAC clock source
   ///
   /// Get the source of the clock used by the main DAC.
   ///
   /// \return the main DAC clock source.
   /// \sa SetMainDACClockSource  
   UeiDaqAPI tUeiAOWaveformClockSource GetMainDACClockSource();
   
   /// \brief Set the main DAC clock source
   ///
   /// Set the source of the clock used by the main DAC.
   ///
   /// \param source the new main DAC clock source.
   /// \sa GetMainDACClockSource  
   UeiDaqAPI void SetMainDACClockSource(tUeiAOWaveformClockSource source);

   /// \brief Get the offset DAC clock source
   ///
   /// Get the source of the clock used by the offset DAC.
   ///
   /// \return the offset DAC clock source.
   /// \sa SetOffsetDACClockSource  
   UeiDaqAPI tUeiAOWaveformOffsetClockSource GetOffsetDACClockSource();
   
   /// \brief Set the offset DAC clock source
   ///
   /// Set the source of the clock used by the offset DAC.
   ///
   /// \param source the new offset DAC clock source.
   /// \sa GetOffsetDACClockSource  
   UeiDaqAPI void SetOffsetDACClockSource(tUeiAOWaveformOffsetClockSource source);

   /// \brief Get the main DAC clock synchronization
   ///
   /// Get the output where the clock used by the main DAC is routed.
   ///
   /// \return the main DAC clock synchronization.
   /// \sa SetMainDACClockSync  
   UeiDaqAPI tUeiAOWaveformClockSync GetMainDACClockSync();
   
   /// \brief Route the main DAC synchronization
   ///
   /// Set the output where the clock used by the main DAC will be routed.
   ///
   /// \param sync the new main DAC clock synchronization.
   /// \sa GetMainDACClockSync  
   UeiDaqAPI void SetMainDACClockSync(tUeiAOWaveformClockSync sync);

   /// \brief Get the main DAC trigger source
   ///
   /// Get the source of the trigger used by the main DAC.
   ///
   /// \return the main DAC trigger source.
   /// \sa SetMainDACTriggerSource  
   UeiDaqAPI tUeiAOWaveformTriggerSource GetMainDACTriggerSource();
   
   /// \brief Set the main DAC trigger source
   ///
   /// Set the source of the trigger used by the main DAC.
   ///
   /// \param source the new main DAC trigger source.
   /// \sa GetMainDACTriggerSource  
   UeiDaqAPI void SetMainDACTriggerSource(tUeiAOWaveformTriggerSource source);

   /// \brief Get the offset DAC trigger source
   ///
   /// Get the source of the trigger used by the offset DAC.
   ///
   /// \return the offset DAC trigger source.
   /// \sa SetOffsetDACTriggerSource  
   UeiDaqAPI tUeiAOWaveformOffsetTriggerSource GetOffsetDACTriggerSource();
   
   /// \brief Set the offset DAC trigger source
   ///
   /// Set the source of the trigger used by the offset DAC.
   ///
   /// \param source the new offset DAC trigger source.
   /// \sa GetOffsetDACTriggerSource  
   UeiDaqAPI void SetOffsetDACTriggerSource(tUeiAOWaveformOffsetTriggerSource source);
  
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAOWaveformChannelImpl> m_pImpl;
};

/// \brief Manages settings for each protected analog output channel
///
/// Manages settings for each analog output channel protected by a circuit breaker.
class CUeiAOProtectedChannel : public CUeiAOChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiAOProtectedChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAOProtectedChannel();

   /// \brief Get the DAC mode
   ///
   /// Each channel uses two DACs that can be enabled independently. 
   ///
   /// \return The current DAC mode.
   UeiDaqAPI tUeiAODACMode GetDACMode();

   /// \brief Set the DAC mode
   ///
   /// Each channel uses two DACs that can be enabled independently. 
   ///
   /// \param mode The new DAC mode.
   UeiDaqAPI void SetDACMode(tUeiAODACMode mode);

   /// \brief Gets diagnostic channels
   ///
   /// Each AO channel comes with up to five diagnostic channels.
   /// You can select which diagnostic to monitor.
   ///
   /// \param index The 0 based index of the diagnostic channel
   /// \return The diagnostic channel at this index.
   UeiDaqAPI tUeiAODiagChannel GetADCChannel(int index);

   /// \brief Sets diagnostic channels
   ///
   /// Each AO channel comes with up to five diagnostic channels.
   /// Add a diagnostic channel to the list of channels
   ///
   /// \param index The 0 based index of the diagnostic channel
   /// \param adcChannel The new diagnostic channel at specified index
   UeiDaqAPI void SetADCChannel(int index, tUeiAODiagChannel adcChannel);

   /// \brief Determines whether the CB is currently protecting the channel
   /// 
   /// Return true if circuit breaker for this channel is enabled and
   /// false otherwise
   ///
   /// \param index The 0 based index of the circuit breaker
   /// \return Circuit breaker state
   UeiDaqAPI bool IsCircuitBreakerEnabled(int index);

   /// \brief Enable or Disable channel protection 
   /// 
   /// Enable or disable circuit breaker on this channel. when enabled a circuit
   /// breaker monitors up a diagnostic channel and opens the circuit
   /// if any of the measurements goes out of pre-set limits.
   ///
   /// \param index The 0 based index of the circuit breaker
   /// \param enable True to turn-on protection, false to turn it off
   UeiDaqAPI void EnableCircuitBreaker(int index, bool enable);

   /// \brief Get the minimum circuit breaker limits
   ///
   /// Each circuit-breaker can monitor one diagnostic channels.
   /// Get the minimum current/volt/temperature allowed on the specified channel.
   /// The circuit will open if less than the minimum value is monitored.
   ///
   /// \param index The 0 based index of the circuit breaker
   /// \return The current low limit.
   UeiDaqAPI double GetCircuitBreakerLowLimit(int index);

   /// \brief Set the minimum circuit breaker limits
   ///
   /// Each circuit-breaker can monitor one diagnostic channel.
   /// Set the minimum current/volt/temperature allowed on the specified channel.
   /// The circuit will open if less than the minimum value is monitored.
   ///
   /// \param index The 0 based index of the circuit breaker
   /// \param lowLimit The new low limit.
   UeiDaqAPI void SetCircuitBreakerLowLimit(int index, double lowLimit);

   /// \brief Get the maximum circuit breaker limits
   ///
   /// Each circuit-breaker can monitor one diagnostic channel.
   /// Get the maximum current/volt/temperature allowed on the specified channel.
   /// The circuit will open if more than the maximum value is monitored.
   ///
   /// \param index The 0 based index of the circuit breaker
   /// \return The current high limit.
   UeiDaqAPI double GetCircuitBreakerHighLimit(int index);

   /// \brief Set the maximum circuit breaker limits
   ///
   /// Each circuit-breaker can monitor one diagnostic channel.
   /// Set the maximum current/volt/temperature allowed on the specified channel.
   /// The circuit will open if more than the minimum value is monitored.
   ///
   /// \param index The 0 based index of the circuit breaker
   /// \param highLimit The new high limit.
   UeiDaqAPI void SetCircuitBreakerHighLimit(int index, double highLimit);

   /// \brief Get the diagnostic measurement rate 
   ///
   /// Get the rate at which the diagnostic channels are monitored.
   /// This rate determines how fast the device react when an under or over limit
   /// condition occurs.
   ///
   /// \return The current circuit breaker measurement rate.
   /// \sa SetMeasurementRate
   UeiDaqAPI double GetMeasurementRate(void);

   /// \brief Set the diagnostic measurement rate 
   ///
   /// Set the rate at which the diagnostic channels are monitored.
   /// This rate determines how fast the device react when an under or over limit
   /// condition occurs.
   ///
   /// \param measurementRate The new circuit breaker measurement rate.
   /// \sa GetMeasurementRate
   UeiDaqAPI void SetMeasurementRate(double measurementRate);

   /// \brief Get the auto retry setting. 
   ///
   /// The auto retry setting specifies whether the device should attempt
   /// to close the circuit after it was opened because of an over or
   /// under limit condition.
   /// If it is set to true the device will try to close the circuit at a rate
   /// set by the autoRetryRate setting.
   ///
   /// \return true if autoRetry is on, false otherwise.
   /// \sa SetAutoRetry
   UeiDaqAPI bool GetAutoRetry(void);

   /// \brief Set the auto retry setting. 
   ///
   /// The auto retry setting specifies whether the device should attempt
   /// to close the circuit after it was opened because of an over or
   /// under limit condition.
   /// If it is set to true the device will try to close the circuit at a rate
   /// set by the autoRetryRate setting.
   ///
   /// \param autoRetry true to turn auto-retry on, false to turn it off.
   /// \sa GetAutoRetry
   UeiDaqAPI void SetAutoRetry(bool autoRetry);

   /// \brief Get the auto retry rate. 
   ///
   /// Specifies how often the device will attempt to close a circuit that
   /// was opened because of an over or under limit condition.
   ///
   /// \return The number of retries per second.
   /// \sa SetAutoRetryRate
   UeiDaqAPI double GetAutoRetryRate(void);

   /// \brief Set the auto retry rate. 
   ///
   /// Specifies how often the device will attempt to close a circuit that
   /// was opened because of an over or under limit condition.
   ///
   /// \param autoRetryRate The new number of retries per second.
   /// \sa GetAutoRetryRate
   UeiDaqAPI void SetAutoRetryRate(double autoRetryRate);

   /// \brief Get the over/under count. 
   ///
   /// Specifies number of consecutive over/under limit diagnostic readings that must 
   /// occur in order to trip breaker. 
   ///
   /// \return The maximum number of over/under readings.
   /// \sa SetOverUnderCount
   UeiDaqAPI uInt32 GetOverUnderCount(void);

   /// \brief Set the over/under count. 
   ///
   /// Specifies number of consecutive over/under limit diagnostic readings that must 
   /// occur in order to trip breaker. 
   ///
   /// \param overUnderCount The new maximum number of over/under readings.
   /// \sa GetOverUnderCount
   UeiDaqAPI void SetOverUnderCount(uInt32 overUnderCount);


private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAOProtectedChannelImpl> m_pImpl;
};

/// \brief Manages settings for each protected analog output channel
///
/// Manages settings for each analog output channel protected by a circuit breaker.
class CUeiAOProtectedCurrentChannel : public CUeiAOProtectedChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiAOProtectedCurrentChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiAOProtectedCurrentChannel();

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiAOProtectedCurrentChannelImpl> m_pImpl;
};

/// \brief Manages settings for each thermocouple input channel
///
/// Manages settings for each thermocouple input channel
class CUeiSimulatedTCChannel : public CUeiAOChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiSimulatedTCChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSimulatedTCChannel();

   /// \brief Get the thermocouple type
   ///
   /// Get the type of the thermocouple simulated by the channel.
   ///
   /// \return the thermocouple type.
   /// \sa SetThermocoupleType  
   UeiDaqAPI tUeiThermocoupleType GetThermocoupleType();

   /// \brief Set the thermocouple type
   ///
   /// Set the type of the thermocouple simulated by the channel.
   ///
   /// \param tcType the thermocouple type.
   /// \sa GetThermocoupleType  
   UeiDaqAPI void SetThermocoupleType(tUeiThermocoupleType tcType);

   /// \brief Get the temperature scale
   ///
   /// Get the temperature scale used to convert the temperature to output voltage.
   ///
   /// \return the temperature scale.
   /// \sa SetTemperatureScale  
   UeiDaqAPI tUeiTemperatureScale GetTemperatureScale();

   /// \brief Set the temperature scale
   ///
   /// Set the temperature scale used to convert the temperature to output voltage.
   ///
   /// \param tempScale the temperature scale.
   /// \sa GetTemperatureScale  
   UeiDaqAPI void SetTemperatureScale(tUeiTemperatureScale tempScale);

   /// \brief Get the cold junction compensation state 
   ///
   /// Determines whether CJC is enabled
   ///
   /// \return the cold junction compensation state.
   UeiDaqAPI bool IsCJCEnabled();

   /// \brief Enable or disable the cold junction compensation 
   ///
   /// Enable or disable the cold junction compensation.
   ///
   /// \param enableCJC true to enable the cold junction compensation, false otherwise.
   UeiDaqAPI void EnableCJC(bool enableCJC);

   /// \brief Get the cold junction compensation constant 
   ///
   /// Get the cold junction compensation temperature constant. This setting
   /// is only used when the CJC type is set to UeiCJCTypeConstant. The unit
   /// is the same as the configured temperature scale.
   ///
   /// \return the cold junction compensation constant.
   /// \sa SetCJCConstant  
   UeiDaqAPI UeiDaq::f64 GetCJCConstant();

   /// \brief Set the cold junction compensation constant
   ///
   /// Set the cold junction compensation temperature constant. This setting
   /// is only used when the CJC type is set to UeiCJCTypeConstant. The unit
   /// is the same as the configured temperature scale.
   ///
   /// \param cjcConstant the cold junction compensation constant.
   /// \sa GetCJCConstant  
   UeiDaqAPI void SetCJCConstant(UeiDaq::f64 cjcConstant);

   /// \cond DO_NOT_DOCUMENT
   CUeiSimulatedTCChannelImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond 

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSimulatedTCChannelImpl> m_pImpl;
};


/// \brief Manages settings for each Variable Reluctance channel
///
/// Manages settings for VR channels uses to read data from a VR sensor.
/// A VR input device converts the VR sensor analog signal to
/// a digital signal that can be processed by a counter/timer
class CUeiVRChannel : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiVRChannel();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiVRChannel();

   /// \brief Get the current VR channel input mode. 
   ///
   /// The VR-608 can use four different modes to measure velocity, position or direction 
   /// The counting mode can be set to:
   /// * Decoder: Even and Odd channels are used in pair to determine direction and position
   /// * Timed: Count number of teeth detected during a timed interval
   /// * N pulses: Measure the time taken to detect N teeth (Number of teeth needs to be set separately)
   /// * Z pulse: Measure the number of teeth and the time elapsed between two Z pulses (The Z tooth is usually a gap or a double tooth on the encoder wheel)
   ///
   /// In decoder mode the settings for the even channel are applied to both even and odd channels.
   ///
   /// \return the current VR mode
   UeiDaqAPI tUeiVRMode GetMode();

   /// \brief Set the VR channel input mode.
   ///
   /// The VR-608 can use four different modes to measure velocity, position or direction 
   /// The counting mode can be set to:
   /// * Decoder: Even and Odd channels are used in pair to determine direction and position
   /// * Timed: Count number of teeth detected during a timed interval
   /// * N pulses: Measure the time taken to detect N teeth (Number of teeth needs to be set separately)
   /// * Z pulse: Measure the number of teeth and the time elapsed between two Z pulses (The Z tooth is usually a gap or a double tooth on the encoder wheel) 
   ///
   /// In decoder mode the settings for the even channel are applied to both even and odd channels.
   ///
   /// \param mode the new VR mode
   UeiDaqAPI void SetMode(tUeiVRMode mode);

   /// \brief Get the current zero-crossing mode
   ///
   /// Zero crossing finds the point in time where the VR sensor output voltage goes from positive
   /// to negative voltage. This point is when the center of the tooth is lining up with the center
   /// of the VR sensor.
   ///
   /// \return the current Zero Crossing mode
   UeiDaqAPI tUeiVRZCMode GetZCMode();

   /// \brief Set the zero-crossing mode
   ///
   /// Zero crossing finds the point in time where the VR sensor output voltage goes from positive
   /// to negative voltage. This point is when the center of the tooth is lining up with the center
   /// of the VR sensor.
   ///
   /// \param mode the new zero-crossing mode
   UeiDaqAPI void SetZCMode(tUeiVRZCMode mode);

   /// \brief Get the current adaptive peak threshold mode
   ///
   /// APT finds the point in time where the VR sensor output voltage falls below a certain
   /// threshold. This point marks the beginning of the gap between two teeth.
   ///
   /// \return the current APT mode
   UeiDaqAPI tUeiVRAPTMode GetAPTMode();

   /// \brief Set the adaptive peak threshold mode
   ///
   /// APT finds the point in time where the VR sensor output voltage falls below a certain
   /// threshold. This point marks the beginning of the gap between two teeth.
   ///
   /// \param mode the new APT mode
   UeiDaqAPI void SetAPTMode(tUeiVRAPTMode mode);

   /// \brief Get the ADC measurement rate 
   ///
   /// Get the rate at which the VR sensor signal is measured.
   ///
   /// \return The current ADC rate.
   UeiDaqAPI double GetADCRate(void);

   /// \brief Set the ADC rate 
   ///
   /// Set the rate at which the VR sensor is measured.
   ///
   /// \param rate The new ADC rate.
   UeiDaqAPI void SetADCRate(double rate);

   /// \brief Get the ADC moving average 
   ///
   /// Get the size of the moving average window applied to the VR sensor signal
   /// while it is measured.
   ///
   /// \return The current ADC moving average.
   UeiDaqAPI int GetADCMovingAverage(void);

   /// \brief Set the ADC moving average 
   ///
   /// Set the size of the moving average window applied to the VR sensor signal
   /// while it is measured.
   ///
   /// \param mvAvrg The new ADC moving average.
   UeiDaqAPI void SetADCMovingAverage(int mvAvrg);

   /// \brief Get the APT threshold divider 
   ///
   /// The APT threshold divider is used when APT mode is set to "Logic".
   /// It specifies that the AP threshold will be set at a fraction of the peak input voltage
   /// This is a value between 1 and 15:
   /// 1=1/2, 2=1/4, 3=1/8 etc...
   ///
   /// \return The current APT threshold divider.
   UeiDaqAPI int GetAPTThresholdDivider(void);

   /// \brief Set the APT threshold divider 
   ///
   /// The APT threshold divider is used when APT mode is set to "Logic"
   /// It specifies that the AP threshold will be set at a fraction of the peak input voltage
   /// This is a value between 1 and 15:
   /// 1=1/2, 2=1/4, 3=1/8 etc...
   ///
   /// \param divider The new APT threshold divider.
   UeiDaqAPI void SetAPTThresholdDivider(int divider);

   /// \brief Get the APT threshold 
   ///
   /// The APT threshold is used when APT mode is set to "Fixed"
   ///
   /// \return The current APT threshold.
   UeiDaqAPI double GetAPTThreshold(void);

   /// \brief Set the APT threshold 
   ///
   /// The APT threshold is used when APT mode is set to "Fixed"
   ///
   /// \param threshold The new APT threshold.
   UeiDaqAPI void SetAPTThreshold(double threshold);

   /// \brief Get the ZC level 
   ///
   /// The ZC level is used when ZC mode is set to "Fixed"
   ///
   /// \return The current ZC level.
   UeiDaqAPI double GetZCLevel(void);

   /// \brief Set the ZC level 
   ///
   /// The ZC level is used when ZC mode is set to "Fixed"
   ///
   /// \param level The new ZC level.
   UeiDaqAPI void SetZCLevel(double level);

   /// \brief Get the number of teeth on the encoder wheel 
   ///
   /// The number of teeth on the encoder wheel
   ///
   /// \return The current number of teeth.
   UeiDaqAPI int GetNumberOfTeeth(void);

   /// \brief Set the number of teeth on the encoder wheel 
   ///
   /// The number of teeth on the encoder wheel
   ///
   /// \param numTeeth The new number of teeth.
   UeiDaqAPI void SetNumberOfTeeth(int numTeeth);

   /// \brief Get the Z tooth size 
   ///
   /// A Z Tooth is usually materialized by a one or more missing teeth or one or more fused teeth.
   /// This parameter specified the number of fused or missing teeth.
   ///
   /// \return The current number Z tooth size.
   UeiDaqAPI int GetZToothSize(void);

   /// \brief Set the Z tooth size 
   ///
   /// A Z Tooth is usually materialized by a one or more missing teeth or one or more fused teeth.
   /// This parameter specified the number of fused or missing teeth.
   ///
   /// \param size The new Z tooth size.
   UeiDaqAPI void SetZToothSize(int size);

   /// \brief Get the optional FIFO mode
   ///
   /// When enabled, FIFO data can be used to calculate a map of the inter-tooth delays 
   /// around the encoder wheel. this is useful to calculate acceleration
   ///
   /// \return The FIFO data status.
   UeiDaqAPI tUeiVRFIFOMode GetFIFOMode(void);

   /// \brief Set the optional FIFO mode
   ///
   /// When enabled, FIFO data can be used to calculate a map of the inter-tooth delays 
   /// around the encoder wheel. this is useful to calculate acceleration
   ///
   /// \param fifoMode The new FIFO mode.
   UeiDaqAPI void SetFIFOMode(tUeiVRFIFOMode fifoMode);

   /// \brief Get the timed mode measurement rate 
   ///
   /// Get the rate at which the VR sensor signal is measured.
   ///
   /// \return The current timed mode rate.
   UeiDaqAPI double GetTimedModeRate(void);

   /// \brief Set the timed mode measurement rate 
   ///
   /// Set the rate at which the VR sensor is measured.
   ///
   /// \param rate The new timed mode rate.
   UeiDaqAPI void SetTimedModeRate(double rate);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiVRChannelImpl> m_pImpl;
};

/// \brief Manage 1PPS synchronization settings
///
/// This objects stores 1PPS synchronization settings
/// The 1PPS synchronization uses an ADPLL and an event module to produce a clock at an arbitrary rate
/// Multiple racks can easily be synchronized when they use the same 1PPS synchronization clock
/// The ADPLL+event module on each rack will produce synchronized scan clocks
///
/// The source of the 1PPS sync clock can be internal, external or generated from NTP
/// The 1PPS clock is routed via one of the four internal sync lines to the ADPLL (adaptive digital PLL)
/// The ADPLL locks on the 1PPS and outputs its own 1PPS that is an average of the original 1PPS clock
/// The ADPLL can maintain its 1PPS output even if the original 1PPS clock gets disconnected
/// The ADPLL 1PPS output is routed via one of the four sync lines to the event module
/// The ADPLL 1PPS output can also be routed to the sync connector for sharing with other racks/cubes
/// The event module produces a user selectable number of pulses upon every 1PPS pulse coming from the ADPLL.
/// The event module clock output is routed to the Input layers via one of the remaining sync lines 
class CUeiSync1PPSPort : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiSync1PPSPort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSync1PPSPort();

   /// \brief Get the current 1PPS sync mode
   ///
   /// Get the current 1PPS sync mode
   /// Clock uses a 1PPS signal produced internally or received from an external source
   /// NTP derives the 1PPS from an NTP server
   /// \return the current 1PPS mode
   UeiDaqAPI tUeiSync1PPSMode Get1PPSMode();

   /// \brief Set the 1PPS sync mode
   ///
   /// Set the 1PPS sync mode
   /// Clock uses a 1PPS signal produced internally or received from an external source
   /// NTP derives the 1PPS from an NTP server
   /// \param mode the new 1PPS mode
   UeiDaqAPI void Set1PPSMode(tUeiSync1PPSMode mode);

   /// \brief Get the current 1PPS clock source
   ///
   /// Get the source of the 1PPS clock in SyncClock mode:
   /// Internal when 1PPS is generated internally
   /// Input0 when external 1PPS is connected to input 0 of sync connector (trigger input)
   /// Input1 when external 1PPS is connected to input 1 of sync connector (clock input)
   /// \return the current source of the 1PPS
   UeiDaqAPI tUeiSync1PPSSource Get1PPSSource();

   /// \brief Set the 1PPS clock source
   ///
   /// Set the source of the 1PPS clock in SyncClock mode:
   /// Internal when 1PPS is generated internally
   /// Input0 when external 1PPS is connected to input 0 of sync connector (trigger input)
   /// Input1 when external 1PPS is connected to input 1 of sync connector (clock input)
   /// \param source the new 1PPS source
   UeiDaqAPI void Set1PPSSource(tUeiSync1PPSSource source);

   /// \brief Get the current 1PPS output
   ///
   /// When module is a master (1PPS clock source is internal)
   /// Get the pin used to output the 1PPS sync clock
   /// Output0 when 1PPS is emitted out of output 0 of sync connector (trigger output)
   /// Output1 when 1PPS is emitted out of output 1 of sync connector (clock output)
   /// \return the current 1PPS output
   UeiDaqAPI tUeiSync1PPSOutput Get1PPSOutput();

   /// \brief Set the 1PPS output
   ///
   /// When module is a master (1PPS clock source is internal)
   /// Set the pin used to output the 1PPS sync clock
   /// Output0 when 1PPS is emitted out of output 0 of sync connector (trigger output)
   /// Output1 when 1PPS is emitted out of output 1 of sync connector (clock output)
   /// \param output the new 1PPS output
   UeiDaqAPI void Set1PPSOutput(tUeiSync1PPSOutput output);

   /// \brief Get the sync line connecting the 1PPS clock to the ADPLL
   /// 
   /// Get the internal sync line connecting the internal or external 1PPS clock to the ADPLL
   /// \return the current sync line connecting 1PPS to ADPLL
   UeiDaqAPI tUeiSyncLine Get1PPSToADPLLSyncLine();

   /// \brief Set the sync line connecting the 1PPS clock to the ADPLL
   /// 
   /// Set the internal sync line connecting the internal or external 1PPS clock to the ADPLL
   /// \param line the new sync line used to connect 1PPS to ADPLL
   UeiDaqAPI void Set1PPSToADPLLSyncLine(tUeiSyncLine line);

   /// \brief Get the number of pulses per second 
   ///
   /// Get the number of pulses per second used by the synchronization clock signal
   /// Default is 1
   /// \return the number of pulses per second
   UeiDaqAPI int GetNumPPS();

   /// \brief Set the number of pulses per second 
   ///
   /// Set the number of pulses per second used by the synchronization clock signal
   /// Default is 1
   /// \param pps the new number of pulses per second 
   UeiDaqAPI void SetNumPPS(int pps);

   /// \brief Get the 1PPS accuracy
   ///
   /// Get the required accuracy in microsecs of the 1PPS clock signal.
   /// Clocks that are out of range are ignored
   /// \return the 1PPS minimal accuracy
   UeiDaqAPI int Get1PPSAccuracy();

   /// \brief Set the 1PPS accuracy
   ///
   /// Set the expected accuracy in microsecs of the 1PPS clock signal.
   /// Clocks that are out of range are ignored
   /// \param accuracy the new 1PPS minimal accuracy
   UeiDaqAPI void Set1PPSAccuracy(int accuracy);

   /// \brief Get the sync line connected to the ADPLL output
   /// 
   /// Get the internal sync line connected to the ADPLL output 
   /// \return the sync line used to connect the ADPLL output
   UeiDaqAPI tUeiSyncLine GetADPLLOutputSyncLine();

   /// \brief Set the sync line connected to the ADPLL output
   /// 
   /// Set the internal sync line connected to the ADPLL output 
   /// \param line the new sync line used to connect the ADPLL output
   UeiDaqAPI void SetADPLLOutputSyncLine(tUeiSyncLine line);

   /// \brief Get the sync line connecting the event module output to the I/O layers
   /// 
   /// Get the internal sync line connecting the event module output to the I/O layers
   /// The event module produces the clock used by the I/O layers to pace data acquisition
   /// or generation
   /// \return the sync line used to connect the event output module to I/O layers
   UeiDaqAPI tUeiSyncLine GetEMOutputSyncLine();

   /// \brief Set the sync line connecting the event module output to the I/O layers
   /// 
   /// Set the internal sync line connecting the event module output to the I/O layers
   /// The event module produces the clock used by the I/O layers to pace data acquisition
   /// or generation
   /// \param line the new sync line used to connect the event output module to I/O layers
   UeiDaqAPI void SetEMOutputSyncLine(tUeiSyncLine line);

   /// \brief Get the event module output clock rate
   ///
   /// Get the rate (Hz) of the clock produced by the event module
   /// \return the current event module output clock rate
   UeiDaqAPI double GetEMOutputRate();

   /// \brief Set the event module output clock rate
   ///
   /// Set the rate (Hz) of the clock produced by the event module
   /// \param rate the new event module output clock rate
   UeiDaqAPI void SetEMOutputRate(double rate);

   /// \brief Get the sync line connecting the 1PPS trigger to the I/O layers
   /// 
   /// The ADPLL is capable of emitting a trigger signal simultaneously with the next 1PPS pulse
   /// Get the sync line connecting the 1PPS trigger to the I/O layers
   /// \return the sync line used to connect the 1PPS trigger to I/O layers
   UeiDaqAPI tUeiSyncLine GetTriggerOutputSyncLine();

   /// \brief Set the sync line connecting the 1PPS trigger to the I/O layers
   /// 
   /// The ADPLL is capable of emitting a trigger signal simultaneously with the next 1PPS pulse
   /// Get the sync line connecting the 1PPS trigger to the I/O layers
   /// \param line the new sync line used to connect the 1PPS trigger to I/O layers
   UeiDaqAPI void SetTriggerOutputSyncLine(tUeiSyncLine line);

   /// \brief Get the PTP ethernet port
   /// 
   /// Get the PTP ethernet port used to connect with master clock
   /// \return the current PTP ethernet port
   UeiDaqAPI int GetPTPEthernetPort();

   /// \brief Set the PTP ethernet port
   /// 
   /// Set the PTP ethernet port used to connect with master clock
   /// \param ethernetPort the new PTP ethernet port
   UeiDaqAPI void SetPTPEthernetPort(int ethernetPort);

   /// \brief Get the PTP subdomain
   /// 
   /// Get the PTP subdomain which is a logical group of PTP clocks
   /// \return the current PTP domain
   UeiDaqAPI uInt8 GetPTPSubdomain();

   /// \brief Set the PTP subdomain
   /// 
   /// Set the PTP subdomain which is a logical group of PTP clocks
   /// \param subDomain the new PTP domain
   UeiDaqAPI void SetPTPSubdomain(uInt8 subDomain);

   /// \brief Get the first order PTP priority
   /// 
   /// Get the first order PTP priority used as a factor for selecting master clock
   /// or becoming master if none with higher priority is found
   /// \return the current first order PTP priority
   UeiDaqAPI uInt8 GetPTPPriority1();

   /// \brief Set the first order PTP priority
   /// 
   /// Set the first order  PTP priority used as a factor for selecting master clock
   /// or becoming master if none with higher priority is found
   /// \param priority1 the new first order PTP priority
   UeiDaqAPI void SetPTPPriority1(uInt8 priority1);

   /// \brief Get the second order PTP priority
   /// 
   /// Get the second order PTP priority used as a factor for selecting master clock
   /// or becoming master if none with higher priority is found
   /// \return the current second order PTP priority
   UeiDaqAPI uInt8 GetPTPPriority2();

   /// \brief Set the second order PTP priority
   /// 
   /// Set the second order PTP priority used as a factor for selecting master clock
   /// or becoming master if none with higher priority is found
   /// \param priority2 the new second order PTP priority
   UeiDaqAPI void SetPTPPriority2(uInt8 priority2);

   /// \brief Get the sync interval
   /// 
   /// Get the sync interval which is how often the master sends sync packets 
   /// Value is specifed as the log of actual sync interval.
   /// \return the current Sync interval
   UeiDaqAPI Int8 GetPTPLogSyncInterval();

   /// \brief Set the sync interval
   /// 
   /// Set the sync interval which is how often the master sends sync packets 
   /// Value is specifed as the log of actual sync interval.
   /// \param logSyncInterval the new Sync interval
   UeiDaqAPI void SetPTPLogSyncInterval(Int8 logSyncInterval);

   /// \brief Get the minimum delay request interval
   /// 
   /// Get the minimum interval allowed between PTP delay request packets 
   /// Value is specifed as the log of actual interval.
   /// \return the current minimum delay request interval
   UeiDaqAPI Int8 GetPTPLogMinDelayRequestInterval();

   /// \brief Set the minimum delay request interval
   /// 
   /// Set the minimum interval allowed between PTP delay request packets 
   /// Value is specifed as the log of actual interval.
   /// \param logMinDelayRequestInterval the new minimum delay request interval
   UeiDaqAPI void SetPTPLogMinDelayRequestInterval(Int8 logMinDelayRequestInterval);

   /// \brief Get the interval between PTP announce messages
   /// 
   /// Get the the interval between PTP announce messages 
   /// Value is specifed as the log of actual interval.
   /// \return the current interval between PTP announce messages
   UeiDaqAPI Int8 GetPTPLogAnnounceInterval();

   /// \brief Set the interval between PTP announce messages
   /// 
   /// Set the interval between PTP announce messages 
   /// Value is specifed as the log of actual interval.
   /// \param logAnnouceInterval the new interval between PTP announce messages
   UeiDaqAPI void SetPTPLogAnnounceInterval(Int8 logAnnouceInterval);

   /// \brief Get the number of PTP intervals before a timeout occurs
   /// 
   /// Get the number of PTP intervals before a timeout occurs 
   /// \return the current number of PTP intervals before a timeout occurs
   UeiDaqAPI uInt8 GetPTPAnnounceTimeout();

   /// \brief Set the number of PTP intervals before a timeout occurs
   /// 
   /// Set the number of PTP intervals before a timeout occurs 
   /// \param announceTimeout the new number of PTP intervals before a timeout occurs
   UeiDaqAPI void SetPTPAnnounceTimeout(uInt8 announceTimeout);

   /// \brief Get the UTC offset
   /// 
   /// Get the offset between UTC and TAI in seconds
   /// \return the current UTC offset
   UeiDaqAPI uInt8 GetPTPUTCOffset();

   /// \brief Set the UTC offset
   /// 
   /// Set the offset between UTC and TAI in seconds
   /// \param utcOffset the new UTC offset
   UeiDaqAPI void SetPTPUTCOffset(uInt8 utcOffset);

   /// \brief Get the debounce time for sync input
   /// 
   /// Get the amount of time during which the sync input doesn't register any incoming edge
   /// \return the current debounce time in nanoseconds
   UeiDaqAPI uInt32 GetSyncInputDebounceTime();

   /// \brief Set the debounce time for sync input
   /// 
   /// Set the amount of time during chich the sync input doesn't register any incoming edge
   /// \param debounceTimeNs New debounce time in nanoseconds
   UeiDaqAPI void SetSyncInputDebounceTime(uInt32 debounceTimeNs);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSync1PPSPortImpl> m_pImpl;
};


/// \brief Manage CSDB port settings
///
/// This objects stores CSDB port settings
class CUeiCSDBPort : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiCSDBPort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiCSDBPort();

   /// \brief Get port speed in bits per second
   ///
   /// Get the current port speed in bits per second (12500 or 50000)
   /// \return the current port speed
   UeiDaqAPI int GetBps();

   /// \brief Set port speed in bits per second
   ///
   /// Set the port speed in bits per second (12500 or 50000)
   /// \param bps the new port speed
   UeiDaqAPI void SetBps(int bps);

   /// \brief Get port parity 
   ///
   /// Get the current port parity (0=even >0=odd)
   /// \return the current port parity
   UeiDaqAPI int GetParity();                     
   
   /// \brief Set port parity 
   ///
   /// Set the port parity (0=even >0=odd)
   /// \param parity the new port parity
   UeiDaqAPI void SetParity(int parity);    

   /// \brief Get message block size  
   ///
   /// Get the current message block size in bytes (including address and status bytes)
   /// \return the current message block size
   UeiDaqAPI int GetBlockSize();
   
   /// \brief Set message block size  
   ///
   /// Set the message block size in bytes (including address and status bytes)
   /// \param blockSize the new message block size
   UeiDaqAPI void SetBlockSize(int blockSize);

   /// \brief Get the number of message blocks  
   ///
   /// Get the current number of message blocks within a frame
   /// \return the current number of message blocks
   UeiDaqAPI int GetNumMessages();             
   
   /// \brief Get the number of message blocks  
   ///
   /// Get the current number of message blocks within a frame
   /// \param numMessages the new number of message blocks
   UeiDaqAPI void SetNumMessages(int numMessages);

   /// \brief Get the inter-byte delay   
   ///
   /// Get the current inter-byte delay in usecs
   /// \return the current inter-byte delay
   UeiDaqAPI int GetInterByteDelayUs();           
   
   /// \brief Set the inter-byte delay   
   ///
   /// Set the new inter-byte delay in usecs
   /// \param interByteDelay the new inter-byte delay
   UeiDaqAPI void SetInterByteDelayUs(int interByteDelay);

   /// \brief Get the inter-block delay   
   ///
   /// Get the current inter-block delay in usecs
   /// \return the current inter-block delay
   UeiDaqAPI int GetInterBlockDelayUs();          

   /// \brief Set the inter-block delay   
   ///
   /// Set the new inter-block delay in usecs
   /// \param interBlockDelay the new inter-block delay
   UeiDaqAPI void SetInterBlockDelayUs(int interBlockDelay);

   /// \brief Get the frame period   
   ///
   /// Get the frame period in usecs
   /// \return the current frame period
   UeiDaqAPI int GetFramePeriodUs(); 

   /// \brief Set the frame period   
   ///
   /// Set the frame period in usecs
   /// \param framePeriod the new frame period
   UeiDaqAPI void SetFramePeriodUs(int framePeriod);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiCSDBPortImpl> m_pImpl;
};


/// \brief Manage SSI master port settings
///
/// This objects stores SSI port settings
class CUeiSSIMasterPort : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiSSIMasterPort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSSIMasterPort();

   /// \brief Get port speed in bits per second
   ///
   /// Get the current port speed in bits per second (12500 or 50000)
   /// \return the current port speed
   UeiDaqAPI unsigned int GetBps();

   /// \brief Set port speed in bits per second
   ///
   /// Set the port speed in bits per second (12500 or 50000)
   /// \param bps the new port speed
   UeiDaqAPI void SetBps(unsigned int bps);

   /// \brief Get word size
   ///
   /// Get the current word size (3 to 32 bits)
   /// \return the current word size
   UeiDaqAPI unsigned int GetWordSize();

   /// \brief Set word size
   ///
   /// Set the word size (3 to 32 bits)
   /// \param wordSize the new word size
   UeiDaqAPI void SetWordSize(unsigned int wordSize);

   /// \brief Get the termination resistor state
   ///
   /// Determines whether the termination resistor is enabled
   ///
   /// \return The termination resistor state.
   /// \sa EnableTerminationResistor  
   UeiDaqAPI bool IsTerminationResistorEnabled();

   /// \brief Enable or disable termination resistor
   ///
   /// Enable or disable the termination resistor.
   ///
   /// \param enabled The new termination resistor state
   /// \sa IsTerminationResistorEnabled  
   UeiDaqAPI void EnableTerminationResistor(bool enabled);

   /// \brief Get the master clock state
   ///
   /// Determines whether the master is emitting the clock signal
   ///
   /// \return The master clock state.
   /// \sa EnableClock  
   UeiDaqAPI bool IsClockEnabled();

   /// \brief Enable or disable master clock
   ///
   /// Enable or disable the master clock output.
   ///
   /// \param enabled The new master clock state
   /// \sa IsClockEnabled  
   UeiDaqAPI void EnableClock(bool enabled);

   /// \brief Get the minimum data pulse width in microseconds
   ///
   /// Get the minimum pulse width in us the master recognizes at its data input. 
   /// Any pulse whose width is smaller will be ignored.
   /// \return the minimum pulse width
   /// \sa SetMinimumDataPulseWidth
   UeiDaqAPI double GetMinimumDataPulseWidth();

   /// \brief Set the minimum data pulse width in microseconds
   ///
   /// Set the minimum pulse width in us the master recognizes at its data input. 
   /// Any pulse whose width is smaller will be ignored.
   /// Set the minimum pulse width to 0 to disable digital filtering.
   /// \param minWidth the minimum data pulse width
   /// \sa GetMinimumDataPulseWidth
   UeiDaqAPI void SetMinimumDataPulseWidth(double minWidth);

   /// \brief Get the pause time in microseconds
   ///
   /// Get the time delay between two consecutive clock sequences from the master.
   /// Pause time is typically named Tp
   ///
   /// \return the pause time
   /// \sa SetPauseTime
   UeiDaqAPI double GetPauseTime();

   /// \brief Set the pause time in microseconds
   ///
   /// Set the time delay between two consecutive clock sequences from the master. 
   /// Pause time is typically named Tp
   ///
   /// \param pauseTime the new pause time
   /// \sa GetPauseTime
   UeiDaqAPI void SetPauseTime(double pauseTime);

   /// \brief Get the transfer timeout in microseconds
   ///
   /// Get the minimum time required by the slave to realise that the data transmission is complete
   /// Transfer timeout is typically named Tm
   ///
   /// \return the transfer timeout
   /// \sa SetTransferTimeout
   UeiDaqAPI double GetTransferTimeout();

   /// \brief Set the transfer timeout in microseconds
   ///
   /// Set the minimum time required by the slave to realise that the data transmission is complete
   /// Transfer timeout is typically named Tm 
   ///
   /// \param transferTimeout the new transfer timeout
   /// \sa GetTransferTimeout
   UeiDaqAPI void SetTransferTimeout(double transferTimeout);

   /// \brief Get the bit update time in microsconds
   ///
   /// Get the maximum duration for a low to high transition of high to low transition
   /// Bit update time is typically named Tv
   ///
   /// \return the bit update time
   /// \sa SetBitupdateTime
   UeiDaqAPI double GetBitUpdateTime();

   /// \brief Set the repetition time in microseconds
   ///
   /// Set the maximum duration for a low to high transition of high to low transition
   /// Bit update time is typically named Tv
   ///
   /// \param bitUpdateTime the new bit update time
   /// \sa GetBitUpdateTime
   UeiDaqAPI void SetBitUpdateTime(double bitUpdateTime);

   /// \brief Get the timestamping state
   ///
   /// Determines whether each received frame is timestamped.
   ///
   /// \return The timestamping state.
   /// \sa EnableTimestamping  
   UeiDaqAPI bool IsTimestampingEnabled(void);

   /// \brief Set the timestamping state
   ///
   /// Specifies whether each received frame is timestamped.
   ///
   /// \param enableTimestamping true to turn timestamping on, false otherwise
   /// \sa IsTimestampingEnabled  
   UeiDaqAPI void EnableTimestamping(bool enableTimestamping);

   /// \brief Get the timestamp resolution
   ///
   /// Get the timestamp resolution in seconds.
   ///
   /// \return the timestamp resolution.
   /// \sa SetTimestampResolution  
   UeiDaqAPI f64 GetTimestampResolution();

   /// \brief Set the timestamp resolution
   ///
   /// Set the timestamp resolution in seconds.
   ///
   /// \param resolution the new resolution.
   /// \sa GetTimestampResolution  
   UeiDaqAPI void SetTimestampResolution(f64 resolution);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSSIMasterPortImpl> m_pImpl;
};

/// \brief Manage SSI slave port settings
///
/// This objects stores SSI port settings
class CUeiSSISlavePort : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiSSISlavePort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSSISlavePort();

   /// \brief Get port speed in bits per second
   ///
   /// Get the current port speed in bits per second (12500 or 50000)
   /// \return the current port speed
   UeiDaqAPI unsigned int GetBps();

   /// \brief Set port speed in bits per second
   ///
   /// Set the port speed in bits per second (12500 or 50000)
   /// \param bps the new port speed
   UeiDaqAPI void SetBps(unsigned int bps);

   /// \brief Get word size
   ///
   /// Get the current word size (3 to 32 bits)
   /// \return the current word size
   UeiDaqAPI unsigned int GetWordSize();

   /// \brief Set word size
   ///
   /// Set the word size (3 to 32 bits)
   /// \param wordSize the new word size
   UeiDaqAPI void SetWordSize(unsigned int wordSize);

   /// \brief Get the termination resistor state
   ///
   /// Determines whether the termination resistor is enabled
   ///
   /// \return The termination resistor state.
   /// \sa EnableTerminationResistor  
   UeiDaqAPI bool IsTerminationResistorEnabled();

   /// \brief Enable or disable termination resistor
   ///
   /// Enable or disable the termination resistor.
   ///
   /// \param enabled The new termination resistor state
   /// \sa IsTerminationResistorEnabled  
   UeiDaqAPI void EnableTerminationResistor(bool enabled);

   /// \brief Get the slave transmit state
   ///
   /// Determines whether the master will transmit data upon receiving the clock signal
   ///
   /// \return The slave transmit state.
   /// \sa EnableTransmit  
   UeiDaqAPI bool IsTransmitEnabled();

   /// \brief Enable or disable data transmission
   ///
   /// Enable or disable the data output.
   ///
   /// \param enabled The new master clock state
   /// \sa IsTransmitEnabled  
   UeiDaqAPI void EnableTransmit(bool enabled);

   /// \brief Get the minimum clock pulse width in microseconds
   ///
   /// Get the minimum pulse width in us the slave recognizes at its clock input. 
   /// Any pulse whose width is smaller will be ignored.
   /// \return the minimum pulse width
   /// \sa SetMinimumClockPulseWidth
   UeiDaqAPI double GetMinimumClockPulseWidth();

   /// \brief Set the minimum clock pulse width in microseconds
   ///
   /// Set the minimum pulse width in us the slave recognizes at its clock input. 
   /// Any pulse whose width is smaller will be ignored.
   /// Set the minimum pulse width to 0 to disable digital filtering.
   /// \param minWidth the minimum clock pulse width
   /// \sa GetMinimumClockPulseWidth
   UeiDaqAPI void SetMinimumClockPulseWidth(double minWidth);

   /// \brief Get the pause time in microseconds
   ///
   /// Get the time delay between two consecutive clock sequences from the master.
   /// Pause time is typically named Tp
   ///
   /// \return the pause time
   /// \sa SetPauseTime
   UeiDaqAPI double GetPauseTime();

   /// \brief Set the pause time in microseconds
   ///
   /// Set the time delay between two consecutive clock sequences from the master. 
   /// Pause time is typically named Tp
   ///
   /// \param pauseTime the new pause time
   /// \sa GetPauseTime
   UeiDaqAPI void SetPauseTime(double pauseTime);

   /// \brief Get the transfer timeout in microseconds
   ///
   /// Get the minimum time required by the slave to realise that the data transmission is complete
   /// Transfer timeout is typically named Tm
   ///
   /// \return the transfer timeout
   /// \sa SetTransferTimeout
   UeiDaqAPI double GetTransferTimeout();

   /// \brief Set the transfer timeout in microseconds
   ///
   /// Set the minimum time required by the slave to realise that the data transmission is complete
   /// Transfer timeout is typically named Tm 
   ///
   /// \param transferTimeout the new transfer timeout
   /// \sa GetTransferTimeout
   UeiDaqAPI void SetTransferTimeout(double transferTimeout);

   /// \brief Get the bit update time in microsconds
   ///
   /// Get the maximum duration for a low to high transition of high to low transition
   /// Bit update time is typically named Tv
   ///
   /// \return the bit update time
   /// \sa SetBitupdateTime
   UeiDaqAPI double GetBitUpdateTime();

   /// \brief Set the repetition time in microseconds
   ///
   /// Set the maximum duration for a low to high transition of high to low transition
   /// Bit update time is typically named Tv
   ///
   /// \param bitUpdateTime the new bit update time
   /// \sa GetBitUpdateTime
   UeiDaqAPI void SetBitUpdateTime(double bitUpdateTime);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSSISlavePortImpl> m_pImpl;
};


/// \brief Manage MUX port settings
///
/// This objects stores MUX port settings
class CUeiMuxPort : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiMuxPort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiMuxPort();

   /// \brief Get port break before make setting
   ///
   /// Get the current port break before make setting
   /// \return the current break before make
   UeiDaqAPI bool IsBreakBeforeMakeEnabled();

   /// \brief Set port break before make setting
   ///
   /// Set the port break before make setting
   /// \param enable true to enable, false otherwise
   UeiDaqAPI void EnableBreakBeforeMake(bool enable);

   /// \brief Get port synchronization input setting
   ///
   /// Get the current port synchronization input setting
   /// A MUX device can wait for a pulse on its synchronization input before
   /// configuring its relays
   /// \return the current synchronization input
   UeiDaqAPI bool IsSyncInputEnabled();

   /// \brief Set port synchronization input setting
   ///
   /// Set the port synchronization input setting
   /// A MUX device can wait for a pulse on its synchronization input before
   /// configuring its relays
   /// \param enable true to enable, false otherwise
   UeiDaqAPI void EnableSyncInput(bool enable);

   /// \brief Get port synchronization input edge/level setting
   ///
   /// Get the current port synchronization input edge/level setting
   /// The sync input can work in level or edge mode
   /// \return the current synchronization input
   UeiDaqAPI bool IsSyncInputEdgeModeEnabled();

   /// \brief Set port synchronization input edge/level setting
   ///
   /// Set the port synchronization input edge/level setting
   /// The sync input can work in level or edge mode
   /// \param enable true to enable, false otherwise
   UeiDaqAPI void EnableSyncInputEdgeMode(bool enable);

   /// \brief Get port synchronization input edge/level polarity
   ///
   /// Get the current port synchronization input edge/level polarity
   /// \return the current synchronization input polarity
   UeiDaqAPI tUeiDigitalEdge GetSyncInputEdgePolarity();

   /// \brief Set port synchronization input edge/level polarity
   ///
   /// Set the port synchronization input edge/level polarity
   /// \param polarity the new polarity
   UeiDaqAPI void SetSyncInputEdgePolarity(tUeiDigitalEdge polarity);

   /// \brief Get port synchronization output mode
   ///
   /// Get the current port synchronization output mode
   /// A MUX device can emit a pulse on its synchronization output when
   /// configuring its relays
   /// \return the current synchronization output mode
   UeiDaqAPI tUeiMuxSyncOutputMode GetSyncOutputMode();

   /// \brief Set port synchronization output mode
   ///
   /// Set the port synchronization output mode
   /// A MUX device can emit a pulse on its synchronization output when
   /// configuring its relays
   /// \param mode the new synchronization output mode
   UeiDaqAPI void SetSyncOutputMode(tUeiMuxSyncOutputMode mode);

   /// \brief Get port synchronization output pulse width
   ///
   /// Get the current port synchronization output pulse width in microseconds
   /// \return the current synchronization output pulse width
   UeiDaqAPI int GetSyncOutputPulseWidth();

   /// \brief Set port synchronization output pulse width
   ///
   /// Set the port synchronization output oulse width in microseconds
   /// \param width the new synchronization output pulse width
   UeiDaqAPI void SetSyncOutputPulseWidth(int width);

   /// \brief Get port on delay
   ///
   /// Get the current port on delay in microseconds
   /// \return the current on delay
   UeiDaqAPI int GetOnDelay();

   /// \brief Set port on delay
   ///
   /// Set the port on delay
   /// \param delay the new on delay
   UeiDaqAPI void SetOnDelay(int delay);

   /// \brief Get port off delay
   ///
   /// Get the current port off delay in microseconds
   /// \return the current off delay
   UeiDaqAPI int GetOffDelay();

   /// \brief Set port on delay
   ///
   /// Set the port off delay
   /// \param delay the new off delay
   UeiDaqAPI void SetOffDelay(int delay);
   
   /// \brief Set voltage of DC/DC during relay holding
   ///
   /// Set voltage of DC/DC during relay holding
   /// \param voltage the DC/DC voltage during relay holding
   UeiDaqAPI void SetHoldingVoltage(tUeiMuxVoltage voltage);

   /// \brief Get voltage of DC/DC during relay holding
   ///
   /// Get voltage of DC/DC during relay holding
   /// \return the current DC/DC voltage during relay holding
   UeiDaqAPI tUeiMuxVoltage GetHoldingVoltage();

   /// \brief Set voltage of DC/DC during relay switching
   ///
   /// Set voltage of DC/DC during relay switching
   /// \param voltage the DC/DC voltage during relay switching
   UeiDaqAPI void SetSwitchingVoltage(tUeiMuxVoltage voltage);

   /// \brief Get voltage of DC/DC during relay switching
   ///
   /// Get voltage of DC/DC during relay switching
   /// \return the current DC/DC voltage during relay switching
   UeiDaqAPI tUeiMuxVoltage GetSwitchingVoltage();

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiMuxPortImpl> m_pImpl;
};


/// \brief Manage I2C master port settings
///
/// This objects stores I2C master port settings
class CUeiI2CMasterPort : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiI2CMasterPort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiI2CMasterPort();

   /// \brief Get the I2C bus bit rate
   ///
   /// Get the number of data bits transmitted per second.
   ///
   /// \return the I2C bus bit rate.
   UeiDaqAPI tUeiI2CPortSpeed GetSpeed();

   /// \brief Set the I2C bus bit rate
   ///
   /// Set the number of data bits transmitted per second.
   ///
   /// \param bitRate the new I2C bus bit rate.
   UeiDaqAPI void SetSpeed(tUeiI2CPortSpeed bitRate);

   /// \brief Get the I2C bus custom bit rate
   ///
   /// Get the number of data bits transmitted per second.
   ///
   /// \return the I2C bus custom bit rate.
   UeiDaqAPI float GetCustomSpeed();

   /// \brief Set the I2C bus custom bit rate
   ///
   /// Set the number of data bits transmitted per second.
   ///
   /// \param bitRate the new I2C bus custom bit rate.
   UeiDaqAPI void SetCustomSpeed(float bitRate);

   /// \brief Get the I2C bus TTL level
   ///
   /// Get the TTL level for data and clock signals.
   ///
   /// \return the TTL level.
   UeiDaqAPI tUeiI2CTTLLevel GetTTLLevel();

   /// \brief Set the I2C bus TTL level
   ///
   /// Set the TTL level for data and clock signals.
   ///
   /// \param ttlLevel the new TTL level.
   UeiDaqAPI void SetTTLLevel(tUeiI2CTTLLevel ttlLevel);

   /// \brief Query the secure shell feature
   ///
   /// Query status of secure shell feature.
   ///
   /// \return the secure shell status.
   UeiDaqAPI bool IsSecureShellEnabled();

   /// \brief Enable or Disable secure shell feature
   ///
   /// Enable or Disable secure shell.
   ///
   /// \param enabled the new secure shell state.
   UeiDaqAPI void EnableSecureShell(bool enabled);

   /// \brief Query the termination resistor feature
   ///
   /// Query the termination resistor feature.
   ///
   /// \return the current termination resistor status.
   UeiDaqAPI bool IsTerminationResistorEnabled();

   /// \brief Enable or Disable termination resistor
   ///
   /// Enable or Disable termination resistor.
   ///
   /// \param enabled the new termination resistor state.
   UeiDaqAPI void EnableTerminationResistor(bool enabled);

   /// \brief Get the loopback mode
   ///
   /// Get the loopback mode.
   ///
   /// \return the current loopback mode.
   UeiDaqAPI tUeiI2CLoopback GetLoopbackMode();

   /// \brief Get the loopback mode
   ///
   /// Get the loopback mode.
   ///
   /// \param mode the new loopback mode.
   UeiDaqAPI void SetLoopbackMode(tUeiI2CLoopback mode);

   /// \brief Get the delay in microseconds that the master will delay between bytes
   ///
   /// Get the delay in microseconds that the master will delay between sending bytes
   ///
   /// \return the current delay in microseconds
   UeiDaqAPI uInt16 GetByteToByteDelay();

   /// \brief Set the delay in microseconds that the master will delay between bytes
   ///
   /// Set the delay in microseconds that the master will delay between sending bytes.
   ///
   /// \param delayUs the new delay in microseconds
   UeiDaqAPI void SetByteToByteDelay(uInt16 delayUs);

   /// \brief Get the time in microseconds that the master will allow a slave to delay the clock
   ///
   /// Get the time in microseconds that the master will allow a slave to delay the clock
   ///
   /// \return the current time in microseconds
   UeiDaqAPI uInt16 GetMaxClockStretchingDelay();

   /// \brief Set the time in microseconds that the master will allow a slave to delay the clock
   ///
   /// Set the time in microseconds that the master will allow a slave to delay the clock
   ///
   /// \param delayUs the new time in microseconds
   UeiDaqAPI void SetMaxClockStretchingDelay(uInt16 delayUs);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiI2CMasterPortImpl> m_pImpl;
};


/// \brief Manage I2C slave port settings
///
/// This objects stores I2C slave port settings
class CUeiI2CSlavePort : public CUeiChannel
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiI2CSlavePort();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiI2CSlavePort();

   /// \brief Get the I2C bus TTL level
   ///
   /// Get the TTL level for data and clock signals.
   ///
   /// \return the TTL level.
   UeiDaqAPI tUeiI2CTTLLevel GetTTLLevel();

   /// \brief Set the I2C bus TTL level
   ///
   /// Set the TTL level for data and clock signals.
   ///
   /// \param ttlLevel the new TTL level.
   UeiDaqAPI void SetTTLLevel(tUeiI2CTTLLevel ttlLevel);

   /// \brief Get the slave address width
   ///
   /// Get the slave address width.
   ///
   /// \return the slave address width.
   UeiDaqAPI tUeiI2CSlaveAddressWidth GetSlaveAddressWidth();

   /// \brief Set the I2C slave address width
   ///
   /// Set the slave address width.
   ///
   /// \param width the new slave address width.
   UeiDaqAPI void SetSlaveAddressWidth(tUeiI2CSlaveAddressWidth width);

   /// \brief Get the slave address
   ///
   /// Get the slave address.
   ///
   /// \return the slave address.
   UeiDaqAPI int GetSlaveAddress();

   /// \brief Set the slave address
   ///
   /// Set the slave address.
   ///
   /// \param address the new slave address.
   UeiDaqAPI void SetSlaveAddress(int address);

   /// \brief Query the bus monitor feature
   ///
   /// Query the status of the bus monitor feature.
   ///
   /// \return the status of the bus monitor feature.
   UeiDaqAPI bool IsBusMonitorEnabled();

   /// \brief Enable or disable bus monitor
   ///
   /// Enable or disable bus monitor.
   ///
   /// \param enabled the new bus monitor state.
   UeiDaqAPI void EnableBusMonitor(bool enabled);
   
   /// \brief Query the bus monitor ACK feature
   ///
   /// Query the status of the bus monitor ACK feature.
   /// If enabled, bus monitor will generate an ACK on
   /// receiving data or address to allow simulating
   /// multiple devices on the bus.
   ///
   /// \return the status of the bus monitor ACK feature.
   UeiDaqAPI bool IsBusMonitorAckEnabled();

   /// \brief Enable or disable bus monitor ACK
   ///
   /// Enable or disable bus monitor ACK.
   /// If enabled, bus monitor will generate an ACK on
   /// receiving data or address to allow simulating
   /// multiple devices on the bus.
   ///
   /// \param enabled the new bus monitor ACK state.
   UeiDaqAPI void EnableBusMonitorAck(bool enabled);

   /// \brief Get slave transmit data mode
   ///
   /// Get slave transmit data mode
   ///
   /// \return the slave transmit data mode
   UeiDaqAPI tUeiI2CSlaveDataMode GetTransmitDataMode();

   /// \brief Set slave transmit data mode
   ///
   /// Set slave transmit data mode
   ///
   /// \param dataMode the new slave transmit data mode
   UeiDaqAPI void SetTransmitDataMode(tUeiI2CSlaveDataMode dataMode);

   /// \brief Get data transmitted when in Register mode or padding data when in FIFO mode
   ///
   /// Get data transmitted when in Register mode or padding data when in FIFO mode.
   ///
   /// \param byteIndex index of the byte to retrieve, 0-3
   /// \return data used in Register mode of padding data in FIFO mode.
   UeiDaqAPI uInt8 GetSlaveRegisterData(int byteIndex);

   /// \brief Set data transmitted when in Register mode or padding data when in FIFO mode
   ///
   /// Set data transmitted when in Register mode or padding data when in FIFO mode.
   ///
   /// \param byteIndex index of the byte to set, 0-3
   /// \param data the new byte data to use
   UeiDaqAPI void SetSlaveRegisterData(int byteIndex, uInt8 data);

   /// \brief Get the number of bytes used in slave data when in Register data mode
   ///
   /// Get the number of bytes used in slave data when in Register data mode.
   ///
   /// \return the number of bytes used in slave data when in Register data mode
   UeiDaqAPI int GetSlaveRegisterDataSize();

   /// \brief Set the number of bytes used in slave data when in Register data mode
   ///
   /// Set the number of bytes used in slave data when in Register data mode.
   ///
   /// \param size the new number of bytes used in slave data when in Register data mode
   UeiDaqAPI void SetSlaveRegisterDataSize(int size);

   /// \brief Get maximum number of words slave will receive per transmission
   ///
   /// Get maximum number of words slave will receive per transmission
   ///
   /// \return the maximum number of words slave will receive per transmission
   UeiDaqAPI int GetMaxWordsPerAck();

   /// \brief Set maximum number of words slave will receive per transmission
   ///
   /// Set maximum number of words slave will receive per transmission
   ///
   /// \param maxWords the new maximum number of words slave will receive per transmission
   UeiDaqAPI void SetMaxWordsPerAck(int maxWords);

   /// \brief Get the number of clocks the slave will delay an ACK
   ///
   /// Get the delay in 15ns clock increments that the slave will delay an ACK.
   /// The clock stretching delay must also be individually enabled for address, transmit,
   /// and receive cycles. Max clock stretching delay is ~62ms.
   ///
   /// \return the current delay in clocks
   UeiDaqAPI uInt16 GetClockStretchingDelay();

   /// \brief Get the number of clocks the slave will delay an ACK
   ///
   /// Get the delay in 15ns clock increments that the slave will delay an ACK.
   /// The clock stretching delay must also be individually enabled for address, transmit,
   /// and receive cycles. Max clock stretching delay is ~62ms.
   ///
   /// \param clocks the new delay in clocks
   UeiDaqAPI void SetClockStretchingDelay(uInt16 clocks);

   /// \brief Query the status of clock stretching during address cycle
   ///
   /// Query the status of clock stretching during address cycle.
   ///
   /// \return the status of clock stretching during address cycle.
   UeiDaqAPI bool IsAddressClockStretchingEnabled();

   /// \brief Enable clock stretching during address cycle
   ///
   /// Enable clock stretching during address cycle.
   ///
   /// \param enabled the new clock stretching during address cycle state
   UeiDaqAPI void EnableAddressClockStretching(bool enabled);

   /// \brief Query the status of clock stretching during transmit cycle
   ///
   /// Query the status of clock stretching during transmit cycle.
   ///
   /// \return the status of clock stretching during transmit cycle.
   UeiDaqAPI bool IsTransmitClockStretchingEnabled();

   /// \brief Enable clock stretching during transmit cycle
   ///
   /// Enable clock stretching during transmit cycle.
   ///
   /// \param enabled the new clock stretching during transmit cycle state
   UeiDaqAPI void EnableTransmitClockStretching(bool enabled);

   /// \brief Query the status of clock stretching during receive cycle
   ///
   /// Query the status of clock stretching during receive cycle.
   ///
   /// \return the status of clock stretching during receive cycle.
   UeiDaqAPI bool IsReceiveClockStretchingEnabled();

   /// \brief Enable clock stretching during receive cycle
   ///
   /// Enable clock stretching during receive cycle.
   ///
   /// \param enabled the new clock stretching during receive cycle state
   UeiDaqAPI void EnableReceiveClockStretching(bool enabled);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiI2CSlavePortImpl> m_pImpl;
};


}   // namespace UeiDaq

#endif // __UEICHANNEL_H__
