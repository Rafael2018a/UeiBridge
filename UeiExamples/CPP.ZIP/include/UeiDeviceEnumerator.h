// UeiDeviceEnumerator.h: interface for the CUeiDeviceEnumerator class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __UEIDEVICEENUMERATOR_H__
#define __UEIDEVICEENUMERATOR_H__

#include <string>
#include <vector>
#include <memory>

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

namespace UeiDaq
{

// Private classe
class CUeiDeviceEnumeratorImpl;

// Forward declaration
class CUeiDevice;
class CUeiException;

/// \brief Device enumerator
///
/// Enumerates devices detected on the specified resource
class CUeiDeviceEnumerator  
{
public:
   ///  \brief Constructor
   ///
   /// Build a device enumerator from the device class and the remote address strings.  
   ///
   /// \param deviceClass the class of device to enumerate (ex: simu, pwrdaq).
   /// \param remoteAddress the address of the module where the enumeration takes place.
   /// \param remotePort the port used by the remote module 
   /// \sa GetDevice  
   UeiDaqAPI CUeiDeviceEnumerator(std::string deviceClass, std::string remoteAddress, unsigned int remotePort);
   
   ///  \brief Constructor
   ///
   /// Build a device enumerator from the driver resource string (ex: pdna://192.168.0.12/).  
   ///
   /// \param driverResource the resource name of the device family to enumerate (ex: simu://, pwrdaq://, pdna://192.168.100.2).
   /// \sa GetDevice  
   UeiDaqAPI CUeiDeviceEnumerator(std::string driverResource);
  
   ///  \brief Destructor
   UeiDaqAPI virtual ~CUeiDeviceEnumerator();

   /// \brief Get a device object from its index
   ///
   /// Enumerates a device.  
   ///
   /// \return a pointer to the device object or NULL if there is no more devices to enumerate.
   /// \sa GetNumberOfDevices  
   UeiDaqAPI CUeiDevice* GetDevice(int deviceIndex);
   
   /// \brief Get the number of devices
   ///
   /// Get the number of enumerated devices  
   ///
   /// \return the number of enumerated devices.
   /// \sa GetDevice  
   UeiDaqAPI int GetNumberOfDevices();

   /// \brief Get a device object from its resource string
   ///
   /// Get a device object pointer specified by its resource string
   ///
   /// \return a pointer to the device object or NULL if the device doesn't exist
   UeiDaqAPI static CUeiDevice* GetDeviceFromResource(std::string resource);

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiDeviceEnumeratorImpl> m_pImpl;
};

}

#endif // __UEIDEVICEENUMERATOR_H__
