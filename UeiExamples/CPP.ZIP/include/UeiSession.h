#ifndef __UEISESSION_H__
#define __UEISESSION_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif


#include "UeiObject.h"
#include "UeiConstants.h"
#include "UeiStructs.h"
#include "UeiChannel.h"
#include "UeiTiming.h"
#include "UeiTrigger.h"
#include "UeiDevice.h"
#include "UeiEvent.h"
#include "UeiDataStream.h"

namespace UeiDaq
{
// private classes
class CUeiSessionImpl;

// Forward declaration
class CUeiException;

/// \brief Session Class
///
/// The session class is used to store the DAQ device settings
/// and control its operation
/// \include AnalogInSingle/AnalogInSingle.cpp
class CUeiSession : public CUeiObject
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiSession();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiSession();

   /// \brief Create Diagnostic input channel list
   ///
   /// Create and add one or more channel to the diagnostic channel list associated with the session.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \return A pointer to the first channel created.
   UeiDaqAPI CUeiDiagnosticChannel* CreateDiagnosticChannel(std::string resource);

   /// \brief Create Analog voltage input channel list
   ///
   /// Create and add one or more channel to the AI channel list associated with the session.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// mySession.CreateAIChannel("pwrdaq://Dev1/Ai0", -10.0, 10.0, UeiAIChannelInputModeDifferential );
   /// \endcode
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param min The minimum value you expect to measure.
   /// \param max The maximum value you expect to measure
   /// \param mode The input mode of the Analog input(s)
   /// \return A pointer to the first channel created.
   /// \sa CreateAOChannel, CreateDIChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiAIChannel* CreateAIChannel(std::string resource, 
                                            f64 min, 
                                            f64 max, 
                                            tUeiAIChannelInputMode mode);

   /// \brief Create Analog current input channel list
   ///
   /// Create and add one or more channel to the AI channel list associated with the session.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// mySession.CreateAICurrentChannel("pdna://192.168.100.2/Dev1/Ai0", -10.0, 10.0, UeiFeatureDisabled, UeiAIChannelInputModeDifferential );
   /// \endcode
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param min The minimum value you expect to measure.
   /// \param max The maximum value you expect to measure
   /// \param enableCB The circuit breaker configuration
   /// \param mode The input mode of the Analog input(s)
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel
   UeiDaqAPI CUeiAICurrentChannel* CreateAICurrentChannel(std::string resource, 
                                                          f64 min, 
                                                          f64 max,
                                                          tUeiFeatureEnable enableCB,
                                                          tUeiAIChannelInputMode mode);

   /// \brief Create Analog output voltage channel list
   ///
   /// Create and add one or more voltage channel to the AO channel list associated with the session.
   /// Voltage channels are only available on AO devices capable of outputting voltage signals
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param min The minimum value you expect to generate.
   /// \param max The maximum value you expect to generate
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateDIChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiAOChannel* CreateAOChannel(std::string resource, 
                                            f64 min, 
                                            f64 max);

   /// \brief Create Analog output current channel list
   ///
   /// Create and add one or more current channel to the AO current channel list associated with the session.
   /// Current channels are only available on AO devices capable of outputing current
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param min The minimum value you expect to generate.
   /// \param max The maximum value you expect to generate
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateDIChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiAOCurrentChannel* CreateAOCurrentChannel(std::string resource, 
                                            f64 min, 
                                            f64 max);

   /// \brief Create Analog output waveform channel list
   ///
   /// Create and add one or more waveform channel to the channel list associated with the session.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param dacClockSource the main DAC clock source
   /// \param offsetDACClockSource the offset DAC clock source
   /// \param clockSync channel0 clock routing
   /// \return A pointer to the first channel created.
   /// \sa CreateAOChannel
   UeiDaqAPI CUeiAOWaveformChannel* CreateAOWaveformChannel(std::string resource, 
                                                            tUeiAOWaveformClockSource  dacClockSource,
                                                            tUeiAOWaveformOffsetClockSource offsetDACClockSource,
                                                            tUeiAOWaveformClockSync  clockSync);

   /// \brief Create Protected analog output voltage channel list
   ///
   /// Create and add one or more channel to the channel list associated with the session.
   /// Protected AO channels are available on certain devices such as the DNA-AO-318 and DNA-AO-316.
   /// The amount of current flowing through each output is monitored at the given rate
   /// and must stay within the specified range, otherwise the device will automatically open
   /// the circuit acting as a breaker.
   /// You can specify whether the device should attempt to reestablish the circuit and how
   /// often it should try to do so.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param mode Selects which DAC is connected to the output
   /// \param measurementRate The monitoring rate. Determines how fast the breaker react after an over or under-limit condition.
   /// \param autoRetry Specifies whether the device will attempt to reestablish the circuit after an over or under-limit condition
   /// \param retryRate The number of retries per second.
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDIChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiAOProtectedChannel* CreateAOProtectedChannel(std::string resource,
                                                              tUeiAODACMode mode,
                                                              double measurementRate,
                                                              bool autoRetry,
                                                              double retryRate);

   /// \brief Create Protected analog output current channel list
   ///
   /// Create and add one or more channel to the channel list associated with the session.
   /// Protected AO current channels are available on certain devices such as the DNA-AO-318-020
   /// The amount of current flowing through each output is monitored at the given rate
   /// and must stay within the specified range, otherwise the device will automatically open
   /// the circuit acting as a breaker.
   /// You can specify whether the device should attempt to reestablish the circuit and how
   /// often it should try to do so.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param mode Selects which DAC is connected to the output
   /// \param measurementRate The monitoring rate. Determines how fast the breaker react after an over or under-limit condition.
   /// \param autoRetry Specifies whether the device will attempt to reestablish the circuit after an over or under-limit condition
   /// \param retryRate The number of retries per second.
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDIChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiAOProtectedCurrentChannel* CreateAOProtectedCurrentChannel(std::string resource,
                                                              tUeiAODACMode mode,
                                                              double measurementRate,
                                                              bool autoRetry,
                                                              double retryRate);

   /// \brief Create Simulated Thermocouple output channel list
   ///
   /// Create and add one or more simulated thermocouple channel to the session.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param tcType The type of thermocouple to simulate.
   /// \param tempScale The temperature unit used to convert temperature to volts.
   /// \param enableCjc The cold junction compensation state.
   /// \return A pointer to the first channel created.
   UeiDaqAPI CUeiSimulatedTCChannel* CreateSimulatedTCChannel(std::string resource,
                                                            tUeiThermocoupleType tcType,
                                                            tUeiTemperatureScale tempScale,
                                                            bool enableCjc);

   /// \brief Create simulated RTD output channel list
   ///
   /// Create and add one or more simulated RTD channel to the channel list associated with the session.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param rtdType The type of RTD connected on the Analog input(s).
   /// \param rtdNominalResistance The nominal resistance of the RTD at ice point (0 deg Celsius).
   /// \param tempScale The temperature unit used to convert resistance to temperature.
   /// \return A pointer to the first channel created.
   UeiDaqAPI CUeiSimulatedRTDChannel* CreateSimulatedRTDChannel(std::string resource,
                                                               tUeiRTDType rtdType,
                                                               double rtdNominalResistance,
                                                               tUeiTemperatureScale tempScale);

   /// \brief Create Digital input channel list
   ///
   /// Create and add one or more channel to the DI channel list associated with the session.
   /// Each channel is associated with a digital input port that groups a predefined number of input lines. 
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiDIChannel* CreateDIChannel(std::string resource);

   /// \brief Create industrial digital input channel list
   ///
   /// Create and add one or more channel to the channel list associated with the session.
   /// Each channel is associated with a digital input port that groups a predefined number of input lines.
   /// Industrial channels are only available on certain DIO devices such as the DNA-DIO-448.
   /// You can program the levels at which the input line state change as well as configure
   /// a digital filter to eliminate glitches and spikes
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param lowThreshold the low hysteresis threshold
   /// \param highThreshold the high hysteresis threshold
   /// \param minPulseWidth the digital filter minimum pulse width in ms. Use 0.0 to disable digital input filter.
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiDIIndustrialChannel* CreateDIIndustrialChannel(std::string resource,
                                                                double lowThreshold,
                                                                double highThreshold,
                                                                double minPulseWidth);

   /// \brief Create Digital output channel list
   ///
   /// Create and add one or more channel to the DO channel list associated with the session.
   /// Each channel is associated with a digital output port that groups a predefined number of output lines.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDIChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiDOChannel* CreateDOChannel(std::string resource);

   /// \brief Create Industrial digital output channel list
   ///
   /// Create and add one or more channel to the channel list associated with the session.
   /// Each channel is associated with a digital output port that groups a predefined number of output lines.
   /// Industrial DO channels are available on certain devices such as the DNx-MF-101 and DNx-DIO-43x.
   /// low-to high and high to low transitions can be replaced by pwm providing soft start and soft stop.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param pwmMode The PWM mode used to soft start and/or stop.
   /// \param pwmLengthUs The soft start/stop pulse train length in micro-seconds.
   /// \param pwmPeriodUs The soft start/stop or continuous pulse train period in micro-seconds.
   /// \param pwmDutyCycle The continuous pulse train duty cycle
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDIChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiDOIndustrialChannel* CreateDOIndustrialChannel(std::string resource, 
                                                                tUeiDOPWMMode pwmMode, 
                                                                uInt32 pwmLengthUs,
                                                                uInt32 pwmPeriodUs,
                                                                double pwmDutyCycle);

   /// \brief Create Protected digital output channel list
   ///
   /// Create and add one or more channel to the channel list associated with the session.
   /// Each channel is associated with a digital output port that groups a predefined number of output lines.
   /// Protected channels are available on certain devices such as the DNA-DIO-416 and DNA-DIO-43x.
   /// The amount of current flowing through each digital line is monitored at the given rate
   /// and must stay within the specified range, otherwise the device will automatically open
   /// the circuit acting as a breaker.
   /// You can specify whether the device should attempt to reestablish the circuit and how
   /// often it should try to do so.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param underCurrentLimit The minimum amount of current allowed in Amps.
   /// \param overCurrentLimit The maximum amount of current allowed in Amps.
   /// \param currentSampleRate The current sampling rate. Determines how fast the breaker react after an over or under-current condition.
   /// \param autoRetry Specifies whether the device will attempt to reestablish the circuit after an over or under-current condition
   /// \param retryRate The number of retries per second.
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDIChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiDOProtectedChannel* CreateDOProtectedChannel(std::string resource, 
                                                              double underCurrentLimit, 
                                                              double overCurrentLimit,
                                                              double currentSampleRate,
                                                              bool autoRetry,
                                                              double retryRate);

   /// \brief Create Counter input channel list
   ///
   /// Create and add one or more channel to the CI channel list associated with the session.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param source The source of the signal counted or used as a timebase
   /// \param mode The mode that specify whether the session counts events, measures a pulse width or measures a period on the signal configured as the source
   /// \param gate The signal that specify whether the counter/timer is on or off
   /// \param divider The divider used to scale the timebase speed
   /// \param inverted Specifies whether the signal at the source is inverted before performing the counting operation
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDIChannel, CreateDOChannel, CreateCOChannel
   UeiDaqAPI CUeiCIChannel* CreateCIChannel(std::string resource,
                                            tUeiCounterSource source, 
                                            tUeiCounterMode mode, 
                                            tUeiCounterGate gate,
                                            Int32 divider,
                                            Int32 inverted);

   /// \brief Create quadrature encoder input channel list
   ///
   /// Create and add one or more channel to the CI channel list associated with the session.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param initialPosition The initial number of pulses when the session starts
   /// \param decodingType The decoding type 1x, 2x or 4x
   /// \param enableZeroIndexing Enable or disable resetting the measurement when a zero index event is detected
   /// \param zeroIndexPhase Specifies the states of A, B and Z inputs that will generate a zero index event
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDIChannel, CreateDOChannel, CreateCOChannel
   UeiDaqAPI CUeiQuadratureEncoderChannel* CreateQuadratureEncoderChannel(std::string resource,
                                            uInt32 initialPosition,
                                            tUeiQuadratureDecodingType decodingType, 
                                            bool enableZeroIndexing, 
                                            tUeiQuadratureZeroIndexPhase zeroIndexPhase);

   /// \brief Create variable reluctance input channel list
   ///
   /// Create and add one or more channel to the VR channel list associated with the session.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param mode The VR measurement device can use four different modes to measure velocity, position or direction: Decoder, Timed, NPulses and ZPulse 
   /// \return A pointer to the first channel created.
   UeiDaqAPI CUeiVRChannel* CreateVRChannel(std::string resource,
                                            tUeiVRMode mode);

   /// \brief Create SSI master port list
   ///
   /// Create and add one or more port to the SSI channel list associated with the session.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param bps The speed of the clock
   /// \param wordSize The number of bits per word (3 to 32)
   /// \param enableClock Enable or disable clock output
   /// \param enableTermination Enable or disable termination resistor
   /// \param pauseTime Specifies the time delay between two consecutive clock sequences from the master
   /// \param transferTimeout Specifies the minimum time required by the slave to realise that the data transmission is complete
   /// \param bitUpdateTime Specifies the minimum time elapsed between retransmissions of the same data
   /// \return A pointer to the first channel created.
   UeiDaqAPI CUeiSSIMasterPort* CreateSSIMasterPort(std::string resource,
                                                   unsigned int bps,
                                                   unsigned int wordSize,
                                                   bool enableClock,
                                                   bool enableTermination,
                                                   double pauseTime,
                                                   double transferTimeout,
                                                   double bitUpdateTime);

   /// \brief Create SSI slave port list
   ///
   /// Create and add one or more port to the SSI channel list associated with the session.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param bps The speed of the clock
   /// \param wordSize The number of bits per word (3 to 32)
   /// \param enableTransmit Enable or disable data output
   /// \param enableTermination Enable or disable termination resistor
   /// \param pauseTime Specifies the time delay between two consecutive clock sequences from the master
   /// \param transferTimeout Specifies the minimum time required by the slave to realise that the data transmission is complete
   /// \param bitUpdateTime Specifies the minimum time elapsed between retransmissions of the same data
   /// \return A pointer to the first channel created.
   UeiDaqAPI CUeiSSISlavePort* CreateSSISlavePort(std::string resource,
                                                   unsigned int bps,
                                                   unsigned int wordSize,
                                                   bool enableTransmit,
                                                   bool enableTermination,
                                                   double pauseTime,
                                                   double transferTimeout,
                                                   double bitUpdateTime);
   
   /// \brief Create Counter output channel list
   ///
   /// Create and add one or more channel to the CO channel list associated with the session.
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param source The timebase used to determine the shape of the signal generated on the counter output
   /// \param mode The mode that specify whether the session generate a pulse or a pulse train on the counter output
   /// \param gate The signal that specify whether the counter/timer is on or off   
   /// \param tick1 Specifies how long the output stays low, number of ticks of the signal connected at the source.
   /// \param tick2 Specifies how long the output stays high, number of ticks of the signal connected at the source.
   /// \param divider The divider used to scale the timebase speed
   /// \param inverted Specifies whether the signal at the source is inverted before performing the operation
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDIChannel, CreateDOChannel, CreateCIChannel
   UeiDaqAPI CUeiCOChannel* CreateCOChannel(std::string resource,
                                            tUeiCounterSource source, 
                                            tUeiCounterMode mode, 
                                            tUeiCounterGate gate,
                                            uInt32 tick1, 
                                            uInt32 tick2,
                                            Int32 divider,
                                            Int32 inverted);

   /// \brief Create Thermocouple input channel list
   ///
   /// Create and add one or more thermocouple channel to the thermocouple channel list associated with the session.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// mySession.CreateTCChannel("pwrdaq://Dev1/Ai0", 0.0, 1000.0, UeiThermocoupleTypeJ,
   ///                           UeiTemperatureScaleCelsius, UeiCJCTypeConstant, 25.0, "", 
   ///                           UeiAIChannelInputModeDifferential);
   /// \endcode
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param min The minimum value you expect to measure.
   /// \param max The maximum value you expect to measure.
   /// \param tcType The type of thermocouple connected on the Analog input(s).
   /// \param tempScale The temperature unit used to convert volts to temperature.
   /// \param cjcType The cold junction compensation type.
   /// \param cjcConstant The cold junction compensation constant, this parameter is only used if cjcType is set to UeiCJCTypeConstant.
   /// \param cjcResource The resource string of the channel on which the cold junction compensation sensor is connected, this parameter is only used if cjcType is set to UeiCJCTypeResource.
   /// \param mode The input mode used to measure voltage from the sensor
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel
   UeiDaqAPI CUeiTCChannel* CreateTCChannel(std::string resource, 
                                            f64 min, 
                                            f64 max, 
                                            tUeiThermocoupleType tcType,
                                            tUeiTemperatureScale tempScale,
                                            tUeiColdJunctionCompensationType cjcType,
                                            f64 cjcConstant,
                                            std::string cjcResource,
                                            tUeiAIChannelInputMode mode);

   /// \brief Create RTD input channel list
   ///
   /// Create and add one or more RTD channel to the channel list associated with the session.
   /// In two wires mode, only one analog input channel per RTD is required.
   /// In four wires mode, two analog input channels per RTD are required effectively
   /// dividing the number of available channels on your device by two.
   /// Channels are paired consecutively: (0,1), (2,3), (3,4).... You only need to specify the first channel in the channel list.
   /// Read the DNA-STP-AIU manual to learn how to connect your RTD.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// mySession.CreateRTDChannel("pdna://192.168.100.2/Dev1/Ai0", -100.0, 100.0, 
   ///                            UeiFourWires, 0.0,
   ///                            UeiRTDType3850, 100.0, 
   ///                            UeiTemperatureScaleCelsius, 
   ///                            UeiAIChannelInputModeDifferential);
   /// \endcode
   /// \param resource The device and channel(s) to add to the list.
   /// \param min The minimum value you expect to measure.
   /// \param max The maximum value you expect to measure.
   /// \param wiring The wiring scheme used to connect the RTD to the acquisition device.
   /// \param twoWiresLeadResistance The leads resistance in two wires mode. 
   /// \param rtdType The type of RTD connected on the Analog input(s).
   /// \param rtdNominalResistance The nominal resistance of the RTD at ice point (0 deg Celsius).
   /// \param tempScale The temperature unit used to convert resistance to temperature.
   /// \param mode The input mode used to measure voltage from the sensor
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel
   UeiDaqAPI CUeiRTDChannel* CreateRTDChannel(std::string resource, 
                                              f64 min, 
                                              f64 max, 
                                              tUeiWiringScheme wiring,
                                              double twoWiresLeadResistance,
                                              tUeiRTDType rtdType,
                                              double rtdNominalResistance,
                                              tUeiTemperatureScale tempScale,                                             
                                              tUeiAIChannelInputMode mode);

   /// \brief Create resistance input channel list
   ///
   /// Create and add one or more resistance channel to the channel list associated with the session.
   /// In two wires mode, only one analog input channel per resistance is required.
   /// In four wires mode, two analog input channels per resistance are required effectively
   /// dividing the number of available channels on your device by two.
   /// Channels are paired consecutively: (0,1), (2,3), (4,5).... You only need to specify the first channel in the channel list.
   /// Read the DNA-STP-AIU manual to learn how to connect your resistance.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// mySession.CreateResistanceChannel("pdna://192.168.100.2/Dev1/Ai0", 0.0, 1000.0, 
   ///                                   UeiFourWires, 0.0, 
   ///                                   UeiAIChannelInputModeDifferential);
   /// \endcode
   /// \param resource The device and channel(s) to add to the list.
   /// \param min The minimum value you expect to measure.
   /// \param max The maximum value you expect to measure.
   /// \param wiring The wiring scheme used to connect the resistive sensor to the acquisition device.
   /// \param twoWiresLeadResistance The lead resistance in two wires mode. 
   /// \param mode The input mode used to measure voltage from the sensor
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel
   UeiDaqAPI CUeiResistanceChannel* CreateResistanceChannel(std::string resource, 
                                                            f64 min, 
                                                            f64 max, 
                                                            tUeiWiringScheme wiring,
                                                            double twoWiresLeadResistance,                                           
                                                            tUeiAIChannelInputMode mode);


   /// \brief Create Analog input with excitation channel list
   ///
   /// Create and add one or more analog input channel to the channel list associated with the session.
   /// This will only work with devices that can provide excitation voltage.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// mySession.CreateAIVExChannel("pwrdaq://Dev1/Ai0", -100.0, 100.0, UeiSensorFullBridge,
   ///                         10.0, true);
   /// \endcode
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param min The minimum value you expect to measure.
   /// \param max The maximum value you expect to measure.
   /// \param sensorBridgeType The type of the wheatstone bridge built-in the sensor
   /// \param excitationVoltage The excitation voltage to output to the sensor
   /// \param bUseExcitationForScaling Specifies whether the acquired data is divided by the excitation voltage
   /// \param mode The input mode used to measure voltage from the sensor
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel
   UeiDaqAPI CUeiAIVExChannel* CreateAIVExChannel(std::string resource, 
                                                  f64 min, 
                                                  f64 max, 
                                                  tUeiSensorBridgeType sensorBridgeType,
                                                  double excitationVoltage,
                                                  bool bUseExcitationForScaling,
                                                  tUeiAIChannelInputMode mode);

   /// \brief Create Accelerometer channel list
   ///
   /// Create and add one or more accelerometer channel to the channel list associated with the session.
   /// This will only work with devices that can provide excitation current for
   /// ICP and IEPE sensors.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// // Configure channel 0 on device 1 to acquire acceleration measured
   /// // by a sensor with a sensitivity of 24 mV/g, powered by a current
   /// // of 5mA. the gain of the device is adjusted to measure accelerations
   /// // between -10.0g and + 10.0g
   /// mySession.CreateAccelChannel("pwrdaq://Dev1/Ai0", -10.0, 10.0, 24,
   ///                              5.0, UeiCouplingAC, false);
   /// \endcode
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param min The minimum value you expect to measure. The unit depends on the unit of the accelerometer sensitivity. (mV/g will provide measurements in g).
   /// \param max The maximum value you expect to measure. The unit depends on the unit of the accelerometer sensitivity. (mV/g will provide measurements in g).
   /// \param sensorSensitivity The sensitivity of the accelerometer. The unit of this parameter specifies the unit of the measurements.
   /// \param excitationCurrent The excitation current to output to the sensor
   /// \param coupling The coupling type. AC coupling turns on a 0.1Hz high pass filter.
   /// \param enableLowPassFilter Turn on or off the low-pass anti-aliasing filter
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel
   UeiDaqAPI CUeiAccelChannel* CreateAccelChannel(std::string resource, 
                                                  f64 min, 
                                                  f64 max, 
                                                  double sensorSensitivity,
                                                  double excitationCurrent,
                                                  tUeiCoupling coupling,
                                                  bool enableLowPassFilter);

   /// \brief Create digital multi-meter channel
   ///
   /// Create and add one or more analog input channel to the channel list associated with the session.
   /// This will only work with DMM devices.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// mySession.CreateDMMChannel("pdna://192.168.100.2/Dev1/Ai0", 10, UeiDMMModeDCVoltage);
   /// \endcode
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param range The input range. Input signals will need to be within -range/+range interval.
   /// \param measurementMode The measurement mode configuration
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel
   UeiDaqAPI CUeiDMMChannel* CreateDMMChannel(std::string resource,
                                              f64 range,
                                              tUeiDMMMeasurementMode measurementMode);

   /// \brief Create LVDT/RVDT analog input channel list
   ///
   /// Create and add one or more LVDT or RVDT channel to the channel list associated with the session.
   /// This will only work with devices that can provide excitation waveform
   /// to the LVDT or RVDT sensor.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// // Configure channel 0 on device 1 to acquire position measured
   /// // by a LVDT with a sensitivity of 24 mV/V/mm, powered by a 600Hz
   /// // sine waveform with amplitude of 10.0 VRMS. 
   /// // The gain of the device is adjusted to measure positions
   /// // between -10.0mm and + 10.0mm
   /// mySession.CreateLVDTChannel("pdna://192.168.100.2/Dev1/Ai0", -10.0, 10.0, 24,
   ///                             UeiLVDTFiveWires, 10.0, 600.0, false);
   /// \endcode
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param min The minimum value you expect to measure. The unit depends on the unit of the LVDT/RVDT sensitivity. (mV/V/mm will provide measurements in mm).
   /// \param max The maximum value you expect to measure. The unit depends on the unit of the LVDT/RVDT sensitivity. (mV/V/mm will provide measurements in mm).
   /// \param sensorSensitivity The sensitivity of the LVDT or RVDT. The unit of this parameter specifies the unit of the measurements.
   /// \param wiringScheme Specifies whether the LVDT/RVDT is tied to the device using 4 or 5 wires
   /// \param excitationVoltage The amplitude RMS of the excitation sine waveform to output to the sensor
   /// \param excitationFrequency The frequency of the excitation sine waveform to output to the sensor
   /// \param externalExcitation Specifies whether the LVDT is powered by the device or by an external source.
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel
   UeiDaqAPI CUeiLVDTChannel* CreateLVDTChannel(std::string resource, 
                                                f64 min, 
                                                f64 max, 
                                                double sensorSensitivity,
                                                tUeiLVDTWiringScheme wiringScheme,
                                                double excitationVoltage,
                                                double excitationFrequency,
                                                bool externalExcitation);

   /// \brief Create simulated LVDT/RVDT analog output channel list
   ///
   /// Create and add one or more simulated LVDT or RVDT channel to the channel list associated with the session.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// // Configure channel 0 on device 1 to simulate position measurement
   /// // given by a LVDT with a sensitivity of 24 mV/V/mm, powered by a 600Hz
   /// // sine waveform with amplitude of 10.0V RMS. 
   /// mySession.CreateSimulatedLVDTChannel("pdna://192.168.100.2/Dev1/Ao0", 24,
   ///                                      UeiLVDTFiveWires, 10.0, 600.0);
   /// \endcode
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param sensorSensitivity The sensitivity of the simulated LVDT or RVDT. The unit of this parameter specifies the unit of the measurements.
   /// \param wiringScheme Specifies whether the simulated LVDT/RVDT is tied to the device using 4 or 5 wires
   /// \param excitationVoltage The amplitude RMS of the excitation sine waveform to output to the sensor
   /// \param excitationFrequency The frequency of the excitation sine waveform to output to the sensor
   /// \return A pointer to the first channel created.
   /// \sa CreateAOChannel
   UeiDaqAPI CUeiSimulatedLVDTChannel* CreateSimulatedLVDTChannel(std::string resource, 
                                                                  double sensorSensitivity,
                                                                  tUeiLVDTWiringScheme wiringScheme,
                                                                  double excitationVoltage,
                                                                  double excitationFrequency);

   /// \brief Create Synchro/Resolver analog input channel list
   ///
   /// Create and add one or more Synchro or Resolver channel to the channel list associated with the session.
   /// This will only work with devices that can provide excitation waveform
   /// to the Synchro or Resolver sensor.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// // Configure channel 0 on device 1 to acquire position measured
   /// // by a synchro powered by a 600Hz sine waveform with 
   /// // amplitude of 10.0 VRMS. 
   /// mySession.CreateSynchroResolverChannel("pdna://192.168.100.2/Dev1/Ai0", 
   ///                                        UeiSynchroMode, 10.0, 600.0, false);
   /// \endcode
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param mode Specifies whether the input sensor is a synchro or a resolver
   /// \param excitationVoltage The amplitude RMS of the excitation sine waveform to output to the sensor
   /// \param excitationFrequency The frequency of the excitation sine waveform to output to the sensor
   /// \param externalExcitation Specifies whether the sensor is powered by the device or by an external source.
   /// \return A pointer to the first channel created.
   /// \sa CreateAIChannel
   UeiDaqAPI CUeiSynchroResolverChannel* CreateSynchroResolverChannel(std::string resource, 
                                                                     tUeiSynchroResolverMode mode,
                                                                     double excitationVoltage,
                                                                     double excitationFrequency,
                                                                     bool externalExcitation);

   /// \brief Create simulated Synchro/Resolver analog output channel list
   ///
   /// Create and add one or more simulated synchro or simulated resolver 
   /// channel to the channel list associated with the session.
   ///
   /// \par Example:
   /// \code 
   /// CUeiSession mySession;
   ///
   /// // Configure channel 0 on device 1 to simulate position measurement
   /// // returned by a synchro powered by a 600Hz sine waveform with 
   /// // amplitude of 10.0 VRMS. 
   /// mySession.CreateSimulatedSynchroResolverChannel("pdna://192.168.100.2/Dev1/Ao0", 
   ///                                                 UeiSynchroMode, 10.0, 600.0, false);
   /// \endcode
   ///
   /// \param resource The device and channel(s) to add to the list.
   /// \param mode Specifies whether the sensor simulated is a synchro or a resolver
   /// \param excitationVoltage The amplitude RMS of the excitation sine waveform to output to the sensor
   /// \param excitationFrequency The frequency of the excitation sine waveform to output to the sensor
   /// \param externalExcitation Specifies whther the sensor is powered by the device or by an external source.
   /// \return A pointer to the first channel created.
   /// \sa CreateAOChannel
   UeiDaqAPI CUeiSimulatedSynchroResolverChannel* CreateSimulatedSynchroResolverChannel(std::string resource, 
                                                                     tUeiSynchroResolverMode mode,
                                                                     double excitationVoltage,
                                                                     double excitationFrequency,
                                                                     bool externalExcitation);

   /// \brief Create Serial port
   ///
   /// Create and add one or more serial ports to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param mode The serial port mode: RS-232, RS-485 half and full duplex
   /// \param bitsPerSecond The number of bits transmitted per second over the serial link
   /// \param dataBits The number of data bits describing each character
   /// \param parity The parity scheme used for transmission error detection
   /// \param stopBits The number of stop bits used to indicate the end of a data message
   /// \param termination The read operation terminates when the termination string is read from the serial device
   /// \return A pointer to the first port created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiSerialPort* CreateSerialPort(std::string resource,
                                              tUeiSerialPortMode mode,
                                              tUeiSerialPortSpeed bitsPerSecond,
                                              tUeiSerialPortDataBits dataBits,
                                              tUeiSerialPortParity parity,
                                              tUeiSerialPortStopBits stopBits,
                                              std::string termination);

   /// \brief Create HDLC port
   ///
   /// Create and add one or more HDLC ports to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param physInterface The physical interface: RS-232, RS-485 or RS-422
   /// \param bitsPerSecond The number of bits transmitted per second 
   /// \param encoding The method used to encode bits on the physical interface
   /// \param crcMode The method used to calculate each frame CRC
   /// \param txClockSource The source of the transmitter clock
   /// \param rxClockSource The source of the receiver clock
   /// \return A pointer to the first port created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiHDLCPort* CreateHDLCPort(std::string resource,
                                          tUeiHDLCPortPhysical physInterface,
                                          uInt32 bitsPerSecond,
                                          tUeiHDLCPortEncoding encoding,
                                          tUeiHDLCPortCRCMode crcMode,
                                          tUeiHDLCPortClockSource txClockSource,
                                          tUeiHDLCPortClockSource rxClockSource);

   /// \brief Create CAN port
   ///
   /// Create and add one or more CAN ports to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param bitsPerSecond The number of bits transmitted per second over the CAN port
   /// \param frameFormat Specifies the format of frames sent, basic (11 bits ID) or extended (29 bits ID)
   /// \param mode The operation mode, normal or passive to only listen 
   /// \param acceptanceMask The acceptance mask is used to filter incoming frames. The mask selects
   ///                       which bits within arbitration ID will be used for filtering.
   /// \param acceptanceCode The acceptance code is used to filter incoming frames. The arbitration ID bits selected
   ///                       by the mask are compared to the code and the frame is rejected if there is any difference.
   ///                       If (mask XOR id) AND code == 0 the frame is accepted.
   /// \return A pointer to the first port created.
   /// \sa CreateAIChannel, CreateAOChannel, CreateDOChannel, CreateCIChannel, CreateCOChannel
   UeiDaqAPI CUeiCANPort* CreateCANPort(std::string resource, 
                                        tUeiCANPortSpeed bitsPerSecond,
                                        tUeiCANFrameFormat frameFormat,
                                        tUeiCANPortMode mode,
                                        uInt32 acceptanceMask,
                                        uInt32 acceptanceCode);

   /// \brief Create ARINC input port
   ///
   /// Create and add one or more ARINC input ports to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param bitsPerSecond The number of bits transmitted per second over the ARINC port
   /// \param parity The parity used to detect transmission errors.
   /// \param enableSDIFilter Set to true to enable frame filtering based on their SDI bits. 
   /// \param SDIMask The mask used to match incoming frame SDI bits (only bits 0 and 1 are significant).
   /// \return A pointer to the first port created.
   /// \sa CreateARINCOutputPort
   UeiDaqAPI CUeiARINCInputPort* CreateARINCInputPort(std::string resource, 
                                                      tUeiARINCPortSpeed bitsPerSecond,
                                                      tUeiARINCPortParity parity,
                                                      bool enableSDIFilter,
                                                      uInt32 SDIMask);

   /// \brief Create ARINC output port
   ///
   /// Create and add one or more ARINC output ports to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param bitsPerSecond The number of bits transmitted per second over the ARINC port
   /// \param parity The parity used to detect transmission errors.
   /// \return A pointer to the first port created.
   /// \sa CreateARINCInputPort
   UeiDaqAPI CUeiARINCOutputPort* CreateARINCOutputPort(std::string resource, 
                                                        tUeiARINCPortSpeed bitsPerSecond,
                                                        tUeiARINCPortParity parity);

   /// \brief Create MIL-1553 port
   ///
   /// Create and add one or more MIL-1553 ports to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param coupling The way how the port is connected to MIL-1553 bus (tranformer, direct, etc.)
   /// \param portMode The mode of operation (bus monitor, remote terminal, bus controller)
   /// \return A pointer to the first port created.
   UeiDaqAPI CUeiMIL1553Port* CreateMIL1553Port(std::string resource, 
                                                tUeiMIL1553PortCoupling coupling,
                                                tUeiMIL1553PortOpMode portMode);

   /// \brief Create IRIG time keeper channel
   ///
   /// Create and add one or more IRIG time keeper channels to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param source The 1 PPS signal source
   /// \param autoFollow Enable or disable auto follow
   /// \return A pointer to the first channel created.
   UeiDaqAPI CUeiIRIGTimeKeeperChannel* CreateIRIGTimeKeeperChannel(std::string resource, 
                                                                    tUeiIRIGTimeKeeper1PPSSource source,
                                                                    bool autoFollow);

   /// \brief Create IRIG input channel
   ///
   /// Create and add one or more IRIG input channels to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param inputType The input where the timecode signal is connected
   /// \param timeCodeFormat The time code format used by the input signal
   /// \return A pointer to the first channel created.
   UeiDaqAPI CUeiIRIGInputChannel* CreateIRIGInputChannel(std::string resource, 
                                                          tUeiIRIGDecoderInputType inputType,
                                                          tUeiIRIGTimeCodeFormat timeCodeFormat);

   /// \brief Create IRIG output channel
   ///
   /// Create and add one or more IRIG output channels to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param timeCodeFormat The time code format to use for the generated signal
   /// \return A pointer to the first channel created.
   UeiDaqAPI CUeiIRIGOutputChannel* CreateIRIGOutputChannel(std::string resource, 
                                                           tUeiIRIGTimeCodeFormat timeCodeFormat);

   /// \brief Create IRIG DO TTL channel
   ///
   /// Create and add one or more IRIG DO TTL channels to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param source0 The source used to generate TTL pulses on output 0
   /// \param source1 The source used to generate TTL pulses on output 1
   /// \param source2 The source used to generate TTL pulses on output 2
   /// \param source3 The source used to generate TTL pulses on output 3
   /// \return A pointer to the first channel created.
   UeiDaqAPI CUeiIRIGDOTTLChannel* CreateIRIGDOTTLChannel(std::string resource, 
                                                          tUeiIRIGDOTTLSource source0,
                                                          tUeiIRIGDOTTLSource source1,
                                                          tUeiIRIGDOTTLSource source2,
                                                          tUeiIRIGDOTTLSource source3);

   /// \brief Create 1PPS synchronization port
   ///
   /// The 1PPS synchronization port uses an ADPLL and an event module to produce a clock at an arbitrary rate
   /// Multiple racks can easily be synchronized when they use the same 1PPS synchronization clock
   /// The ADPLL+event module on each rack will produce synchronized scan clocks
   ///
   /// The source of the 1PPS sync clock can be internal, external or generated from NTP
   /// The 1PPS clock is routed via one of the four internal sync lines to the ADPLL (adaptive digital PLL)
   /// The ADPLL locks on the 1PPS and outputs its own 1PPS that is an average of the original 1PPS clock
   /// The ADPLL can maintain its 1PPS output even if the original 1PPS clock gets disconnected
   /// The ADPLL 1PPS output is routed via one of the four sync lines to the event module
   /// The ADPLL 1PPS output can also be routed to the sync connector for sharing with other racks/cubes
   /// The event module produces a user selectable number of pulses upon every 1PPS pulse coming from the ADPLL.
   /// The event module clock output is routed to the Input layers via one of the remaining sync lines 
   ///
   /// \param resource The IO module IP address.
   /// \param mode The mode used to obtain the reference 1PPS (existing 1PPS clock, NTP or 1588)
   /// \param source The source of the 1PPS refenrece clock
   /// \param EMOutputRate The rate of the resulting clock (synchronized with the 1PPS reference)
   /// \return A pointer to the synchronization port.
   UeiDaqAPI CUeiSync1PPSPort* CreateSync1PPSPort(std::string resource,
                                                  tUeiSync1PPSMode mode,
                                                  tUeiSync1PPSSource source,
                                                  double EMOutputRate);

   /// \brief Create CSDB port
   ///
   /// Create and add one or more CSDB ports to the session.
   ///
   /// \param resource The device and port(s) to add to the session.
   /// \param bps The CSDB port speed in bits per second (12500 or 50000)
   /// \param parity The parity (0 for even >0 for odd)
   /// \param blockSize The number of bytes per block (including address and status bytes)
   /// \param numberOfMessages The number of message blocks per frame
   /// \param interByteDelayUs The delay between bytes within a block
   /// \param interBlockDelayUs The delay between blocks within a frame
   /// \param framePeriodUs The period at which cyclic frames are emitted
   /// \return A pointer to the first port created.
   UeiDaqAPI CUeiCSDBPort* CreateCSDBPort(std::string resource,
                                          int bps,
                                          int parity,
                                          int blockSize,
                                          int numberOfMessages,
                                          int interByteDelayUs,
                                          int interBlockDelayUs,
                                          int framePeriodUs);

   /// \brief Create Mux port
   ///
   /// Create and add a MUX port to the session.
   ///
   /// \param resource The device and port to add to the session.
   /// \param breakBeforeMake True to enable break before make, false otherwise
   /// \return A pointer to the first port created.
   UeiDaqAPI CUeiMuxPort* CreateMuxPort(std::string resource,
                                       bool breakBeforeMake);

   /// \brief Create I2C master port
   ///
   /// Create and add an I2C master port to the session.
   ///
   /// \param resource The device and port to add to the session.
   /// \param bitRate the clock speed (bits per second)
   /// \param ttlLevel the TTL level used by clock and data signals
   /// \param enableSecureShell True to enable secure shell feature, false otherwise
   /// \return A pointer to the first port created.
   UeiDaqAPI CUeiI2CMasterPort* CreateI2CMasterPort(std::string resource,
                                                    tUeiI2CPortSpeed bitRate, 
                                                    tUeiI2CTTLLevel ttlLevel, 
                                                    bool enableSecureShell);

   /// \brief Create I2C slave port
   ///
   /// Create and add an I2C slave port to the session.
   ///
   /// \param resource The device and port to add to the session.
   /// \param ttlLevel the TTL level used by clock and data signals
   /// \param addressWidth specify the number of bits used to encode this slave address
   /// \param address the address of this slave port
   /// \return A pointer to the first port created.
   UeiDaqAPI CUeiI2CSlavePort* CreateI2CSlavePort(std::string resource,
                                                  tUeiI2CTTLLevel ttlLevel,
                                                  tUeiI2CSlaveAddressWidth addressWidth,
                                                  int address);

   /// \brief Create info session
   ///
   /// This session is useful to retrieve information about a device
   /// or directly access its registers.
   ///
   /// \param resource The device.
   UeiDaqAPI void CreateInfoSession(std::string resource);

   /// \brief Configure the timing object for simple IO
   ///
   /// Configure the timing object for simple IO. In this mode scans are acquired/generated
   /// one at a time. The pace of the acquisition/generation is entirely determined by the
   /// speed at which your software is calling the read/write functions.
   ///
   /// \sa ConfigureTimingForBufferedIO, ConfigureTimingForEdgeDetection, ConfigureTimingForTimeSequencing, ConfigureTimingForDataMappingIO
   UeiDaqAPI void ConfigureTimingForSimpleIO();

   /// \brief Configure the timing object for buffered mode
   ///
   /// Configure the timing object for buffered mode using hardware timing
   ///
   /// \param samplePerChannel The number of samples to acquire if duration is one-shot.
   /// \param clkSource The source of the clock. 
   /// \param rate The frequency of the scan clock in Hz.
   /// \param edge The edge of the clock that triggers the scan acquisition: rising or falling.
   /// \param duration The duration of the acquisition/generation, continuous or single-shot. 
   /// \sa ConfigureTimingForSimpleIO, ConfigureTimingForEdgeDetection, ConfigureTimingForTimeSequencing
   UeiDaqAPI void ConfigureTimingForBufferedIO(int samplePerChannel, 
                                               tUeiTimingClockSource clkSource, 
                                               double rate, 
                                               tUeiDigitalEdge edge, 
                                               tUeiTimingDuration duration);

   /// \brief Configure the timing object for data map mode
   ///
   /// Configure the timing object for direct data mapping mode using hardware timing
   ///
   /// \param clkSource The source of the clock. 
   /// \param rate The refresh rate of the data map.
   /// \sa ConfigureTimingForSimpleIO, ConfigureTimingForEdgeDetection, ConfigureTimingForTimeSequencing
   UeiDaqAPI void ConfigureTimingForDataMappingIO(tUeiTimingClockSource clkSource, 
                                                  double rate);

   /// \brief Configure the timing object for digital line state change detection
   ///
   /// Configure the timing object for digital line state change detection
   /// The line on which the state change is sensed is specified by calling
   /// the SetEdgeMask() method on the DIChannel object.
   ///
   /// \param edge The edge of the signal that triggers the state change detection event.
   /// \sa SetEdgeMask, ConfigureTimingForSimpleIO, ConfigureTimingForBufferedIO, ConfigureTimingForTimeSequencing
   UeiDaqAPI void ConfigureTimingForEdgeDetection(tUeiDigitalEdge edge);

   /// \brief Configure the timing object for asynchronous FIFO based I/O
   ///
   /// Configure the timing object for asynchronous FIFO based I/O
   /// Data is read/written when the input/output FIFO reaches the specified watermark level,
   /// when the periodic timer expires or when the no activity timeout expires (whichever happens first)
   /// Set watermark to -1 to disable watermark events
   /// Set period to -1 to disable periodic timer events
   /// Set no activity timeout to -1 to disable no activity events
   ///
   /// \param watermark The watermark level used to configure FIFO asynchronous event. (-1) to disable
   /// \param periodUs The period at which an event is fired when the FIFO level stays below watermark for too long (-1) to disable) 
   /// \param noActivityTimeoutUs The maximum time to wait for any activity (-1) disable
   /// \param maxDataSize The maximum number of values returned along with an event
   UeiDaqAPI void ConfigureTimingForAsynchronousIO(int watermark, int periodUs, int noActivityTimeoutUs, int maxDataSize);

   /// \brief Configure the timing object for time sequencing
   ///
   /// In Time sequencing mode, the timing information is built-in the data buffer
   /// written to the board
   ///
   /// \param samplePerChannel The number of samples to acquire if duration is one-shot.
   /// \param duration The duration of the acquisition/generation, continuous or single-shot. 
   /// \sa ConfigureTimingForSimpleIO, ConfigureTimingForEdgeDetection, ConfigureTimingForBufferedIO
   UeiDaqAPI void ConfigureTimingForTimeSequencing(int samplePerChannel,
                                                   tUeiTimingDuration duration);

   /// \brief Configure the timing object for messaging IO
   ///
   /// Configure the session to do messaging IOs. This timing mode is only available
   /// for Serial, CAN, ARINC-429 and MIL-1553 bus sessions.
   /// The Serial, CAN, ARINC-429 and MIL-1553 bus devices can be programmed to wait for a certain 
   /// number of messages to be received before notifying the session. 
   /// It is also possible to program the maximum amount of time to wait for the
   /// specified number of messages before notifying the session.
   ///
   /// For serial sessions a message is simply a byte, for CAN sessions a message
   /// is a CAN frame represented with the data structure tUeiCANFrame.
   ///
   /// \param bufferSize The miminum number of messages to buffer before notifying the session
   /// \param refreshRate The rate at which the device notifies the session that messages have been received. Set the rate to 0 to be notified immediately when a message is received.
   /// \sa ConfigureTimingForBufferedIO, ConfigureTimingForEdgeDetection, ConfigureTimingForTimeSequencing
   UeiDaqAPI void ConfigureTimingForMessagingIO(int bufferSize, double refreshRate);

   /// \brief Configure the timing object for variable map mode
   ///
   /// Configure the timing object forVMAP mode
   /// VMap mode provides access to a device's FIFO without any buffering
   ///
   /// \param rate The rate at which data is clocked in or out of the FIFO (relevant only for clocked I/Os such as AI, AO, DI and DO).
   /// \sa ConfigureTimingForSimpleIO, ConfigureTimingForEdgeDetection, ConfigureTimingForTimeSequencing
   UeiDaqAPI void ConfigureTimingForVMapIO(double rate);

   /// \brief Configure the digital trigger condition that will start the session
   ///
   /// Configure the digital trigger condition that will start the session
   ///
   /// \param source	The trigger source descriptor
   /// \param edge The edge of the trigger signal that starts the session. 
   UeiDaqAPI void ConfigureStartDigitalTrigger(tUeiTriggerSource source, tUeiDigitalEdge edge);

   /// \brief Configure the digital trigger condition that will stop the session
   ///
   /// Configure the digital trigger condition that will stop the session
   ///
   /// \param source	The trigger source descriptor
   /// \param edge The edge of the trigger signal that stops the session. 
   UeiDaqAPI void ConfigureStopDigitalTrigger(tUeiTriggerSource source, tUeiDigitalEdge edge);

   /// \brief Configure the analog software trigger  
   ///
   /// The analog software trigger looks at every sample acquired on the
   /// specified channel until the trigger condition is met. 
   /// Once the trigger condition is met the application can read the acquired
   /// scans in a buffer.
   /// The trigger level and hysteresis are specified in the same unit as the
   /// measurements.
   ///
   /// \param action The action to execute when the trigger condition is met.
   /// \param condition	The condition for the trigger to occur.
   /// \param triggerChannel The channel to monitor for the trigger condition.
   /// \param level The scaled value that defines the trigger threshold.
   /// \param hysteresis The scaled size of the hysteresis window.
   /// \param preTriggerScans The number of scans to save before the trigger occurs.
   UeiDaqAPI void ConfigureAnalogSoftwareTrigger(tUeiTriggerAction action,
                                                 tUeiTriggerCondition condition, 
                                                 Int32 triggerChannel,
                                                 f64 level,
                                                 f64 hysteresis,
                                                 Int32 preTriggerScans);

   /// \brief Configure the trigger signal that will start or stop the session
   ///
   /// Configure the trigger signal that will start or stop the session
   /// The trigger signal is device dependent, it can be a physical line
   /// on a backplane (such as a PXI trigger) or a software signal used
   /// to synchronize multiple devices (for example starting all layers
   /// in a PowerDNA cube simultaneously).
   ///
   /// \param action The action to execute when the signal occurs. 
   /// \param signal The signal that will transmit the trigger
   UeiDaqAPI void ConfigureSignalTrigger(tUeiTriggerAction action,
                                         std::string signal);

   /// \brief Add an event listener to the session.
   ///
   /// Add an event listener that will be called each time an event is fired.
   ///
   /// \param pListener User implementation of IUeiEventListener interface.
   UeiDaqAPI void AddEventListener(IUeiEventListener *pListener);

   /// \brief Start the session.
   ///
   /// Start the session immediately of after the trigger condition occurred.
   ///
   /// \sa Stop CleanUp IsRunning WaitUntilDone
   UeiDaqAPI void Start();

   /// \brief Check session status.
   ///
   /// Check whether the session is in the running state.
   ///
   /// \return true if the session is still running and false otherwise
   /// \sa Start Stop CleanUp WaitUntilDone
   UeiDaqAPI bool IsRunning();

   /// \brief Wait for the specified time until the session is stopped.
   ///
   /// Wait for the specified time until the session is stopped.
   ///
   /// \param timeout Maximum amount of ms this call will wait.
   /// \return true if the session is finished, false otherwise 
   /// \sa Start Stop CleanUp IsRunning
   UeiDaqAPI bool WaitUntilDone(int timeout);

   /// \brief Stop the session.
   ///
   /// Stop the session immediately and wait for the session to be in 
   /// the stopped state before returning, once it returned you can restart
   /// the session immediately with Start() without having to 
   /// reconfigure channels. timing or triggers.
   ///
   /// \sa Start CleanUp IsRunning WaitUntilDone
   UeiDaqAPI void Stop();

   /// \brief Pause one port in the session.
   ///
   /// Pause the specified messaging port.
   ///
   /// \param port The port to pause
   /// \return the number of elements that are pending and might need to be resent after the pause
   UeiDaqAPI int Pause(int port);

   /// \brief Pause one port in the session.
   ///
   /// Pause the specified messaging port.
   ///
   /// \param port The port to resume 
   UeiDaqAPI void Resume(int port);

   /// \brief Clean-up the session object.
   ///
   /// Stop and Clean-up the session. All session parameters are lost and 
   /// you need to reconfigure channels, timing or triggers if you want to reuse 
   /// the same session object.
   ///
   /// \sa Stop Start IsRunning WaitUntilDone
   UeiDaqAPI void CleanUp();

   /// \brief Enable/Disable session auto-restart
   ///
   /// Enabling auto-restart will automatically stop/start a running session
   /// once it is detected that the device was reset (uually because of a power-cycle).
   ///
   /// \param enable true to auto-restart, false otherwise
   UeiDaqAPI void EnableAutoReStart(bool enable);

   /// \brief Get a pointer to the device object.
   ///
   /// Get a pointer to the device object associated with the session.
   ///
   /// \return A pointer to a CUeiDevice object that can be later used to retrieve information about the device associated to the session.
   UeiDaqAPI CUeiDevice* GetDevice();

   /// \brief Get a pointer to the timing object.
   ///
   /// Get a pointer to the timing object associated with the session.
   ///
   /// \return A pointer to the CUeiTiming object that is used to configure timing informations.
   UeiDaqAPI CUeiTiming* GetTiming();

   /// \brief Get a pointer to the stream object.
   ///
   /// Get a pointer to the stream object associated with the session.
   ///
   /// \return A pointer to the CUeiDataStream object that is used to access data.
   UeiDaqAPI CUeiDataStream* GetDataStream();

   /// \brief Get a pointer to the start trigger object.
   ///
   /// Get a pointer to the start trigger object associated with the session.
   ///
   /// \return A pointer to the CUeiTrigger object that is used to access triggers data. 
   UeiDaqAPI CUeiTrigger* GetStartTrigger();

   /// \brief Get a pointer to the stop trigger object.
   ///
   /// Get a pointer to the stop trigger object associated with the session.
   ///
   /// \return A pointer to the CUeiTrigger object that is used to access triggers data. 
   UeiDaqAPI CUeiTrigger* GetStopTrigger();

   /// \brief Get the number of channels.
   ///
   /// Get the number of channels in the channel list.
   ///
   /// \return number of channels. 
   UeiDaqAPI int GetNumberOfChannels();

   /// \brief Get a channel object by position index in channel list.
   ///
   /// Get the channel object specified by its index in the channel list.
   ///
   /// \param index index of the channel object in the channel list
   /// \return A pointer to the channel object. 
   UeiDaqAPI CUeiChannel* GetChannel(int index);

   /// \brief Get a channel object by physical channel id.
   ///
   /// Get the channel object specified by its physical channel id.
   ///
   /// \param id physical id of the channel object
   /// \return A pointer to the channel object. 
   UeiDaqAPI CUeiChannel* GetChannelById(int id);

   /// \brief Set a custom property
   ///
   /// Set a custom property on the device or subsystem associated with this session
   /// Custom properties are device dependent, refer to the device user manual to learn
   /// about the properties supported by your device
   ///
   /// \param property string containing the name of the property to set
   /// \param valueSize size in bytes of the memory block containing the property value
   /// \param value pointer to the memory block containing the property value
   UeiDaqAPI void SetCustomProperty(std::string property, int valueSize, void* value);

   /// \brief Set an integer custom property
   ///
   /// Set a custom property on the device or subsystem associated with this session
   /// Custom properties are device dependent, refer to the device user manual to learn
   /// about the properties supported by your device
   ///
   /// \param property string containing the name of the property to set
   /// \param value contain the new property value
   UeiDaqAPI void SetCustomProperty(std::string property, int value);

   /// \brief Set a double custom property
   ///
   /// Set a custom property on the device or subsystem associated with this session
   /// Custom properties are device dependent, refer to the device user manual to learn
   /// about the properties supported by your device
   ///
   /// \param property string containing the name of the property to set
   /// \param value contain the new property value
   UeiDaqAPI void SetCustomProperty(std::string property, double value);

   /// \brief Set an integer array custom property
   ///
   /// Set a custom property on the device or subsystem associated with this session
   /// Custom properties are device dependent, refer to the device user manual to learn
   /// about the properties supported by your device
   ///
   /// \param property string containing the name of the property to set
   /// \param arraySize number of integers in the array
   /// \param valueArray contain the new property value
   UeiDaqAPI void SetCustomProperty(std::string property, int arraySize, int* valueArray);

   /// \brief Set a double array custom property
   ///
   /// Set a custom property on the device or subsystem associated with this session
   /// Custom properties are device dependent, refer to the device user manual to learn
   /// about the properties supported by your device
   ///
   /// \param property string containing the name of the property to set
   /// \param arraySize number of doubles in the array
   /// \param valueArray contain the new property value
   UeiDaqAPI void SetCustomProperty(std::string property, int arraySize, double* valueArray);

   /// \brief Get a custom property
   ///
   /// Get a custom property on the device or subsystem associated with this session
   /// Custom properties are device dependent, refer to the device user manual to learn
   /// about the properties supported by your device
   ///
   /// \param property string containing the name of the property to get
   /// \param valueSize size in bytes of the memory block receiving the property value
   /// \param value pointer to the memory block receiving the property value
   UeiDaqAPI void GetCustomProperty(std::string property, int valueSize, void* value);

   /// \brief Get an integer custom property
   ///
   /// Get a custom property on the device or subsystem associated with this session
   /// Custom properties are device dependent, refer to the device user manual to learn
   /// about the properties supported by your device
   ///
   /// \param property string containing the name of the property to get
   /// \param value pointer to the current property value
   UeiDaqAPI void GetCustomProperty(std::string property, int* value);

   /// \brief Get a double custom property
   ///
   /// Get a custom property on the device or subsystem associated with this session
   /// Custom properties are device dependent, refer to the device user manual to learn
   /// about the properties supported by your device
   ///
   /// \param property string containing the name of the property to get
   /// \param value pointer to the current property value
   UeiDaqAPI void GetCustomProperty(std::string property, double* value);

   /// \brief Get an integer array custom property
   ///
   /// Get a custom property on the device or subsystem associated with this session
   /// Custom properties are device dependent, refer to the device user manual to learn
   /// about the properties supported by your device
   ///
   /// \param property string containing the name of the property to get
   /// \param arraySize maximum number of elements that can be stored in value array
   /// \param valueArray pointer to the current property value
   UeiDaqAPI void GetCustomProperty(std::string property, int arraySize, int* valueArray);

   /// \brief Get a double array custom property
   ///
   /// Get a custom property on the device or subsystem associated with this session
   /// Custom properties are device dependent, refer to the device user manual to learn
   /// about the properties supported by your device
   ///
   /// \param property string containing the name of the property to get
   /// \param arraySize maximum number of elements that can be stored in value array
   /// \param valueArray pointer to the current property value
   UeiDaqAPI void GetCustomProperty(std::string property, int arraySize, double* valueArray);

   /// \brief Get the session type
   ///
   /// Get the session type of this session. The session type is set by the first channel
   /// added to the session.
   ///
   /// \return the session type
   UeiDaqAPI tUeiSessionType GetType();

   /// \brief Get the session susbsytem index
   ///
   /// Get the subsystem index of this session. 
   ///
   /// \return the subsystem index
   UeiDaqAPI int GetSubsystem();

   /// \brief Load Session settings from an XML stream
   /// 
   /// Load Session settings from an XML stream, session is ready to be started
   ///
   /// \param xmlSettings String containing the session settings in XML format
   UeiDaqAPI void LoadFromXml(std::string xmlSettings);

   /// \brief Load Session settings from a file
   /// 
   /// Load Session settings from a file, session is ready to be started
   ///
   /// \param sessionFile String containing the session settings file path
   UeiDaqAPI void LoadFromFile(std::string sessionFile);

   /// \cond DO_NOT_DOCUMENT
   CUeiSessionImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond
  
private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiSessionImpl> m_pImpl;
};

}

#endif // __UEISESSION_H__
