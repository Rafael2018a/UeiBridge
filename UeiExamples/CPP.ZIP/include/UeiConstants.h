///
/// \file
/// Typedefs and constants use thoughout the Ueidaq Framework
///

#ifndef __UEICONSTANTS_H__
#define __UEICONSTANTS_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif


#ifdef __cplusplus
namespace UeiDaq
{
#endif

   typedef long long Int64; ///< 32-bit signed integer
   typedef unsigned long long uInt64; ///< 32-bit unsigned integer
   typedef int Int32; ///< 32-bit signed integer
   typedef unsigned int uInt32; ///< 32-bit unsigned integer
   typedef short Int16; ///< 16-bit signed integer
   typedef unsigned short uInt16; ///< 16-bit unsigned integer
   typedef char Int8; ///< 8-bit signed integer
   typedef unsigned char uInt8; ///< 8-bit unsigned integer
   typedef float f32; ///< 32-bit floating point
   typedef double f64; ///< 64-bit double precision floating point

   /// \brief AI input mode
   ///
   /// Input modes for Analog input channels 
   typedef enum _tUeiAIChannelInputMode
   {
      UeiAIChannelInputModeDifferential, ///< Differential mode
      UeiAIChannelInputModeSingleEnded ///< Referenced Single Ended mode
   } tUeiAIChannelInputMode;

   /// \brief AI mux modes
   ///
   /// Mux modes for AI self-test
   typedef enum _tUeiAIChannelMuxPos
   {
      UeiAIChannelMuxPosOff, ///< Normal operations, BIT testing turned off
      UeiAIChannelMuxPosAlt5V, ///< Self-test: 5V alternate input to PGA. Input signal has no effect
      UeiAIChannelMuxPosIn5V ///< Self-test: 5V normal input to PGA. Input signal may effect this (useful for detecting broken wiring)
   } tUeiAIChannelMuxPos;

   /// \brief AO waveform type
   ///
   /// Shape of the waveform to program on a waveform generation capable device
   typedef enum _tUeiAOWaveformType
   {
      UeiAOWaveformTypeSine, ///< Sine waveform
      UeiAOWaveformTypePulse, ///< Square and trapezoid waveform
      UeiAOWaveformTypeTriangle, ///< Triangle waveform
      UeiAOWaveformTypeSawtooth, ///< Sawtooth and ramp waveform
      UeiAOWaveformTypeCustom ///< Custom waveform (4096 points max.)
   } tUeiAOWaveformType;

   /// \brief AO waveform mode
   ///
   /// Timing mode used to generate waveform.
   typedef enum _tUeiAOWaveformMode
   {
      UeiAOWaveformModeDDS, ///< This mode allows immediate change in the waveform frequency at the expense of a higher THD
      UeiAOWaveformModePLL, ///< This mode gives the lowest possible THD but requires 500ms to switch frequency.
   } tUeiAOWaveformMode;

   /// \brief AO waveform transform
   ///
   /// Transform applied to each waveform period
   typedef enum _tUeiAOWaveformXform
   {
      UeiAOWaveformXformNone, ///< Do not apply any transfrom
      UeiAOWaveformXformMirror, ///< Mirrors each period of the waveform
      UeiAOWaveformXformInvert, ///< Inverts waveform
      UeiAOWaveformXformMirrorAndInvert, ///< Mirror and Invert waveform
   } tUeiAOWaveformXform;

   /// \brief AO waveform offset DAC clock source
   ///
   /// Clock used to pace offset DAC
   typedef enum _tUeiAOWaveformOffsetClockSource
   {
      UeiAOWaveformOffsetClockSourceDIO0,     ///< use channel DIO0 line for clock
      UeiAOWaveformOffsetClockSourceDIO1,     ///< use channel DIO1 line for clock                                               
      UeiAOWaveformOffsetClockSourceDAC,      ///< main DAC clock divided is a source of ODAC
      UeiAOWaveformOffsetClockSourcePLL,      ///< PLL is the source of ODAC (independent of main DAC)
      UeiAOWaveformOffsetClockSourceSW        ///< ODAC is clocked by software (DC offset only)
   } tUeiAOWaveformOffsetClockSource;

   /// \brief AO waveform main clock source
   ///
   /// Clock used to pace main DAC
   typedef enum _tUeiAOWaveformClockSource
   {
      UeiAOWaveformClockSourceSYNC2,  ///< use SYNC2 line for clock
      UeiAOWaveformClockSourceSYNC0,  ///< use SYNC0 line for clock
      UeiAOWaveformClockSourceALT0,   ///< use layer channel zero PLL routed to Channel 0 trigger out to clock all channels
      UeiAOWaveformClockSourceTMR,    ///< clock from internal TMR0 timebase
      UeiAOWaveformClockSourceDIO0,   ///< use channel DIO0 line for clock
      UeiAOWaveformClockSourcePLL,    ///< clock from PLL on the channel                                
      UeiAOWaveformClockSourceSW      ///< DAC is clocked by software (DC offset only)
   } tUeiAOWaveformClockSource;

   /// \brief AO waveform clock synchronization
   ///
   /// Specifies where a clock signal should be routed
   /// to synchronize with other channels and/or layers
   /// Route signal to TrgOut to synchronize multiple channels on the same AO-364
   /// Route signal to Sync lines to synchronize multiple AO-364s
   /// Only valid for channel 0 on AO-364
   typedef enum _tUeiAOWaveformClockSync
   { 
      UeiAOWaveformClockRouteNone,            ///< No sync routing 
      UeiAOWaveformClockRouteDIO1ToTrgOut,    ///< Route DIO1/trigger input pin to Channel0 trigger out (channel 0 only)
      UeiAOWaveformClockRouteDIO0ToTrgOut,    ///< Route DIO0/clock input pin to Channel0 trigger out(channel 0 only)
      UeiAOWaveformClockRoutePLLToTrgOut,     ///< Route PLL clock to Channel0 trigger out (channel 0 only)
      UeiAOWaveformClockRoutePLLToSYNC2,   ///< Route PLL clock to SYNC2 (channel 0 only)
      UeiAOWaveformClockRoutePLLToSYNC0    ///< Route PLL clock to SYNC0 (channel 0 only)
   } tUeiAOWaveformClockSync;

   /// \brief AO waveform offset DAC trigger source
   ///
   /// source used to trigger a new period out of the offset DAC
   typedef enum _tUeiAOWaveformOffsetTriggerSource
   {
      UeiAOWaveformOffsetTriggerSourceNone,       ///< no trigger, layer outputs when clock is available (use with NIS clocking)
      UeiAOWaveformOffsetTriggerSourceSYNC3,      ///< use SYNC3 line as a trigger
      UeiAOWaveformOffsetTriggerSourceSYNC1,      ///< use SYNC1 line as a trigger
      UeiAOWaveformOffsetTriggerSourceALT0,       ///< use channel 0 CH0-TIN line for trigger (needs to be connected to a source)
      UeiAOWaveformOffsetTriggerSourceDIO1,       ///< use channel DIO1 line for trigger
      UeiAOWaveformOffsetTriggerSourceSW          ///< use software trigger (simultaneous only within single layer)
   } tUeiAOWaveformOffsetTriggerSource;

   /// \brief AO waveform main DAC trigger source
   ///
   /// source used to trigger a new period out of the main DAC
   typedef enum _tUeiAOWaveformTriggerSource
   {
      UeiAOWaveformTriggerSourceNone,             ///< no trigger, layer outputs when clock is available
      UeiAOWaveformTriggerSourceCH0,              ///< ch0 will deliver clock triggered upon CH0_TRIGIN line
      UeiAOWaveformTriggerSourceSYNC3,            ///< use SYNC3 line as a trigger
      UeiAOWaveformTriggerSourceSYNC1,            ///< use SYNC1 line as a trigger
      UeiAOWaveformTriggerSourceALT0,             ///< use channel 0 CH0-TIN line for trigger (nneds to be connected to a source)
      UeiAOWaveformTriggerSourceDIO1,             ///< use channel DIO1 line for trigger
      UeiAOWaveformTriggerSourceSW                ///< use software trigger (simultaneous only within single layer)
   } tUeiAOWaveformTriggerSource;

   /// \brief AO waveform message type
   ///
   /// AO waveform parameters are changed on the fly by sending commands
   /// to the AO session
   typedef enum _tUeiAOWaveformCommandType
   {
      UeiAOWaveformCommandShape, ///< Specify shape of waveform to be generated 
      UeiAOWaveformCommandSweep, ///< Specify sweep to apply to waveform being generated
      UeiAOWaveformCommandAWF    ///< Load arbitrary waveform data for custom waveform
   } tUeiAOWaveformCommandType;

   /// \brief AO waveform sweep control
   ///
   /// Command used to control sweep operation
   typedef enum _tUeiAOWaveformSweepControl
   {
      UeiAOWaveformSweepUpStart, ///< Start sweep from lower value to higher value
      UeiAOWaveformSweepDownStart, ///< Start sweep from higher value to lower value
      UeiAOWaveformSweepUpDownStart, ///< Start sweep from lower value to higher value to lower value
      UeiAOWaveformSweepDownUpStart, ///< Start sweep from higher value to lower value to higher value
      UeiAOWaveformSweepStop ///< Stop sweep
   } tUeiAOWaveformSweepControl;

   /// \brief DAC mode
   ///
   /// Mode of the DAC connected to channel
   typedef enum _tUeiAODACMode
   {
      UeiAODACModeDisconnected, ///< Disconnects all DACs from the output pin
      UeiAODACModeBothConnected, ///< Connect both DACs to output pin
      UeiAODACModeAConnected, ///< Connect DAC A to output pin
      UeiAODACModeBConnected ///< Connect DAC B to output pin
   } tUeiAODACMode;

   /// \brief AO Diagnostic ADC channel
   ///
   /// The available diagnostic measurements for each AO channel
   typedef enum _tUeiAODiagChannel
   {
      UeiAODiagnosticCurrent, ///< Monitor output current
      UeiAODiagnosticDACAVoltage, ///< Monitor voltage out of DAC A (before relay)
      UeiAODiagnosticDACBVoltage, ///< Monitor voltage out of DAC B (before relay)
      UeiAODiagnosticVoltage, ///< Monitor output voltage (after relay)
      UeiAODiagnosticTemperature, ///< Monitor dual DAC die temperature.
      UeiAODiagnosticNone ///< Do not monitor
   } tUeiAODiagChannel;
   
   /// \brief Counter/Timer mode
   ///
   /// Counter/Timer mode
   typedef enum _tUeiCounterMode
   {
      UeiCounterModeCountEvents, ///< Event counting
      UeiCounterModeMeasurePulseWidth, ///< Pulse width measurement
      UeiCounterModeMeasurePeriod, ///< Period measurement
      UeiCounterModeGeneratePulse, ///< Pulse generation
      UeiCounterModeGeneratePulseTrain, ///< Pulse train generation
      UeiCounterModePulseWidthModulation, ///< Pulse width modulation
      UeiCounterModeQuadratureEncoder, ///< Quadrature encoder measurement
      UeiCounterModeDirectionCounter, ///< Count up or down depending on the state of gate input
      UeiCounterModeTimedPeriodMeasurement, ///< Measure period over a specified duration
      UeiCounterModeBinCounting ///< Count events over a specified duration
   } tUeiCounterMode;

   /// \brief Counter/Timer source
   ///
   /// Source of the clock signal or the signal to count
   typedef enum _tUeiCounterSource
   {
      UeiCounterSourceClock, ///< Use internal clock as a source
      UeiCounterSourceClockDiv2, ///< Use internal clock divided by 2 as a source
      UeiCounterSourceInput, ///< Use external input connector as a source
      UeiCounterSourceCounter0Out, ///< Use Counter 0 output as a source
      UeiCounterSourceCounter1Out, ///< Use Counter 1 output as a source
      UeiCounterSourceCounter2Out ///< Use Counter 2 output as a source
   } tUeiCounterSource;

   /// \brief Counter/Timer gate
   ///
   /// source of the gating signal
   typedef enum _tUeiCounterGate
   {
      UeiCounterGateInternal, ///< Use internal gate driven by software
      UeiCounterGateExternal ///< Use external gate connector
   } tUeiCounterGate;

   /// \brief Counter/Timer gate mode
   ///
   /// gating mode
   typedef enum _tUeiCounterGateMode
   {
      UeiCounterGateModeContinuous, ///< The counter runs continuously after the gate is set
      UeiCounterGateModeSingleShot  ///< The counter runs once after the gate is set
   } tUeiCounterGateMode;

   /// \brief Counter/Timer measurement timebase
   ///
   /// timebase used measure period, frequency and pulse width 
   typedef enum _tUeiCounterCaptureTimebase
   {
      UeiCounterCaptureTimebase1x, ///< Use standard timebase
      UeiCounterCaptureTimebase2x,  ///< Use double resolution timebase if supported by device 
      UeiCounterCaptureTimebaseSync0, ///< Use sync0 as timebase 
      UeiCounterCaptureTimebaseSync1, ///< Use sync1 as timebase 
      UeiCounterCaptureTimebaseSync2, ///< Use sync2 as timebase 
      UeiCounterCaptureTimebaseSync3 ///< Use sync3 as timebase 
   } tUeiCounterCaptureTimebase;

   /// \brief Digital Edge
   ///
   /// Edge of a digital pulse
   typedef enum _tUeiDigitalEdge
   {
      UeiDigitalEdgeRising, ///< Detect rising edge
      UeiDigitalEdgeFalling, ///< Detect falling edge
      UeiDigitalEdgeBoth ///< Detect both edges
   } tUeiDigitalEdge;

   /// \brief Digital Input Mux
   ///
   /// Mode of the digital input mux installed on Industrial
   /// digital input devices.
   typedef enum _tUeiDigitalInputMux
   {
      UeiDigitalInputMuxTriState, ///< voltage supply disconnected from input line
      UeiDigitalInputMuxPullUp,   ///< voltage supply is connected to input line through a pull-up resistor
      UeiDigitalInputMuxDiag      ///< voltage supply is directly connected to input line for diagnostic
   } tUeiDigitalInputMux;

   /// \brief Digital output termination
   ///
   /// specified termination resistor applied to a digital output
   typedef enum _tUeiDigitalTermination
   {
      UeiDigitalTerminationNone,  ///< No termination
      UeiDigitalTerminationPullUp,  ///< termination resistor is connected between VCC and digital line
      UeiDigitalTerminationPullDown,  ///< termination resistor is connected between Ground and digital line
      UeiDigitalTerminationPullUpPullDown  ///< termination resistors are connected between digital line and Ground and VCC
   } tUeiDigitalTermination;

   /// \brief Timing Duration
   ///
   /// Duration of a timed operation
   typedef enum _tUeiTimingDuration
   {
      UeiTimingDurationContinuous, ///< Continuous timed operation
      UeiTimingDurationSingleShot ///< One-shot timed operation
   } tUeiTimingDuration;

   /// \brief Timing mode
   ///
   /// Mode of a timed operation
   typedef enum _tUeiTimingMode
   {
      UeiTimingModeSimpleIO, ///< Simple I/O mode. The data is read/written one scan at a time. It is timed by software
      UeiTimingModeBufferedIO, ///< Buffered I/O mode. The data is read/written in buffers. It is timed by a hardware internal or external clock
      UeiTimingModeChangeDetection, ///< Digital line state change detection
      UeiTimingModeTimeSequencing, ///< Time Sequencing 
      UeiTimingModeDirectDataMapping, ///< Direct data mapping I/O mode. The data values on inputand output channels are mirrored on the host. It is timed by a hardware internal or external clock
      UeiTimingModeMessagingIO,  ///<  The data is read/written in messages transferred over a communication bus
      UeiTimingModeAsyncIO, ///< Asynchronous I/O mode. The data is read/written upon a hardware asynhronous event
      UeiTimingModeAsyncVMapIO, ///< lower-level version of ACB, data is pulled directly from device's FIFO without any intermediate buffering
      UeiTimingModeVMapIO ///< low-level mode that provides direct access to device's FIFO
   } tUeiTimingMode;

   /// \brief Clock source
   ///
   /// Clock source for a timed operation
   typedef enum _tUeiTimingClockSource
   {
      UeiTimingClockSourceInternal, ///< Internal hardware clock timing
      UeiTimingClockSourceExternal, ///< External clock timing
      UeiTimingClockSourceContinuous, ///< Timing clock is continuous and runs at the maximum capability of the hardware
      UeiTimingClockSourceSoftware, ///< Software timing
      UeiTimingClockSourceSlave, ///< Board synchronization timing
      UeiTimingClockSourceExternalDividedByCounter, ///< External clock divided by a counter
      UeiTimingClockSourceSignal   ///< The clock is coming from an internal signal
   } tUeiTimingClockSource;

   /// \brief Session type
   ///
   /// Session type
   typedef enum _tUeiSessionType
   {
      UeiSessionTypeAI, ///< Analog input session
      UeiSessionTypeAO, ///< Analog output session
      UeiSessionTypeDI, ///< Port level digital input session
      UeiSessionTypeDO, ///< Port level digital output session
      UeiSessionTypeCI, ///< Counter input session
      UeiSessionTypeCO, ///< Counter output session
      UeiSessionTypeInfo, ///< Info retrieval session
      UeiSessionTypeSerial, ///< Serial port communication session
      UeiSessionTypeSynchronousSerial, ///< IRIG session
      UeiSessionTypeCAN, ///< CAN bus communication session
      UeiSessionTypeARINC, ///< ARINC-429 bus communication session
      UeiSessionTypeMIL1553, ///< MIL-STD-1553B bus communication session
      UeiSessionTypeIRIG, ///< IRIG session
      UeiSessionTypeSync, ///< Synchronization session
      UeiSessionTypeDILineLevel, ///< Line level digital input session
      UeiSessionTypeDOLineLevel, ///< Line level digital output session
      UeiSessionTypeVR, ///< Variable reluctance input session
      UeiSessionTypeCSDB, ///< CSDB communication session
      UeiSessionTypeSSI, ///< SSI communication session
      UeiSessionTypeSPI, ///< SPI communication session
      UeiSessionTypeMUX, ///< MUX session
      UeiSessionTypeI2C, ///< I2C communication session
      UeiSessionTypeDiagnostic, ///< Diagnostic input session
   } tUeiSessionType;

   /// \brief Session state
   ///
   /// Session state
   typedef enum _tUeiSessionState
   {
      UeiSessionStateUnknown, ///< Session is in an unknown state
      UeiSessionStateReserved, ///< Session has reserved resources
      UeiSessionStateConfigured, ///< Session is configured and ready
      UeiSessionStateRunning, ///< Session is running
      UeiSessionStateFinished ///< Session is finished
   } tUeiSessionState;

   /// \brief Asynchronous event
   ///
   /// Asynchronous event
   typedef enum _tUeiEvent
   {
      UeiEventFrameDone, ///< A frame has been filled
      UeiEventBufferDone, ///< All the frames of a buffer have been filled
      UeiEventError, ///< An error occurred while the session was running
      UeiEventDigitalIn, ///< Digital input line state change detected
      UeiEventSessionDone,  ///< The session is done, it either acquired or generated the specified amount of data
      UeiEventFIFOWatermark, ///< Watermark level is reached in the FIFO
      UeiEventPeriodicTimer ///< Periodic timer expired
   } tUeiEvent;

   /// \brief Trigger Source
   ///
   /// Trigger Source
   typedef enum _tUeiTriggerSource
   {
      UeiTriggerSourceImmediate, ///< Session is triggered as soon as it is started
      UeiTriggerSourceSoftware,  ///< Session is triggered when a software trigger condition is satisfied
      UeiTriggerSourceExternal,  ///< Session is triggered by an external signal
      UeiTriggerSourceSignal,    ///< Session is triggered by a software or internal signal
      UeiTriggerSourceNext1PPS,  ///< Session is triggered upon the next 1PPS pulse (only valid for synchronization sessions)
      UeiTriggerSourceSyncLine0,       ///< Session is triggered by backplane synchronization line 0
      UeiTriggerSourceSyncLine1,       ///< Session is triggered by backplane synchronization line 1
      UeiTriggerSourceSyncLine2,       ///< Session is triggered by backplane synchronization line 2
      UeiTriggerSourceSyncLine3        ///< Session is triggered by backplane synchronization line 3
   } tUeiTriggerSource;

   /// \brief Trigger Condition
   ///
   /// Trigger Condition
   typedef enum _tUeiTriggerCondition
   {
      UeiTriggerConditionRising, ///< The trigger occurs when the signal has a positive slope when passing through the specified value.
      UeiTriggerConditionFalling, ///< The trigger occurs when the signal has a negative slope when passing through the specified value.
   } tUeiTriggerCondition;

   /// \brief Trigger Action
   ///
   /// Trigger Action
   typedef enum _tUeiTriggerAction
   {
      UeiTriggerActionStartSession,  ///< The session will start when the trigger occurs
      UeiTriggerActionStopSession,   ///< The session will stop when the trigger occurs
      UeiTriggerActionBuffer,        ///< Each buffer will be acquired or generated when the trigger occurs 
   } tUeiTriggerAction;

   /// \brief Buffer access reference
   ///
   /// Specifies what position to use as a reference in the framework's internal buffer
   typedef enum _tUeiDataStreamRelativeTo
   {
      UeiDataStreamRelativeToCurrentPosition, ///< Read/write data at the specified offset relative to the last sample read or written
      UeiDataStreamRelativeToMostRecentSample ///< Read/write data at the specified offset relative to the most current sample acquired or generated
   } tUeiDataStreamRelativeTo;

   /// \brief Thermocouple types
   ///
   /// Thermocouple types 
   typedef enum _tUeiThermocoupleType
   {
      UeiThermocoupleTypeE, ///< Type E thermocouple
      UeiThermocoupleTypeJ, ///< Type J thermocouple
      UeiThermocoupleTypeK, ///< Type K thermocouple
      UeiThermocoupleTypeR, ///< Type R thermocouple
      UeiThermocoupleTypeS, ///< Type S thermocouple
      UeiThermocoupleTypeT, ///< Type T thermocouple
      UeiThermocoupleTypeB, ///< Type B thermocouple
      UeiThermocoupleTypeN, ///< Type N thermocouple
      UeiThermocoupleTypeC  ///< Type C thermocouple
   } tUeiThermocoupleType;

   /// \brief Cold junction sensor type
   /// 
   /// Some terminal block connectors such as the DNA-STP-AIU include a built-in
   /// cold junction sensor. You can also provide your own.
   typedef enum _tUeiColdJunctionCompensationType
   {
      UeiCJCTypeBuiltIn, ///< Use the CJC sensor built-in the connector block
      UeiCJCTypeConstant, ///< Use a constant value for cold-junction temperature
      UeiCJCTypeResource   ///< Use a resource string to describe how to measure cold junction temperature
   } tUeiColdJunctionCompensationType;

   /// \brief Temperature scales 
   ///
   /// Temperature scales 
   typedef enum _tUeiTemperatureScale
   {
      UeiTemperatureScaleCelsius, ///< Celsius temperature scale
      UeiTemperatureScaleFahrenheit, ///< Fahrenheit temperature scale
      UeiTemperatureScaleKelvin, ///< Kelvin temperature scale
      UeiTemperatureScaleRankine  ///< Rankine temperature scale
   } tUeiTemperatureScale;

   /// \brief RTD sensor type
   ///
   /// RTD sensors are specified using the "alpha" (a) constant
   /// It is also known as the temperature coefficient of resistance, 
   /// and symbolizes the resistance change factor per degree of 
   /// temperature change.
   /// The RTD type is used to select the proper coefficients A, B and C
   /// for the Callendar Van-Dusen equation used to convert resistance
   /// measurements to temperature.
   typedef enum _tUeiRTDType
   {
      UeiRTDType3750, ///< Low-cost Platinum RTD. a=0.00375 A=3.81E�3 B=-6.02E-7 C=-6.0E-12
      UeiRTDType3850, ///< IEC-751 European standard Platinum RTD. a=0.00385 A=3.9083E-3 B=-5.775E-7 C=-4.183E-12  
      UeiRTDType3902, ///< US Industrial standard Platinum RTD. a=0.003902 A=3.96E-3 B=-5.93E-7 C=-4.3E-12
      UeiRTDType3911, ///< ASTM 1137 American standard Platinum RTD. a=0.003911 A=3.9692E-3 B=�5.8495E-7 C=�4.233E-12
      UeiRTDType3916, ///< JISC-1604 Japanese standard Platinum RTD. a=0.003916 A=3.9739E-3 B=�5.870E-7 C=�4.4E-12
      UeiRTDType3920, ///< Old American standard Platinum RTD. a=0.00392 A=3.9787E-3 B=�5.8686E-7 C=�4.167E-12
      UeiRTDType3926, ///< ITS-90 standard Platinum RTD. a=0.003926 A=3.9848E-3 B=�5.870E-7 C=�4.0E-12
      UeiRTDType3928, ///< ITS-90 standard Platinum RTD. a=0.003928 A=3.9888E-3 B=�5.915E-7 C=�3.85E-12
      UeiRTDTypeCustom ///< Custom RTD. Specify A,B and C using the RTDChannel object attributes
   } tUeiRTDType;

   /// \brief Reference resistor type
   ///
   /// Reference resistors are used to measure the current flowing through RTDs
   /// or other resistive measurement devices.
   /// Some terminal block connectors such as the DNA-STP-AIU include a built-in
   /// reference resistor. You can also provide your own.
   typedef enum _tUeiReferenceResistorType
   {
      UeiRefResistorBuiltIn,///< Use the reference resistor built-in the terminal block
      UeiRefResistorExternal///< Use an external reference resistor connected on a dedicated channel
   } tUeiReferenceResistorType;

   /// \brief Strain gage bridge configurations 
   ///
   /// Strain gage bridge configurations 
   typedef enum _tUeiStrainGageBridgeType
   {
      UeiStrainGageQuarterBridgeI, ///< Quarter Bridge I strain gage
      UeiStrainGageQuarterBridgeII, ///< Quarter Bridge II strain gage
      UeiStrainGageHalfBridgeI, ///< Half Bridge I strain gage
      UeiStrainGageHalfBridgeII, ///< Half Bridge II strain gage
      UeiStrainGageFullBridgeI, ///< Full Bridge I strain gage
      UeiStrainGageFullBridgeII, ///< Full Bridge II strain gage
      UeiStrainGageFullBridgeIII ///< Full Bridge III strain gage
   } tUeiStrainGageBridgeType;

   /// \brief Sensor bridge configurations 
   ///
   /// Sensor bridge configurations 
   typedef enum _tUeiSensorBridgeType
   {
      UeiSensorQuarterBridge, ///< Quarter Bridge sensor
      UeiSensorHalfBridge, ///< Half Bridge sensor
      UeiSensorFullBridge, ///< Full Bridge sensor
      UeiSensorNoBridge ///< No bridge
   } tUeiSensorBridgeType;

   /// \brief Measurement type
   ///
   /// Measurement type
   typedef enum _tUeiMeasurementType
   {
      UeiMeasurementVoltage,///<Voltage measurement
      UeiMeasurementThermocouple,///<Temperature measurement with thermocouples
      UeiMeasurementStrainGage,///<Strain gage measurement
      UeiMeasurementVoltageWithExcitation,///<Voltage measurement with excitation (typically for load cells)
      UeiMeasurementRTD,///<Temperature measurement with RTDs
      UeiMeasurementResistance,///<Resistance measurement
      UeiMeasurementAccelerometer,///<Accelrometer measurement
      UeiMeasurementLVDT,///<Position Measurement with LVDT or RVDT
      UeiMeasurementSynchroResolver,///<Angle measurement with Synchro or Resolver
      UeiMeasurementCurrent ///<Current measurement
   } tUeiMeasurementType;

   /// \brief OS Type
   ///
   /// OS Type
   typedef enum _tUeiOSType
   {
      UeiOSWindows,///<Microsoft Windows NT/2000/XP/2003 operating systems
      UeiOSLinux,///<Linux operating system
      UeiOSPharlapEts,///<Ardence Pharlap ETS operating system
      UeiOSMacOS///<Apple MacOS operating system
   } tUeiOSType;

   /// \brief Serial port mode
   ///
   /// Serial port mode
   typedef enum _tUeiSerialPortMode
   {
      UeiSerialModeRS232,///<RS-232 mode
      UeiSerialModeRS485HalfDuplex,///<RS-485 Half-Duplex mode
      UeiSerialModeRS485FullDuplex///<RS-485 Full-Duplex mode
   } tUeiSerialPortMode;

   /// \brief Serial port speed
   ///
   /// Serial port pseed
   typedef enum _tUeiSerialPortSpeed
   {
      UeiSerialBitsPerSecond110,///< 110 bits per second
      UeiSerialBitsPerSecond300,///< 300 bits per second
      UeiSerialBitsPerSecond600,///< 600 bits per second
      UeiSerialBitsPerSecond1200,///< 1200 bits per second
      UeiSerialBitsPerSecond2400,///< 2400 bits per second
      UeiSerialBitsPerSecond4800,///< 4800 bits per second
      UeiSerialBitsPerSecond9600,///< 9600 bits per second
      UeiSerialBitsPerSecond14400,///< 14400 bits per second
      UeiSerialBitsPerSecond19200,///< 19200 bits per second
      UeiSerialBitsPerSecond28800,///< 28800 bits per second
      UeiSerialBitsPerSecond38400,///< 38400 bits per second
      UeiSerialBitsPerSecond57600,///< 57600 bits per second
      UeiSerialBitsPerSecond115200,///< 115200 bits per second
      UeiSerialBitsPerSecond128000,///< 128000 bits per second
      UeiSerialBitsPerSecond250000,///< 250000 bits per second
      UeiSerialBitsPerSecond256000,///< 256000 bits per second (available only in RS-485 mode)
      UeiSerialBitsPerSecond1000000,///< 1000000 bits per second (available only in RS-485 mode)
      UeiSerialBitsPerSecondCustom///< Use custom port speed (to be programmed using port attribute)
   } tUeiSerialPortSpeed;

   /// \brief Serial port number of data bits per character frame
   ///
   /// Serial port number of data bits per character frame
   typedef enum _tUeiSerialPortDataBits
   {
      UeiSerialDataBits5,///<5 bits of data per frame
      UeiSerialDataBits6,///<6 bits of data per frame
      UeiSerialDataBits7,///<7 bits of data per frame
      UeiSerialDataBits8///<8 bits of data per frame
   } tUeiSerialPortDataBits;

   /// \brief Serial port parity
   ///
   /// Serial port parity
   typedef enum _tUeiSerialPortParity
   {
      UeiSerialParityNone,///<No parity bit
      UeiSerialParityOdd,///<Set parity bit to 1 if the frame contains an even number of bit(s) set to 1
      UeiSerialParityEven,///<Set parity bit to 0 if the frame contains an odd number of bit(s) set to 1
      UeiSerialParityMark,///<Always set parity bit to 1
      UeiSerialParitySpace///<Always set parity bit to 0
   } tUeiSerialPortParity;

   /// \brief Serial port number of stop bits
   ///
   /// Serial port number of stop bits
   typedef enum _tUeiSerialPortStopBits
   {
      UeiSerialStopBits1,     ///< Use one stop bit at the end of each frame
      UeiSerialStopBits1_5,   ///< Use one and a half stop bits at the end of each frame
      UeiSerialStopBits2      ///< Use two stop bits at the end of each frame
   } tUeiSerialPortStopBits;

   /// \brief Serial port flow control setting
   ///
   /// Serial port flow control setting
   typedef enum _tUeiSerialPortFlowControl
   {
       UeiSerialFlowControlNone,   ///< No flow control
       UeiSerialFlowControlRtsCts, ///< Hardware flow control, stop sending when CTS is held low, set RTS low when input FIFO is full
       UeiSerialFlowControlXonXoff ///< Software flow control, not implemented yet
   } tUeiSerialPortFlowControl;

   /// \brief Minor frame delay mode
   ///
   /// Minor framing configures a delay between groups of characters.
   /// The mode selects how minor frames are defined
   typedef enum _tUeiSerialPortMinorFrameMode
   {
      UeiSerialMinorFrameModeFixedLength, ///< Minor frame is a fixed number of characters
      UeiSerialMinorFrameModeZeroChar, ///< Minor frame is terminated by a NULL character (0x00)
      UeiSerialMinorFrameModeVariableLength ///< Minor frame is prefixed with a byte containing the length of the frame
   } tUeiSerialPortMinorFrameMode;

   /// \brief CUeiSerialReader data types
   ///
   /// Data type options for CUeiSerialReader.
   typedef enum _tUeiSerialReadDataType
   {
      UeiSerialReadDataTypeNoTimestamp = 0, ///< No timestamp with data
      UeiSerialReadDataTypeTimestamp = 1 ///< Timestamped data
   } tUeiSerialReadDataType;

   /// \brief CAN port speed
   ///
   /// CAN port speed
   typedef enum _tUeiCANPortSpeed
   {
      UeiCANBitsPerSecond10K, ///< 10000 bits per second
      UeiCANBitsPerSecond20K, ///< 20000 bits per second
      UeiCANBitsPerSecond50K, ///< 50000 bits per second
      UeiCANBitsPerSecond100K, ///< 100000 bits per second
      UeiCANBitsPerSecond125K, ///< 125000 bits per second
      UeiCANBitsPerSecond250K, ///< 250000 bits per second
      UeiCANBitsPerSecond500K, ///< 500000 bits per second
      UeiCANBitsPerSecond800K, ///< 800000 bits per second
      UeiCANBitsPerSecond1M ///< 1000000 bits per second
   } tUeiCANPortSpeed;

   /// \brief CAN frame format
   ///
   /// CAN frame format
   typedef enum _tUeiCANFrameFormat
   {
      UeiCANFrameBasic,    ///< CAN 2.0a - basic CAN frame format (11 bit identifier)
      UeiCANFrameExtended  ///< CAN 2.0b - extended CAN frame format (29 bit identifier)
   } tUeiCANFrameFormat;

   /// \brief CAN frame type
   ///
   /// Specifies the type of CAN frame sent or received
   typedef enum _tUeiCANFrameType
   {
      UeiCANFrameTypeData,    ///< Data CAN frame
      UeiCANFrameTypeRemote,  ///< Remote CAN frame
      UeiCANFrameTypeError    ///< Error CAN frame
   } tUeiCANFrameType;

   /// \brief CAN operation mode
   ///
   /// CAN operation mode
   typedef enum _tUeiCANPortMode
   {
      UeiCANPortModeNormal,   ///< Normal mode
      UeiCANPortModePassive   ///< Passive, listen only mode
   } tUeiCANPortMode;

   /// \brief Wheatstone bridge branches
   ///
   /// Specify one of the four branches on a Wheatstone bridge
   /// \code     _______ P+
   ///          /\
   ///     R1  X  X  R4
   ///        X    X
   ///   S-  /      \ S+
   ///       \      /
   ///        X    X
   ///     R2  X  X  R3
   ///          \/______ P-
   /// \endcode
   typedef enum _tUeiWheatstoneBridgeBranch
   {
      UeiWheatstoneBridgeR1,///< R1 branch (P+ S-)
      UeiWheatstoneBridgeR2,///< R2 branch (S- P-)
      UeiWheatstoneBridgeR3,///< R3 branch (S+ P-)
      UeiWheatstoneBridgeR4 ///< R4 branch (P+ S+)  
   } tUeiWheatstoneBridgeBranch;

   /// \brief The source of a synchronization signal
   ///
   /// The source of a synchronization signal
   typedef enum _tUeiSignalSource
   {
      UeiSignalStartTrigger,  ///< start trigger 
      UeiSignalStopTrigger,   ///< stop trigger
      UeiSignalScanClock,     ///< Scan clock signal
      UeiSignalConvertClock,  ///< Convert Clock signal
      UeiSignalBackplane,     ///< One of the synchronization lines built-in the back plane
      UeiSignalSoftware,      ///< A software signal that is emmited with the FireSignal API
      UeiSignalExternal,      ///< The external sync connector (Only on PowerDNA)
      UeiSignalPLL,           ///< The PLL frequency generator running at multiplied scan rate for devices that require it (Only on PowerDNA)
      UeiSignalSync1PPS       ///< Clock signal generated by ADPLL and event module
   } tUeiSignalSource;

   /// \brief Sensor with excitation wiring schemes
   ///
   /// Sensor with excitation wiring schemes
   typedef enum _tUeiWiringScheme
   {
      UeiTwoWires,  ///< Sensor is connected using two wires
      UeiFourWires, ///< Sensor is connected using four wires
      UeiSixWires,  ///< Sensor is connected using six wires
      UeiThreeWires ///< Sensor is connected using three wires
   } tUeiWiringScheme;

   /// \brief ARINC port speed
   ///
   /// ARINC port speed
   typedef enum _tUeiARINCPortSpeed
   {
      UeiARINCBitsPerSecond12500, ///< 12500 bits per second
      UeiARINCBitsPerSecond100000, ///< 100000 bits per second
   } tUeiARINCPortSpeed;

   /// \brief ARINC port parity
   ///
   /// ARINC port parity
   typedef enum _tUeiARINCPortParity
   {
      UeiARINCParityNone,///<No parity bit
      UeiARINCParityOdd,///<Set parity bit to 1 if the frame contains an even number of bit(s) set to 1
      UeiARINCParityEven///<Set parity bit to 0 if the frame contains an odd number of bit(s) set to 1
   } tUeiARINCPortParity;

   /// \brief ARINC port frame counting mode
   ///
   /// ARINC port frame counting mode
   typedef enum _tUeiARINCPortFrameCountingMode
   {
      UeiARINCFrameCountAll, ///< Count all frames
      UeiARINCFrameCountGood, ///< Only count correcty received frames
      UeiARINCFrameCountFIFO, ///< Only count frames placed into the FIFO
      UeiARINCFrameCountTrigger, ///< Only count frames that triggered scheduler
      UeiARINCFrameParityError ///< Only count frames with parity error
   } tUeiARINCPortFrameCountingMode;

   /// \brief ARINC message type
   ///
   /// Specifies the type of message sent or received by the ARINC stream
   typedef enum _tUeiARINCMessageType
   {
      UeiARINCMessageTypeWord, ///< Send/Receive ARINC words
      UeiARINCMessageTypeScheduledWord, ///< Modify scheduled ARINC words
      UeiARINCMessageTypePauseScheduler, ///< Pause Scheduler
      UeiARINCMessageTypeResumeScheduler, ///< Resume Scheduler
      UeiARINCMessageTypeSetMajorMinorActivePage ///< Set the mask 
   } tUeiARINCMessageType;

   /// \brief ARINC scheduler type
   ///
   /// Specifies the type of scheduler used to emit scheduled words out of a given ARINC-429 port
   typedef enum _tUeiARINCSchedulerType
   {
      UeiARINCSchedulerTypeNormal, ///< Normal ARINC scheduler 
      UeiARINCSchedulerTypeFramed, ///< Framed ARINC scheduler
      UeiARINCSchedulerTypeMajorMinorFrame ///< Major/Minor frame ARINC scheduler
   } tUeiARINCSchedulerType;

   /// \brief 1553 filter setting
   ///
   /// 1553 filter settings
   typedef enum _tUeiMIL1553FilterType
   {
      UeiMIL1553FilterByRt, ///< Filter only by RT numbers, all SAs of any lenght are enabled
      UeiMIL1553FilterByRtSa,  ///< Each RT/SA combination should be declared
      UeiMIL1553FilterByRtSaSize,   ///< Each RT/SA combination and size of Rx/Tx Min/Max data should be declared
      UeiMIL1553FilterValidationEntry   ///< Validation entry is written directly
   } tUeiMIL1553FilterType;

   /// \brief 1553 port coupling
   ///
   /// 1553 port coupling
   typedef enum _tUeiMIL1553PortCoupling
   {
      UeiMIL1553CouplingDisconnected, ///< Device is disconnected from the bus
      UeiMIL1553CouplingTransformer,  ///< Bus is connected using transformer
      UeiMIL1553CouplingLocalStub,    ///< Stub is located right on the PCB (requres special hardware)
      UeiMIL1553CouplingDirect ///< Direct coupling - no transformer
   } tUeiMIL1553PortCoupling;

   /// \brief 1553 port operating mode
   ///
   /// 1553 port operating mode
   typedef enum _tUeiMIL1553PortOpMode
   {
      UeiMIL1553OpModeBusMonitor, ///< Bus Monitor Mode
      UeiMIL1553OpModeRemoteTerminal,  ///< Remote Terminal Mode
      UeiMIL1553OpModeBusController,   ///< Bus Controller Mode
      UeiMIL1553OpModeARINC708         ///< ARINC-708 Mode (1553 is shut off)
   } tUeiMIL1553PortOpMode;

   /// \brief 1553 port bus
   ///
   /// 1553 port active bus
   typedef enum _tUeiMIL1553PortActiveBus
   {
      UeiMIL1553OpModeBusA,    ///< Bus A is used (default for transmission)
      UeiMIL1553OpModeBusB,    ///< Bus B is used
      UeiMIL1553OpModeBusBoth,    ///< Bus Controller Mode (default for listening)
   } tUeiMIL1553PortActiveBus;

   /// \brief 1553 endian (ARINC-708 model only)
   ///
   /// 1553 port endian
   typedef enum _tUeiMIL1553Endian
   {
      UeiMIL1553SmallEndian,  ///< Use small-endian notation for Rx or Tx (ARINC-708 only)
      UeiMIL1553BigEndian,    ///< Use big-endian notation for Rx or Tx
   } tUeiMIL1553Endian;

   /// \brief 1553 major frame flags
   ///
   ///  MIL-1553 BC major frame flags
   typedef enum _tUeiMIL1553BCMajorFlags
   {
      UeiMIL1553MjLink = (1L<<9),           ///< Do not wait for the MN clock to execute this entry
      UeiMIL1553MjEnable = (1L<<8),         ///< Major entry is enabled
      UeiMIL1553MjExecuteOnce = (1L<<7),    ///< Execute entry once, then disable it
      UeiMIL1553MjSendMessage = (1L<<6),    ///< Send asynchronous message to user when executed
      UeiMIL1553MjSwapEnabled = (1L<<5),    ///< Swap this entry on the next swap cycle (enable if disabled and vice versa)
      UeiMIL1553MjDoneOnce = (1L<<4)        ///< (status) Entry was executed at least once (R/O)
   } tUeiMIL1553BCMajorFlags;

   /// \brief 1553 minor frame flags
   ///
   ///  MIL-1553 BC minor frame flags
   typedef enum _tUeiMIL1553BCMinorFlags
   {
      UeiMIL1553MnEnable = (1L<<8),         ///< Minor entry is enabled
      UeiMIL1553MnExecuteOnce = (1L<<8)+(1L<<7),    ///< Execute entry once, then disable it
      UeiMIL1553MnCurrentBusB = (1L<<6),    ///< (status) Bus B selected as a current bus
      UeiMIL1553MnRTRecovered = (1L<<5),    ///< (status) RT had failed but since recovered
      UeiMIL1553MnNDoneOnce = (1L<<4),      ///< (status) Entry was executed at least once
      UeiMIL1553MnExecError = (1L<<3)       ///< (status) Label execution error
   } tUeiMIL1553BCMinorFlags;


   /// \brief 1553 commands
   ///
   /// STD-MIL-1553 commands
   typedef enum _tUeiMIL1553CommandType
   {
      UeiMIL1553CmdBCRT,     ///< Remote terminal to receive data from bus controller
      UeiMIL1553CmdRTBC,     ///< Remote terminal to transmit data to bus controller
      UeiMIL1553CmdRTRT,   ///< One remote terminal to transmit data to another remote terminal
      UeiMIL1553CmdModeTxNoData,  ///< Status word
      UeiMIL1553CmdModeTxWithData, ///< Remote terminal to transmit data and/or status word to bus controller
      UeiMIL1553CmdModeRxWithData,  ///< Remote terminal to receive data for mode command from bus controller
      UeiMIL1553CmdBCRTBroadcast, ///< Remote terminal to receive broadcast data from bus controller
      UeiMIL1553CmdRTRTBroadcast, ///< One remote terminal to broadcast data to other remote terminal
      UeiMIL1553CmdModeTxNoDataBroadcast, ///< Mode command without data, remote terminals should not reply
      UeiMIL1553CmdModeRxWithDataBroadcast,  ///< Mode command with data, remote terminals should receive data
   } tUeiMIL1553CommandType;

   /// \brief 1553 control command
   ///
   /// STD-MIL-1553 control commands
   typedef enum _tUeiMIL1553RTControlType
   {
      UeiMIL1553Disable,        ///< Disable RT functionality
      UeiMIL1553Enable,         ///< Enable RT functionality
      UeiMIL1553EnableMask,     ///< Enable RT functionality by mask
      UeiMIL1553RTSetRtBcBlock, ///< Select which block to use for data for RT-&gt;BC command (Tx)
      UeiMIL1553RTSetBcRtBlock, ///< Select which block to use for data for BC-&gt;RT command (Rx)
      UeiMIL1553RTSetValid,     ///< Write validation entry directly to RT
      UeiMIL1553RTResponseTiming ///< Set inter message gap
   } tUeiMIL1553RTControlType;

   /// \brief 1553 commands
   ///
   /// STD-MIL-1553 commands
   typedef enum _tUeiMIL1553BCRetryType
   {
      UeiMIL1553BCR_IRT   =(1L<<14), ///< Retry on incorrect RT# in status 
      UeiMIL1553BCR_RUS   =(1L<<13), ///< Retry on unexpected status reception
      UeiMIL1553BCR_RUD   =(1L<<12), ///< Retry on unexpected data reception
      UeiMIL1553BCR_RWB   =(1L<<11), ///< Retry on wrong bus response
      UeiMIL1553BCR_RIS   =(1L<<10), ///< Retry on illegal bits set in status
      UeiMIL1553BCR_RBB   =(1L<<9),  ///< Retry on busy bit in status
      UeiMIL1553BCR_RTE   =(1L<<8),  ///< Retry on bus timing error
      UeiMIL1553BCR_RWC   =(1L<<7),  ///< Retry on word count
      UeiMIL1553BCR_RE    =(1L<<6),  ///< Reenable command transmission on succesfull status reply
      UeiMIL1553BCR_RNR   =(1L<<5),  ///< Retry on no-response
      UeiMIL1553BCR_ERE   =(1L<<4),  ///< Enable re-transmit on alternative bus each retry
      UeiMIL1553BCR_ESR   =(1L<<3)   ///< Enable periodic status request command when retry
   } tUeiMIL1553BCRetryType;


   /// \brief 1553 BC frame type
   ///
   /// MIL-1553 BC frame type
   typedef enum _tUeiMIL1553BCFrameType
   {
      UeiMIL1553BCFrameUndef,     ///< Undefined frame
      UeiMIL1553BCFrameMajor,     ///< Major frame
      UeiMIL1553BCFrameMinor      ///< Minor frame
   } tUeiMIL1553BCFrameType;

   /// \brief 1553 mode command codes
   ///
   /// STD-MIL-1553 mode command codes. These mode codes are encoded in the Word Count field
   typedef enum _tUeiMIL1553ModeCommandTypes
   {
      UeiMIL1553ModeDynamicBusControl = 0x0,     ///< DBC, Data=No, Broadcast=No
      UeiMIL1553ModeSynchronize = 0x1,     ///< Synchronize terminals, Data=No, Broadcast=Yes
      UeiMIL1553ModeTransmitStatusWord = 0x2,    ///< Transmit status word for RT, Data=No, Broadcast=No
      UeiMIL1553ModeStartSelfTest = 0x3,    ///< Initiate self test, Data=No, Broadcast=Yes
      UeiMIL1553ModeTxShutdown = 0x4,   ///< Transmitter shutdown, Data=No, Broadcast=Yes
      UeiMIL1553ModeTxShutdownOver = 0x5,   ///< Transmitter shutdown override, Data=No, Broadcast=Yes
      UeiMIL1553ModeInhTerminalFlag = 0x6,   ///< Inhibit terminal flag bit, Data=No, Broadcast=Yes
      UeiMIL1553ModeInhTerminalFlagOver = 0x7,   ///< Override Inhibit terminal flag bit, Data=No, Broadcast=Yes
      UeiMIL1553ModeResetRt = 0x8,   ///< Reset remote terminal, Data=No, Broadcast=Yes
      UeiMIL1553ModeTxVectorWord = 0x10,   ///< Transmit vector word, Data=Yes, Broadcast=No
      UeiMIL1553ModeSynchronizeData = 0x11,   ///< Synchronize with synchronization data, Data=Yes, Broadcast=Yes
      UeiMIL1553ModeTxLastCommand = 0x12,   ///< Transmit last command word, Data=Yes, Broadcast=No
      UeiMIL1553ModeTxBITWord = 0x13,   ///< Transmit vector word, Data=Yes, Broadcast=No
      UeiMIL1553ModeSelectedTxShutdown = 0x14,   ///< Shutdown selected transmitter, Data=Yes, Broadcast=Yes
      UeiMIL1553ModeOverrideTxShutdown = 0x15,   ///< Override selected transmitters shutdown, Data=Yes, Broadcast=Yes
   } tUeiMIL1553ModeCommandTypes;

   /// \brief MIL-1553 frame type
   ///
   /// Specifies the type of 1553 frame sent or received
   typedef enum _tUeiMIL1553FrameType
   {
      UeiMIL1553FrameTypeRtData,         ///< RW Remote terminal data (tUeiMIL1553RTFrame)
      UeiMIL1553FrameTypeBusWriter,      ///< W Data to transmit to output FIFO (tUeiMIL1553BusWriterFrame)
      UeiMIL1553FrameTypeBusMon,         ///< R Data in bus monitor format (tUeiMIL1553BMFrame)
      UeiMIL1553FrameTypeBusMonCmd,      ///< R Data in protocol-parsed bus monitor format (tUeiMIL1553BMCmdFrame)
      UeiMIL1553FrameTypeRtStatusData,   ///< R Remote terminal status data (ready/sent) (tUeiMIL1553RTStatusFrame)
      UeiMIL1553FrameTypeRtStatusLast,   ///< R Bus status and last command and last mode command - reserved
      UeiMIL1553FrameTypeRtParameters,   ///< W Remote terminal parameters data (tUeiMIL1553RTParametersFrame)
      UeiMIL1553FrameTypeRtControlData,  ///< W Remote terminal control data (tUeiMIL1553RTControlFrame)
      UeiMIL1553FrameTypeError,          ///< R Error 1553 frame - UEIDAQ_NOT_IMPLEMENTED_ERROR 
      UeiMIL1553FrameTypeBCCBData,       ///< W BCCB Data (upper 0x80) (tUeiMIL1553BCCBDataFrame)
      UeiMIL1553FrameTypeBCCBStatus,     ///< R BCCB Status (lower 0x40) (tUeiMIL1553BCCBStatusFrame)
      UeiMIL1553BCSchedFrame,            ///< RW Scheduler entries (tUeiMIL1553BCSchedFrame)
      UeiMIL1553BCControlFrame,          ///< W Control BC (tUeiMIL1553BCControlFrame)
      UeiMIL1553BCStatusFrame,           ///< R BC Status (tUeiMIL1553BCStatusFrame)
      UeiMIL1553FrameTypeA708Data,       ///< RW ARINC-708 Data (tUeiMIL1553A708DataFrame)
      UeiMIL1553FrameTypeA708Control,    ///< W ARINC-708 Control (tUeiMIL1553A708ControlFrame)
      UeiMIL1553FrameTypeGeneric = 100   ///< RW Generic frame type (tUeiMIL1553Frame)
   } tUeiMIL1553FrameType;


   /// \brief 1553 BC operations
   ///
   /// 1553 BC operations
   typedef enum _tUeiMIL1553BCOps
   {
      UeiMIL1553BcOpDisable,     ///< Disable BC operation
      UeiMIL1553BcOpEnable,      ///< Enable BC operation
      UeiMIL1553BcOpStepMj,      ///< Execute one step (major)
      UeiMIL1553BcOpStepMn,      ///< Execute one step (minor)
      UeiMIL1553BcOpGoto,        ///< Switch to a different entry
      UeiMIL1553BcOpMnSelect,    ///< Select minor frame blocks
      UeiMIL1553BcOpMjSwap       ///< Swap major frame "swap" marked entries from "disabled" to "enabled"
   } tUeiMIL1553BCOps;

   /// \brief 1553 BC GoTo command types
   ///
   /// 1553 BC GoTo command types
   typedef enum _tUeiMIL1553BCGotoOps
   {
      UeiMIL1553GotoBcbNoret = 0,     ///< Make jump after BCB, no return
      UeiMIL1553GotoMnNoret,          ///< Make jump after minor frame, no return
      UeiMIL1553GotoBcbBcb,           ///< Make jump after BCB, return after BCB
      UeiMIL1553GotoMnBCB,            ///< Make jump after minor frame, return after BCB
      UeiMIL1553GotoBcbMn,            ///< Make jump after BCB, return after minor frame
      UeiMIL1553GotoMnMn,             ///< Make jump after minor frame, return after minor frame
   } tUeiMIL1553BCGotoOps;


   /// \brief ARINC-708 operations
   ///
   /// ARINC-708 operations
   typedef enum _tUeiMIL1553A708Ops
   {
      UeiMIL1553A708OpDisable,     ///< Disable ARINC-708 operation
      UeiMIL1553A708OpEnable,      ///< Enable ARINC-708 operation
      UeiMIL1553A708FIFODisable,   ///< Disable ARINC-708 FIFO mode operation
      UeiMIL1553A708FIFOEnable,    ///< Enable ARINC-708 FIFO mode operation
      UeiMIL1553A708FIFOClear      ///< Clear ARINC-708 FIFOs
   } tUeiMIL1553A708Ops;


   /// \brief Log file format
   ///
   /// The format for logging acquired data to disk 
   typedef enum _tUeiLogFileFormat
   {
      UeiLogFileCSV, ///< Comma separated values format
      UeiLogFileBinary ///< Binary format
   } tUeiLogFileFormat;

   /// \brief Capacitive coupling
   ///
   /// The type of coupling used to connect a signal to 
   /// an analog input device
   typedef enum _tUeiCoupling
   {
      UeiCouplingDC, ///< DC coupling
      UeiCouplingAC, ///< AC coupling using 10Hz High pass filter
      UeiCouplingAC_1Hz, ///< AC coupling using 1Hz High pass filter
      UeiCouplingAC_100mHz, ///< AC coupling using 0.1Hz High pass filter
   } tUeiCoupling;

   /// \brief LVDT/RVDT excitation wiring schemes
   ///
   /// LVDT/RVDT excitation wiring schemes
   typedef enum _tUeiLVDTWiringScheme
   {
      UeiLVDTFourWires, ///< Sensor is connected using four wires
      UeiLVDTFiveWires  ///< Sensor is connected using five wires
   } tUeiLVDTWiringScheme;

   /// \brief Quadrature decoding type
   /// 
   /// Method used to count and interpret the pulses the encoder 
   /// generates on input A and B
   typedef enum _tUeiQuadratureDecodingType
   {
      UeiQuadratureDecodingType1x, ///< Count one pulse for each rising edge of Input A signal.
      UeiQuadratureDecodingType2x, ///< Count one pulse for each rising and falling edge of Input A signal.
      UeiQuadratureDecodingType4x  ///< Count one pulse for each rising and falling edge of both A and B Input signals.
   } tUeiQuadratureDecodingType;

   /// \brief Z input phase
   ///
   /// The states at which A and B input signals must be in when Z is high
   /// to trigger a measurement reset
   typedef enum _tUeiQuadratureZeroIndexPhase
   {
      UeiQuadratureZeroIndexPhaseZHigh, ///< reset measurement when Z is high
      UeiQuadratureZeroIndexPhaseALowBLow, ///< reset measurement when Z is high, A is low and B is low
      UeiQuadratureZeroIndexPhaseALowBHigh, ///< reset measurement when Z is high, A is low and B is high
      UeiQuadratureZeroIndexPhaseAHighBLow, ///< reset measurement when Z is high, A is high and B is low
      UeiQuadratureZeroIndexPhaseAHighBHigh///< reset measurement when Z is high, A is high and B is high
   } tUeiQuadratureZeroIndexPhase;

   /// \brief Synchro/Resolver Mode
   ///
   /// Specifies whether a synchro or a resolver is measured or simulated
   typedef enum _tUeiSynchroResolverMode
   {
      UeiSynchroMode, ///< A synchro is measured or simulated
      UeiResolverMode, ///< A resolver is measured or simulated
      UeiSynchroZGroundMode ///< A synchro with Z wire connected to ground is measured or simulated
   } tUeiSynchroResolverMode;

   /// \brief Synchro/Resolver message data types
   ///
   ///  Synchro/Resolver message data types (internal use)
   typedef enum _tUeiSynchroMessageType
   {
      UeiSynchroMessageStageAngles,  ///< Write angles
      UeiSynchroMessageUpdate, ///< Update FIFOs
   } tUeiSynchroMessageType;

   /// \brief Digital output PWM mode
   /// 
   /// Specifies the PWM mode for DO channels that support the capability
   /// With PWM mode you can replace the rising and falling edges with a pulse
   /// train to allow for soft start and/or stop
   typedef enum _tUeiDOPWMMode
   {
      UeiDOPWMDisabled,  ///< Disable pulsed transitions
      UeiDOPWMSoftStart, ///< Use a pulse train for low to high transitions
      UeiDOPWMSoftStop,  ///< Use a pulse train for high to low transition
      UeiDOPWMSoftBoth,  ///< Use a pulse train for both transitions
      UeiDOPWMContinuous,///< Continuously output a pulse train
      UeiDOPWMGated      ///< Output pulse train only when output line is toggled by software
   } tUeiDOPWMMode;

   /// \brief Digital output PWM output mode
   ///
   /// specifies if PWM is enabled on low size, high size or both sides of the FET
   /// This setting is only valid for digital outputlines based on FET
   typedef enum _tUeiDOPWMOutputMode
   {
      UeiDOPWMOutputPush,  ///< PWM enabled on high side only
      UeiDOPWMOutputPull,  ///< PWM enabled on low side only
      UeiDOPWMOutputPushPull,  ///< PWM enabled on both sides
      UeiDOPWMOutputOff    ///< PWM output is off
   } tUeiDOPWMOutputMode;

   /// \brief Flush actions
   ///
   /// Specifies how to flush a messaging port (serial, CAN, ARINC, MIL-1553)
   typedef enum _tUeiFlushAction
   {
      UeiFlushReadBuffer = 0x01, ///< Flush the receive device by writing all data from hardware FIFO to receive buffer
      UeiFlushDiscardReadBuffer = 0x02, ///< Discard the hardware FIFO and receive buffer contents (data is lost)
      UeiFlushWriteBuffer = 0x04, ///< Flush the transmit buffer by writing all buffered data to device
      UeiFlushDiscardWriteBuffer = 0x08, ///< Discard the transmit buffer content (data is not sent)
   } tUeiFlushAction;

   /// \brief Custom Scale type
   ///
   /// The type of cutom scale to apply to a scaled input channel
   typedef enum _tUeiCustomScaleType
   {
       UeiCustomScaleNone, ///< No custom scaling
       UeiCustomScaleLinear, ///< Use linear scale
       UeiCustomScalePolynomial, ///< Use polynomial scale
       UeiCustomScaleTable ///< Use interpolation table
   } tUeiCustomScaleType;

   /// \brief IRIG Time code format
   ///
   /// The time code format used by the time coder and the time decoder
   /// 
   typedef enum _tUeiIRIGTimeCodeFormat
   {
      UeiIRIGTimeCodeFormatA, ///< IRIG-A
      UeiIRIGTimeCodeFormatB, ///< IRIG-B
      UeiIRIGTimeCodeFormatD_100Hz, ///< IRIG-D 100Hz
      UeiIRIGTimeCodeFormatD_1000Hz, ///< IRIG-D 1000Hz
      UeiIRIGTimeCodeFormatE_100Hz, ///< IRIG-E 100Hz
      UeiIRIGTimeCodeFormatE_1000Hz, ///< IRIG-E 1000Hz
      UeiIRIGTimeCodeFormatG, ///< IRIG-G
      UeiIRIGTimeCodeFormatH_100Hz, ///< IRIG-H 100Hz
      UeiIRIGTimeCodeFormatH_1000Hz ///< IRIG-H 1000Hz
   } tUeiIRIGTimeCodeFormat;

   /// \brief IRIG time keeper 1 PPS signal source
   ///
   /// The source of the incoming 1 PPS signal used
   /// to keep time
   typedef enum _tUeiIRIGTimeKeeper1PPSSource
   {
      UeiIRIG1PPSInternal, ///< 1PPS signal is generated internally with precision oscillator
      UeiIRIG1PPSInputTimeCode, ///< 1PPS signal is derived from input timecode
      UeiIRIG1PPSGPS, ///< 1PPS signal is derived from GPS
      UeiIRIG1PPSRFIn, ///< 1PPS signal is derived from signal connected on RF input
      UeiIRIG1PPSExternalTTL0, ///< External 1PPS signal is connected to TTL0 input pin
      UeiIRIG1PPSExternalTTL1, ///< External 1PPS signal is connected to TTL1 input pin
      UeiIRIG1PPSExternalTTL2, ///< External 1PPS signal is connected to TTL2 input pin
      UeiIRIG1PPSExternalTTL3, ///< External 1PPS signal is connected to TTL3 input pin
      UeiIRIG1PPSExternalSync0, ///< External 1PPS signal is connected to SYNC0 bus line
      UeiIRIG1PPSExternalSync1, ///< External 1PPS signal is connected to SYNC1 bus line
      UeiIRIG1PPSExternalSync2, ///< External 1PPS signal is connected to SYNC2 bus line
      UeiIRIG1PPSExternalSync3, ///< External 1PPS signal is connected to SYNC3 bus line
   } tUeiIRIGTimeKeeper1PPSSource;

   /// \brief Time decoder input
   ///
   /// The type of signal connected to time decoder input
   typedef enum _tUeiIRIGDecoderInputType
   {
      UeiIRIGDecoderInputAM, ///< Time code is provided as an AM signal
      UeiIRIGDecoderInputManchesterRF0, ///< Time code is provided as a Manchester II code on RF input 0
      UeiIRIGDecoderInputManchesterRF1, ///< Time code is provided as a Manchester II code on RF input 1
      UeiIRIGDecoderInputManchesterIO0, ///< Time code is provided as a Manchester II code on I/O input 0
      UeiIRIGDecoderInputManchesterIO1, ///< Time code is provided as a Manchester II code on I/O input 1
      UeiIRIGDecoderInputNRZRF0, ///< Time code is provided as a NRZ code on RF input 0
      UeiIRIGDecoderInputNRZRF1, ///< Time code is provided as a NRZ code on RF input 1
      UeiIRIGDecoderInputNRZIO0, ///< Time code is provided as a NRZ code on I/O input 0
      UeiIRIGDecoderInputNRZIO1, ///< Time code is provided as a NRZ code on I/O input 1
      UeiIRIGDecoderInputGPS ///< Time code is taken from GPS NMEA message
   } tUeiIRIGDecoderInputType;

   /// \brief IRIG time format type
   ///
   /// Specifies the format used to send/receive time to/from the IRIG device
   typedef enum _tUeiIRIGTimeFormat
   {
      UeiIRIGBCDTime, ///< Time is formatted as binary coded decimal values
      UeiIRIGSBSTime, ///< Time is formatted as straight binary seconds values
      UeiIRIGANSITime,///< Time is formatted as struct tm C ANSI
      UeiIRIGGPSTime, ///< Time (and position) is formatted as a NMEA GPS string
      UeiIRIGTREG,    ///< Content of TREG registers (internal use only)
      UeiIRIGTimeCode, ///< Raw timecode data stream
      UeiIRIGSecondsSinceUnixEpochTime /// Time is formated as number of seconds since UNIX EPOCH
   } tUeiIRIGTimeFormat;

   /// \brief IRIG DO outputs source
   ///
   /// Specifies the source that drives an IRIG TTL output
   typedef enum _tUeiIRIGDOTTLSource
   {
      UeiIRIGDOTTLAMtoNRZ,    ///< AM->NRZ output
      UeiIRIGDOTTLGPSFixValid,    ///< GPS Fix Valid output
      UeiIRIGDOTTLGPSAntennaShorted,    ///< GPS Antenna Shorted output
      UeiIRIGDOTTLGPSAntennaOK,    ///< GPS Antenna Ok output
      UeiIRIGDOTTLGPSTxD1,    ///< GPS TXD1 (COM1) output
      UeiIRIGDOTTLGPSTxD0,    ///< GPS TXD0 (COM0) output
      UeiIRIGDOTTLManchesterIItoNRZ,    ///< Decoded Manchester II -> NRZ sequence
      UeiIRIGDOTTLSYNC3,    ///< Drive output from sync[3]
      UeiIRIGDOTTLSYNC2,    ///< Drive output from sync[2]
      UeiIRIGDOTTLSYNC1,    ///< Drive output from sync[1]
      UeiIRIGDOTTLSYNC0,    ///< Drive output from sync[0]
      UeiIRIGDOTTLOutputCarrierFrequency,    ///< Output carrier frequency
      UeiIRIGDOTTLPLLFrequency,    ///< Custom frequency output (from PLL)
      UeiIRIGDOTTLPrecision10MHZ,    ///< Precision 10MHz
      UeiIRIGDOTTLPrecision5MHZ,    ///< Precision 5MHz
      UeiIRIGDOTTLPrecision1MHZ,    ///< Precision 1MHz
      UeiIRIGDOTTLNRZStartStrobe,    ///< Output NRZ start strobe
      UeiIRIGDOTTLManchesterIITimeCode,    ///< Manchester II output time code
      UeiIRIGDOTTLNRZTimeCode,    ///< NRZ output time code
      UeiIRIGDOTTLGPS1PPS,    ///< Re-route GPS 1PPS pulse
      UeiIRIGDOTTL1PPH,    ///< 1PPH pulse
      UeiIRIGDOTTL1PPM,    ///< 1PPM pulse
      UeiIRIGDOTTL1PPS,    ///< 1PPS pulse
      UeiIRIGDOTTL0_1S,    ///< 0.1sec pulse
      UeiIRIGDOTTL0_01S,    ///< 0.01sec pulse
      UeiIRIGDOTTL1uS,      ///< 1uec pulse
      UeiIRIGDOTTLLogic1,    ///< Drive output with 1
      UeiIRIGDOTTLLogic0,   ///< Drive output with 0
      UeiIRIGDOTTLEventChannel0, /// Drive output from event channel 0
      UeiIRIGDOTTLEventChannel1, /// Drive output from event channel 1
      UeiIRIGDOTTLEventChannel2, /// Drive output from event channel 2
      UeiIRIGDOTTLEventChannel3 /// Drive output from event channel 3
   } tUeiIRIGDOTTLSource;

   /// \brief IRIG event module source
   ///
   /// Specifies the source that drives the event module
   typedef enum _tUeiIRIGEventSource
   {
      UeiDaqIRIGEventSYNC0,  /// Drive event module from SYNC bus line 0 
      UeiDaqIRIGEventSYNC1,  /// Drive event module from SYNC bus line 1 
      UeiDaqIRIGEventSYNC2,  /// Drive event module from SYNC bus line 2 
      UeiDaqIRIGEventSYNC3,  /// Drive event module from SYNC bus line 3 
      UeiDaqIRIGEvent1PPS,   /// Drive event module from PPS pulse
      UeiDaqIRIGEventEXTT,   /// Drive event module from External time received and applied
      UeiDaqIRIGEventEINV,   /// Drive event module from External sync lost
      UeiDaqIRIGEventTTL0,   /// Drive event module from External TTL input 0
      UeiDaqIRIGEventTTL1,   /// Drive event module from External TTL input 1
      UeiDaqIRIGEventTTL2,   /// Drive event module from External TTL input 2
      UeiDaqIRIGEventTTL3    /// Drive event module from External TTL input 3
   } tUeiIRIGEventSource;

   /// \brief HDLC port physical interface
   ///
   /// HDLC port physical interface
   typedef enum _tUeiHDLCPortPhysical
   {
      UeiHDLCPortRS232, ///<RS-232 
      UeiHDLCPortRS485, ///<RS-485 
      UeiHDLCPortRS422, ///<RS-422
      UeiHDLCPortV35    ///<V35
   } tUeiHDLCPortPhysical;

   /// \brief HDLC port abort symbol
   ///
   /// Symbol used to abort HDLC transmission
   typedef enum _tUeiHDLCPortAbortSymbol
   {
      UeiHDLCPortAbort7, ///< Send 0x7F to abort 
      UeiHDLCPortAbort15 ///< Send 0x7FFF to abort 
   } tUeiHDLCPortAbortSymbol;

   /// \brief HDLC port underrun action
   ///
   /// Action to take when underrun condition is detected
   typedef enum _tUeiHDLCPortUnderrunAction
   {
      UeiHDLCPortUnderrunFinish, ///< Close the frame by adding CRC to it 
      UeiHDLCPortUnderrunFlags   ///< Send flags 
   } tUeiHDLCPortUnderrunAction;

   /// \brief HDLC port encoding
   ///
   /// HDLC port encoding
   typedef enum _tUeiHDLCPortEncoding
   {
      UeiHDLCPortEncodingNRZ,   ///< NRZ encoding
      UeiHDLCPortEncodingNRZB,   ///< inverted NRZ encoding
      UeiHDLCPortEncodingNRZI,   ///< NRZI encoding
      UeiHDLCPortEncodingNRZIMark,   ///< NRZI encoding, invert state for 1
      UeiHDLCPortEncodingNRZISpace,   ///< NRZI encoding, invert state for 0
      UeiHDLCPortEncodingBiphaseMark,   ///< biphase encoding, used with DPLL
      UeiHDLCPortEncodingBiphaseSpace,   ///< biphase encoding, used with DPLL
      UeiHDLCPortEncodingBiphaseLevel,   ///< biphase encoding, used with DPLL
      UeiHDLCPortEncodingBiphaseDiff   ///< biphase encoding, used with DPLL
   } tUeiHDLCPortEncoding;

   /// \brief HDLC port clock source
   ///
   /// clock source used to synchronize transmit and or receive lines
   typedef enum _tUeiHDLCPortClockSource
   {
      UeiHDLCPortClockExternalPin,  ///< Take clock from RxC/TxC pin (default)
      UeiHDLCPortClockBRG,          ///< Take clock from baud rate generator
      UeiHDLCPortClockDPLL,         ///< Take clock from DPLL divided by 32
      UeiHDLCPortClockDPLLDiv8,     ///< Take clock from DPLL divided by 8
      UeiHDLCPortClockDPLLDiv16,    ///< Take clock from DPLL divided by 16
      UeiHDLCPortClockDPLLSRCBRG    ///< Take clock from DPLL with DPLL taking its input from baud rate generator
   } tUeiHDLCPortClockSource;

   /// \brief HDLC port CRC mode
   ///
   /// Algorithm used to calculate the CRC
   typedef enum _tUeiHDLCPortCRCMode
   {
      UeiHDLCPortCRCNone,     ///< CRC is not check neither for transmit nor receive
      UeiHDLCPortCRCUser,     ///< User is responsible for inserting and checking CRC
      UeiHDLCPortCRC16CCITT,  ///< 16-bit CCITT CRC is used (x^16+x^12+x^5+1)
      UeiHDLCPortCRC16,       ///< 16-bit polynomial CRC is used (x^16+x^15+x^2+1)
      UeiHDLCPortCRC32        ///< 32-bit Eth CRC is used (x^32+x^26+x^23+x^22+x^16+x^12+x^11+x^10+x^8+x^7+x^5+x^4+x^2+x+1)
   } tUeiHDLCPortCRCMode;

   /// \brief HDLC port filter mode
   ///
   /// filter mode
   typedef enum _tUeiHDLCPortFilterMode
   {
      UeiHDLCPortFilterNone,   ///< No filtering
      UeiHDLCPortFilterA16,    ///< +16 bits into RxFIFO if Addr matches or B/C as 2 bytes
      UeiHDLCPortFilterA24,    ///< +24 bits into RxFIFO if Addr matches or B/C as 3 bytes
      UeiHDLCPortFilterA32,    ///< +32 bits into RxFIFO if Addr matches or B/C as 4 bytes
      UeiHDLCPortFilterEALS,   ///< Places bytes while LS==0, then byte with LS==1 then 16 bits as 2 bytes into RxFIFO if EA matches or B/C
      UeiHDLCPortFilterEA24,   ///< Places 24 bits as 3 bytes into RxFIFO if EA matches or B/C
      UeiHDLCPortFilterEAMS,   ///< Places bytes while MS==0, then byte with MS==1 then 8 bits as 1 byte into RxFIFO if Ext Addr matches or B/C
      UeiHDLCPortFilterEAMS16  ///< Places bytes while MS==0, then byte with MS==1 then 16 bits as 2 bytes into RxFIFO if Ext Addr matches or B/C
   } tUeiHDLCPortFilterMode;

   /// \brief HDLC port preamble pattern
   ///
   /// HDLC port preamble pattern
   typedef enum _tUeiHDLCPortPreamble
   {
      UeiHDLCPortPreambleNone,   ///< No preamble
      UeiHDLCPortPreambleZero,   ///< All zeros
      UeiHDLCPortPreambleOne,    ///< All ones
      UeiHDLCPortPreambleFlag,   ///< All flags
      UeiHDLCPortPreamble10,     ///< Alternating 1 and 0
      UeiHDLCPortPreamble01,     ///< Alternating 0 and 1 
   } tUeiHDLCPortPreamble;

   /// \brief HDLC port preamble size
   ///
   /// HDLC port preamble size
   typedef enum _tUeiHDLCPortPreambleSize
   {
      UeiHDLCPortPreambleSize16,   ///< 16 bits preamble is used
      UeiHDLCPortPreambleSize32,   ///< 32 bits preamble is used
      UeiHDLCPortPreambleSize64    ///< 64 bits preamble is used
   } tUeiHDLCPortPreambleSize;

   /// \brief HDLC port idle character
   ///
   /// HDLC port idle character
   typedef enum _tUeiHDLCPortIdleCharacter
   {
      UeiHDLCPortIdleFlag,   ///< continuous flags
      UeiHDLCPortIdleZero,   ///< continuous zeroes
      UeiHDLCPortIdleOne,    ///< continuous ones
      UeiHDLCPortIdleMark,   ///< idle chars are marks
      UeiHDLCPortIdleSpace,  ///< idle chars are spaces
      UeiHDLCPortIdleMS,     ///< alternating Mark and Space
      UeiHDLCPortIdle01      ///< alternating 0 and 1
   } tUeiHDLCPortIdleCharacter;

   /// \brief Watchdog command
   ///
   /// Configures the watchdog timer to reset the device
   /// it is attached to when a programmable timer delay expires.
   /// Periodically clearing the timer prevents reset.
   typedef enum _tUeiWatchDogCommand
   {
      UeiWatchDogDisable,   ///< Disable watchdog
      UeiWatchDogEnableClearOnReceive, ///< Configure watchdog to clear timer upon receiving a packet
      UeiWatchDogEnableClearOnTransmit, ///< Configure watchdog to clear timer upon transmitting a packet
      UeiWatchDogEnableClearOnCommand, ///< Configure watchdog to clear timer upon receiving a clear command 
      UeiWatchDogClearTimer ///< Clear the timer
   } tUeiWatchDogCommand;

   /// \brief VR data message type
   ///
   /// VR sessions can read single measurements, FIFO based data, and AI FIFO data
   typedef enum _tUeiVRDataType
   {
      UeiVRDataPositionVelocity, ///< Read position and velocity measurement 
      UeiVRDataFifoPosition, ///< Read multiple position measurements. This is useful to calculate inter-tooth timing and acceleration
      UeiVRDataADCFifo,    ///< Read ADC FIFO. this is useful for diagnostic purpose.
      UeiVRDataADCStatus, ///< Read ADC status
   } tUeiVRDataType;

   /// \brief Variable reluctance measurement mode
   ///
   /// Configures the input mode on variable reluctance sessions.
   /// Variable reluctance input device converts the VR sensor analog signal to
   /// a digital signal that can be processed by a counter/timer
   /// The VR-608 can use four different modes to measure velocity, position or direction 
   /// The counting mode can be set to:
   /// * Decoder: Even and Odd channels are used in pair to determine direction and position
   /// * Timed: Count number of teeth detected during a timed interval
   /// * N pulses: Measure the time taken to detect N teeth (Number of teeth needs to be set separately)
   /// * Z pulse: Measure the number of teeth and the time elapsed between two Z pulses (The Z tooth is usually a gap or a double tooth on the encoder wheel)
   typedef enum _tUeiVRMode
   {
      UeiVRModeDecoder, ///< Even and Odd channels are used in pair to measure direction and position
      UeiVRModeCounterTimed, ///< Count number of teeth detected during given time interval to measure velocity and position
      UeiVRModeCounterNPulses, ///< Count time taken to detect N teeth to measure velocity only
      UeiVRModeCounterZPulse ///< Count elapsed time and number of teeth detected between two Z pulses to measure velocity and position.
   } tUeiVRMode;

   /// \brief Variable reluctance zero-crossing mode
   ///
   /// Configures the zero-crossing mode on variable reluctance sessions.
   /// Zero crossing finds the point in time where the VR sensor output voltage goes from positive
   /// to negative voltage. This point is the center of the tooth lining up with the center
   /// of the VR sensor
   typedef enum _tUeiVRZCMode
   {
      UeiZCModeChip, ///< The front-end IC will automatically calculate the ZC level
      UeiZCModeLogic, ///< The device's FPGA measures the VR sensor signal and calculate the ZC level as (min+max)/2 
      UeiZCModeFixed ///< Use hard-coded ZC level
   } tUeiVRZCMode;

   /// \brief Variable reluctance adaptive peak threshold mode
   ///
   /// Configures the adaptive peak threshold (APT) mode on variable reluctance sessions.
   /// APT finds the point in time where the VR sensor output voltage falls below a certain
   /// threshold. This point marks the beginning of the gap between two teeth.
   typedef enum _tUeiVRAPTMode
   {
      UeiAPTModeChip, ///< The front-end IC will automatically set the AP threshold to 1/3 of the peak input voltage
      UeiAPTModeLogic, ///< The device's FPGA measures the VR sensor signal and sets the AP threshold to a programmable fraction of the peak input voltage
      UeiAPTModeFixed, ///< Turn-off APT and use hard-coded AP threshold
      UeiAPTModeTTL ///< Turn-off APT, use this mode when connecting a TTL signal to the VR input
   } tUeiVRAPTMode;

   /// \brief Variable reluctance FIFO mode
   ///
   /// Variable reluctance FIFO data can be used to calculate a map of the inter-tooth delays 
   /// around the encoder wheel. this is useful to calculate acceleration.
   typedef enum _tUeiVRFIFOMode
   {
      UeiFIFOModeDisabled, ///< No data is pushed to FIFO
      UeiFIFOModePosition, ///< Raw counter data is pushed to FIFO
      UeiFIFOModePosAndTS  ///< Raw counter data and timestamp is pushed to FIFO
   } tUeiVRFIFOMode;

   /// \brief Variable reluctance digital output source
   ///
   /// The source of a digital output on a variable reluctance device
   typedef enum _tUeiVRDigitalSource
   {
      UeiVRDigitalSourceDisable, ///< Disable output
      UeiVRDigitalSourceForceHigh, ///< Set output level to high
      UeiVRDigitalSourceForceLow, ///< Set output level to low
      UeiVRDigitalSourceZTooth7, ///< Set output to high when Z tooth is detected on channel 7
      UeiVRDigitalSourceZTooth6, ///< Set output to high when Z tooth is detected on channel 6
      UeiVRDigitalSourceZTooth5, ///< Set output to high when Z tooth is detected on channel 5
      UeiVRDigitalSourceZTooth4, ///< Set output to high when Z tooth is detected on channel 4
      UeiVRDigitalSourceZTooth3, ///< Set output to high when Z tooth is detected on channel 3
      UeiVRDigitalSourceZTooth2, ///< Set output to high when Z tooth is detected on channel 2
      UeiVRDigitalSourceZTooth1, ///< Set output to high when Z tooth is detected on channel 1
      UeiVRDigitalSourceZTooth0, ///< Set output to high when Z tooth is detected on channel 0
      UeiVRDigitalSourceNPulse7, ///< Set output to high when N teeth have been detected on channel 7
      UeiVRDigitalSourceNPulse6, ///< Set output to high when N teeth have been detected on channel 6
      UeiVRDigitalSourceNPulse5, ///< Set output to high when N teeth have been detected on channel 5
      UeiVRDigitalSourceNPulse4, ///< Set output to high when N teeth have been detected on channel 4
      UeiVRDigitalSourceNPulse3, ///< Set output to high when N teeth have been detected on channel 3
      UeiVRDigitalSourceNPulse2, ///< Set output to high when N teeth have been detected on channel 2
      UeiVRDigitalSourceNPulse1, ///< Set output to high when N teeth have been detected on channel 1
      UeiVRDigitalSourceNPulse0 ///< Set output to high when N teeth have been detected on channel 0
   } tUeiVRDigitalSource;

   /// \brief Specifies whether a feature is manually or automatically turned on or off
   /// 
   /// Manual mode lets you turn on or off a feature from your code
   /// Automatic mode controls the feature from a setting saved in EEPROM
   typedef enum _tUeiFeatureEnable
   {
      UeiFeatureDisabled,  ///< Feature is disabled
      UeiFeatureEnabled, ///< Feature is enabled
      UeiFeatureAuto      ///< Feature is enabled/disabled depending on EEPROM content
   } tUeiFeatureEnable;

   /// \brief EEPROM area
   ///
   /// Specifies the area to read/write in EEPROM
   typedef enum _tUeiEEPROMArea
   {
      UeiEEPROMAreaCommon,      ///< Common area (holds data common to all devices)
      UeiEEPROMAreaCalibration, ///< Calibration coefficients area
      UeiEEPROMAreaInitialization, ///< Initialization state area
      UeiEEPROMAreaOperation,   ///< Operation mode state area
      UeiEEPROMAreaShutdown,    ///< Shutdown state area
      UeiEEPROMAreaNames,       ///< Channel names area
      UeiEEPROMAreaWhole,       ///< Read whole EEPROM if layer supports it
      UeiEEPROMAreaFlags        ///< Flags area
   } tUeiEEPROMArea;

   /// \brief 1PPS synchronization mode
   ///
   /// Specifies the mode used to obtain 1PPS synchronization clock
   typedef enum _tUeiSync1PPSMode
   {
      UeiSyncClock,   ///< External 1PPS TTL clock is connected to a sync input pin
      UeiSync1588,    ///< 1PPS is derived from 1588 master clock 
      UeiSyncNTP,     ///< 1PPS is derived from NTP server 
      UeiSyncIRIG     ///< 1PPS is derived from IRIG device 
   } tUeiSync1PPSMode;

   /// \brief the source of the 1PPS sync clock
   ///
   /// When in sync clock mode, specifies where the 1PPS clock is coming from
   typedef enum _tUeiSync1PPSSource
   {
      UeiSync1PPSInternal,  ///< 1PPS is generated internally
      UeiSync1PPSInput0,    ///< 1PPS is connected to synchronization input 0
      UeiSync1PPSInput1     ///< 1PPS is connected to synchronization input 1
   } tUeiSync1PPSSource;

   /// \brief Backplane synchonization line
   ///
   /// Specifies the backplane synchronization used to connect
   /// the hardware to synchronize
   typedef enum _tUeiSyncLine
   {
      UeiSyncLine0,  ///< Use synchronization 0
      UeiSyncLine1,  ///< Use synchronization 1
      UeiSyncLine2,  ///< Use synchronization 2
      UeiSyncLine3,  ///< Use synchronization 3
      UeiSyncNone    ///< Not connected
   } tUeiSyncLine;

   /// \brief the output of the 1PPS sync clock
   ///
   /// when synchronizing multiple devices, a master device
   /// must output the synchronization 1PPS clock to the slave devices
   typedef enum _tUeiSync1PPSOutput
   {
      UeiSync1PPSNone,     ///< No output of 1PPS clock
      UeiSync1PPSOutput0,  ///< Sync clock is emitted through synchronization output 0
      UeiSync1PPSOutput1   ///< Sync clock is emitted through synchronization output 1
   } tUeiSync1PPSOutput;

   /// \brief 1PPS status message type
   ///
   /// Synchronization sessions can read status for different components
   typedef enum _tUeiSync1PPSDataType
   {
      UeiSync1PPSDataFull,    ///< Read all status values from all components 
      UeiSync1PPSDataLocked,  ///< Read locked status to determine when the event module output clock is stable
      UeiSync1PPSPTPStatus,   ///< Read PTP status
      UeiSync1PPSPTPUTCTime   ///< Read UTC time in seconds since UNIX Epoch Time (01/01/1970)
   } tUeiSync1PPSDataType;

   /// \brief 1PPS action
   ///
   /// Trigger operations that a 1PPS sync session can use to start slave devices
   typedef enum _tUeiSync1PPSTriggerOperation
   {
      UeiSync1PPSTriggerOnNextPPS,   ///< trigger local slave devices on next PPS rising edge
      UeiSync1PPSTriggerOnNextPPSBroadCast,   ///< trigger local and remote slave devices on next PPS rising edge
   } tUeiSync1PPSTriggerOperation;

   /// \brief CSDB data message type
   ///
   /// CSDB sessions can read/write entire frame or single message block
   typedef enum _tUeiCSDBDataType
   {
      UeiCSDBDataFrame, ///< Read/Write entire frame 
      UeiCSDBDataMessageByIndex, ///< Read/Write single message selected by aro based index within the frame
      UeiCSDBDataMessageByAddress ///< Read single message selected by address.
   } tUeiCSDBDataType;

   /// \brief PTP states
   ///
   /// PTP states for internal PTP state machine
   typedef enum _tUeiPTPState
   {
      UeiPTPStateInit,
      UeiPTPStateFaulty,
      UeiPTPStateDisabled,
      UeiPTPStateListening,
      UeiPTPStatePreMaster,
      UeiPTPStateMaster,
      UeiPTPStatePassive,
      UeiPTPStateUncalibrated,
      UeiPTPStateSlave
   } tUeiPTPState;

   /// \brief DMM measurement modes
   ///
   /// the modes of measurement for a DMM device
   typedef enum _tUeiDMMMeasurementMode
   {
      UeiDMMModeCalibratedDCVoltage, // calibrated DC voltage measurement
      UeiDMMModeAveragedDCVoltage, // averaged over N measurements DC voltage measurement 
      UeiDMMModeAveragedPeriodDCVoltage, // averaged over N AC periods DC voltage measurement 
      UeiDMMModeSpecialAveragedDCVoltage, // averaged using 'special average' channel
      UeiDMMModeRMSACVoltage, // RMS AC voltage measurement mode
      UeiDMMModeSpecialAveragedRMSACVoltage, // RMS AC voltage averaged using 'special average' channel
      UeiDMMModeMinACVoltage, // Minimum peak AC voltage measurement mode
      UeiDMMModeMaxACVoltage, // Maximum peak AC voltage measurement mode
      UeiDMMModeFrequencyACVoltage, // Maximum peak AC voltage measurement mode
      UeiDMMModeCalibratedDCCurrent, // calibrated DC current measurement
      UeiDMMModeAveragedDCCurrent, // averaged over N measurements DC current measurement 
      UeiDMMModeAveragedPeriodDCCurrent, // averaged over N AC periods DC current measurement 
      UeiDMMModeSpecialAveragedDCCurrent, // averaged using 'special average' channel
      UeiDMMModeRMSACCurrent, // RMS AC current measurement mode
      UeiDMMModeSpecialAveragedRMSACCurrent, // RMS AC current averaged using 'special average' channel
      UeiDMMModeMinACCurrent, // Minimum peak AC current measurement mode
      UeiDMMModeMaxACCurrent, // Maximum peak AC current measurement mode
      UeiDMMModeFrequencyACCurrent, // Maximum peak AC current measurement mode
      UeiDMMModeTwoWiresResistance,  // Two wires Resistance measurement mode
      UeiDMMModeFourWiresResistance,  // Four wires Resistance measurement mode
      UeiDMMModeGuardianDCVoltageVRef,
      UeiDMMModeGuardianDCCurrentVRef,
      UeiDMMModeGuardianDCCurrent,
      UeiDMMModeGuardianACCurrent,
      UeiDMMModeGuardianVoltage0,
      UeiDMMModeGuardianVoltage1,
      UeiDMMModeGuardianVoltage2,
      UeiDMMModeGuardianVoltage3,
      UeiDMMModeGuardianTemperature
   } tUeiDMMMeasurementMode;

   typedef enum _tUeiDMMStatus
   {
      UeiDMMStatusProtectionReconfiguredSafeRange = (1L << 2),    // DMM protection tripped previously, layer is reconfigured to safe range until readings are within configured range
      UeiDMMStatusProtectionTripped = (1L << 1),                  // DMM protection tripped, but layer will try to reconfigure to safe range until readings are within configured range
      UeiDMMStatusProtectionTrippedMax = (1L << 0),               // DMM protection tripped while in max range, user must reconfigure layer
   } tUeiDMMStatus;

   /// \brief measurement units
   ///
   /// the units of measurement for a device
   typedef enum _tUeiMeasurementUnits
   {
      UeiMeasurementUnitsDCVolts, // DC voltage measurement
      UeiMeasurementUnitsACVolts, // AC voltage measurement
      UeiMeasurementUnitsDCAmperes, //DC current measurement
      UeiMeasurementUnitsACAmperes, // AC current measurement
      UeiMeasurementUnitsOhms  // Resistance measurement 
   } tUeiMeasurementUnits;

   /// \brief DMM FIR cutoff frequency modes
   typedef enum _tUeiDMMFIRCutoff
   {
      UeiDMMFIROff, ///< Disabled
      UeiDMMFIR24Hz, ///< 24Hz
      UeiDMMFIR50Hz, ///< 50Hz,
      UeiDMMFIR100Hz, ///< 100Hz
      UeiDMMFIR1kHz ///< 1kHz
   } tUeiDMMFIRCutoff;

   /// \brief DMM zero crossing detection modes
   typedef enum _tUeiDMMZeroCrossingMode
   {
      UeiDMMZeroCrossingModeLevel, ///< User provided ZC level
      UeiDMMZeroCrossingModeMinMax, ///< Use MAX+MIN/2 for ZC level
      UeiDMMZeroCrossingModeRMS, ///< Use one period DC average for ZC level
      UeiDMMZeroCrossingModeDC ///< Use DC average  for ZC level
   } tUeiDMMZeroCrossingMode;

   /// \brief Auxiliary AO command
   ///
   /// AO sessions use those commands to control auxiliary features such
   /// as circuit breakers, short or open circuit simulations
   typedef enum _tUeiAOAuxCommand
   {
      UeiAOAuxResetCircuitBreaker, ///< Re-engage circuit breaker in case it has tripped 
      UeiAOAuxShortOpenCircuit ///< Short/Open output lines
   } tUeiAOAuxCommand;

   /// \brief MUX device synchronization output mode
   ///
   /// MUX devices can assert a synchronization output line when
   /// relays are configured
   typedef enum _tUeiMuxSyncOutputMode
   {
      UeiMuxSyncOutputLogic0, ///< Drive constant logic 0
      UeiMuxSyncOutputLogic1, ///< Drive constant logic 1
      UeiMuxSyncOutputSyncLine0, ///< Driven by internal sync bus line #0
      UeiMuxSyncOutputSyncLine1, ///< Driven by internal sync bus line #1
      UeiMuxSyncOutputSyncLine2, ///< Driven by internal sync bus line #2
      UeiMuxSyncOutputSyncLine3, ///< Driven by internal sync bus line #3
      UeiMuxSyncOutputRelaysReadyPulse0, ///< Drive logic 0 pulse upon "relays ready" event
      UeiMuxSyncOutputRelaysReadyPulse1, ///< Drive logic 1 pulse upon "relays ready" event
      UeiMuxSyncOutputRelaysReadyLogic0, ///< Driven to logic 0 upon "relays ready" event
      UeiMuxSyncOutputRelaysReadyLogic1 ///< Driven to logic 1 upon "relays ready" event
   } tUeiMuxSyncOutputMode;

   /// \brief MUX message type
   ///
   /// MUX message type
   typedef enum _tUeiMUXMessageType
   {
      UeiMUXMessageDirectRelayWrite,
      UeiMUXMessageMUXWrite,
      UeiMUXMessageMUXRawWrite,
      UeiMUXMessageMUXDmmWrite,
      UeiMUXMessageStatusRead,
      UeiMUXMessageADCRead,
      UeiMUXMessageCountsRead
   } tUeiMUXMessageType;

   /// \brief MUX device voltage level
   ///
   /// Voltage levels for DC/DC during relay holding and switching
   typedef enum _tUeiMuxVoltage
   {
       UeiMuxVoltage2_42,  ///< 2.42V
       UeiMuxVoltage3_3,   ///< 3.3V
       UeiMuxVoltage4_2,   ///< 4.2V
       UeiMuxVoltage5_1    ///< 5.1V
   } tUeiMuxVoltage;

   /// \brief MUX to DMM output select
   ///
   /// MUX output to DMM modes
   typedef enum _tUeiMuxDmmMode
   {
      UeiMuxDmmDisable,
      UeiMuxDmmMeasI,
      UeiMuxDmmMeasV,
      UeiMuxDmmMeasRes2,
      UeiMuxDmmMeasRes4
   } tUeiMuxDmmMode;

   /// \brief I2C port speed
   typedef enum _tUeiI2CPortSpeed
   {
      UeiI2CBitsPerSecond100K, ///< 100 Kbits per second
      UeiI2CBitsPerSecond400K, ///< 400 Kbits per second
      UeiI2CBitsPerSecond1M, ///< 1 Mbits per second
      UeiI2CBitsPerSecondCustom ///< Use custom
   } tUeiI2CPortSpeed;

   /// \brief I2C TTL level
   typedef enum _tUeiI2CTTLLevel
   {
      UeiI2CTTLLevel3_3V, ///< 3.3V
      UeiI2CTTLLevel5V ///< 5V
   } tUeiI2CTTLLevel;

   /// \brief I2C slave addressing mode
   typedef enum _tUeiI2CSlaveAddressWidth
   {
      UeiI2CSlaveAddress7bit, ///< 7-bit slave address
      UeiI2CSlaveAddress10bit ///< 10-bit slave address
   } tUeiI2CSlaveAddressWidth;

   /// \brief I2C message data types
   ///
   /// I2C message data types
   typedef enum _tUeiI2CMessageType
   {
      UeiI2CMessageSlaveWrite,  ///< Slave Tx write
      UeiI2CMessageMasterWrite, ///< Master Tx write
      UeiI2CMessageSlaveRead,   ///< Read from Slave Rx
      UeiI2CMessageMasterRead,  ///< Read from Master Rx
      UeiI2CMessageMasterAvailInput, ///< Read number of available master input messages
      UeiI2CMessageSlaveAvailInput, ///< Read number of available slave input messages
      UeiI2CMessageSlaveAvailOutput, ///< Read number of available slave output messages
   } tUeiI2CMessageType;

   /// \brief I2C commands
   ///
   /// I2C commands
   typedef enum _tUeiI2CCommand
   {
      UeiI2CCommandWrite, ///< Write command
      UeiI2CCommandRead, ///< Read command
      UeiI2CCommandWriteRead ///< Write, Restart, Read command
   } tUeiI2CCommand;

   /// \brief I2C slave data modes
   ///
   /// I2C slave data modes
   typedef enum _tUeiI2CSlaveDataMode
   {
      UeiI2CSlaveDataModeFIFO, ///< Slave transmits data using FIFO
      UeiI2CSlaveDataModeRegister ///< Slave transmits up to 4 bytes of pre-configured data
   } tUeiI2CSlaveDataMode;

   /// \brief I2C loopback modes
   ///
   /// I2C loopback modes
   typedef enum _tUeiI2CLoopback
   {
      UeiI2CLoopbackNone, ///< No loopback enabled
      UeiI2CLoopbackRelay, ///< Connect master and slave on channel using relay. Master and slave are still on external I2C bus.
      UeiI2CLoopbackFPGA ///< Enable loopback within FPGA. Disconnects master and slave from the external I2C bus.
   } tUeiI2CLoopback;

   /// \brief Bus condition codes
   ///
   /// Bus condition codes
   typedef enum _tUeiI2CBusCode
   {
      UeiI2CBusUnknown, ///< Unknown bus code
      UeiI2CBusStart, ///< Start condition, no data
      UeiI2CBusRestart, ///< Restart condition, no data
      UeiI2CBusStop, ///< Stop, no data
      UeiI2CBusAddressAck, ///< Address received with ACK
      UeiI2CBusAddressNack, ///< Address received with no ACK
      UeiI2CBusDataAck, ///< Data received with ACK
      UeiI2CBusDataNack, ///< Data received with no ACK
      UeiI2CBusAllData, ///< Last data byte received
      UeiI2CBusClockStretchError ///< Clock stretching error
   } tUeiI2CBusCode;

   /// \brief Init parameters
   ///
   /// Specifies the parameter to read/write
   typedef enum _tUeiInitParameter
   {
      UeiInitParameterModelId, ///< IOM model ID
      UeiInitParameterModelOption, ///< IOM model option
      UeiInitParameterIOMSerial, ///< IOM serial number
      UeiInitParameterIOMMfgDate, ///< IOM manufacturing date
      UeiInitParameterIOMBaseFrequency, ///< IOM base frequency
      UeiInitParameterTickSize, ///< OS tick size
      UeiInitParameterPeriod, ///< Periodic tick size
      UeiInitParameterWatchdogTimer, ///< Watchdog timer reset delay
      UeiInitParameterTime, ///< Current time, seconds from 1/1/2000
      UeiInitParameterOptions, ///< Firmware options
      UeiInitParameterComDelay, ///< Delay before entering shutdown mode after communication is lost
      UeiInitParameterFWCT, ///< Type of the IOM firmware
      UeiInitParameterLayerId, ///< Layer ID
      UeiInitParameterLayerOption, ///< Layer option
      UeiInitParameterLayerSerial, ///< Layer serial number
      UeiInitParameterEEPROMSize, ///< Total EEPROM size
      UeiInitParameterLayerMfgDate, ///< Layer manufacturing date
      UeiInitParameterLayerCalDate, ///< Layer calibration date
      UeiInitParameterLayerCalExpiration, ///< Layer calibration expiration date
      UeiInitParameterDQRev, ///< DaqBIOS revision supported
      UeiInitParameterFWRev, ///< Firmware revision supported
   } tUeiInitParameter;

#ifdef __cplusplus
}
#endif

#endif // __UEICONSTANTS_H__
