#ifndef __UEITIMING_H__
#define __UEITIMING_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif


#include "UeiObject.h"

namespace UeiDaq
{

// private classes
class CUeiTimingImpl;

// Forward declaration
class CUeiException;

/// \brief Timing object
///
/// This object store the timing parameters of a session
class CUeiTiming : public CUeiObject
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiTiming();

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiTiming();
   
   /// \brief Get the timing mode
   ///
   /// Get the timing mode
   /// \return the timing mode
   /// \sa SetMode
   UeiDaqAPI tUeiTimingMode GetMode();
   
   /// \brief Set the timing mode
   ///
   /// Set the timing mode
   /// \param mode the timing mode
   /// \sa GetMode
   UeiDaqAPI void SetMode(tUeiTimingMode mode);

   /// \brief Get the Conversion clock source
   ///
   /// Get the source of the A/D conversion clock
   /// \return the clock source
   /// \sa SetConvertClockSource
   UeiDaqAPI tUeiTimingClockSource GetConvertClockSource();
   
   /// \brief Set the Conversion clock source
   ///
   /// Set the source of the A/D conversion clock
   /// \param source the clock source
   /// \sa GetConvertClockSource
   UeiDaqAPI void SetConvertClockSource(tUeiTimingClockSource source);

   /// \brief Get the Scan clock source
   ///
   /// Get the source of the scan clock
   /// \return the clock source
   /// \sa SetScanClockSource
   UeiDaqAPI tUeiTimingClockSource GetScanClockSource();
   
   /// \brief Set the Scan clock source
   ///
   /// Set the source of the scan clock
   /// \param source the clock source
   /// \sa GetScanClockSource
   UeiDaqAPI void SetScanClockSource(tUeiTimingClockSource source);

   /// \brief Get the timestamp clock source
   ///
   /// Get the source of the clock used to increment timestamp counter
   /// \return the timetamp clock source
   /// \sa SetTimestampClockSource
   UeiDaqAPI tUeiTimingClockSource GetTimestampClockSource();

   /// \brief Set the timestamp clock source
   ///
   /// Set the source of the signal used to increment timestamp counter
   /// \param source the timestamp clock source
   /// \sa GetTimestampClockSource
   UeiDaqAPI void SetTimestampClockSource(tUeiTimingClockSource source);

   /// \brief Get the conversion clock rate
   ///
   /// Get the rate of the conversion clock
   /// \return the clock rate
   /// \sa SetConvertClockRate
   UeiDaqAPI f64 GetConvertClockRate();
   
   /// \brief Set the conversion clock rate
   ///
   /// Set the rate of the conversion clock
   /// \param rate the clock rate
   /// \sa GetConvertClockRate
   UeiDaqAPI void SetConvertClockRate(f64 rate);

   /// \brief Get the scan clock rate
   ///
   /// Get the rate of the scan clock
   /// \return the clock rate
   /// \sa SetScanClockRate
   UeiDaqAPI f64 GetScanClockRate();
   
   /// \brief Set the scan clock rate
   ///
   /// Set the rate of the scan clock
   /// \param rate the clock rate
   /// \sa GetScanClockRate
   UeiDaqAPI void SetScanClockRate(f64 rate);
     
   /// \brief Get the conversion clock edge
   ///
   /// Get the active edge of the conversion clock.
   /// \return the clock active edge
   /// \sa SetConvertClockEdge
   UeiDaqAPI tUeiDigitalEdge GetConvertClockEdge();
   
   /// \brief Set the conversion clock edge
   ///
   /// Set the active edge of the conversion clock.
   /// \param edge the clock active edge
   /// \sa GetConvertClockEdge
   UeiDaqAPI void SetConvertClockEdge(tUeiDigitalEdge edge);

   /// \brief Get the scan clock edge
   ///
   /// Get the active edge of the scan clock.
   /// \return the clock active edge
   /// \sa SetScanClockEdge
   UeiDaqAPI tUeiDigitalEdge GetScanClockEdge();
   
   /// \brief Set the scan clock edge
   ///
   /// Set the active edge of the scan clock.
   /// \param edge the clock active edge
   /// \sa GetScanClockEdge
   UeiDaqAPI void SetScanClockEdge(tUeiDigitalEdge edge);

   /// \brief Get the duration
   ///
   /// Get the duration of the timed operation.
   /// \return the duration
   /// \sa SetDuration
   UeiDaqAPI tUeiTimingDuration GetDuration();
   
   /// \brief Set the duration
   ///
   /// Set the duration of the timed operation.
   /// \param duration the duration
   /// \sa GetDuration
   UeiDaqAPI void SetDuration(tUeiTimingDuration duration);

   /// \brief Get the scan clock divisor
   ///
   /// Get the scan clock divisor. This divisor is used to divide
   /// an external clock using one of the on-board counter/timers.
   /// \return the timebase divisor
   /// \sa SetScanClockTimebaseDivisor
   UeiDaqAPI Int32 GetScanClockTimebaseDivisor();
   
   /// \brief Set the scan clock divisor
   ///
   /// Set the scan clock divisor. This divisor is used to divide
   /// an external clock using one of the on-board counter/timers.
   /// \param divisor the timebase divisor
   /// \sa GetScanClockTimebaseDivisor
   UeiDaqAPI void SetScanClockTimebaseDivisor(Int32 divisor);

   /// \brief Get the convert clock divisor
   ///
   /// Get the convert clock divisor. This divisor is used to divide
   /// an external clock using one of the on-board counter/timers.
   /// \return the timebase divisor
   /// \sa SetScanClockTimebaseDivisor
   UeiDaqAPI Int32 GetConvertClockTimebaseDivisor();
   
   /// \brief Set the convert clock divisor
   ///
   /// Set the convert clock divisor. This divisor is used to divide
   /// an external clock using one of the on-board counter/timers.
   /// \param divisor the timebase divisor
   /// \sa GetScanClockTimebaseDivisor
   UeiDaqAPI void SetConvertClockTimebaseDivisor(Int32 divisor);

   /// \brief Get the scan clock dividing counter
   ///
   /// Get the scan clock dividing counter. This counter is used to divide
   /// an external clock signal.
   /// \return the timebase dividing counter
   /// \sa SetScanClockTimebaseDividingCounter
   UeiDaqAPI Int32 GetScanClockTimebaseDividingCounter();
   
   /// \brief Set the scan clock dividing counter
   ///
   /// Set the scan clock dividing counter. This counter is used to divide
   /// an external clock.
   /// \param counter the timebase dividing counter
   /// \sa GetScanClockTimebaseDividingCounter
   UeiDaqAPI void SetScanClockTimebaseDividingCounter(Int32 counter);

   /// \brief Get the convert clock dividing counter
   ///
   /// Get the convert clock dividing counter. This counter is used to divide
   /// an external clock.
   /// \return the timebase dividing counter
   /// \sa SetConvertClockTimebaseDividingCounter
   UeiDaqAPI Int32 GetConvertClockTimebaseDividingCounter();
   
   /// \brief Set the convert clock dividing counter
   ///
   /// Set the convert clock dividing counter. This counter is used to divide
   /// an external.
   /// \param counter the timebase dividing counter
   /// \sa GetConvertClockTimebaseDividingCounter
   UeiDaqAPI void SetConvertClockTimebaseDividingCounter(Int32 counter);

   /// \brief Get the name of the signal to use as Scan clock
   ///
   /// Get the name of the signal to use as Scan clock
   /// The signal name is device dependent.
   /// \return the current scan clock source signal
   /// \sa SetScanClockSourceSignal
   UeiDaqAPI std::string GetScanClockSourceSignal();
   
   /// \brief Set the name of the signal to use as Scan clock
   ///
   /// Set the name of the signal to use as Scan clock.
   /// The signal name is device dependent.
   /// \param signal the new scan clock source signal
   /// \sa GetScanClockSourceSignal
   UeiDaqAPI void SetScanClockSourceSignal(std::string signal);

   /// \brief Get the name of the signal to route the Scan clock to
   ///
   /// Get the name of the signal driven by the Scan clock
   /// The signal name is device dependent.
   /// \return the current scan clock destination signal
   /// \sa SetScanClockDestinationSignal
   UeiDaqAPI std::string GetScanClockDestinationSignal();
   
   /// \brief Set the name of the signal to route the Scan clock to
   ///
   /// Set the name of the signal driven by the Scan clock.
   /// The signal name is device dependent.
   /// \param signal the new scan clock destination signal
   /// \sa GetScanClockDestinationSignal
   UeiDaqAPI void SetScanClockDestinationSignal(std::string signal);

   /// \brief Get the name of the signal to use as conversion clock
   ///
   /// Get the name of the signal to use as conversion clock
   /// The signal name is device dependent.
   /// \return the current conversion clock signal source
   /// \sa SetConvertClockSourceSignal
   UeiDaqAPI std::string GetConvertClockSourceSignal();
   
   /// \brief Set the name of the signal to use as conversion clock
   ///
   /// Set the name of the signal to use as conversion clock.
   /// The signal name is device dependent.
   /// \param signal the new conversion clock signal source
   /// \sa GetConvertClockSourceSignal
   UeiDaqAPI void SetConvertClockSourceSignal(std::string signal);

   /// \brief Get the name of the signal to route the conversion clock to
   ///
   /// Get the name of the signal driven by the conversion clock
   /// The signal name is device dependent.
   /// \return the current conversion clock signal destination
   /// \sa SetConvertClockDestinationSignal
   UeiDaqAPI std::string GetConvertClockDestinationSignal();
   
   /// \brief Set the name of the signal to route the conversion clock to
   ///
   /// Set the name of the signal driven by the conversion clock
   /// The signal name is device dependent.
   /// \param signal the new conversion clock signal destination
   /// \sa GetConvertClockDestinationSignal
   UeiDaqAPI void SetConvertClockDestinationSignal(std::string signal);

   /// \brief Get the read or write timeout
   ///
   /// Get the maximum amount of time (in ms) for a read or write operation to complete.
   /// \return the timeout
   /// \sa SetTimeout
   UeiDaqAPI Int32 GetTimeout();
   
   /// \brief Set the timeout
   ///
   /// Set the maximum amount of time (in ms) for a read or write operation to complete.
   /// \param timeout the timeout
   /// \sa GetTimeout
   UeiDaqAPI void SetTimeout(Int32 timeout);

   /// \brief Get Timestamp source
   ///
   /// Get the source of the signal used to increment timestamp counter
   /// \sa SetTimestampSourceSignal
   UeiDaqAPI std::string GetTimestampSourceSignal();

   /// \brief Set Timestamp source
   ///
   /// Set the source of the signal used to increment timestamp counter
   /// \sa GetTimestampSourceSignal
   UeiDaqAPI void SetTimestampSourceSignal(std::string signal);

   /// \brief Get the timestamp resolution
   ///
   /// Get the timestamp resolution in seconds.
   ///
   /// \return the timestamp resolution.
   /// \sa SetTimestampResolution  
   UeiDaqAPI f64 GetTimestampResolution();

   /// \brief Set the timestamp resolution
   ///
   /// Set the timestamp resolution in seconds.
   ///
   /// \param resolution the new resolution.
   /// \sa GetTimestampResolution  
   UeiDaqAPI void SetTimestampResolution(f64 resolution);

   /// \brief Get the timestamp reset all state
   ///
   /// When enabled, all I/O layers timestamp counters will be reset at the same time
   /// when this session is started
   ///
   /// \return true if timestamp reset is enabled, false otherwise.
   /// \sa EnableTimestampReset  
   UeiDaqAPI bool IsTimestampResetEnabled();

   /// \brief Enable/disable timestamp reset
   ///
   /// When enabled, all I/O layers timestamp counters will be reset at the same time
   /// when this session is started
   ///
   /// \param true to enable timestamp reset. false to disable.
   /// \sa IsTimestampResetEnabled  
   UeiDaqAPI void EnableTimestampReset(bool enable);

   /// \brief Get the watermark level
   ///
   /// Get the watermark level used to configure FIFO asynchronous event.
   ///
   /// \return the watermark level.
   UeiDaqAPI int GetAsyncWatermark();

   /// \brief Set the watermark level
   ///
   /// Set the watermark level used to configure FIFO asynchronous event. (-1) to disable
   ///
   /// \param watermark the new asynchronous watermark level.
   UeiDaqAPI void SetAsyncWatermark(int watermark);

   /// \brief Get the output watermark level
   ///
   /// Get the output watermark level used to configure FIFO asynchronous event.
   ///
   /// \return the output watermark level.
   UeiDaqAPI int GetAsyncOutputWatermark();

   /// \brief Set the output watermark level
   ///
   /// Set the output watermark level used to configure FIFO asynchronous event. (-1) to disable
   ///
   /// \param watermark the new asynchronous watermark level.
   UeiDaqAPI void SetAsyncOutputWatermark(int watermark);

   /// \brief Get the asynchronous period
   ///
   /// Get the asynchronous period used to fire events when FIFO level is below watermark.
   ///
   /// \return the period in microseconds.
   UeiDaqAPI int GetAsyncPeriod();

   /// \brief Set the asynchronous period
   ///
   /// Set the asynchronous period used to fire events when FIFO level is below watermark. (-1 to disable)
   ///
   /// \param periodUs the new period in microseconds.
   UeiDaqAPI void SetAsyncPeriod(int periodUs);

   /// \brief Get the asynchronous no activity timeout
   ///
   /// Get the asynchronous timeout to fire events when no activity has been detected for the specified amount of time.
   ///
   /// \return the period in microseconds.
   UeiDaqAPI int GetAsyncNoActivityTimeout();

   /// \brief Set the asynchronous no activity timeout
   ///
   ///  Set the asynchronous timeout to fire events when no activity has been detected for the specified amount of time. (-1 to disable)
   ///
   /// \param timeoutUs the new timeout in microseconds.
   UeiDaqAPI void SetAsyncNoActivityTimeout(int timeoutUs);

   /// \brief Get the max amount of messages returned along a timeout or periodic event
   ///
   /// Get the max amount of messages returned along a timeout of periodic event.
   ///
   /// \return the max amount of data .
   UeiDaqAPI int GetAsyncMaxDataSize();

   /// \brief Set the max amount of messages returned along a timeout or periodic event
   ///
   ///  Set the max amount of messages returned along a timeout of periodic event.
   ///
   /// \param maxDataSize the new timeout in microseconds.
   UeiDaqAPI void SetAsyncMaxDatasize(int maxDataSize);

   /// \cond DO_NOT_DOCUMENT
   UeiDaqAPI CUeiTimingImpl* GetImpl() { return m_pImpl.get(); }
   /// \endcond

private:
   // pimpl idiom member. For internal use only
   std::unique_ptr<CUeiTimingImpl> m_pImpl;
};

}

#endif // __UEITIMING_H__
