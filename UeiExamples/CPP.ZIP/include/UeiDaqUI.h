#ifndef __UEIDAQUI_H__
#define __UEIDAQUI_H__

#ifdef __cplusplus
   #include "UeiDialog.h"
#else
   #include "UeiDaqUIAnsiC.h"
#endif

#ifdef UEIDAQSTATIC
   #if defined(__PHARLAP_ETS__)
      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqUIETSSD.lib")
      #else
         #pragma comment(lib, "UeiDaqUIETSS.lib")
      #endif
   #elif (_MSC_VER < 1300)
      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqUIVC6SD.lib")
      #else
         #pragma comment(lib, "UeiDaqUIVC6S.lib")
      #endif
   #else
      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqUISD.lib")
      #else
         #pragma comment(lib, "UeiDaqUIS.lib")
      #endif
   #endif
#else
   #if defined(__PHARLAP_ETS__)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqUIETSD.lib")
      #else
         #pragma comment(lib, "UeiDaqUIETS.lib")
      #endif
   #elif (_MSC_VER < 1300)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqUIVC6D.lib")
      #else
         #pragma comment(lib, "UeiDaqUIVC6.lib")
      #endif
   #elif (_MSC_VER >= 1300) && (_MSC_VER < 1400)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqUID.lib")
      #else
         #pragma comment(lib, "UeiDaqUI.lib")
      #endif
   #elif (_MSC_VER >= 1400) && (_MSC_VER < 1500)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqUIVC8D.lib")
      #else
         #pragma comment(lib, "UeiDaqUIVC8.lib")
      #endif
   #elif (_MSC_VER >= 1500) && (_MSC_VER < 1600)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqUIVC9D.lib")
      #else
         #pragma comment(lib, "UeiDaqUIVC9.lib")
      #endif
   #elif (_MSC_VER >= 1600) && (_MSC_VER < 1700)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqUIVC10D.lib")
      #else
         #pragma comment(lib, "UeiDaqUIVC10.lib")
      #endif
   #elif (_MSC_VER >= 1700)  && (_MSC_VER < 1800)
      #if !defined(_MT) || !defined(_DLL)
         #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
         #pragma comment(lib, "UeiDaqUIVC11D.lib")
      #else
         #pragma comment(lib, "UeiDaqUIVC11.lib")
      #endif
    #elif (_MSC_VER >= 1800) && (_MSC_VER < 1900)
      #if !defined(_MT) || !defined(_DLL)
        #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
        #pragma comment(lib, "UeiDaqUIVC12D.lib")
      #else
        #pragma comment(lib, "UeiDaqUIVC12.lib")
      #endif
    #elif (_MSC_VER >= 1900) && (_MSC_VER < 1910)
      #if !defined(_MT) || !defined(_DLL)
        #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
      #endif

      #ifdef _DEBUG
        #pragma comment(lib, "UeiDaqUIVC14D.lib")
      #else
        #pragma comment(lib, "UeiDaqUIVC14.lib")
      #endif
    #elif (_MSC_VER >= 1910) && (_MSC_VER < 2000)
        #if !defined(_MT) || !defined(_DLL)
            #error UeiDaq requires C++ compile option set to Multithreaded DLL run-time library!
        #endif

        #ifdef _DEBUG
            #pragma comment(lib, "UeiDaqUIVC15D.lib")
        #else
            #pragma comment(lib, "UeiDaqUIVC15.lib")
        #endif
    #else 
      #error This version of Visual Studio is not supported
    #endif
#endif

#endif