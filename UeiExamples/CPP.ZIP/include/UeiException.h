#ifndef __UEIEXCEPTION_H__
#define __UEIEXCEPTION_H__

#ifndef UeiDaqAPI
   #define UeiDaqAPI __declspec(dllimport)
#endif

#include "UeiDaqError.h"

namespace UeiDaq
{

/// \brief Exception class
///
/// This class is used to report exceptions that
/// occur while setting-up or running a session
class CUeiException
{
public:
   /// \brief Constructor
   UeiDaqAPI CUeiException(tUeiError error);

   /// \brief Destructor
   UeiDaqAPI virtual ~CUeiException();

   /// \brief Get the error message
   ///
   /// Get the error message explaining the reason
   /// for the exception
   /// \return error message
   UeiDaqAPI const char* GetErrorMessage();


   /// \brief Get the error code
   ///
   /// Get the error code of the exception
   /// \return error code
   UeiDaqAPI tUeiError GetError();

   /// \brief Translate error code
   ///
   /// Translate the exception error code to a human readable string.
   /// \return error message string
   UeiDaqAPI static const char* TranslateError(tUeiError error);
   
private:
   const char* m_Message;
   tUeiError   m_Error;
};

}


#endif // __UEIEXCEPTION_H__
